import React, { useState, useEffect, useRef } from 'react';
import { User, PayrollPeriod, Designation, Contractor, Circle, DashboardStats } from './types';
import { apiRequest, getToken, clearToken } from './api';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { DashboardView } from './components/DashboardView';
import { EmployeeView } from './components/EmployeeView';
import { PayrollView } from './components/PayrollView';
import { DesignationView } from './components/DesignationView';
import { ContractorView } from './components/ContractorView';
import { ImportView } from './components/ImportView';
import { ExportView } from './components/ExportView';
import { ReconciliationView } from './components/ReconciliationView';
import { UserView } from './components/UserView';
import { AuditLogView } from './components/AuditLogView';
import { SettingsView } from './components/SettingsView';
import { FormulaRulesView } from './components/FormulaRulesView';
import { LoginModal } from './components/LoginModal';
import { TeamChatModal } from './components/TeamChatModal';
import { LogoutConfirmationModal } from './components/LogoutConfirmationModal';
import { Footer } from './components/Footer';
import { ErrorBoundary } from './components/ErrorBoundary';

export const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [activeColumnPreset, setActiveColumnPreset] = useState<string>('all');

  // Unsaved changes tracking & confirmation modal state
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isSavingBeforeLogout, setIsSavingBeforeLogout] = useState(false);
  const [logoutSaveError, setLogoutSaveError] = useState<string | null>(null);
  const saveUnsavedChangesRef = useRef<(() => Promise<boolean>) | null>(null);

  // Sidebar hover & drawer control
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const sidebarTimerRef = useRef<any>(null);

  const handleFunctionsMouseEnter = () => {
    if (sidebarTimerRef.current) {
      clearTimeout(sidebarTimerRef.current);
      sidebarTimerRef.current = null;
    }
    setIsSidebarOpen(true);
  };

  const handleFunctionsMouseLeave = () => {
    sidebarTimerRef.current = setTimeout(() => {
      setIsSidebarOpen(false);
    }, 300);
  };

  // Global plant telemetry data
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [selectedPeriodId, setSelectedPeriodId] = useState<number | null>(null);
  const [designations, setDesignations] = useState<Designation[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [circles, setCircles] = useState<Circle[]>([]);
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);
  const [loadingDashboard, setLoadingDashboard] = useState(false);

  // Check auth session
  const checkAuth = async () => {
    const token = getToken();
    if (!token) {
      setCheckingAuth(false);
      return;
    }
    try {
      const res = await apiRequest<{ user: User }>('/auth/me');
      setUser(res.user);
    } catch {
      clearToken();
      setUser(null);
    } finally {
      setCheckingAuth(false);
    }
  };

  useEffect(() => {
    checkAuth();
    window.addEventListener('auth:unauthorized', () => setUser(null));
  }, []);

  // Fetch initial master lists
  const fetchMasterData = async () => {
    if (!user) return;
    try {
      const [pRes, dRes, cRes, cirRes] = await Promise.all([
        apiRequest<{ periods: PayrollPeriod[] }>('/payroll/periods'),
        apiRequest<{ designations: Designation[] }>('/designations'),
        apiRequest<{ contractors: Contractor[] }>('/org/contractors'),
        apiRequest<{ circles: Circle[] }>('/org/circles')
      ]);

      setPeriods(pRes.periods);
      if (pRes.periods.length > 0 && !selectedPeriodId) {
        setSelectedPeriodId(pRes.periods[0].id);
      }
      setDesignations(dRes.designations);
      setContractors(cRes.contractors);
      setCircles(cirRes.circles);
    } catch (err: any) {
      console.error('Error fetching master data:', err);
    }
  };

  // Fetch dashboard stats whenever selected period changes
  const fetchDashboardStats = async () => {
    if (!user) return;
    try {
      setLoadingDashboard(true);
      const url = selectedPeriodId ? `/dashboard/stats?periodId=${selectedPeriodId}` : '/dashboard/stats';
      const res = await apiRequest<DashboardStats>(url);
      setDashboardStats(res);
    } catch (err: any) {
      console.error('Error fetching dashboard stats:', err);
    } finally {
      setLoadingDashboard(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchMasterData();
    }
  }, [user]);

  useEffect(() => {
    if (user && currentTab === 'dashboard') {
      fetchDashboardStats();
    }
  }, [user, selectedPeriodId, currentTab]);

  // Handle browser tab / window close warning if unsaved changes exist
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = 'You have unsaved changes in the payroll grid. Please save to database before leaving.';
        return e.returnValue;
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [hasUnsavedChanges]);

  // Logout request: check if unsaved changes exist and open confirmation modal
  const handleRequestLogout = () => {
    setLogoutSaveError(null);
    setIsLogoutModalOpen(true);
  };

  // Immediate save & logout
  const handleSaveAndLogout = async () => {
    setIsSavingBeforeLogout(true);
    setLogoutSaveError(null);
    try {
      if (saveUnsavedChangesRef.current) {
        const success = await saveUnsavedChangesRef.current();
        if (!success) {
          throw new Error('Database save failed. Please check network/server connection.');
        }
      }
      setHasUnsavedChanges(false);
      setIsLogoutModalOpen(false);
      clearToken();
      setUser(null);
    } catch (err: any) {
      console.error('Save before logout error:', err);
      setLogoutSaveError(err.message || 'Failed to save changes before logout. Database might be busy.');
    } finally {
      setIsSavingBeforeLogout(false);
    }
  };

  // Discard & logout
  const handleConfirmLogout = () => {
    setIsLogoutModalOpen(false);
    setHasUnsavedChanges(false);
    clearToken();
    setUser(null);
  };

  if (checkingAuth) {
    return (
      <div style={{ display: 'flex', height: '100vh', justifyContent: 'center', alignItems: 'center', background: '#0f172a', color: '#ffffff' }}>
        <div>Connecting to GGSSTP Thermal Plant Portal...</div>
      </div>
    );
  }

  if (!user) {
    return <LoginModal onSuccess={(u) => setUser(u)} />;
  }

  const activePeriod = periods.find(p => p.id === selectedPeriodId) || periods[0] || null;

  return (
    <div className="app-container">
      {/* Slide-out Sidebar on Hover / Click */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          setIsSidebarOpen(false);
        }}
        userRole={user.role}
        isOpen={isSidebarOpen}
        onMouseEnter={handleFunctionsMouseEnter}
        onMouseLeave={handleFunctionsMouseLeave}
        onClose={() => setIsSidebarOpen(false)}
      />

      <div className="main-content">
        <TopBar
          user={user}
          onLogout={handleRequestLogout}
          hasUnsavedChanges={hasUnsavedChanges}
          periods={periods}
          selectedPeriodId={selectedPeriodId}
          onSelectPeriod={(id) => setSelectedPeriodId(id)}
          onPeriodCreated={async (id) => {
            setSelectedPeriodId(id);
            await fetchMasterData();
            await fetchDashboardStats();
          }}
          currentTab={currentTab}
          setCurrentTab={setCurrentTab}
          onOpenChat={() => setIsChatOpen(true)}
          activeColumnPreset={activeColumnPreset}
          onSelectColumnPreset={setActiveColumnPreset}
        />

        <div className="view-scroll-container">
          <main className="view-body">
            <ErrorBoundary fallbackTitle="Module View Unavailable">
              {currentTab === 'dashboard' && (
                <DashboardView
                  stats={dashboardStats}
                  loading={loadingDashboard}
                  onNavigateTab={setCurrentTab}
                />
              )}

              {currentTab === 'employees' && (
                <EmployeeView
                  designations={designations}
                  contractors={contractors}
                  circles={circles}
                  userRole={user.role}
                />
              )}

              {currentTab === 'payroll' && (
                <PayrollView
                  period={activePeriod}
                  periods={periods}
                  onSelectPeriod={(id) => setSelectedPeriodId(id)}
                  onRefreshPeriod={() => {
                    fetchMasterData();
                    fetchDashboardStats();
                  }}
                  onPeriodCreated={async (id) => {
                    setSelectedPeriodId(id);
                    await fetchMasterData();
                    await fetchDashboardStats();
                  }}
                  designations={designations}
                  contractors={contractors}
                  userRole={user.role}
                  columnPreset={activeColumnPreset}
                  onSelectColumnPreset={setActiveColumnPreset}
                  onUnsavedStateChange={(unsaved, saveFn) => {
                    setHasUnsavedChanges(unsaved);
                    saveUnsavedChangesRef.current = saveFn || null;
                  }}
                />
              )}

              {currentTab === 'formula-rules' && (
                <FormulaRulesView
                  onRefreshAll={fetchMasterData}
                />
              )}

              {currentTab === 'designations' && (
                <DesignationView
                  designations={designations}
                  onRefresh={fetchMasterData}
                  userRole={user.role}
                />
              )}

              {currentTab === 'contractors' && (
                <ContractorView
                  contractors={contractors}
                  circles={circles}
                  onRefresh={fetchMasterData}
                />
              )}

              {currentTab === 'import' && (
                <ImportView
                  onRefreshAll={() => {
                    fetchMasterData();
                    fetchDashboardStats();
                  }}
                />
              )}

              {currentTab === 'export' && (
                <ExportView
                  period={activePeriod}
                  userRole={user.role}
                />
              )}

              {currentTab === 'reconciliation' && (
                <ReconciliationView />
              )}

              {currentTab === 'users' && (
                <UserView />
              )}

              {currentTab === 'audit' && (
                <AuditLogView />
              )}

              {currentTab === 'settings' && (
                <SettingsView />
              )}
            </ErrorBoundary>
          </main>

          <Footer
            currentTab={currentTab}
            setCurrentTab={setCurrentTab}
            userRole={user.role}
            onOpenChat={() => setIsChatOpen(true)}
          />
        </div>
      </div>

      {/* Real-time Team Chat & File Sharing Modal */}
      {user && (
        <TeamChatModal
          isOpen={isChatOpen}
          onClose={() => setIsChatOpen(false)}
          currentUser={user}
        />
      )}

      {/* Logout Confirmation Modal with Immediate Database Save Option */}
      <LogoutConfirmationModal
        isOpen={isLogoutModalOpen}
        hasUnsavedChanges={hasUnsavedChanges}
        isSaving={isSavingBeforeLogout}
        saveError={logoutSaveError}
        onConfirmLogout={handleConfirmLogout}
        onSaveAndLogout={handleSaveAndLogout}
        onCancel={() => setIsLogoutModalOpen(false)}
      />
    </div>
  );
};

export default App;
