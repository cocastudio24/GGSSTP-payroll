export interface User {
  id: number;
  uuid?: string;
  username: string;
  fullName: string;
  role: 'SUPER_ADMIN' | 'PAYROLL_ADMIN' | 'Super Administrator' | 'Payroll Administrator' | 'Payroll Operator' | 'Approver / Auditor' | 'Read-Only User' | string;
}

export interface PayslipData {
  entryId: number;
  periodId: number;
  monthName: string;
  year: number;
  totalDays: number;
  periodStatus: string;
  ownerUserId: number;
  creatorUsername?: string;
  creatorFullName?: string;

  // Employee Information
  employeeId: number;
  empCode: string;
  srNo?: string;
  empName: string;
  fatherName?: string;
  uan?: string;
  designationName: string;
  designationAlias: string;
  contractorName: string;
  circleName: string;
  departmentName?: string;
  bankAccount?: string;
  ifsc?: string;
  esiNumber?: string;
  dob?: string;
  dateOfJoining?: string;

  // Attendance
  presentDays: number;

  // Earnings
  grossSalaryRate: number;
  proportionedSalary: number;
  specialAllowance: number;
  totalBasic: number;
  thermalAllowance: number;
  perfAllowanceMonthly: number;
  perfAllowanceDays: number;
  bonus: number;
  bonusPercentage?: number;
  totalEarningsBeforeBonus: number;
  grossEarnings: number;
  employeeCashEarnings?: number;

  // EMC Performance Allowance Circle Comparison
  perfLastDrawn?: number;
  perfAsPerCircle?: number;
  perfDifference?: number;

  // Deductions
  employeeEpf12: number;
  employeeEsi075: number;
  employeeLwf: number;
  totalEmployeeDeductions: number;
  employeeOnlyDeductions?: number;

  // Net Payable
  netPayable: number;
  netPayableWords: string;

  // Employer Contributions
  employerEpf12: number;
  employerEpf1: number;
  employerEsi325: number;
  employerLwf: number;
  totalEmployerContributions: number;

  // Comprehensive Totals
  grossTotal?: number;
  combinedDeductions?: number;

  // Organization Metadata
  companyName: string;
  plantName: string;
  location: string;
  generatedAt: string;
}



export interface Designation {
  id: number;
  name: string;
  alias: string;
  is_active: boolean;
  rate_id?: number;
  gross_salary_rate?: number;
  special_allowance?: number;
  thermal_allowance?: number;
  perf_allowance_default?: number;
  effective_from?: string;
  employee_count?: number;
}

export interface Contractor {
  id: number;
  name: string;
  code?: string;
  contact_person?: string;
  phone?: string;
  employee_count?: number;
}

export interface Circle {
  id: number;
  name: string;
  code?: string;
  employee_count?: number;
}

export interface Department {
  id: number;
  circle_id?: number;
  circle_name?: string;
  name: string;
  code?: string;
  employee_count?: number;
}

export interface PayrollRuleSet {
  id: number;
  name: string;
  is_active: boolean;
  epf_wage_cap: number;
  epf_employer_rate: number;
  epf_max_cap: number;
  epf_admin_rate: number;
  epf_admin_max_cap: number;
  epf_employee_rate: number;
  esi_threshold: number;
  esi_employer_rate: number;
  esi_employee_rate: number;
  employer_lwf: number;
  employee_lwf: number;
  thermal_allowance_base: number;
  created_at?: string;
}

export interface Employee {
  id: number;
  owner_user_id?: number;
  created_by_user_id?: number;
  emp_code: string;
  sr_no?: string;
  name: string;
  father_name?: string;
  uan?: string;
  designation_id?: number;
  designation_name?: string;
  designation_alias?: string;
  dob?: string;
  age_above_58?: string;
  date_of_joining?: string;
  more_than_3_yrs?: string;
  more_than_5_yrs?: string;
  qualification?: string;
  experience_years?: string;
  qualified_status?: string;
  contractor_id?: number;
  contractor_name?: string;
  circle_id?: number;
  circle_name?: string;
  department_id?: number;
  department_name?: string;
  hazard_duty?: string;
  above_60?: string;
  check_status?: string;
  cell?: string;
  bank_name?: string;
  bank_account?: string;
  ifsc?: string;
  account_holder_name?: string;
  esi_number?: string;
  aadhar_number?: string;
  pan_number?: string;
  mobile_number?: string;
  date_of_exit?: string;
  custom_data?: Record<string, any>;
  epf_applicable?: boolean;
  esi_applicable?: boolean;
  lwf_applicable?: boolean;
  epf_statutory_doj?: string;
  default_gross_rate?: number;
  default_special_allowance?: number;
  default_thermal_allowance?: number;
  default_perf_allowance?: number;
  default_bonus_percentage?: number | null;
  custom_employee_epf?: number | null;
  custom_employer_epf?: number | null;
  custom_employer_epf1?: number | null;
  custom_employee_esi?: number | null;
  custom_employer_esi?: number | null;
  custom_employee_lwf?: number | null;
  custom_employer_lwf?: number | null;
  other_allowances?: number;
  other_deductions?: number;
  is_active: boolean;
  archived_at?: string;
  archived_by_user_id?: number;
  archived_reason?: string;
  created_at: string;
  updated_at?: string;
  calculated_salary?: {
    grossSalaryRate: number;
    proportionedSalary: number;
    specialAllowance: number;
    totalBasic: number;
    thermalAllowance: number;
    perfAllowanceMonthly: number;
    perfAllowanceDaysWise: number;
    totalEarningsBeforeBonus: number;
    bonus: number;
    bonusPercentage: number;
    employerEpf12: number;
    employerEpf1: number;
    employerEsi325: number;
    employerLwf: number;
    grossTotal: number;
    employeeEpf12: number;
    employeeEsi075: number;
    employeeLwf: number;
    totalEmployeeDeductions: number;
    totalEmployerContributions: number;
    combinedDeductions: number;
    netPayable: number;
    formulas?: Record<string, string>;
  };
}

export interface PayrollPeriod {
  id: number;
  year: number;
  month: number;
  month_name: string;
  total_days: number;
  status: 'Draft' | 'Calculated' | 'Under Review' | 'Approved' | 'Finalized';
  notes?: string;
  employee_count?: number;
  total_net_payable?: number;
  total_employer_cost?: number;
  finalized_at?: string;
}

export interface PayrollEntry {
  id: number;
  payroll_period_id: number;
  employee_id: number;
  emp_code: string;
  emp_name: string;
  father_name?: string;
  uan?: string;
  designation_alias?: string;
  contractor_name?: string;
  circle_name?: string;
  department_name?: string;
  bank_account?: string;
  ifsc?: string;
  esi_number?: string;
  present_days: number;
  period_total_days?: number;
  gross_salary_rate: number;
  proportioned_salary: number;
  special_allowance: number;
  total_basic: number;
  thermal_allowance: number;
  perf_allowance_monthly: number;
  perf_allowance_days: number;
  total_earnings_before_bonus: number;
  bonus: number;
  employer_epf_12: number;
  employer_epf_1: number;
  employer_esi_325: number;
  employer_lwf: number;
  gross_total: number;
  employee_epf_12: number;
  employee_esi_075: number;
  employee_lwf: number;
  total_employee_deductions: number;
  total_employer_contributions: number;
  combined_deductions: number;
  net_payable: number;
  bonus_percentage?: number;
  perf_last_drawn?: number;
  perf_as_per_circle?: number;
  perf_difference?: number;
  designation_id?: number;
  is_overridden: boolean;
  calculation_mode: string;
}

export interface DashboardEmployeeItem {
  id: number;
  name: string;
  emp_code: string;
  uan?: string;
  bank_account?: string;
  ifsc?: string;
  esi_number?: string;
  designation_alias: string;
  designation_name: string;
  contractor_id?: number;
  contractor_name: string;
  circle_id?: number;
  circle_name: string;
  present_days: number;
  gross_salary_rate: number;
  total_basic: number;
  thermal_allowance: number;
  perf_allowance_days: number;
  bonus: number;
  total_earnings_before_bonus: number;
  employee_epf_12: number;
  employee_esi_075: number;
  employee_lwf: number;
  total_employee_deductions: number;
  net_payable: number;
}

export interface CircleWorkforceStats {
  circleName: string;
  totalCount: number;
  totalNetPayable: number;
  totalBasic: number;
  totalGross: number;
  totalEmployeeDeductions?: number;
  totalEmployeeEpf?: number;
  totalEmployeeEsi?: number;
  totalEmployeeLwf?: number;
  employees: DashboardEmployeeItem[];
}

export interface DashboardStats {
  employeeOverview: {
    total: number;
    active: number;
    inactive: number;
    missing_bank: number;
    missing_uan: number;
    missing_esi: number;
  };
  employeesByDesignation: Array<{
    designation: string;
    alias?: string;
    count: number;
    totalNetPayable?: number;
    totalEmployeeDeductions?: number;
    totalEmployeeEpf?: number;
    totalEmployeeEsi?: number;
    totalEmployeeLwf?: number;
    employees?: DashboardEmployeeItem[];
  }>;
  employeesByContractor: Array<{
    id?: number;
    contractor: string;
    count: number;
    totalNetPayable?: number;
    totalEmployeeDeductions?: number;
    totalEmployeeEpf?: number;
    totalEmployeeEsi?: number;
    totalEmployeeLwf?: number;
    employees?: DashboardEmployeeItem[];
  }>;
  employeesByCircle: Array<{ circle: string; count: number }>;
  circleWorkforce?: {
    emc: CircleWorkforceStats;
    mm1: CircleWorkforceStats;
    allCircles?: CircleWorkforceStats[];
  };
  payrollStats: {
    periodId: number | null;
    periodName: string;
    status: string;
    totalEmployeesPaid: number;
    totalGrossEarnings: number;
    totalEmployerEpf12: number;
    totalEmployerEpf1: number;
    totalEmployerEsi325: number;
    totalEmployerLwf: number;
    totalEmployeeEpf: number;
    totalEmployeeEsi: number;
    totalEmployeeLwf: number;
    totalEmployeeDeductions: number;
    totalCombinedDeductions: number;
    totalNetPayable: number;
    totalEmployerCost: number;
  };

  recentActivity: Array<{
    user_name: string;
    action: string;
    entity_type: string;
    details: string;
    created_at: string;
  }>;
}

export interface ExtractedFormulaInfo {
  col: string;
  header: string;
  formula: string;
  sampleVal: any;
  category: 'earnings' | 'employer_contribution' | 'employee_deduction' | 'net_payable' | 'other';
  description?: string;
}

export interface DetectedFormulaParameters {
  thermalBase?: number;
  epfWageCap?: number;
  epfEmployerRate?: number;
  epfMaxCap?: number;
  epfAdminRate?: number;
  epfAdminMaxCap?: number;
  esiThreshold?: number;
  esiEmployerRate?: number;
  esiEmployeeRate?: number;
  employerLwf?: number;
  employeeLwf?: number;
}

export interface ReconciliationSheetData {
  sheetName?: string;
  totalChecked: number;
  totalMatched: number;
  mismatches: number;
  matchRate: string;
  extractedFormulas?: ExtractedFormulaInfo[];
  detectedParameters?: DetectedFormulaParameters;
  netPayableFormula?: string;
  sampleComparisons: Array<{
    row: number;
    empCode: string;
    empName: string;
    designation: string;
    attendance: string;
    softwareNetPayable: number;
    excelNetPayable: number;
    diff: number;
    status: string;
    breakdown: any;
  }>;
}

export interface ReconciliationReport {
  timestamp: string;
  referenceFile: string;
  isUploaded?: boolean;
  overall: {
    totalEmployeesAudited: number;
    totalEmployeesMatched: number;
    overallMatchRate: string;
    status: string;
  };
  sheets: {
    [key: string]: ReconciliationSheetData;
  };
  extractedFormulasSummary?: ExtractedFormulaInfo[];
  detectedParameters?: DetectedFormulaParameters;
}

export interface ChatMessage {
  id: number;
  user_id?: number | null;
  user_name: string;
  user_role: string;
  message?: string | null;
  file_url?: string | null;
  file_name?: string | null;
  file_size?: number | null;
  file_type?: string | null;
  created_at: string;
}

export interface DiscoveredColumn {
  colIndex: number;
  colLetter: string;
  rawHeader: string;
  sampleValue: any;
  detectedType: 'string' | 'number' | 'date' | 'boolean';
  proposedField: string;
  confidence: number;
  status: 'matched' | 'review' | 'excluded' | 'custom';
  reason: string;
}

export interface TargetFieldOption {
  key: string;
  label: string;
  category: 'identification' | 'statutory' | 'bank' | 'hr' | 'attendance' | 'salary' | 'deductions' | 'auxiliary' | 'system';
  dataType: 'string' | 'number' | 'date' | 'boolean';
  description: string;
}

export interface ExcelInspectResponse {
  fileName: string;
  sheetNames: string[];
  selectedSheet: string;
  sheetsSummary?: Array<{
    sheetName: string;
    totalRows: number;
    totalColumns: number;
    headerRowIndex: number;
    isValid: boolean;
  }>;
  headerRowIndex: number;
  totalRows: number;
  totalColumns: number;
  columns: DiscoveredColumn[];
  targetFields: TargetFieldOption[];
  previewRows: any[];
  summary: {
    totalColumns: number;
    mappedCount: number;
    excludedCount: number;
    unmappedCount: number;
  };
}
