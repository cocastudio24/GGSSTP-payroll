import React, { useEffect, useState } from 'react';
import { apiRequest, downloadFile } from '../api';
import { PayslipData } from '../types';
import {
  X, Printer, FileDown, FileSpreadsheet, Building2,
  ShieldCheck, AlertCircle, Loader2
} from 'lucide-react';

interface PayslipModalProps {
  entryId: number;
  onClose: () => void;
  autoPrint?: boolean;
}

export const PayslipModal: React.FC<PayslipModalProps> = ({ entryId, onClose, autoPrint = false }) => {
  const [payslip, setPayslip] = useState<PayslipData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloadingPdf, setDownloadingPdf] = useState(false);
  const [downloadingXlsx, setDownloadingXlsx] = useState(false);

  useEffect(() => {
    let mounted = true;
    const fetchPayslip = async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await apiRequest<{ payslip: PayslipData }>(`/payroll/entries/${entryId}/payslip`);
        if (mounted) {
          setPayslip(res.payslip);
          if (autoPrint) {
            setTimeout(() => {
              window.print();
            }, 600);
          }
        }
      } catch (err: any) {
        if (mounted) {
          setError(err.message || 'Failed to fetch payslip details.');
        }
      } finally {
        if (mounted) setLoading(false);
      }
    };

    fetchPayslip();
    return () => {
      mounted = false;
    };
  }, [entryId, autoPrint]);

  const handleDownloadPdf = async () => {
    if (!payslip) return;
    try {
      setDownloadingPdf(true);
      const filename = `Payslip_${payslip.empCode}_${payslip.monthName}_${payslip.year}.pdf`;
      await downloadFile(`/export/payslip-pdf/${payslip.entryId}`, filename);
    } catch (err: any) {
      alert(`PDF download failed: ${err.message}`);
    } finally {
      setDownloadingPdf(false);
    }
  };

  const handleDownloadXlsx = async () => {
    if (!payslip) return;
    try {
      setDownloadingXlsx(true);
      const filename = `Payslip_${payslip.empCode}_${payslip.monthName}_${payslip.year}.xlsx`;
      await downloadFile(`/export/payslip-xlsx/${payslip.entryId}`, filename);
    } catch (err: any) {
      alert(`Excel download failed: ${err.message}`);
    } finally {
      setDownloadingXlsx(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="modal-overlay payslip-modal-overlay" style={{ overflowY: 'auto', padding: '20px 10px', zIndex: 1100 }}>
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          .payslip-printable-card, .payslip-printable-card * {
            visibility: visible !important;
          }
          .payslip-printable-card {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 20px !important;
            border: none !important;
            box-shadow: none !important;
            background: #ffffff !important;
          }
          .payslip-modal-actions, .modal-close-btn, .payslip-modal-overlay {
            display: none !important;
            background: transparent !important;
          }
        }
      `}</style>

      <div
        className="modal-content payslip-modal-container"
        style={{
          maxWidth: '820px',
          width: '100%',
          background: '#ffffff',
          borderRadius: '12px',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
          overflow: 'hidden',
          margin: 'auto'
        }}
      >
        {/* Modal Top Bar (Hidden in Print) */}
        <div
          className="payslip-modal-actions"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '12px 20px',
            background: '#0f172a',
            color: '#ffffff',
            borderBottom: '1px solid #334155'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Building2 size={18} color="#38bdf8" />
            <span style={{ fontWeight: 700, fontSize: '14px', letterSpacing: '0.3px' }}>
              Employee Salary Slip {payslip ? `• ${payslip.empCode} (${payslip.empName})` : ''}
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <button
              onClick={handlePrint}
              disabled={loading || !payslip}
              className="btn btn-secondary btn-sm"
              style={{ background: '#334155', color: '#f8fafc', borderColor: '#475569', display: 'flex', alignItems: 'center', gap: '6px' }}
              title="Print Payslip"
            >
              <Printer size={14} />
              <span>Print</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              disabled={loading || downloadingPdf || !payslip}
              className="btn btn-primary btn-sm"
              style={{ background: '#1e40af', display: 'flex', alignItems: 'center', gap: '6px' }}
              title="Download Payslip as PDF"
            >
              {downloadingPdf ? <Loader2 size={14} className="animate-spin" /> : <FileDown size={14} />}
              <span>PDF</span>
            </button>

            <button
              onClick={handleDownloadXlsx}
              disabled={loading || downloadingXlsx || !payslip}
              className="btn btn-success btn-sm"
              style={{ background: '#15803d', display: 'flex', alignItems: 'center', gap: '6px' }}
              title="Download Payslip as Excel"
            >
              {downloadingXlsx ? <Loader2 size={14} className="animate-spin" /> : <FileSpreadsheet size={14} />}
              <span>Excel</span>
            </button>

            <button
              onClick={onClose}
              className="btn btn-secondary btn-sm modal-close-btn"
              style={{ background: '#1e293b', borderColor: '#334155', color: '#94a3b8' }}
              title="Close modal"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Modal Content Body */}
        <div style={{ padding: '24px', background: '#f8fafc' }}>
          {loading ? (
            <div style={{ padding: '60px', textAlign: 'center', color: '#64748b' }}>
              <Loader2 size={32} className="animate-spin" style={{ margin: '0 auto 12px auto' }} />
              <div>Generating official salary slip...</div>
            </div>
          ) : error || !payslip ? (
            <div style={{ padding: '40px 20px', textAlign: 'center', color: '#dc2626' }}>
              <AlertCircle size={32} style={{ margin: '0 auto 10px auto' }} />
              <div style={{ fontWeight: 600 }}>{error || 'Unable to load payslip'}</div>
            </div>
          ) : (
            /* Printable Salary Card */
            <div
              className="payslip-printable-card"
              id="ggsstp-printable-payslip"
              style={{
                background: '#ffffff',
                border: '1px solid #cbd5e1',
                borderRadius: '8px',
                padding: '24px',
                color: '#0f172a'
              }}
            >
              {/* Header */}
              <div style={{ borderBottom: '2px solid #1e3a8a', paddingBottom: '14px', marginBottom: '16px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px' }}>
                  <img
                    src="/pspcl_logo.png"
                    alt="PSPCL Logo"
                    style={{ width: '56px', height: '56px', objectFit: 'contain' }}
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  <div style={{ flex: 1, textAlign: 'center' }}>
                    <div style={{ fontSize: '16px', fontWeight: 800, color: '#1e3a8a', letterSpacing: '0.4px', textTransform: 'uppercase' }}>
                      {payslip.companyName}
                    </div>
                    <div style={{ fontSize: '12px', fontWeight: 600, color: '#334155', marginTop: '2px' }}>
                      {payslip.plantName}
                    </div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>
                      {payslip.location}
                    </div>
                    <div
                      style={{
                        display: 'inline-block',
                        marginTop: '6px',
                        background: '#eff6ff',
                        color: '#1e3a8a',
                        fontWeight: 700,
                        fontSize: '11.5px',
                        padding: '3px 12px',
                        borderRadius: '4px',
                        border: '1px solid #bfdbfe'
                      }}
                    >
                      MONTHLY SALARY SLIP — {payslip.monthName.toUpperCase()} {payslip.year}
                    </div>
                  </div>
                  <div style={{ width: '56px', textAlign: 'right' }}>
                    <ShieldCheck size={28} color="#059669" />
                  </div>
                </div>
              </div>

              {/* Employee Information Grid */}
              <div
                style={{
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '6px',
                  padding: '12px 14px',
                  marginBottom: '16px',
                  fontSize: '11.5px'
                }}
              >
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px 14px' }}>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Employee Code: </span>
                    <span style={{ fontWeight: 800, color: '#1e3a8a' }}>{payslip.empCode}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Employee Name: </span>
                    <span style={{ fontWeight: 700 }}>{payslip.empName}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Designation: </span>
                    <span style={{ fontWeight: 700 }}>{payslip.designationAlias} ({payslip.designationName})</span>
                  </div>

                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Father's Name: </span>
                    <span>{payslip.fatherName || 'N/A'}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Contractor: </span>
                    <span style={{ fontWeight: 600 }}>{payslip.contractorName}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Circle / Dept: </span>
                    <span>{payslip.circleName}{payslip.departmentName ? ` - ${payslip.departmentName}` : ''}</span>
                  </div>

                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>UAN / PF No.: </span>
                    <span style={{ fontFamily: 'monospace', fontWeight: 600 }}>{payslip.uan || 'N/A'}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>ESI Number: </span>
                    <span style={{ fontFamily: 'monospace' }}>{payslip.esiNumber || 'N/A'}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Attendance: </span>
                    <span style={{ fontWeight: 800, color: '#047857' }}>{payslip.presentDays} / {payslip.totalDays} Days</span>
                  </div>

                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Bank A/c: </span>
                    <span style={{ fontFamily: 'monospace' }}>{payslip.bankAccount || 'N/A'}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>IFSC Code: </span>
                    <span style={{ fontFamily: 'monospace' }}>{payslip.ifsc || 'N/A'}</span>
                  </div>
                  <div>
                    <span style={{ color: '#64748b', fontWeight: 600 }}>Payment Mode: </span>
                    <span>Direct Bank Transfer</span>
                  </div>
                </div>
              </div>

              {/* Earnings & Deductions Tables */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px', marginBottom: '16px' }}>
                {/* Earnings Table */}
                <div style={{ border: '1px solid #cbd5e1', borderRadius: '6px', overflow: 'hidden' }}>
                  <div style={{ background: '#1e3a8a', color: '#ffffff', padding: '6px 12px', fontWeight: 700, fontSize: '11.5px', display: 'flex', justifyContent: 'space-between' }}>
                    <span>EARNINGS</span>
                    <span>AMOUNT (₹)</span>
                  </div>
                  <table style={{ width: '100%', fontSize: '11px', borderCollapse: 'collapse' }}>
                    <tbody>
                      <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Gross Salary Rate</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600 }}>₹{payslip.grossSalaryRate.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#f8fafc' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Basic Proportioned Salary</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600 }}>₹{payslip.proportionedSalary.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Special Allowance</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600 }}>₹{payslip.specialAllowance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#f8fafc' }}>
                        <td style={{ padding: '5px 12px', color: '#0f172a', fontWeight: 600 }}>Total Basic</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 700 }}>₹{payslip.totalBasic.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Thermal Allowance</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600 }}>₹{payslip.thermalAllowance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#f8fafc' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Performance Allowance</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600 }}>₹{payslip.perfAllowanceDays.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Bonus / Arrears</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600 }}>₹{payslip.bonus.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr style={{ background: '#e0e7ff', borderTop: '2px solid #1e3a8a', fontWeight: 800 }}>
                        <td style={{ padding: '7px 12px', color: '#1e3a8a' }}>TOTAL GROSS EARNINGS</td>
                        <td style={{ padding: '7px 12px', textAlign: 'right', color: '#1e3a8a', fontSize: '12px' }}>₹{payslip.grossEarnings.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* Deductions Table */}
                <div style={{ border: '1px solid #cbd5e1', borderRadius: '6px', overflow: 'hidden' }}>
                  <div style={{ background: '#991b1b', color: '#ffffff', padding: '6px 12px', fontWeight: 700, fontSize: '11.5px', display: 'flex', justifyContent: 'space-between' }}>
                    <span>DEDUCTIONS</span>
                    <span>AMOUNT (₹)</span>
                  </div>
                  <table style={{ width: '100%', fontSize: '11px', borderCollapse: 'collapse' }}>
                    <tbody>
                      <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Employee EPF (12%)</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600, color: '#991b1b' }}>₹{payslip.employeeEpf12.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#f8fafc' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Employee ESI (0.75%)</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600, color: '#991b1b' }}>₹{payslip.employeeEsi075.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                        <td style={{ padding: '5px 12px', color: '#475569' }}>Labour Welfare Fund (LWF)</td>
                        <td style={{ padding: '5px 12px', textAlign: 'right', fontWeight: 600, color: '#991b1b' }}>₹{payslip.employeeLwf.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                      <tr style={{ height: '78px' }}>
                        <td colSpan={2} style={{ padding: '10px 12px', color: '#94a3b8', fontSize: '10px', verticalAlign: 'top', fontStyle: 'italic' }}>
                          Statutory deductions as per Employees' Provident Funds and Miscellaneous Provisions Act and ESI Act.
                        </td>
                      </tr>
                    </tbody>
                    <tfoot>
                      <tr style={{ background: '#fee2e2', borderTop: '2px solid #991b1b', fontWeight: 800 }}>
                        <td style={{ padding: '7px 12px', color: '#991b1b' }}>TOTAL DEDUCTIONS</td>
                        <td style={{ padding: '7px 12px', textAlign: 'right', color: '#991b1b', fontSize: '12px' }}>₹{payslip.totalEmployeeDeductions.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              {/* Net Salary Payable Highlight Banner */}
              <div
                style={{
                  background: '#ecfdf5',
                  border: '1.5px solid #10b981',
                  borderRadius: '6px',
                  padding: '12px 18px',
                  marginBottom: '14px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <div>
                  <div style={{ fontSize: '12px', fontWeight: 800, color: '#065f46', letterSpacing: '0.3px' }}>
                    NET SALARY PAYABLE
                  </div>
                  <div style={{ fontSize: '11px', color: '#047857', marginTop: '2px', fontStyle: 'italic', fontWeight: 600 }}>
                    Amount in Words: {payslip.netPayableWords}
                  </div>
                </div>
                <div style={{ fontSize: '20px', fontWeight: 900, color: '#047857' }}>
                  ₹{payslip.netPayable.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </div>
              </div>

              {/* Employer Contributions Box (Statutory Disclosure) */}
              <div
                style={{
                  background: '#f8fafc',
                  border: '1px solid #cbd5e1',
                  borderRadius: '6px',
                  padding: '10px 14px',
                  marginBottom: '16px',
                  fontSize: '11px'
                }}
              >
                <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '6px', fontSize: '10.5px' }}>
                  STATUTORY EMPLOYER CONTRIBUTIONS (Separate Establishment Cost - Not Deducted from Salary):
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '6px', color: '#475569' }}>
                  <div>EPF (12%): <strong style={{ color: '#0f172a' }}>₹{payslip.employerEpf12.toFixed(2)}</strong></div>
                  <div>EPF Admin (1%): <strong style={{ color: '#0f172a' }}>₹{payslip.employerEpf1.toFixed(2)}</strong></div>
                  <div>ESI (3.25%): <strong style={{ color: '#0f172a' }}>₹{payslip.employerEsi325.toFixed(2)}</strong></div>
                  <div>LWF: <strong style={{ color: '#0f172a' }}>₹{payslip.employerLwf.toFixed(2)}</strong></div>
                </div>
                <div style={{ marginTop: '6px', fontWeight: 700, color: '#1e293b' }}>
                  Total Statutory Employer Contribution: ₹{payslip.totalEmployerContributions.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </div>
              </div>

              {/* Bottom Signatures & Disclaimer */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', paddingTop: '10px', borderTop: '1px solid #e2e8f0', fontSize: '10px', color: '#64748b' }}>
                <div>
                  <div>This is a computer-generated salary slip and requires no physical signature.</div>
                  <div style={{ marginTop: '2px' }}>Generated On: {payslip.generatedAt} | Authorized System Account: {payslip.creatorUsername || 'admin'}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: 700, color: '#334155' }}>For Guru Gobind Singh Super Thermal Plant (PSPCL)</div>
                  <div style={{ marginTop: '16px', color: '#64748b' }}>Authorised Signatory / Accounts Cell</div>
                </div>
              </div>

              {/* Formal Copyright Footer */}
              <div style={{ marginTop: '14px', paddingTop: '8px', borderTop: '1px solid #cbd5e1', textAlign: 'center', fontSize: '9px', color: '#64748b' }}>
                © 2026 Punjab State Power Corporation Limited PSEB Head Office, The MALL, Patiala | GGSSTP Rupnagar Contractual Labour Cell
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
