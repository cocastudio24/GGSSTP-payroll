import React, { useState, useEffect } from 'react';
import { Designation, Contractor } from '../types';
import { apiRequest } from '../api';
import { Zap, X, AlertCircle, RefreshCw, CheckCircle2, Sliders, DollarSign, Calendar } from 'lucide-react';

interface BulkAllowancesRatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  periodId: number;
  monthName: string;
  year: number;
  totalDays: number;
  selectedCount: number;
  selectedEntryIds: number[];
  filteredCount: number;
  totalCount: number;
  designations: Designation[];
  contractors: Contractor[];
  activeDesignationFilter?: string;
  activeContractorFilter?: string;
  onSuccess: (message: string) => void;
}

export const BulkAllowancesRatesModal: React.FC<BulkAllowancesRatesModalProps> = ({
  isOpen,
  onClose,
  periodId,
  monthName,
  year,
  totalDays,
  selectedCount,
  selectedEntryIds,
  filteredCount,
  totalCount,
  designations,
  contractors,
  activeDesignationFilter,
  activeContractorFilter,
  onSuccess
}) => {
  // Target Scope
  const [targetScope, setTargetScope] = useState<'selected' | 'filtered' | 'all' | 'designation' | 'contractor'>(
    selectedCount > 0 ? 'selected' : 'filtered'
  );
  const [targetDesignationId, setTargetDesignationId] = useState<string>(activeDesignationFilter || '');
  const [targetContractorId, setTargetContractorId] = useState<string>(activeContractorFilter || '');

  // Component Toggles
  const [enableGrossRate, setEnableGrossRate] = useState(false);
  const [grossRate, setGrossRate] = useState<string>('16530');

  const [enableSpecialAllowance, setEnableSpecialAllowance] = useState(false);
  const [specialAllowance, setSpecialAllowance] = useState<string>('3802');

  const [enableThermal, setEnableThermal] = useState(false);
  const [thermalMode, setThermalMode] = useState<'auto' | 'fixed' | 'custom'>('fixed');
  const [thermalAllowance, setThermalAllowance] = useState<string>('1500');

  const [enablePerformance, setEnablePerformance] = useState(false);
  const [perfAllowanceMonthly, setPerfAllowanceMonthly] = useState<string>('225');

  const [enableBonus, setEnableBonus] = useState(false);
  const [bonus, setBonus] = useState<string>('0');

  const [enableBonusPercentage, setEnableBonusPercentage] = useState(false);
  const [bonusPercentage, setBonusPercentage] = useState<string>('8.33');

  const [enablePresentDays, setEnablePresentDays] = useState(false);
  const [presentDays, setPresentDays] = useState<string>(String(totalDays || 30));

  const [resetToDesignationDefaults, setResetToDesignationDefaults] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync initial scope with selection count changes
  useEffect(() => {
    if (selectedCount > 0) {
      setTargetScope('selected');
    } else {
      setTargetScope('filtered');
    }
  }, [selectedCount, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Validate at least one action is chosen
    if (
      !resetToDesignationDefaults &&
      !enableGrossRate &&
      !enableSpecialAllowance &&
      !enableThermal &&
      !enablePerformance &&
      !enableBonus &&
      !enableBonusPercentage &&
      !enablePresentDays
    ) {
      setErrorMsg('Please select at least one allowance, rate, or attendance component to update, or choose reset to defaults.');
      return;
    }

    try {
      setSubmitting(true);

      const updates: any = {};

      if (resetToDesignationDefaults) {
        updates.resetToDesignationDefaults = true;
      } else {
        if (enableGrossRate) updates.gross_salary_rate = Number(grossRate);
        if (enableSpecialAllowance) updates.special_allowance = Number(specialAllowance);
        if (enableThermal) {
          updates.thermal_mode = thermalMode;
          if (thermalMode === 'fixed' || thermalMode === 'custom') {
            updates.thermal_allowance = Number(thermalAllowance);
          }
        }
        if (enablePerformance) updates.perf_allowance_monthly = Number(perfAllowanceMonthly);
        if (enableBonusPercentage) updates.bonus_percentage = Number(bonusPercentage);
        if (enableBonus) updates.bonus = Number(bonus);
        if (enablePresentDays) updates.present_days = Number(presentDays);
      }

      const payload: any = {
        periodId,
        updates
      };

      if (targetScope === 'selected' && selectedEntryIds.length > 0) {
        payload.entryIds = selectedEntryIds;
      } else if (targetScope === 'designation' && targetDesignationId) {
        payload.designationId = Number(targetDesignationId);
      } else if (targetScope === 'contractor' && targetContractorId) {
        payload.contractorId = Number(targetContractorId);
      } else if (targetScope === 'filtered') {
        if (activeDesignationFilter) payload.designationId = Number(activeDesignationFilter);
        if (activeContractorFilter) payload.contractorId = Number(activeContractorFilter);
      }

      const res = await apiRequest<any>('/payroll/batch-update', {
        method: 'POST',
        body: JSON.stringify(payload)
      });

      onSuccess(res.message || `Successfully updated and recalculated ${res.updatedCount || 'matching'} employees in 1 click!`);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update allowances and rates.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="modal-overlay" style={{ zIndex: 1200 }}>
      <div className="modal-content" style={{ maxWidth: '820px', maxHeight: '92vh', overflowY: 'auto' }}>
        {/* Header */}
        <div className="modal-header" style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{
              width: '36px', height: '36px', borderRadius: '8px',
              background: '#eff6ff', color: '#2563eb',
              display: 'flex', alignItems: 'center', justifyContent: 'center'
            }}>
              <Zap size={20} />
            </div>
            <div>
              <h3 style={{ margin: 0, fontSize: '17px', fontWeight: 700, color: '#0f172a' }}>
                Multi-Edit Allowances, Performance & Rates (1-Click)
              </h3>
              <p style={{ margin: '2px 0 0 0', fontSize: '12px', color: '#64748b' }}>
                Batch update multiple employees and automatically recalculate deductions (EPF, ESI, LWF) & net pay
              </p>
            </div>
          </div>
          <button onClick={onClose} className="btn-close" type="button">
            <X size={18} />
          </button>
        </div>

        {errorMsg && (
          <div style={{
            margin: '16px 0 0', padding: '10px 14px', borderRadius: '6px',
            background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b',
            display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px'
          }}>
            <AlertCircle size={16} />
            <span>{errorMsg}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* SECTION 1: Target Scope */}
          <div style={{
            background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '14px 18px'
          }}>
            <div style={{ fontSize: '13px', fontWeight: 700, color: '#1e3a8a', marginBottom: '10px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
              Step 1: Select Employees to Update
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '10px' }}>
              {selectedCount > 0 && (
                <label style={{
                  display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px',
                  background: targetScope === 'selected' ? '#eff6ff' : '#ffffff',
                  border: targetScope === 'selected' ? '2px solid #2563eb' : '1px solid #cbd5e1',
                  borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600
                }}>
                  <input
                    type="radio"
                    name="targetScope"
                    value="selected"
                    checked={targetScope === 'selected'}
                    onChange={() => setTargetScope('selected')}
                  />
                  <span>Selected Checkboxes ({selectedCount} Staff)</span>
                </label>
              )}

              <label style={{
                display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px',
                background: targetScope === 'filtered' ? '#eff6ff' : '#ffffff',
                border: targetScope === 'filtered' ? '2px solid #2563eb' : '1px solid #cbd5e1',
                borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600
              }}>
                <input
                  type="radio"
                  name="targetScope"
                  value="filtered"
                  checked={targetScope === 'filtered'}
                  onChange={() => setTargetScope('filtered')}
                />
                <span>Current Table View ({filteredCount} Staff)</span>
              </label>

              <label style={{
                display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px',
                background: targetScope === 'all' ? '#eff6ff' : '#ffffff',
                border: targetScope === 'all' ? '2px solid #2563eb' : '1px solid #cbd5e1',
                borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600
              }}>
                <input
                  type="radio"
                  name="targetScope"
                  value="all"
                  checked={targetScope === 'all'}
                  onChange={() => setTargetScope('all')}
                />
                <span>Entire Month Workforce ({totalCount} Staff)</span>
              </label>

              <label style={{
                display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px',
                background: targetScope === 'designation' ? '#eff6ff' : '#ffffff',
                border: targetScope === 'designation' ? '2px solid #2563eb' : '1px solid #cbd5e1',
                borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600
              }}>
                <input
                  type="radio"
                  name="targetScope"
                  value="designation"
                  checked={targetScope === 'designation'}
                  onChange={() => setTargetScope('designation')}
                />
                <span>By Specific Designation</span>
              </label>

              <label style={{
                display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 12px',
                background: targetScope === 'contractor' ? '#eff6ff' : '#ffffff',
                border: targetScope === 'contractor' ? '2px solid #2563eb' : '1px solid #cbd5e1',
                borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: 600
              }}>
                <input
                  type="radio"
                  name="targetScope"
                  value="contractor"
                  checked={targetScope === 'contractor'}
                  onChange={() => setTargetScope('contractor')}
                />
                <span>By Specific Contractor</span>
              </label>
            </div>

            {targetScope === 'designation' && (
              <div style={{ marginTop: '12px' }}>
                <label className="form-label" style={{ fontSize: '12px' }}>Choose Target Designation:</label>
                <select
                  value={targetDesignationId}
                  onChange={(e) => setTargetDesignationId(e.target.value)}
                  className="form-input"
                  style={{ maxWidth: '320px' }}
                  required
                >
                  <option value="">Select Designation...</option>
                  {designations.map(d => (
                    <option key={d.id} value={d.id}>{d.name} ({d.alias})</option>
                  ))}
                </select>
              </div>
            )}

            {targetScope === 'contractor' && (
              <div style={{ marginTop: '12px' }}>
                <label className="form-label" style={{ fontSize: '12px' }}>Choose Target Contractor / Agency:</label>
                <select
                  value={targetContractorId}
                  onChange={(e) => setTargetContractorId(e.target.value)}
                  className="form-input"
                  style={{ maxWidth: '360px' }}
                  required
                >
                  <option value="">Select Contractor...</option>
                  {contractors.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Quick Option: Reset to Designation Defaults */}
          <div style={{
            background: resetToDesignationDefaults ? '#ecfdf5' : '#f8fafc',
            border: resetToDesignationDefaults ? '2px solid #10b981' : '1px dashed #cbd5e1',
            borderRadius: '8px', padding: '12px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
          }}>
            <div>
              <div style={{ fontSize: '13.5px', fontWeight: 700, color: resetToDesignationDefaults ? '#065f46' : '#1e293b' }}>
                🔄 Reset to Standard Designation Master Rates
              </div>
              <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                Automatically assigns standard Gross Rate (USW: 14408, SEMI: 15395, SW: 16530, HSW: 17835), standard Special Allowance, and Perf Allowance.
              </div>
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontWeight: 600, fontSize: '13px' }}>
              <input
                type="checkbox"
                checked={resetToDesignationDefaults}
                onChange={(e) => setResetToDesignationDefaults(e.target.checked)}
                style={{ width: '18px', height: '18px' }}
              />
              <span>Enable Reset</span>
            </label>
          </div>

          {/* SECTION 2: Allowances, Performance & Rates Toggles (Only visible when not reset-all) */}
          {!resetToDesignationDefaults && (
            <div style={{
              display: 'flex', flexDirection: 'column', gap: '14px',
              background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px 18px'
            }}>
              <div style={{ fontSize: '13px', fontWeight: 700, color: '#1e3a8a', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                Step 2: Choose Components to Edit (Check to enable)
              </div>

              {/* 1. Gross Salary Rate */}
              <div style={{
                border: '1px solid', borderColor: enableGrossRate ? '#93c5fd' : '#e2e8f0',
                background: enableGrossRate ? '#eff6ff' : '#fafafa',
                borderRadius: '8px', padding: '12px 14px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: enableGrossRate ? '8px' : 0 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                    <input
                      type="checkbox"
                      checked={enableGrossRate}
                      onChange={(e) => setEnableGrossRate(e.target.checked)}
                      style={{ width: '16px', height: '16px' }}
                    />
                    <span>Gross Salary / Designation Rate (₹)</span>
                  </label>
                  {enableGrossRate && (
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button type="button" onClick={() => setGrossRate('14408')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>USW ₹14,408</button>
                      <button type="button" onClick={() => setGrossRate('15395')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>SEMI ₹15,395</button>
                      <button type="button" onClick={() => setGrossRate('16530')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>SW ₹16,530</button>
                      <button type="button" onClick={() => setGrossRate('17835')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>HSW ₹17,835</button>
                    </div>
                  )}
                </div>
                {enableGrossRate && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                    <span style={{ fontSize: '12.5px', color: '#64748b' }}>Set Gross Rate to:</span>
                    <input
                      type="number"
                      value={grossRate}
                      onChange={(e) => setGrossRate(e.target.value)}
                      className="form-input"
                      style={{ width: '160px', fontWeight: 700, fontFamily: 'monospace' }}
                      required={enableGrossRate}
                    />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>₹ / Month</span>
                  </div>
                )}
              </div>

              {/* 2. Special Allowance */}
              <div style={{
                border: '1px solid', borderColor: enableSpecialAllowance ? '#93c5fd' : '#e2e8f0',
                background: enableSpecialAllowance ? '#eff6ff' : '#fafafa',
                borderRadius: '8px', padding: '12px 14px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: enableSpecialAllowance ? '8px' : 0 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                    <input
                      type="checkbox"
                      checked={enableSpecialAllowance}
                      onChange={(e) => setEnableSpecialAllowance(e.target.checked)}
                      style={{ width: '16px', height: '16px' }}
                    />
                    <span>Special Allowance (₹)</span>
                  </label>
                  {enableSpecialAllowance && (
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button type="button" onClick={() => setSpecialAllowance('3314')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>USW ₹3,314</button>
                      <button type="button" onClick={() => setSpecialAllowance('3541')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>SEMI ₹3,541</button>
                      <button type="button" onClick={() => setSpecialAllowance('3802')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>SW ₹3,802</button>
                      <button type="button" onClick={() => setSpecialAllowance('4102')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>HSW ₹4,102</button>
                    </div>
                  )}
                </div>
                {enableSpecialAllowance && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                    <span style={{ fontSize: '12.5px', color: '#64748b' }}>Set Special Allowance to:</span>
                    <input
                      type="number"
                      value={specialAllowance}
                      onChange={(e) => setSpecialAllowance(e.target.value)}
                      className="form-input"
                      style={{ width: '160px', fontWeight: 700, fontFamily: 'monospace' }}
                      required={enableSpecialAllowance}
                    />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>₹ / Month</span>
                  </div>
                )}
              </div>

              {/* 3. Thermal Allowance */}
              <div style={{
                border: '1px solid', borderColor: enableThermal ? '#93c5fd' : '#e2e8f0',
                background: enableThermal ? '#eff6ff' : '#fafafa',
                borderRadius: '8px', padding: '12px 14px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: enableThermal ? '8px' : 0 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                    <input
                      type="checkbox"
                      checked={enableThermal}
                      onChange={(e) => setEnableThermal(e.target.checked)}
                      style={{ width: '16px', height: '16px' }}
                    />
                    <span>Thermal Allowance (₹)</span>
                  </label>
                  {enableThermal && (
                    <div style={{ display: 'flex', gap: '8px', fontSize: '12px' }}>
                      <label style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                        <input
                          type="radio"
                          name="thermalMode"
                          value="auto"
                          checked={thermalMode === 'auto'}
                          onChange={() => setThermalMode('auto')}
                        />
                        <span>Auto Proportional (₹1,500 Base)</span>
                      </label>
                      <label style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                        <input
                          type="radio"
                          name="thermalMode"
                          value="fixed"
                          checked={thermalMode === 'fixed'}
                          onChange={() => { setThermalMode('fixed'); setThermalAllowance('1500'); }}
                        />
                        <span>Fixed ₹1,500</span>
                      </label>
                      <label style={{ display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                        <input
                          type="radio"
                          name="thermalMode"
                          value="custom"
                          checked={thermalMode === 'custom'}
                          onChange={() => setThermalMode('custom')}
                        />
                        <span>Custom ₹</span>
                      </label>
                    </div>
                  )}
                </div>
                {enableThermal && thermalMode !== 'auto' && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                    <span style={{ fontSize: '12.5px', color: '#64748b' }}>Thermal Amount:</span>
                    <input
                      type="number"
                      value={thermalAllowance}
                      onChange={(e) => setThermalAllowance(e.target.value)}
                      className="form-input"
                      style={{ width: '140px', fontWeight: 700, fontFamily: 'monospace' }}
                      required={enableThermal}
                    />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>₹</span>
                  </div>
                )}
              </div>

              {/* 4. Performance Allowance */}
              <div style={{
                border: '1px solid', borderColor: enablePerformance ? '#93c5fd' : '#e2e8f0',
                background: enablePerformance ? '#eff6ff' : '#fafafa',
                borderRadius: '8px', padding: '12px 14px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: enablePerformance ? '8px' : 0 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                    <input
                      type="checkbox"
                      checked={enablePerformance}
                      onChange={(e) => setEnablePerformance(e.target.checked)}
                      style={{ width: '16px', height: '16px' }}
                    />
                    <span>Performance Allowance (Monthly Base ₹)</span>
                  </label>
                  {enablePerformance && (
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button type="button" onClick={() => setPerfAllowanceMonthly('225')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>₹225 (MM-1 Standard)</button>
                      <button type="button" onClick={() => setPerfAllowanceMonthly('0')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>₹0 (None)</button>
                      <button type="button" onClick={() => setPerfAllowanceMonthly('500')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>₹500</button>
                    </div>
                  )}
                </div>
                {enablePerformance && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                    <span style={{ fontSize: '12.5px', color: '#64748b' }}>Monthly Base Rate:</span>
                    <input
                      type="number"
                      value={perfAllowanceMonthly}
                      onChange={(e) => setPerfAllowanceMonthly(e.target.value)}
                      className="form-input"
                      style={{ width: '140px', fontWeight: 700, fontFamily: 'monospace' }}
                      required={enablePerformance}
                    />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>
                      (Automatically calculated days-wise by: Base / Total Days × Present Days)
                    </span>
                  </div>
                )}
              </div>

              {/* 5. Fixed Bonus */}
              <div style={{
                border: '1px solid', borderColor: enableBonus ? '#93c5fd' : '#e2e8f0',
                background: enableBonus ? '#eff6ff' : '#fafafa',
                borderRadius: '8px', padding: '12px 14px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: enableBonus ? '8px' : 0 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                    <input
                      type="checkbox"
                      checked={enableBonus}
                      onChange={(e) => {
                        setEnableBonus(e.target.checked);
                        if (e.target.checked) setEnableBonusPercentage(false);
                      }}
                      style={{ width: '16px', height: '16px' }}
                    />
                    <span>Manual Fixed Bonus (₹)</span>
                  </label>
                  {enableBonus && (
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button type="button" onClick={() => setBonus('0')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>₹0 (None)</button>
                      <button type="button" onClick={() => setBonus('1400')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>₹1,400</button>
                    </div>
                  )}
                </div>
                {enableBonus && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                    <span style={{ fontSize: '12.5px', color: '#64748b' }}>Set Fixed Bonus to:</span>
                    <input
                      type="number"
                      value={bonus}
                      onChange={(e) => setBonus(e.target.value)}
                      className="form-input"
                      style={{ width: '140px', fontWeight: 700, fontFamily: 'monospace' }}
                      required={enableBonus}
                    />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>₹</span>
                  </div>
                )}
              </div>

              {/* 5B. Dynamic Bonus Percentage */}
              <div style={{
                border: '1px solid', borderColor: enableBonusPercentage ? '#93c5fd' : '#e2e8f0',
                background: enableBonusPercentage ? '#eff6ff' : '#fafafa',
                borderRadius: '8px', padding: '12px 14px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: enableBonusPercentage ? '8px' : 0 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                    <input
                      type="checkbox"
                      checked={enableBonusPercentage}
                      onChange={(e) => {
                        setEnableBonusPercentage(e.target.checked);
                        if (e.target.checked) setEnableBonus(false);
                      }}
                      style={{ width: '16px', height: '16px' }}
                    />
                    <span>Dynamic Bonus Percentage (% of Basic Salary)</span>
                  </label>
                  {enableBonusPercentage && (
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button type="button" onClick={() => setBonusPercentage('8.33')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>8.33% (Default Reference)</button>
                      <button type="button" onClick={() => setBonusPercentage('0')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>0% (None)</button>
                    </div>
                  )}
                </div>
                {enableBonusPercentage && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                    <span style={{ fontSize: '12.5px', color: '#64748b' }}>Bonus Rate:</span>
                    <input
                      type="number"
                      step="0.01"
                      value={bonusPercentage}
                      onChange={(e) => setBonusPercentage(e.target.value)}
                      className="form-input"
                      style={{ width: '140px', fontWeight: 700, fontFamily: 'monospace' }}
                      required={enableBonusPercentage}
                    />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>% of Total Basic (Auto-calculated: ROUND(Basic × % / 100, 0))</span>
                  </div>
                )}
              </div>

              {/* 6. Present Days / Attendance */}
              <div style={{
                border: '1px solid', borderColor: enablePresentDays ? '#93c5fd' : '#e2e8f0',
                background: enablePresentDays ? '#eff6ff' : '#fafafa',
                borderRadius: '8px', padding: '12px 14px'
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: enablePresentDays ? '8px' : 0 }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                    <input
                      type="checkbox"
                      checked={enablePresentDays}
                      onChange={(e) => setEnablePresentDays(e.target.checked)}
                      style={{ width: '16px', height: '16px' }}
                    />
                    <span>Present Days / Attendance Days</span>
                  </label>
                  {enablePresentDays && (
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button type="button" onClick={() => setPresentDays(String(totalDays || 30))} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>Full ({totalDays} Days)</button>
                      <button type="button" onClick={() => setPresentDays('26')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>26 Days</button>
                      <button type="button" onClick={() => setPresentDays('15')} className="btn btn-secondary btn-sm" style={{ padding: '2px 6px', fontSize: '11px' }}>15 Days</button>
                    </div>
                  )}
                </div>
                {enablePresentDays && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '6px' }}>
                    <span style={{ fontSize: '12.5px', color: '#64748b' }}>Present Days:</span>
                    <input
                      type="number"
                      value={presentDays}
                      onChange={(e) => setPresentDays(e.target.value)}
                      className="form-input"
                      style={{ width: '100px', fontWeight: 700, textAlign: 'center' }}
                      min="0"
                      max={totalDays || 31}
                      required={enablePresentDays}
                    />
                    <span style={{ fontSize: '12px', color: '#64748b' }}>/ {totalDays} Calendar Days</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            borderTop: '1px solid #e2e8f0', paddingTop: '16px', marginTop: '4px'
          }}>
            <button type="button" onClick={onClose} className="btn btn-secondary" disabled={submitting}>
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="btn btn-primary"
              style={{
                background: '#059669', borderColor: '#059669', color: '#ffffff',
                padding: '8px 24px', fontSize: '14px', fontWeight: 700,
                display: 'inline-flex', alignItems: 'center', gap: '8px', boxShadow: '0 2px 4px rgba(5, 150, 105, 0.25)'
              }}
            >
              <Zap size={16} />
              <span>{submitting ? 'Applying & Recalculating...' : '⚡ Apply & Recalculate in 1-Click'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
