import React from 'react';
import { AlertTriangle, LogOut, Save, X, ShieldCheck, Database, Loader2 } from 'lucide-react';

interface LogoutConfirmationModalProps {
  isOpen: boolean;
  hasUnsavedChanges: boolean;
  onClose: () => void;
  onConfirmLogout: () => void;
  onSaveAndLogout: () => Promise<void>;
  isSaving: boolean;
  errorMessage?: string | null;
}

export const LogoutConfirmationModal: React.FC<LogoutConfirmationModalProps> = ({
  isOpen,
  hasUnsavedChanges,
  onClose,
  onConfirmLogout,
  onSaveAndLogout,
  isSaving,
  errorMessage
}) => {
  if (!isOpen) return null;

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(15, 23, 42, 0.75)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999,
      padding: '20px'
    }}>
      <div style={{
        background: '#ffffff',
        borderRadius: '14px',
        maxWidth: '520px',
        width: '100%',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.35)',
        border: hasUnsavedChanges ? '2px solid #f59e0b' : '1px solid #cbd5e1',
        overflow: 'hidden',
        animation: 'fadeInModal 0.2s ease-out'
      }}>
        {/* Header */}
        <div style={{
          padding: '16px 20px',
          background: hasUnsavedChanges
            ? 'linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)'
            : 'linear-gradient(135deg, #1e3a8a 0%, #172554 100%)',
          color: hasUnsavedChanges ? '#92400e' : '#ffffff',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: hasUnsavedChanges ? '1px solid #fde68a' : 'none'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            {hasUnsavedChanges ? (
              <div style={{
                background: '#fef2f2',
                borderRadius: '8px',
                padding: '6px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '1px solid #fed7aa'
              }}>
                <AlertTriangle size={22} color="#d97706" />
              </div>
            ) : (
              <div style={{
                background: 'rgba(255, 255, 255, 0.15)',
                borderRadius: '8px',
                padding: '6px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <ShieldCheck size={22} color="#ffffff" />
              </div>
            )}
            <div>
              <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700 }}>
                {hasUnsavedChanges ? 'Unsaved Changes Detected' : 'Confirm Sign Out'}
              </h3>
              <p style={{ margin: 0, fontSize: '12px', opacity: 0.9 }}>
                {hasUnsavedChanges ? 'GGSSTP Payroll Data Integrity Warning' : 'Guru Gobind Singh Super Thermal Plant, Ropar'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSaving}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: isSaving ? 'not-allowed' : 'pointer',
              color: hasUnsavedChanges ? '#92400e' : '#ffffff',
              opacity: 0.8,
              padding: '4px',
              borderRadius: '6px'
            }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div style={{ padding: '22px' }}>
          {errorMessage && (
            <div style={{
              marginBottom: '16px',
              padding: '10px 14px',
              background: '#fef2f2',
              border: '1px solid #fecaca',
              borderRadius: '8px',
              color: '#991b1b',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <AlertTriangle size={16} color="#dc2626" />
              <span>{errorMessage}</span>
            </div>
          )}

          {hasUnsavedChanges ? (
            <div>
              <div style={{
                background: '#fffbeb',
                border: '1px solid #fde68a',
                borderRadius: '8px',
                padding: '12px 14px',
                marginBottom: '14px',
                color: '#78350f',
                fontSize: '13px',
                lineHeight: 1.5
              }}>
                <strong>Warning:</strong> You have edited values in the Monthly Payroll spreadsheet or active form that have <strong>not been committed to the server database</strong> yet.
              </div>

              <p style={{ margin: '0 0 10px 0', fontSize: '13px', color: '#334155', lineHeight: 1.5 }}>
                If you sign out without saving, any uncommitted attendance days, rates, or formula adjustments will be discarded.
              </p>
              <p style={{ margin: 0, fontSize: '13px', color: '#0f172a', fontWeight: 600 }}>
                Would you like to immediately save all pending changes to the server database before logging out?
              </p>
            </div>
          ) : (
            <div>
              <p style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#1e293b', lineHeight: 1.5 }}>
                Are you sure you want to sign out of the GGSSTP Thermal Plant Portal?
              </p>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                background: '#f0fdf4',
                border: '1px solid #bbf7d0',
                borderRadius: '8px',
                padding: '10px 14px',
                color: '#166534',
                fontSize: '12px',
                fontWeight: 600
              }}>
                <Database size={15} color="#15803d" />
                <span>All employee records and payroll entries are safely saved in the server database.</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div style={{
          padding: '14px 20px',
          background: '#f8fafc',
          borderTop: '1px solid #e2e8f0',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          gap: '10px'
        }}>
          {hasUnsavedChanges ? (
            <>
              <button
                type="button"
                onClick={onClose}
                disabled={isSaving}
                style={{
                  padding: '8px 14px',
                  background: '#ffffff',
                  border: '1px solid #cbd5e1',
                  borderRadius: '7px',
                  fontSize: '13px',
                  fontWeight: 600,
                  color: '#475569',
                  cursor: isSaving ? 'not-allowed' : 'pointer'
                }}
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={onConfirmLogout}
                disabled={isSaving}
                style={{
                  padding: '8px 14px',
                  background: '#fef2f2',
                  border: '1px solid #fecaca',
                  borderRadius: '7px',
                  fontSize: '13px',
                  fontWeight: 600,
                  color: '#dc2626',
                  cursor: isSaving ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                <LogOut size={14} />
                <span>Discard Changes & Log Out</span>
              </button>

              <button
                type="button"
                onClick={onSaveAndLogout}
                disabled={isSaving}
                style={{
                  padding: '8px 16px',
                  background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
                  border: 'none',
                  borderRadius: '7px',
                  fontSize: '13px',
                  fontWeight: 700,
                  color: '#ffffff',
                  cursor: isSaving ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '7px',
                  boxShadow: '0 2px 4px rgba(5, 150, 105, 0.3)'
                }}
              >
                {isSaving ? (
                  <>
                    <Loader2 size={15} className="spinner" style={{ animation: 'spin 1s linear infinite' }} />
                    <span>Saving to Database...</span>
                  </>
                ) : (
                  <>
                    <Save size={15} />
                    <span>Save to Database & Log Out</span>
                  </>
                )}
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={onClose}
                style={{
                  padding: '8px 16px',
                  background: '#ffffff',
                  border: '1px solid #cbd5e1',
                  borderRadius: '7px',
                  fontSize: '13px',
                  fontWeight: 600,
                  color: '#475569',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={onConfirmLogout}
                style={{
                  padding: '8px 18px',
                  background: 'linear-gradient(135deg, #1e3a8a 0%, #1d4ed8 100%)',
                  border: 'none',
                  borderRadius: '7px',
                  fontSize: '13px',
                  fontWeight: 700,
                  color: '#ffffff',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  boxShadow: '0 2px 4px rgba(30, 58, 138, 0.25)'
                }}
              >
                <LogOut size={14} />
                <span>Sign Out</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
