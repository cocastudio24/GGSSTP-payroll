import React, { useState, useEffect, useRef } from 'react';
import { ReconciliationReport, ExtractedFormulaInfo, PayrollPeriod } from '../types';
import { apiRequest } from '../api';
import {
  CheckCircle2, RefreshCw, FileSpreadsheet, ShieldCheck, AlertCircle,
  UploadCloud, Copy, Check, Lock, Sparkles, Sliders, ArrowRight,
  Calculator, Search, Eye, FileCheck, RotateCcw
} from 'lucide-react';

export const ReconciliationView: React.FC = () => {
  const [report, setReport] = useState<ReconciliationReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('');
  const [formulaCategoryFilter, setFormulaCategoryFilter] = useState<string>('all');
  const [copiedFormulaCol, setCopiedFormulaCol] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Payroll periods for Net Payable sync
  const [periods, setPeriods] = useState<PayrollPeriod[]>([]);
  const [selectedPeriodId, setSelectedPeriodId] = useState<number | null>(null);
  const [applyingToPeriod, setApplyingToPeriod] = useState(false);
  const [adoptingRules, setAdoptingRules] = useState(false);
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch initial reconciliation
  const fetchDefaultReconciliation = async () => {
    try {
      setLoading(true);
      setFetchError(null);
      const res = await apiRequest<ReconciliationReport>('/reconciliation/run');
      setReport(res);
      const sheetKeys = Object.keys(res.sheets || {});
      if (sheetKeys.length > 0) {
        setActiveTab(sheetKeys[0]);
      }
    } catch (err: any) {
      console.error('Reconciliation error:', err);
      setFetchError(err.message || 'Failed to load formula reconciliation data');
    } finally {
      setLoading(false);
    }
  };

  // Fetch available periods
  const fetchPeriods = async () => {
    try {
      const res = await apiRequest<{ periods: PayrollPeriod[] }>('/reconciliation/periods');
      setPeriods(res.periods || []);
      if (res.periods && res.periods.length > 0 && !selectedPeriodId) {
        setSelectedPeriodId(res.periods[0].id);
      }
    } catch (err) {
      console.error('Error fetching periods:', err);
    }
  };

  useEffect(() => {
    fetchDefaultReconciliation();
    fetchPeriods();
  }, []);

  // Handle Excel Sheet Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      setActionSuccessMessage(null);
      const formData = new FormData();
      formData.append('file', file);

      const token = localStorage.getItem('token');
      const response = await fetch('/api/reconciliation/upload-and-reconcile', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to process uploaded Excel workbook');
      }

      const newReport: ReconciliationReport = await response.json();
      setReport(newReport);
      const sheetKeys = Object.keys(newReport.sheets);
      if (sheetKeys.length > 0) {
        setActiveTab(sheetKeys[0]);
      }
      setActionSuccessMessage(`Successfully uploaded and extracted formulas from "${file.name}"!`);
      setTimeout(() => setActionSuccessMessage(null), 6000);
    } catch (err: any) {
      alert(`Upload Reconciliation failed: ${err.message}`);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Copy formula text to clipboard
  const handleCopyFormula = (formulaText: string, colId: string) => {
    navigator.clipboard.writeText(formulaText);
    setCopiedFormulaCol(colId);
    setTimeout(() => setCopiedFormulaCol(null), 2500);
  };

  // Adopt extracted rules into active engine
  const handleAdoptRules = async () => {
    if (!report?.detectedParameters) return;
    try {
      setAdoptingRules(true);
      const res = await apiRequest<{ message: string }>('/reconciliation/adopt-rules', {
        method: 'POST',
        body: JSON.stringify({
          name: `Excel Formula Rules (${report.referenceFile})`,
          ...report.detectedParameters
        })
      });
      setActionSuccessMessage(res.message || 'Parameters successfully adopted into active calculation engine!');
      setTimeout(() => setActionSuccessMessage(null), 6000);
    } catch (err: any) {
      alert(`Error adopting rules: ${err.message}`);
    } finally {
      setAdoptingRules(false);
    }
  };

  // Apply exact Excel Net Payable to Period
  const handleApplyToPeriod = async () => {
    if (!selectedPeriodId || !report || !activeTab) return;
    const currentSheet = report.sheets[activeTab];
    if (!currentSheet || !currentSheet.sampleComparisons || currentSheet.sampleComparisons.length === 0) {
      alert('No comparisons available in current sheet to apply.');
      return;
    }

    const confirmMsg = `Are you sure you want to apply the exact Excel Net Payable formulas for ${currentSheet.sampleComparisons.length} employees from sheet "${activeTab}" to Payroll Period #${selectedPeriodId}?\n\nThis will lock the exact Net Payable amounts to guarantee error-free employee payments.`;
    if (!window.confirm(confirmMsg)) return;

    try {
      setApplyingToPeriod(true);
      const res = await apiRequest<{ message: string; updatedCount: number }>('/reconciliation/apply-to-period', {
        method: 'POST',
        body: JSON.stringify({
          periodId: selectedPeriodId,
          comparisons: currentSheet.sampleComparisons
        })
      });
      setActionSuccessMessage(`✅ ${res.message}`);
      await fetchPeriods();
      setTimeout(() => setActionSuccessMessage(null), 7000);
    } catch (err: any) {
      alert(`Error applying Net Payable: ${err.message}`);
    } finally {
      setApplyingToPeriod(false);
    }
  };

  // Reset reconciliation comparisons and restore statutory baseline rules
  const handleResetReconciliation = async () => {
    if (!window.confirm('Are you sure you want to reset reconciliation work?\n\nThis will clear all uploaded comparison sheets, purge discrepancy badges, and restore standard statutory formula rules to default.')) {
      return;
    }
    try {
      setResetting(true);
      setActionSuccessMessage(null);
      const res = await apiRequest<{ message: string }>('/reconciliation/reset', {
        method: 'POST',
        body: JSON.stringify({ periodId: selectedPeriodId, resetRules: true })
      });
      if (fileInputRef.current) fileInputRef.current.value = '';
      await fetchDefaultReconciliation();
      await fetchPeriods();
      setActionSuccessMessage(`🔄 ${res.message || 'Reconciliation state reset to clean slate!'}`);
      setTimeout(() => setActionSuccessMessage(null), 6000);
    } catch (err: any) {
      alert(`Error resetting reconciliation: ${err.message}`);
    } finally {
      setResetting(false);
    }
  };

  const currentSheetData = report && activeTab ? report.sheets[activeTab] : null;

  // Filter extracted formulas
  const sheetFormulas: ExtractedFormulaInfo[] = currentSheetData?.extractedFormulas || [];
  const filteredFormulas = sheetFormulas.filter(f => {
    if (formulaCategoryFilter === 'all') return true;
    return f.category === formulaCategoryFilter;
  });

  // Filter employee rows
  const filteredComparisons = (currentSheetData?.sampleComparisons || []).filter(row => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      row.empName.toLowerCase().includes(term) ||
      row.empCode.toLowerCase().includes(term) ||
      row.designation.toLowerCase().includes(term)
    );
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '22px' }}>
      {/* Top Header & Upload Control Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '14px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <h2 style={{ fontSize: '20px', fontWeight: 800, color: '#0f172a' }}>
              Formula Reconciliation & Excel Salary Engine
            </h2>
            <span
              style={{
                fontSize: '11px',
                fontWeight: 700,
                background: report?.isUploaded ? '#ecfdf5' : '#eff6ff',
                color: report?.isUploaded ? '#047857' : '#1e3a8a',
                padding: '3px 8px',
                borderRadius: '6px',
                border: `1px solid ${report?.isUploaded ? '#a7f3d0' : '#bfdbfe'}`
              }}
            >
              {report?.isUploaded ? 'Custom Upload Active' : 'Default Plant Master'}
            </span>
          </div>
          <p style={{ fontSize: '13px', color: '#64748b', marginTop: '3px' }}>
            Inspect formulas, verify mathematical parity, and adopt Excel formulas to guarantee error-free Net Payable generation.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".xlsx, .xls"
            style={{ display: 'none' }}
          />

          {/* Upload Button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="btn btn-primary"
            style={{
              background: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)',
              boxShadow: '0 2px 8px rgba(30, 58, 138, 0.25)'
            }}
          >
            <UploadCloud size={16} />
            <span>{uploading ? 'Parsing Excel Formulas...' : 'Upload Salary Sheet (.xlsx)'}</span>
          </button>

          {/* Rerun Reference Audit */}
          <button
            onClick={fetchDefaultReconciliation}
            disabled={loading || uploading || resetting}
            className="btn btn-secondary btn-sm"
          >
            <RefreshCw size={14} className={loading ? 'spin' : ''} />
            <span>Rerun Default Master</span>
          </button>

          {/* Reset Reconciliation Work */}
          <button
            onClick={handleResetReconciliation}
            disabled={loading || uploading || resetting}
            className="btn btn-secondary btn-sm"
            style={{
              color: '#b91c1c',
              borderColor: '#fca5a5',
              background: '#fff5f5'
            }}
            title="Reset reconciliation work and restore statutory formula rules"
          >
            <RotateCcw size={14} className={resetting ? 'spin' : ''} />
            <span>{resetting ? 'Resetting...' : 'Reset Reconciliation'}</span>
          </button>
        </div>
      </div>

      {/* Action Success Toast/Banner */}
      {actionSuccessMessage && (
        <div
          style={{
            background: '#ecfdf5',
            border: '1px solid #6ee7b7',
            color: '#065f46',
            padding: '12px 18px',
            borderRadius: '8px',
            fontSize: '13.5px',
            fontWeight: 600,
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}
        >
          <CheckCircle2 size={18} color="#059669" />
          <span>{actionSuccessMessage}</span>
        </div>
      )}

      {fetchError && !report ? (
        <div className="card" style={{ textAlign: 'center', padding: '50px 20px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '12px' }}>
          <AlertCircle size={40} color="#dc2626" style={{ margin: '0 auto 12px auto' }} />
          <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#991b1b' }}>Failed to Load Reconciliation Engine</h3>
          <p style={{ fontSize: '13px', color: '#b91c1c', marginTop: '6px' }}>{fetchError}</p>
          <button
            onClick={fetchDefaultReconciliation}
            className="btn btn-primary btn-sm"
            style={{ marginTop: '16px', display: 'inline-flex', gap: '6px' }}
          >
            <RefreshCw size={14} />
            <span>Retry Connection</span>
          </button>
        </div>
      ) : loading || !report ? (
        <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
          <div style={{ display: 'inline-flex', padding: '16px', background: '#eff6ff', borderRadius: '50%', marginBottom: '14px' }}>
            <Calculator size={32} color="#1e3a8a" />
          </div>
          <div style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>
            Analyzing and Reconciling Formula Engines...
          </div>
          <div style={{ fontSize: '12.5px', color: '#64748b', marginTop: '6px' }}>
            Decoding Excel cell formulas, calculating statutory rates, and verifying Net Payable exactness.
          </div>
        </div>
      ) : (
        <>
          {/* Overall Match Rate & Status Banner */}
          <div
            style={{
              background: '#ffffff',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '20px 24px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              boxShadow: '0 2px 6px rgba(0,0,0,0.03)',
              flexWrap: 'wrap',
              gap: '16px'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
              <div
                style={{
                  background: report.overall.status.includes('100%') ? '#059669' : '#d97706',
                  color: '#ffffff',
                  borderRadius: '50%',
                  width: '46px',
                  height: '46px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 4px 10px rgba(5, 150, 105, 0.25)'
                }}
              >
                <CheckCircle2 size={26} />
              </div>
              <div>
                <div style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a' }}>
                  {report.overall.status} ({report.overall.overallMatchRate})
                </div>
                <div style={{ fontSize: '12.5px', color: '#64748b', marginTop: '3px' }}>
                  Reference File: <code style={{ fontWeight: 700, color: '#1e3a8a' }}>{report.referenceFile}</code> • Audited{' '}
                  <strong>{report.overall.totalEmployeesAudited}</strong> contractual employee records across worksheets.
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '20px' }}>
              {Object.entries(report.sheets).map(([sName, sData]) => (
                <div key={sName} style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 700, textTransform: 'uppercase' }}>
                    {sName} MATCH RATE
                  </div>
                  <div style={{ fontSize: '20px', fontWeight: 800, color: '#059669', fontFamily: 'monospace' }}>
                    {sData.matchRate}
                  </div>
                  <div style={{ fontSize: '11px', color: '#64748b' }}>
                    {sData.totalMatched} / {sData.totalChecked} Matched
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Worksheet Selection Tabs */}
          <div style={{ display: 'flex', gap: '8px', borderBottom: '1px solid #e2e8f0', paddingBottom: '10px' }}>
            {Object.keys(report.sheets).map((sName) => {
              const isActive = activeTab === sName;
              const sData = report.sheets[sName];
              return (
                <button
                  key={sName}
                  onClick={() => setActiveTab(sName)}
                  className={`btn ${isActive ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                  style={{
                    borderRadius: '8px',
                    padding: '8px 16px',
                    fontSize: '13px'
                  }}
                >
                  <FileSpreadsheet size={15} />
                  <span>
                    {sName} ({sData.totalChecked} Employees)
                  </span>
                </button>
              );
            })}
          </div>

          {/* SECTION: EXTRACTED FORMULAS & CALCULATION EXECUTION */}
          {currentSheetData && (
            <div
              className="card"
              style={{
                borderRadius: '12px',
                border: '1px solid #cbd5e1',
                padding: '20px',
                background: '#ffffff'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '10px' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <Calculator size={18} color="#1e3a8a" />
                    <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a' }}>
                      Extracted Excel Calculation Formulas ({currentSheetData.extractedFormulas?.length || 0} Columns)
                    </h3>
                  </div>
                  <p style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                    Directly read from the uploaded Excel sheet cells. Click "Copy Formula" to copy any calculation to your clipboard.
                  </p>
                </div>

                {/* Filter categories */}
                <div style={{ display: 'flex', gap: '6px' }}>
                  {[
                    { id: 'all', label: 'All Formulas' },
                    { id: 'net_payable', label: 'Net Payable' },
                    { id: 'earnings', label: 'Earnings & Basic' },
                    { id: 'employer_contribution', label: 'Employer PF/ESI' },
                    { id: 'employee_deduction', label: 'Deductions' }
                  ].map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => setFormulaCategoryFilter(cat.id)}
                      style={{
                        padding: '4px 10px',
                        borderRadius: '6px',
                        fontSize: '11.5px',
                        fontWeight: 600,
                        cursor: 'pointer',
                        border: '1px solid',
                        borderColor: formulaCategoryFilter === cat.id ? '#1e3a8a' : '#e2e8f0',
                        background: formulaCategoryFilter === cat.id ? '#1e3a8a' : '#f8fafc',
                        color: formulaCategoryFilter === cat.id ? '#ffffff' : '#475569',
                        transition: 'all 0.15s ease'
                      }}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Net Payable Hero Banner */}
              {currentSheetData.netPayableFormula && (
                <div
                  style={{
                    background: 'linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%)',
                    border: '1px solid #93c5fd',
                    borderRadius: '10px',
                    padding: '14px 18px',
                    marginBottom: '16px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: '12px'
                  }}
                >
                  <div>
                    <div style={{ fontSize: '11px', color: '#1e3a8a', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                      FINAL NET PAYABLE EXECUTION FORMULA
                    </div>
                    <div style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a', fontFamily: 'monospace', marginTop: '4px' }}>
                      {currentSheetData.netPayableFormula}
                    </div>
                    <div style={{ fontSize: '12px', color: '#475569', marginTop: '2px' }}>
                      Executes Net Payable = (Gross Total Earnings + Bonus) - (Employee EPF + Employee ESI + LWF)
                    </div>
                  </div>

                  <button
                    onClick={() => handleCopyFormula(currentSheetData.netPayableFormula || '', 'HERO_NET')}
                    className="btn btn-secondary btn-sm"
                    style={{ background: '#ffffff', borderColor: '#93c5fd' }}
                  >
                    {copiedFormulaCol === 'HERO_NET' ? (
                      <>
                        <Check size={14} color="#059669" />
                        <span style={{ color: '#059669' }}>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy size={14} />
                        <span>Copy Net Formula</span>
                      </>
                    )}
                  </button>
                </div>
              )}

              {/* Formula Cards Grid */}
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))',
                  gap: '12px',
                  maxHeight: '380px',
                  overflowY: 'auto',
                  padding: '4px'
                }}
              >
                {filteredFormulas.map((f, idx) => (
                  <div
                    key={idx}
                    style={{
                      background: '#f8fafc',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                      padding: '12px 14px',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      gap: '8px'
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '12px', fontWeight: 700, color: '#0f172a' }}>
                          Col {f.col}: {f.header}
                        </span>
                        <span
                          style={{
                            fontSize: '9.5px',
                            fontWeight: 700,
                            padding: '1px 6px',
                            borderRadius: '4px',
                            background:
                              f.category === 'net_payable'
                                ? '#ecfdf5'
                                : f.category === 'employer_contribution'
                                ? '#fef3c7'
                                : f.category === 'employee_deduction'
                                ? '#fef2f2'
                                : '#eff6ff',
                            color:
                              f.category === 'net_payable'
                                ? '#065f46'
                                : f.category === 'employer_contribution'
                                ? '#92400e'
                                : f.category === 'employee_deduction'
                                ? '#991b1b'
                                : '#1e3a8a'
                          }}
                        >
                          {f.category.replace('_', ' ').toUpperCase()}
                        </span>
                      </div>

                      <div
                        style={{
                          background: '#ffffff',
                          border: '1px solid #cbd5e1',
                          borderRadius: '6px',
                          padding: '6px 10px',
                          marginTop: '6px',
                          fontFamily: 'monospace',
                          fontSize: '12px',
                          fontWeight: 700,
                          color: '#1e3a8a',
                          wordBreak: 'break-all'
                        }}
                      >
                        {f.formula}
                      </div>

                      <div style={{ fontSize: '11px', color: '#64748b', marginTop: '6px' }}>
                        {f.description}
                      </div>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid #e2e8f0', paddingTop: '6px' }}>
                      <span style={{ fontSize: '11px', color: '#64748b' }}>
                        Sample evaluated: <strong>₹{Number(f.sampleVal || 0).toLocaleString('en-IN')}</strong>
                      </span>
                      <button
                        onClick={() => handleCopyFormula(f.formula, f.col)}
                        className="btn btn-secondary btn-sm"
                        style={{ padding: '3px 8px', fontSize: '11px' }}
                      >
                        {copiedFormulaCol === f.col ? (
                          <>
                            <Check size={12} color="#059669" />
                            <span style={{ color: '#059669' }}>Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy size={12} />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SECTION: ERROR-FREE GUARANTEE ACTION PANEL */}
          <div
            style={{
              background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
              color: '#ffffff',
              borderRadius: '12px',
              padding: '20px 24px',
              display: 'flex',
              flexDirection: 'column',
              gap: '14px',
              boxShadow: '0 4px 14px rgba(15, 23, 42, 0.2)'
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <ShieldCheck size={20} color="#10b981" />
                  <span style={{ fontSize: '16px', fontWeight: 800 }}>
                    Error-Free Net Payable Adoption & Guarantee Controls
                  </span>
                </div>
                <p style={{ fontSize: '12.5px', color: '#94a3b8', marginTop: '3px' }}>
                  If the software's automated calculation ever differs from what you need to pay, use these controls to adopt the Excel formulas or lock exact Net Payable amounts into the payroll.
                </p>
              </div>

              <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
                {/* 1. Adopt Formula Rules */}
                <button
                  onClick={handleAdoptRules}
                  disabled={adoptingRules || !report.detectedParameters}
                  className="btn btn-secondary btn-sm"
                  style={{
                    background: '#ffffff',
                    color: '#0f172a',
                    fontWeight: 700
                  }}
                  title="Adopt detected parameters (Thermal base ₹1500, EPF 12%, ESI 3.25%, LWF) into the system's active payroll rule set"
                >
                  <Sliders size={14} color="#1e3a8a" />
                  <span>{adoptingRules ? 'Adopting Rules...' : 'Adopt Formula Parameters into Engine'}</span>
                </button>

                {/* 2. Select Period & Lock Net Payable */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: 'rgba(255,255,255,0.1)', padding: '4px 8px', borderRadius: '8px' }}>
                  <span style={{ fontSize: '11px', color: '#cbd5e1', fontWeight: 600 }}>Period:</span>
                  <select
                    value={selectedPeriodId || ''}
                    onChange={(e) => setSelectedPeriodId(Number(e.target.value))}
                    style={{
                      background: '#1e293b',
                      color: '#ffffff',
                      border: '1px solid #475569',
                      borderRadius: '6px',
                      padding: '4px 8px',
                      fontSize: '12px',
                      outline: 'none'
                    }}
                  >
                    {periods.map(p => (
                      <option key={p.id} value={p.id}>
                        {p.month_name} {p.year} ({p.status})
                      </option>
                    ))}
                  </select>

                  <button
                    onClick={handleApplyToPeriod}
                    disabled={applyingToPeriod || !selectedPeriodId}
                    className="btn btn-primary btn-sm"
                    style={{
                      background: '#059669',
                      border: 'none',
                      fontWeight: 700
                    }}
                    title="Lock exact Net Payable amounts from this sheet to matching employees in the selected period"
                  >
                    <Lock size={13} />
                    <span>{applyingToPeriod ? 'Applying to Period...' : 'Lock Excel Net Payable to Period'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION: DETAILED EMPLOYEE COMPARISON AUDIT TABLE */}
          {currentSheetData && (
            <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
              <div style={{ padding: '16px 20px', borderBottom: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <FileCheck size={18} color="#1e3a8a" />
                  <span style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>
                    {activeTab} Employee-by-Employee Mathematical Verification
                  </span>
                  <span className="badge badge-active">
                    {currentSheetData.totalMatched} / {currentSheetData.totalChecked} Matched
                  </span>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div style={{ position: 'relative', width: '220px' }}>
                    <Search size={14} style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
                    <input
                      type="text"
                      placeholder="Search employee..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="form-input"
                      style={{ paddingLeft: '32px', paddingRight: '8px', paddingTop: '6px', paddingBottom: '6px', fontSize: '12px' }}
                    />
                  </div>
                </div>
              </div>

              <div className="table-container" style={{ border: 'none', borderRadius: '0', maxHeight: '520px', overflowY: 'auto' }}>
                <table className="custom-table">
                  <thead>
                    <tr>
                      <th style={{ width: '50px' }}>Row</th>
                      <th>Emp Code</th>
                      <th>Employee Name</th>
                      <th>Designation</th>
                      <th>Attendance</th>
                      <th className="num">Basic (Soft / Excel)</th>
                      <th className="num">Thermal (Soft / Excel)</th>
                      <th className="num">EPF (Soft / Excel)</th>
                      <th className="num" style={{ background: '#eff6ff', color: '#1e3a8a' }}>Software Net (₹)</th>
                      <th className="num" style={{ background: '#f8fafc', color: '#0f172a' }}>Excel Formula Net (₹)</th>
                      <th className="num">Difference</th>
                      <th style={{ textAlign: 'center' }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredComparisons.map((row, i) => {
                      const isMatch = row.status === 'MATCH';
                      return (
                        <tr key={i} style={{ background: isMatch ? 'transparent' : '#fff5f5' }}>
                          <td style={{ color: '#64748b' }}>#{row.row}</td>
                          <td style={{ fontWeight: 700, fontFamily: 'monospace', color: '#1e3a8a' }}>
                            {row.empCode}
                          </td>
                          <td style={{ fontWeight: 600 }}>{row.empName}</td>
                          <td>
                            <span className="badge" style={{ background: '#f1f5f9' }}>
                              {row.designation}
                            </span>
                          </td>
                          <td>{row.attendance}</td>
                          <td className="num">
                            ₹{row.breakdown.totalBasic?.soft ?? '-'} / ₹{row.breakdown.totalBasic?.excel ?? '-'}
                          </td>
                          <td className="num">
                            ₹{row.breakdown.thermalAllowance?.soft ?? '-'} / ₹{row.breakdown.thermalAllowance?.excel ?? '-'}
                          </td>
                          <td className="num">
                            ₹{row.breakdown.employerEpf12?.soft ?? '-'} / ₹{row.breakdown.employerEpf12?.excel ?? '-'}
                          </td>
                          <td className="num" style={{ fontWeight: 800, color: '#1e3a8a', background: '#eff6ff' }}>
                            ₹{Number(row.softwareNetPayable).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                          </td>
                          <td className="num" style={{ fontWeight: 800, color: '#0f172a', background: '#f8fafc' }}>
                            ₹{Number(row.excelNetPayable).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                          </td>
                          <td className="num" style={{ color: isMatch ? '#059669' : '#dc2626', fontWeight: 800 }}>
                            ₹{row.diff.toFixed(2)}
                          </td>
                          <td style={{ textAlign: 'center' }}>
                            {isMatch ? (
                              <span className="badge badge-active" style={{ fontSize: '10.5px' }}>
                                ✓ 100% MATCH
                              </span>
                            ) : (
                              <span className="badge badge-inactive" style={{ fontSize: '10.5px' }}>
                                MISMATCH
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
