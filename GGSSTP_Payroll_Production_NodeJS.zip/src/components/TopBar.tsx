import React, { useState } from 'react';
import { User as UserType, PayrollPeriod } from '../types';
import {
  LogOut, Calendar, Shield, Plus, MessageSquare, Paperclip,
  Activity, LayoutDashboard, Users, Calculator, CheckCircle2,
  Sliders, Award, Building2, FileSpreadsheet, Download, ShieldCheck,
  History, Settings
} from 'lucide-react';
import { CreatePeriodModal } from './CreatePeriodModal';

interface TopBarProps {
  user: UserType | null;
  onLogout: () => void;
  periods: PayrollPeriod[];
  selectedPeriodId: number | null;
  onSelectPeriod: (id: number) => void;
  onPeriodCreated?: (newPeriodId: number) => void;
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenChat?: () => void;
  activeColumnPreset?: string;
  onSelectColumnPreset?: (preset: string) => void;
  hasUnsavedChanges?: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  user,
  onLogout,
  periods,
  selectedPeriodId,
  onSelectPeriod,
  onPeriodCreated,
  currentTab,
  setCurrentTab,
  onOpenChat,
  activeColumnPreset = 'all',
  onSelectColumnPreset,
  hasUnsavedChanges = false
}) => {
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const handleCreated = (id: number) => {
    if (onPeriodCreated) onPeriodCreated(id);
    else onSelectPeriod(id);
  };

  // Get initials for user avatar
  const getUserInitials = (name?: string) => {
    if (!name) return 'U';
    const parts = name.trim().split(/\s+/);
    if (parts.length >= 2) {
      return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    }
    return parts[0].substring(0, 2).toUpperCase();
  };

  // All function navigation modules under the Functions Top Bar - concise labels to fit the browser width perfectly
  const functionModules = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'employees', label: 'Employees', icon: Users },
    { id: 'payroll', label: 'Monthly Payroll', icon: Calculator },
    { id: 'reconciliation', label: 'Reconciliation', icon: CheckCircle2 },
    { id: 'formula-rules', label: 'Formula Rules', icon: Sliders, adminOnly: true },
    { id: 'designations', label: 'Rates & Wages', icon: Award },
    { id: 'contractors', label: 'Contractors', icon: Building2 },
    { id: 'import', label: 'Excel Import', icon: FileSpreadsheet },
    { id: 'export', label: 'Reports', icon: Download },
    { id: 'users', label: 'Users', icon: ShieldCheck, adminOnly: true },
    { id: 'audit', label: 'Audit Logs', icon: History },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  const isSuper = Boolean(user?.role && (user?.role === 'Super Administrator' || user?.role === 'SUPER_ADMIN' || user?.role.toUpperCase().includes('SUPER')));
  const filteredModules = functionModules.filter(item => {
    if (item.adminOnly && !isSuper) return false;
    return true;
  });

  return (
    <header className="top-bar-wrapper">
      {/* ================= TIER 1: MAIN ORGANIZATION BRANDING HEADER ================= */}
      <div className="top-bar-main">
        {/* LEFT SECTION: Official PSPCL Logo & Payroll Period Controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', flexShrink: 0 }}>
          {/* PSPCL Logo */}
          <div style={{ display: 'flex', alignItems: 'center', background: '#ffffff', padding: '2px 4px', borderRadius: '6px' }}>
            <img
              src="/pspcl_logo.png"
              alt="PSPCL Logo"
              title="Punjab State Power Corporation Limited"
              style={{
                height: '42px',
                width: 'auto',
                maxWidth: '120px',
                objectFit: 'contain',
                display: 'block'
              }}
            />
          </div>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '5px',
            background: '#f8fafc',
            padding: '4px 8px',
            borderRadius: '7px',
            border: '1px solid #cbd5e1'
          }}>
            <Calendar size={14} color="#1e3a8a" />
            <span style={{ fontSize: '11.5px', fontWeight: 700, color: '#334155' }}>Period:</span>
            <select
              value={selectedPeriodId || ''}
              onChange={(e) => onSelectPeriod(Number(e.target.value))}
              className="form-input"
              style={{
                width: 'auto',
                padding: '2px 6px',
                fontWeight: 700,
                color: '#1e3a8a',
                fontSize: '12px',
                border: '1px solid #cbd5e1',
                borderRadius: '5px',
                background: '#ffffff'
              }}
            >
              {periods.map(p => (
                <option key={p.id} value={p.id}>
                  {p.month_name} {p.year} ({p.status})
                </option>
              ))}
              {periods.length === 0 && <option value="">No Periods</option>}
            </select>

            <button
              onClick={() => setIsCreateOpen(true)}
              className="btn btn-secondary btn-sm"
              style={{
                padding: '2px 6px',
                fontSize: '11px',
                fontWeight: 700,
                borderColor: '#cbd5e1',
                borderRadius: '4px',
                background: '#ffffff'
              }}
              title="Create a new payroll period"
            >
              <Plus size={11} color="#1e3a8a" />
              <span>New</span>
            </button>
          </div>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            fontSize: '11px',
            fontWeight: 600,
            color: '#059669',
            background: '#ecfdf5',
            padding: '3px 7px',
            borderRadius: '999px',
            border: '1px solid #a7f3d0'
          }}>
            <Activity size={11} />
            <span>Online DB</span>
          </div>
        </div>

        {/* CENTER SECTION: Large Organization Name & Software Subtitle */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          padding: '0 8px',
          flex: 1,
          minWidth: 0
        }}>
          <div style={{
            fontSize: '17px',
            fontWeight: 900,
            color: '#0f172a',
            letterSpacing: '0.6px',
            lineHeight: 1.15,
            textTransform: 'uppercase',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis'
          }}>
            GURU GOBIND SINGH SUPER THERMAL PLANT (GGSSTP)
          </div>
          <div style={{
            fontSize: '11.5px',
            fontWeight: 700,
            color: '#1e3a8a',
            letterSpacing: '0.3px',
            marginTop: '2px',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            whiteSpace: 'nowrap'
          }}>
            <span>Contractual Labour & Employee Payroll Management System</span>
            <span style={{
              fontSize: '9.5px',
              background: '#dbeafe',
              color: '#1e40af',
              padding: '1px 5px',
              borderRadius: '4px',
              fontWeight: 800
            }}>
              RUPNAGAR, PUNJAB
            </span>
          </div>
        </div>

        {/* RIGHT SIDE CORNER: Team Chat & File Sharing + Logged-in User Profile */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
          {/* Team Chat & File Sharing Button */}
          {onOpenChat && (
            <button
              onClick={onOpenChat}
              className="btn-chat-trigger"
              title="Open Plant Team Chat & Share Files"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                padding: '6px 11px',
                background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
                color: '#ffffff',
                border: 'none',
                borderRadius: '7px',
                fontWeight: 700,
                fontSize: '12px',
                cursor: 'pointer',
                boxShadow: '0 2px 4px rgba(5, 150, 105, 0.25)',
                transition: 'all 0.15s ease'
              }}
            >
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                <MessageSquare size={15} />
                <span style={{
                  position: 'absolute',
                  top: '-2px',
                  right: '-2px',
                  width: '6px',
                  height: '6px',
                  backgroundColor: '#34d399',
                  borderRadius: '50%'
                }} />
              </div>
              <span>Chat & Files</span>
              <Paperclip size={12} style={{ opacity: 0.85 }} />
            </button>
          )}

          {/* Logged In User Profile */}
          {user ? (
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '4px 8px 4px 5px',
              background: '#ffffff',
              border: '1px solid #cbd5e1',
              borderRadius: '8px',
              boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
            }}>
              {/* User Avatar with Green Pulse Online Dot */}
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{
                  width: '30px',
                  height: '30px',
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%)',
                  color: '#ffffff',
                  fontWeight: 800,
                  fontSize: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 1px 3px rgba(30, 58, 138, 0.2)'
                }}>
                  {getUserInitials(user.fullName || user.username)}
                </div>
                <span
                  className="pulse-online"
                  title="Status: Online"
                  style={{
                    position: 'absolute',
                    bottom: '-1px',
                    right: '-1px',
                    width: '8px',
                    height: '8px',
                    backgroundColor: '#10b981',
                    borderRadius: '50%',
                    border: '2px solid #ffffff'
                  }}
                />
              </div>

              {/* User Details */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', minWidth: '70px' }}>
                <div style={{ fontSize: '12px', fontWeight: 700, color: '#0f172a', lineHeight: 1.2 }}>
                  {user.fullName || user.username}
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '3px', marginTop: '1px' }}>
                  <Shield size={9} color="#1e3a8a" />
                  <span style={{
                    fontSize: '10px',
                    color: '#1e3a8a',
                    fontWeight: 600,
                    background: '#eff6ff',
                    padding: '1px 4px',
                    borderRadius: '3px',
                    lineHeight: 1.2
                  }}>
                    {user.role}
                  </span>
                </div>
              </div>

              {/* Server Database Sync Status Indicator */}
              {hasUnsavedChanges ? (
                <div
                  title="Unsaved changes detected. Save to database before logging out."
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                    padding: '3px 7px',
                    background: '#fffbeb',
                    border: '1px solid #fde68a',
                    borderRadius: '5px',
                    color: '#b45309',
                    fontSize: '10px',
                    fontWeight: 700
                  }}
                >
                  <span style={{
                    width: '6px',
                    height: '6px',
                    borderRadius: '50%',
                    backgroundColor: '#f59e0b',
                    display: 'inline-block'
                  }} />
                  <span>Unsaved Edits</span>
                </div>
              ) : (
                <div
                  title="All data is saved in PostgreSQL database."
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '3px',
                    padding: '3px 6px',
                    background: '#ecfdf5',
                    border: '1px solid #a7f3d0',
                    borderRadius: '5px',
                    color: '#047857',
                    fontSize: '10px',
                    fontWeight: 600
                  }}
                >
                  <CheckCircle2 size={11} color="#059669" />
                  <span>DB Synced</span>
                </div>
              )}

              {/* Logout Button */}
              <button
                onClick={() => {
                  if (hasUnsavedChanges) {
                    const confirmLeave = window.confirm(
                      'WARNING: You have unsaved changes in the payroll system.\n\nAll unsaved modifications will be lost if you log out without saving to the database.\n\nDo you want to proceed with logout?'
                    );
                    if (!confirmLeave) return;
                  }
                  onLogout();
                }}
                className="btn-logout"
                title="Sign Out"
                style={{
                  padding: '4px 6px',
                  background: '#fee2e2',
                  border: '1px solid #fecaca',
                  borderRadius: '5px',
                  color: '#dc2626',
                  fontSize: '11px',
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '3px',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease'
                }}
              >
                <LogOut size={12} />
                <span>Logout</span>
              </button>
            </div>
          ) : null}
        </div>
      </div>

      {/* ================= TIER 2: TOP BAR FOR ALL FUNCTIONS (FIT PERFECTLY IN BROWSER) ================= */}
      <nav className="top-functions-bar" aria-label="Software Functions Navigation">
        {filteredModules.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              className={`top-function-tab ${isActive ? 'active' : ''}`}
              onClick={() => setCurrentTab(item.id)}
              title={item.label}
            >
              <Icon size={14} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* ================= TIER 3: LINKED COLUMN NAVIGATOR FOR PAYROLL & WORKFORCE ================= */}
      {(currentTab === 'payroll' || currentTab === 'employees') && (
        <div style={{
          background: '#f8fafc',
          borderBottom: '1px solid #e2e8f0',
          padding: '4px 16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '8px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ fontSize: '11px', fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              Linked Table View:
            </span>
            {[
              { id: 'all', label: '📋 Master View (All Columns)' },
              { id: 'attendance', label: '📅 Attendance & Wages' },
              { id: 'allowances', label: '🎁 Allowances & Earnings' },
              { id: 'statutory', label: '⚖️ Statutory EPF/ESI/LWF' },
              { id: 'disbursal', label: '💳 Net Disbursal & Bank' }
            ].map(preset => {
              const isSelected = (activeColumnPreset || 'all') === preset.id;
              return (
                <button
                  key={preset.id}
                  onClick={() => onSelectColumnPreset && onSelectColumnPreset(preset.id)}
                  style={{
                    border: 'none',
                    background: isSelected ? '#1e3a8a' : 'transparent',
                    color: isSelected ? '#ffffff' : '#475569',
                    padding: '2px 8px',
                    borderRadius: '4px',
                    fontSize: '11px',
                    fontWeight: isSelected ? 700 : 500,
                    cursor: 'pointer',
                    transition: 'all 0.15s ease'
                  }}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
          <div style={{ fontSize: '11px', color: '#64748b' }}>
            Active Module: <strong style={{ color: '#1e3a8a' }}>{currentTab === 'payroll' ? 'Monthly Payroll' : 'Employee Register'}</strong>
          </div>
        </div>
      )}

      <CreatePeriodModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onPeriodCreated={handleCreated}
      />
    </header>
  );
};

export default TopBar;
