import React, { useState, useEffect, useMemo } from 'react';
import { Employee, Designation, Contractor, Circle, DiscoveredColumn, TargetFieldOption } from '../types';
import { apiRequest, getToken } from '../api';
import {
  Search, Plus, Filter, Eye, EyeOff, Edit2, Trash2, UserCheck,
  UserX, Download, Upload, FileSpreadsheet, X, AlertCircle,
  CheckCircle2, RefreshCw, ArrowUpDown, DollarSign, Calculator,
  Archive, ShieldCheck, HelpCircle, Check, Info, Sliders, Sparkles, ArrowRight
} from 'lucide-react';

interface EmployeeViewProps {
  designations: Designation[];
  contractors: Contractor[];
  circles: Circle[];
  userRole?: string;
}

const INITIAL_RATES: Record<string, { gross: number; special: number }> = {
  'USW': { gross: 14408, special: 3314 },
  'SEMI SW': { gross: 15395, special: 3541 },
  'SW': { gross: 16530, special: 3802 },
  'HSW': { gross: 17835, special: 4102 }
};

export const EmployeeView: React.FC<EmployeeViewProps> = ({ designations, contractors, circles, userRole }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedDesignation, setSelectedDesignation] = useState('');
  const [selectedContractor, setSelectedContractor] = useState('');
  const [selectedCircle, setSelectedCircle] = useState('');
  const [selectedCell, setSelectedCell] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedStatutory, setSelectedStatutory] = useState('');
  const [selectedCreatorId, setSelectedCreatorId] = useState<string>('');
  const [creatorsList, setCreatorsList] = useState<Array<{ id: number; username: string; full_name: string }>>([]);
  const [maskSensitive, setMaskSensitive] = useState(true);
  const [exporting, setExporting] = useState(false);

  // Sorting
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState<'ASC' | 'DESC'>('ASC');

  // Pagination
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Selection for bulk actions
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  // Modals state
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Partial<Employee> | null>(null);
  const [formTab, setFormTab] = useState<'personal' | 'statutory' | 'salary'>('personal');
  const [simTotalDays, setSimTotalDays] = useState<number>(30);
  const [simPresentDays, setSimPresentDays] = useState<number>(30);

  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [viewingEmployee, setViewingEmployee] = useState<Employee | null>(null);

  // Archive Modal State
  const [isArchiveModalOpen, setIsArchiveModalOpen] = useState(false);
  const [archivingTarget, setArchivingTarget] = useState<{ type: 'single' | 'bulk'; employee?: Employee; ids?: number[] } | null>(null);
  const [archiveReason, setArchiveReason] = useState('Archived by administrator');
  const [archiveLoading, setArchiveLoading] = useState(false);

  // Permanent Delete Modal State
  const [isPermanentDeleteModalOpen, setIsPermanentDeleteModalOpen] = useState(false);
  const [permanentDeleteTarget, setPermanentDeleteTarget] = useState<{ type: 'single' | 'bulk'; employee?: Employee; ids?: number[] } | null>(null);
  const [deleteEligibility, setDeleteEligibility] = useState<{
    loading: boolean;
    totalChecked: number;
    eligibleCount: number;
    blockedCount: number;
    eligibleEmployees: any[];
    blockedEmployees: any[];
  } | null>(null);
  const [permanentDeleteLoading, setPermanentDeleteLoading] = useState(false);

  // Restore Modal State
  const [isRestoreModalOpen, setIsRestoreModalOpen] = useState(false);
  const [restoringTarget, setRestoringTarget] = useState<{ type: 'single' | 'bulk'; employee?: Employee; ids?: number[] } | null>(null);
  const [restoreLoading, setRestoreLoading] = useState(false);

  // Excel Import Modal state
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importSheetNames, setImportSheetNames] = useState<string[]>([]);
  const [selectedImportSheet, setSelectedImportSheet] = useState<string>('');
  const [importStrategy, setImportStrategy] = useState<'both' | 'add_only' | 'update_only'>('both');
  const [importPreviewData, setImportPreviewData] = useState<any | null>(null);
  const [importColumns, setImportColumns] = useState<DiscoveredColumn[]>([]);
  const [importTargetFields, setImportTargetFields] = useState<TargetFieldOption[]>([]);
  const [columnMappings, setColumnMappings] = useState<Record<number, string>>({});
  const [activeImportTab, setActiveImportTab] = useState<'mapping' | 'preview'>('mapping');
  const [importLoading, setImportLoading] = useState(false);
  const [importSuccessResult, setImportSuccessResult] = useState<any | null>(null);

  // Salary Upload Modal state
  const [isSalaryUploadModalOpen, setIsSalaryUploadModalOpen] = useState(false);
  const [salaryFile, setSalaryFile] = useState<File | null>(null);
  const [salaryPreviewData, setSalaryPreviewData] = useState<any | null>(null);
  const [salaryLoading, setSalaryLoading] = useState(false);
  const [salarySuccessResult, setSalarySuccessResult] = useState<any | null>(null);

  const isSuperAdminUser = Boolean(userRole && userRole.toUpperCase().includes('SUPER'));

  useEffect(() => {
    if (isSuperAdminUser) {
      apiRequest<{ users: Array<{ id: number; username: string; full_name: string }> }>('/users')
        .then(res => {
          if (res && res.users) {
            setCreatorsList(res.users);
          }
        })
        .catch(err => console.error('Failed to load user creators for filter:', err));
    }
  }, [isSuperAdminUser]);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      let query = `/employees?page=${page}&limit=25&sortBy=${sortBy}&sortOrder=${sortOrder}`;
      if (search) query += `&search=${encodeURIComponent(search)}`;
      if (selectedDesignation) query += `&designationId=${selectedDesignation}`;
      if (selectedContractor) query += `&contractorId=${selectedContractor}`;
      if (selectedCircle) query += `&circleId=${selectedCircle}`;
      if (selectedCell) query += `&cell=${encodeURIComponent(selectedCell)}`;
      if (selectedStatus && selectedStatus !== 'all') query += `&status=${selectedStatus}`;
      if (selectedStatutory === 'epf') query += `&epfApplicable=true`;
      if (selectedStatutory === 'esi') query += `&esiApplicable=true`;
      if (selectedStatutory === 'lwf') query += `&lwfApplicable=true`;
      if (selectedCreatorId) query += `&creatorId=${selectedCreatorId}`;

      const res = await apiRequest<{ employees: Employee[]; pagination: any }>(query);
      setEmployees(res.employees);
      setTotalPages(res.pagination.totalPages);
      setTotalCount(res.pagination.total);
    } catch (err: any) {
      alert(`Error loading employees: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, [page, search, selectedDesignation, selectedContractor, selectedCircle, selectedCell, selectedStatus, selectedStatutory, selectedCreatorId, sortBy, sortOrder]);

  const handleSelectAll = () => {
    if (selectedIds.length === employees.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(employees.map(e => e.id));
    }
  };

  const handleToggleSelect = (id: number) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const maskString = (val?: string) => {
    if (!val) return '—';
    if (!maskSensitive) return val;
    if (val.length <= 4) return '****';
    return val.slice(0, 2) + '******' + val.slice(-4);
  };

  // ==================== LIVE SALARY CALCULATION IN FORM ====================
  const liveFormCalculation = useMemo(() => {
    if (!editingEmployee) return null;

    const desig = designations.find(d => d.id === editingEmployee.designation_id);
    const alias = desig?.alias || 'SW';
    const initRate = INITIAL_RATES[alias] || INITIAL_RATES['SW'];

    const grossSalaryRate = editingEmployee.default_gross_rate !== undefined && editingEmployee.default_gross_rate !== null
      ? Number(editingEmployee.default_gross_rate)
      : (initRate?.gross || 16530);

    const specialAllowance = editingEmployee.default_special_allowance !== undefined && editingEmployee.default_special_allowance !== null
      ? Number(editingEmployee.default_special_allowance)
      : (initRate?.special || 3802);

    const totalDays = simTotalDays > 0 ? simTotalDays : 30;
    const presentDays = simPresentDays >= 0 ? simPresentDays : 30;

    // Proportioned Salary = ROUND((Gross / TotalDays) * PresentDays, 0)
    // Excel MM-1 Col P: =ROUND((O3/M3)*N3, 0) | EMC Col AD: =AB3/Z3*AA3
    const proportionedSalary = Math.round((grossSalaryRate / totalDays) * presentDays);

    // Total Basic = ROUND((Gross + Special) * PresentDays / TotalDays, 0)
    const totalBasic = Math.round(((grossSalaryRate + specialAllowance) / totalDays) * presentDays);

    // Thermal Allowance = ROUND(1500 * PresentDays / TotalDays, 0)
    const thermalAllowanceBase = editingEmployee.default_thermal_allowance !== undefined && editingEmployee.default_thermal_allowance !== null
      ? Number(editingEmployee.default_thermal_allowance)
      : 1500;
    const thermalAllowance = Math.round((thermalAllowanceBase / totalDays) * presentDays);

    // Performance Allowance
    const perfAllowanceMonthly = Number(editingEmployee.default_perf_allowance || 0);
    const perfAllowanceDaysWise = Math.round((perfAllowanceMonthly / totalDays) * presentDays);

    // Earnings before bonus
    const totalEarningsBeforeBonus = totalBasic + thermalAllowance + perfAllowanceDaysWise;

    // Bonus = ROUND(totalBasic * bonusPct / 100, 0)
    // Bonus can be left completely blank or set to 0, which calculates bonus as ₹0!
    const bonusPct = editingEmployee.default_bonus_percentage !== undefined && editingEmployee.default_bonus_percentage !== null && (editingEmployee.default_bonus_percentage as any) !== ''
      ? Number(editingEmployee.default_bonus_percentage)
      : (editingEmployee.default_bonus_percentage === null || (editingEmployee.default_bonus_percentage as any) === '' ? 0 : 8.33);
    const bonus = Math.round((totalBasic * bonusPct) / 100);

    // Statutory Applicability
    const epfApplicable = editingEmployee.epf_applicable !== false;
    const esiApplicable = editingEmployee.esi_applicable !== false;
    const lwfApplicable = editingEmployee.lwf_applicable !== false;

    // Standard formula calculations (Reference Excel rules):
    const autoEmployerEpf12 = epfApplicable ? Math.round(proportionedSalary < 25000 ? proportionedSalary * 0.12 : 3000) : 0;
    const autoEmployerEpf1 = epfApplicable ? Math.round(proportionedSalary < 25000 ? proportionedSalary * 0.01 : 250) : 0;
    const autoEmployerEsi325 = esiApplicable ? Math.round(totalEarningsBeforeBonus < 21000 ? totalEarningsBeforeBonus * 0.0325 : 0) : 0;
    const autoEmployerLwf = lwfApplicable ? 20 : 0;

    const autoEmployeeEpf12 = epfApplicable ? autoEmployerEpf12 : 0;
    const autoEmployeeEsi075 = esiApplicable ? Math.round(totalEarningsBeforeBonus < 21000 ? totalEarningsBeforeBonus * 0.0075 : 0) : 0;
    const autoEmployeeLwf = lwfApplicable ? 5 : 0;

    // Statutory resolver: if null/undefined/'auto'/'__NULL__' -> auto formula; if ''/0/'0' -> 0 (blank/deleted); else custom number
    const resolveStatVal = (customVal: any, autoVal: number) => {
      if (customVal === null || customVal === undefined || customVal === 'auto' || customVal === '__NULL__') {
        return { val: autoVal, isCustom: false, isBlank: false };
      }
      if (customVal === '' || customVal === 0 || customVal === '0') {
        return { val: 0, isCustom: true, isBlank: true };
      }
      return { val: Math.round(Number(customVal)), isCustom: true, isBlank: false };
    };

    const statEmployerEpf12 = resolveStatVal(editingEmployee.custom_employer_epf, autoEmployerEpf12);
    const statEmployerEpf1 = resolveStatVal(editingEmployee.custom_employer_epf1, autoEmployerEpf1);
    const statEmployerEsi325 = resolveStatVal(editingEmployee.custom_employer_esi, autoEmployerEsi325);
    const statEmployerLwf = resolveStatVal(editingEmployee.custom_employer_lwf, autoEmployerLwf);

    const statEmployeeEpf12 = resolveStatVal(editingEmployee.custom_employee_epf, autoEmployeeEpf12);
    const statEmployeeEsi075 = resolveStatVal(editingEmployee.custom_employee_esi, autoEmployeeEsi075);
    const statEmployeeLwf = resolveStatVal(editingEmployee.custom_employee_lwf, autoEmployeeLwf);

    // Employer Contributions
    const employerEpf12 = statEmployerEpf12.val;
    const employerEpf1 = statEmployerEpf1.val;
    const employerEsi325 = statEmployerEsi325.val;
    const employerLwf = statEmployerLwf.val;
    const totalEmployerContributions = employerEpf12 + employerEpf1 + employerEsi325 + employerLwf;

    // Employee Deductions
    const employeeEpf12 = statEmployeeEpf12.val;
    const employeeEsi075 = statEmployeeEsi075.val;
    const employeeLwf = statEmployeeLwf.val;
    const totalEmployeeDeductions = employeeEpf12 + employeeEsi075 + employeeLwf;

    // Gross Total = Total Earnings Before Bonus + Bonus + all 4 Employer Contributions
    const grossTotal = totalEarningsBeforeBonus + bonus + totalEmployerContributions;

    // Combined Deductions = Total Employee Deductions + Total Employer Contributions
    const combinedDeductions = totalEmployeeDeductions + totalEmployerContributions;

    // Net Payable Salary = Gross Total - Combined Deductions = (Earnings + Bonus) - Employee Deductions
    // Rounded off to nearest whole rupee with 50+ paise rounded up as per statutory EPF/ESI/LWF formula
    const netPayable = Math.round(grossTotal - combinedDeductions);

    return {
      grossSalaryRate,
      specialAllowance,
      proportionedSalary,
      totalBasic,
      thermalAllowance,
      perfAllowanceMonthly,
      perfAllowanceDaysWise,
      bonus,
      bonusPct,
      totalEarningsBeforeBonus,
      employerEpf12,
      employerEpf1,
      employerEsi325,
      employerLwf,
      totalEmployerContributions,
      employeeEpf12,
      employeeEsi075,
      employeeLwf,
      totalEmployeeDeductions,
      grossTotal,
      netPayable,
      totalDays,
      presentDays,
      proportionedFormula: `=(Gross Salary Rate / Total Month Days) * Present Days`,
      excelRefFormula: `=ROUND((O3/M3)*N3, 0)`,
      // Auto formula standard values for placeholders
      autoEmployerEpf12,
      autoEmployerEpf1,
      autoEmployerEsi325,
      autoEmployerLwf,
      autoEmployeeEpf12,
      autoEmployeeEsi075,
      autoEmployeeLwf,
      // Field status descriptors
      statEmployerEpf12,
      statEmployerEpf1,
      statEmployerEsi325,
      statEmployerLwf,
      statEmployeeEpf12,
      statEmployeeEsi075,
      statEmployeeLwf
    };
  }, [editingEmployee, designations, simTotalDays, simPresentDays]);

  // Handle open Add modal
  const handleOpenAdd = () => {
    setSimTotalDays(30);
    setSimPresentDays(30);
    const defaultDesig = designations[0] || { id: 1, alias: 'SW' };
    const defaultRates = INITIAL_RATES[defaultDesig.alias] || INITIAL_RATES['SW'];

    setEditingEmployee({
      emp_code: `EMP-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      father_name: '',
      uan: '',
      designation_id: defaultDesig.id,
      dob: '',
      age_above_58: 'N',
      date_of_joining: '',
      more_than_3_yrs: 'NO',
      more_than_5_yrs: 'NO',
      qualification: '',
      experience_years: '',
      qualified_status: 'Yes',
      contractor_id: contractors[0]?.id,
      circle_id: circles[0]?.id,
      cell: 'EM-1',
      hazard_duty: 'haz',
      above_60: 'N',
      bank_name: 'State Bank of India',
      bank_account: '',
      ifsc: 'SBIN0050302',
      account_holder_name: '',
      esi_number: '',
      epf_applicable: true,
      esi_applicable: true,
      lwf_applicable: true,
      default_gross_rate: defaultRates.gross,
      default_special_allowance: defaultRates.special,
      default_thermal_allowance: 1500,
      default_perf_allowance: 225,
      default_bonus_percentage: 8.33,
      custom_employee_epf: null,
      custom_employer_epf: null,
      custom_employer_epf1: null,
      custom_employee_esi: null,
      custom_employer_esi: null,
      custom_employee_lwf: null,
      custom_employer_lwf: null,
      is_active: true
    });
    setFormTab('personal');
    setIsAddEditModalOpen(true);
  };

  // Handle open Edit modal
  const handleOpenEdit = (emp: Employee) => {
    setSimTotalDays(30);
    setSimPresentDays(30);
    const desig = designations.find(d => d.id === emp.designation_id);
    const alias = desig?.alias || 'SW';
    const initRate = INITIAL_RATES[alias] || INITIAL_RATES['SW'];

    setEditingEmployee({
      ...emp,
      default_gross_rate: emp.default_gross_rate ?? initRate.gross,
      default_special_allowance: emp.default_special_allowance ?? initRate.special,
      default_thermal_allowance: emp.default_thermal_allowance ?? 1500,
      default_perf_allowance: emp.default_perf_allowance ?? 0,
      default_bonus_percentage: emp.default_bonus_percentage !== undefined ? emp.default_bonus_percentage : 8.33,
      custom_employee_epf: emp.custom_employee_epf !== undefined ? emp.custom_employee_epf : null,
      custom_employer_epf: emp.custom_employer_epf !== undefined ? emp.custom_employer_epf : null,
      custom_employer_epf1: emp.custom_employer_epf1 !== undefined ? emp.custom_employer_epf1 : null,
      custom_employee_esi: emp.custom_employee_esi !== undefined ? emp.custom_employee_esi : null,
      custom_employer_esi: emp.custom_employer_esi !== undefined ? emp.custom_employer_esi : null,
      custom_employee_lwf: emp.custom_employee_lwf !== undefined ? emp.custom_employee_lwf : null,
      custom_employer_lwf: emp.custom_employer_lwf !== undefined ? emp.custom_employer_lwf : null,
      epf_applicable: emp.epf_applicable !== false,
      esi_applicable: emp.esi_applicable !== false,
      lwf_applicable: emp.lwf_applicable !== false
    });
    setFormTab('personal');
    setIsAddEditModalOpen(true);
  };

  // Handle open View Details modal
  const handleOpenView = async (emp: Employee) => {
    try {
      const res = await apiRequest<{ employee: Employee }>(`/employees/${emp.id}`);
      setViewingEmployee(res.employee);
      setIsViewModalOpen(true);
    } catch (err: any) {
      alert(`Failed to load employee details: ${err.message}`);
    }
  };

  // Handle Designation Change in Form (auto-populate standard rates)
  const handleDesignationChange = (newDesigId: number) => {
    if (!editingEmployee) return;
    const desig = designations.find(d => d.id === newDesigId);
    const alias = desig?.alias || 'SW';
    const standardRates = INITIAL_RATES[alias] || INITIAL_RATES['SW'];

    setEditingEmployee({
      ...editingEmployee,
      designation_id: newDesigId,
      default_gross_rate: standardRates.gross,
      default_special_allowance: standardRates.special
    });
  };

  // Save Employee (Add or Edit)
  const handleSaveEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee || !editingEmployee.name?.trim()) {
      alert('Please enter employee name.');
      return;
    }

    try {
      const payload: any = {
        ...editingEmployee,
        default_bonus_percentage: editingEmployee.default_bonus_percentage !== undefined && editingEmployee.default_bonus_percentage !== null && (editingEmployee.default_bonus_percentage as any) !== ''
          ? Number(editingEmployee.default_bonus_percentage)
          : '__NULL__',
        custom_employee_epf: editingEmployee.custom_employee_epf === null || editingEmployee.custom_employee_epf === 'auto'
          ? '__NULL__'
          : (editingEmployee.custom_employee_epf === '' || editingEmployee.custom_employee_epf === 0 || editingEmployee.custom_employee_epf === '0' ? 0 : Number(editingEmployee.custom_employee_epf)),
        custom_employer_epf: editingEmployee.custom_employer_epf === null || editingEmployee.custom_employer_epf === 'auto'
          ? '__NULL__'
          : (editingEmployee.custom_employer_epf === '' || editingEmployee.custom_employer_epf === 0 || editingEmployee.custom_employer_epf === '0' ? 0 : Number(editingEmployee.custom_employer_epf)),
        custom_employer_epf1: editingEmployee.custom_employer_epf1 === null || editingEmployee.custom_employer_epf1 === 'auto'
          ? '__NULL__'
          : (editingEmployee.custom_employer_epf1 === '' || editingEmployee.custom_employer_epf1 === 0 || editingEmployee.custom_employer_epf1 === '0' ? 0 : Number(editingEmployee.custom_employer_epf1)),
        custom_employee_esi: editingEmployee.custom_employee_esi === null || editingEmployee.custom_employee_esi === 'auto'
          ? '__NULL__'
          : (editingEmployee.custom_employee_esi === '' || editingEmployee.custom_employee_esi === 0 || editingEmployee.custom_employee_esi === '0' ? 0 : Number(editingEmployee.custom_employee_esi)),
        custom_employer_esi: editingEmployee.custom_employer_esi === null || editingEmployee.custom_employer_esi === 'auto'
          ? '__NULL__'
          : (editingEmployee.custom_employer_esi === '' || editingEmployee.custom_employer_esi === 0 || editingEmployee.custom_employer_esi === '0' ? 0 : Number(editingEmployee.custom_employer_esi)),
        custom_employee_lwf: editingEmployee.custom_employee_lwf === null || editingEmployee.custom_employee_lwf === 'auto'
          ? '__NULL__'
          : (editingEmployee.custom_employee_lwf === '' || editingEmployee.custom_employee_lwf === 0 || editingEmployee.custom_employee_lwf === '0' ? 0 : Number(editingEmployee.custom_employee_lwf)),
        custom_employer_lwf: editingEmployee.custom_employer_lwf === null || editingEmployee.custom_employer_lwf === 'auto'
          ? '__NULL__'
          : (editingEmployee.custom_employer_lwf === '' || editingEmployee.custom_employer_lwf === 0 || editingEmployee.custom_employer_lwf === '0' ? 0 : Number(editingEmployee.custom_employer_lwf))
      };

      if (editingEmployee.id) {
        await apiRequest(`/employees/${editingEmployee.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload)
        });
      } else {
        await apiRequest(`/employees`, {
          method: 'POST',
          body: JSON.stringify(payload)
        });
      }
      setIsAddEditModalOpen(false);
      setEditingEmployee(null);
      fetchEmployees();
    } catch (err: any) {
      alert(`Failed to save employee: ${err.message}`);
    }
  };

  // ==================== ARCHIVE HANDLERS ====================
  const handleOpenSingleArchive = (emp: Employee) => {
    setArchivingTarget({ type: 'single', employee: emp, ids: [emp.id] });
    setArchiveReason('Archived by administrator');
    setIsArchiveModalOpen(true);
  };

  const handleOpenBulkArchive = () => {
    if (selectedIds.length === 0) return;
    setArchivingTarget({ type: 'bulk', ids: selectedIds });
    setArchiveReason('Bulk archived by administrator');
    setIsArchiveModalOpen(true);
  };

  const handleConfirmArchive = async () => {
    if (!archivingTarget || !archivingTarget.ids || archivingTarget.ids.length === 0) return;
    try {
      setArchiveLoading(true);
      if (archivingTarget.type === 'single' && archivingTarget.employee) {
        const res = await apiRequest<{ message: string }>(`/employees/${archivingTarget.employee.id}/archive`, {
          method: 'POST',
          body: JSON.stringify({ reason: archiveReason })
        });
        alert(res.message);
      } else {
        const res = await apiRequest<{ message: string }>(`/employees/bulk-archive`, {
          method: 'POST',
          body: JSON.stringify({ ids: archivingTarget.ids, reason: archiveReason })
        });
        alert(res.message);
        setSelectedIds([]);
      }
      setIsArchiveModalOpen(false);
      setArchivingTarget(null);
      fetchEmployees();
    } catch (err: any) {
      alert(`Archive failed: ${err.message}`);
    } finally {
      setArchiveLoading(false);
    }
  };

  // ==================== PERMANENT DELETE HANDLERS ====================
  const handleOpenSinglePermanentDelete = async (emp: Employee) => {
    setPermanentDeleteTarget({ type: 'single', employee: emp, ids: [emp.id] });
    setIsPermanentDeleteModalOpen(true);
    setDeleteEligibility({ loading: true, totalChecked: 1, eligibleCount: 0, blockedCount: 0, eligibleEmployees: [], blockedEmployees: [] });
    try {
      const res = await apiRequest<{
        totalChecked: number;
        eligibleCount: number;
        blockedCount: number;
        eligibleEmployees: any[];
        blockedEmployees: any[];
      }>('/employees/check-delete-eligibility', {
        method: 'POST',
        body: JSON.stringify({ ids: [emp.id] })
      });
      setDeleteEligibility({ loading: false, ...res });
    } catch (err: any) {
      alert(`Failed to check delete eligibility: ${err.message}`);
      setIsPermanentDeleteModalOpen(false);
    }
  };

  const handleOpenBulkPermanentDelete = async () => {
    if (selectedIds.length === 0) return;
    setPermanentDeleteTarget({ type: 'bulk', ids: selectedIds });
    setIsPermanentDeleteModalOpen(true);
    setDeleteEligibility({ loading: true, totalChecked: selectedIds.length, eligibleCount: 0, blockedCount: 0, eligibleEmployees: [], blockedEmployees: [] });
    try {
      const res = await apiRequest<{
        totalChecked: number;
        eligibleCount: number;
        blockedCount: number;
        eligibleEmployees: any[];
        blockedEmployees: any[];
      }>('/employees/check-delete-eligibility', {
        method: 'POST',
        body: JSON.stringify({ ids: selectedIds })
      });
      setDeleteEligibility({ loading: false, ...res });
    } catch (err: any) {
      alert(`Failed to check delete eligibility: ${err.message}`);
      setIsPermanentDeleteModalOpen(false);
    }
  };

  const handleConfirmPermanentDelete = async (eligibleOnly: boolean = false) => {
    if (!permanentDeleteTarget || !permanentDeleteTarget.ids || permanentDeleteTarget.ids.length === 0) return;
    try {
      setPermanentDeleteLoading(true);
      if (permanentDeleteTarget.type === 'single' && permanentDeleteTarget.employee) {
        const res = await apiRequest<{ message: string }>(`/employees/${permanentDeleteTarget.employee.id}`, {
          method: 'DELETE',
          body: JSON.stringify({ hardDelete: true })
        });
        alert(res.message);
      } else {
        const res = await apiRequest<{ message: string; deletedCount: number }>(`/employees/bulk-delete`, {
          method: 'POST',
          body: JSON.stringify({
            ids: permanentDeleteTarget.ids,
            forceEligibleOnly: eligibleOnly
          })
        });
        alert(res.message);
        setSelectedIds([]);
      }
      setIsPermanentDeleteModalOpen(false);
      setPermanentDeleteTarget(null);
      fetchEmployees();
    } catch (err: any) {
      alert(`Permanent delete failed: ${err.message}`);
    } finally {
      setPermanentDeleteLoading(false);
    }
  };

  // Switch from blocked delete to safe archive
  const handleSwitchToArchiveFromDelete = () => {
    if (!permanentDeleteTarget) return;
    setIsPermanentDeleteModalOpen(false);
    if (permanentDeleteTarget.type === 'single' && permanentDeleteTarget.employee) {
      handleOpenSingleArchive(permanentDeleteTarget.employee);
    } else {
      handleOpenBulkArchive();
    }
  };

  // ==================== RESTORE HANDLERS ====================
  const handleOpenSingleRestore = (emp: Employee) => {
    setRestoringTarget({ type: 'single', employee: emp, ids: [emp.id] });
    setIsRestoreModalOpen(true);
  };

  const handleOpenBulkRestore = () => {
    if (selectedIds.length === 0) return;
    setRestoringTarget({ type: 'bulk', ids: selectedIds });
    setIsRestoreModalOpen(true);
  };

  const handleConfirmRestore = async () => {
    if (!restoringTarget || !restoringTarget.ids || restoringTarget.ids.length === 0) return;
    try {
      setRestoreLoading(true);
      if (restoringTarget.type === 'single' && restoringTarget.employee) {
        const res = await apiRequest<{ message: string }>(`/employees/${restoringTarget.employee.id}/restore`, {
          method: 'POST'
        });
        alert(res.message);
      } else {
        const res = await apiRequest<{ message: string }>(`/employees/bulk-restore`, {
          method: 'POST',
          body: JSON.stringify({ ids: restoringTarget.ids })
        });
        alert(res.message);
        setSelectedIds([]);
      }
      setIsRestoreModalOpen(false);
      setRestoringTarget(null);
      fetchEmployees();
    } catch (err: any) {
      alert(`Restore failed: ${err.message}`);
    } finally {
      setRestoreLoading(false);
    }
  };

  // Download Excel Template
  const handleDownloadTemplate = () => {
    window.open('/api/employees/template', '_blank');
  };

  // Export filtered or selected employees
  const handleExportEmployees = async (onlySelected: boolean = true) => {
    try {
      setExporting(true);
      const token = getToken();
      const body: any = {};
      if (onlySelected && selectedIds.length > 0) {
        body.ids = selectedIds;
      } else {
        if (search) body.search = search;
        if (selectedDesignation) body.designationId = Number(selectedDesignation);
        if (selectedContractor) body.contractorId = Number(selectedContractor);
      }

      const response = await fetch('/api/export/employees-xlsx', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        body: JSON.stringify(body)
      });

      if (!response.ok) throw new Error('Failed to generate employee master export');

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const countLabel = onlySelected && selectedIds.length > 0 ? `Selected_${selectedIds.length}` : 'Master';
      a.download = `GGSSTP_Employees_${countLabel}_${new Date().toISOString().slice(0, 10)}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err: any) {
      alert(`Export failed: ${err.message}`);
    } finally {
      setExporting(false);
    }
  };

  // ==================== EXCEL IMPORT HANDLERS ====================
  const handleImportFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    setImportFile(file);
    setImportPreviewData(null);
    setImportSuccessResult(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      setImportLoading(true);
      const token = getToken();
      const response = await fetch('/api/employees/import-preview', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to preview file');

      setImportSheetNames(data.sheetNames || []);
      setSelectedImportSheet(data.selectedSheet || '');
      setImportPreviewData(data);
      if (data.columns) {
        setImportColumns(data.columns);
        const mapObj: Record<number, string> = {};
        data.columns.forEach((c: any) => {
          mapObj[c.colIndex] = c.proposedField;
        });
        setColumnMappings(mapObj);
      }
      if (data.targetFields) {
        setImportTargetFields(data.targetFields);
      }
      setActiveImportTab('mapping');
    } catch (err: any) {
      alert(`Excel preview failed: ${err.message}`);
    } finally {
      setImportLoading(false);
    }
  };

  const handleImportSheetChange = async (sheet: string) => {
    if (!importFile) return;
    setSelectedImportSheet(sheet);
    const formData = new FormData();
    formData.append('file', importFile);
    formData.append('sheetName', sheet);

    try {
      setImportLoading(true);
      const token = getToken();
      const response = await fetch('/api/employees/import-preview', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to load sheet preview');
      setImportPreviewData(data);
      if (data.columns) {
        setImportColumns(data.columns);
        const mapObj: Record<number, string> = {};
        data.columns.forEach((c: any) => {
          mapObj[c.colIndex] = c.proposedField;
        });
        setColumnMappings(mapObj);
      }
    } catch (err: any) {
      alert(`Sheet preview failed: ${err.message}`);
    } finally {
      setImportLoading(false);
    }
  };

  const handleColumnMappingChange = (colIndex: number, newFieldKey: string) => {
    setColumnMappings(prev => ({
      ...prev,
      [colIndex]: newFieldKey
    }));
    setImportColumns(prev => prev.map(c => {
      if (c.colIndex !== colIndex) return c;
      return {
        ...c,
        proposedField: newFieldKey,
        status: newFieldKey === '__EXCLUDE__' ? 'excluded' : 'custom',
        reason: newFieldKey === '__EXCLUDE__' ? 'Manually excluded by user' : 'Manually mapped by user'
      };
    }));
  };

  const handleConfirmImport = async () => {
    if (!importFile || !importPreviewData) return;
    try {
      setImportLoading(true);
      const formData = new FormData();
      formData.append('file', importFile);
      formData.append('sheetName', selectedImportSheet || importPreviewData.selectedSheet);
      formData.append('mapping', JSON.stringify(columnMappings));
      formData.append('headerRow', String(importPreviewData.headerRowIndex || 0));
      formData.append('strategy', importStrategy);
      formData.append('month', '9');
      formData.append('year', '2026');

      const token = getToken();
      const response = await fetch('/api/import/execute', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to execute mapped import');

      setImportSuccessResult(data.result);
      fetchEmployees();
    } catch (err: any) {
      alert(`Import commit failed: ${err.message}`);
    } finally {
      setImportLoading(false);
    }
  };

  // ==================== SALARY UPLOAD HANDLERS ====================
  const handleSalaryFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    setSalaryFile(file);
    setSalaryPreviewData(null);
    setSalarySuccessResult(null);

    const formData = new FormData();
    formData.append('file', file);

    try {
      setSalaryLoading(true);
      const token = getToken();
      const response = await fetch('/api/employees/salary-upload-preview', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to preview salary file');
      setSalaryPreviewData(data);
    } catch (err: any) {
      alert(`Salary preview failed: ${err.message}`);
    } finally {
      setSalaryLoading(false);
    }
  };

  const handleConfirmSalaryUpload = async () => {
    if (!salaryPreviewData || !salaryPreviewData.matchedRows) return;
    try {
      setSalaryLoading(true);
      const res = await apiRequest<{ message: string; result: any }>('/employees/salary-upload-commit', {
        method: 'POST',
        body: JSON.stringify({
          rows: salaryPreviewData.matchedRows
        })
      });
      setSalarySuccessResult(res.result);
      fetchEmployees();
    } catch (err: any) {
      alert(`Salary update failed: ${err.message}`);
    } finally {
      setSalaryLoading(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Top Action Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
        <div>
          <h2 style={{ fontSize: '20px', fontWeight: 800, color: '#0f172a', margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span>Employee Master Register</span>
            <span style={{ fontSize: '12px', background: '#e0e7ff', color: '#3730a3', padding: '2px 8px', borderRadius: '12px', fontWeight: 700 }}>
              {totalCount} Total
            </span>
          </h2>
          <p style={{ fontSize: '13px', color: '#64748b', margin: '3px 0 0' }}>
            Comprehensive management of contractual workforce, designation-based salary structures, statutory applicability, and automated calculations.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' }}>
          <button
            onClick={handleDownloadTemplate}
            className="btn btn-secondary btn-sm"
            style={{ borderColor: '#64748b', color: '#334155' }}
            title="Download standard Excel import template for employees and salary rates"
          >
            <Download size={15} />
            <span>Template</span>
          </button>

          <button
            onClick={() => {
              setImportFile(null);
              setImportPreviewData(null);
              setImportSuccessResult(null);
              setIsImportModalOpen(true);
            }}
            className="btn btn-secondary btn-sm"
            style={{ borderColor: '#2563eb', color: '#1d4ed8', background: '#eff6ff', fontWeight: 600 }}
            title="Upload and import employees from MM-1, EMC, or standard Excel spreadsheet"
          >
            <Upload size={15} color="#2563eb" />
            <span>Import Employees</span>
          </button>

          <button
            onClick={() => {
              setSalaryFile(null);
              setSalaryPreviewData(null);
              setSalarySuccessResult(null);
              setIsSalaryUploadModalOpen(true);
            }}
            className="btn btn-secondary btn-sm"
            style={{ borderColor: '#059669', color: '#047857', background: '#ecfdf5', fontWeight: 600 }}
            title="Bulk upload and update employee salary rates, allowances, and bonuses from Excel"
          >
            <DollarSign size={15} color="#059669" />
            <span>Upload Salary Excel</span>
          </button>

          <button
            onClick={() => handleExportEmployees(selectedIds.length > 0)}
            disabled={exporting}
            className="btn btn-secondary btn-sm"
            title={selectedIds.length > 0 ? `Export ${selectedIds.length} selected employees to Excel` : 'Export all filtered employees to Excel'}
          >
            <FileSpreadsheet size={15} />
            <span>{exporting ? 'Exporting...' : selectedIds.length > 0 ? `Export (${selectedIds.length})` : 'Export'}</span>
          </button>

          <button
            onClick={() => setMaskSensitive(!maskSensitive)}
            className="btn btn-secondary btn-sm"
            title="Toggle Bank/UAN masking for confidentiality"
          >
            {maskSensitive ? <EyeOff size={15} /> : <Eye size={15} />}
          </button>

          <button onClick={handleOpenAdd} className="btn btn-primary btn-sm" style={{ fontWeight: 700 }}>
            <Plus size={16} />
            <span>Add New Employee</span>
          </button>
        </div>
      </div>

      {/* Status View Quick Tabs */}
      <div style={{ display: 'flex', gap: '8px', borderBottom: '1px solid #e2e8f0', paddingBottom: '10px' }}>
        <button
          onClick={() => { setSelectedStatus('active'); setPage(1); }}
          className="btn btn-sm"
          style={{
            background: selectedStatus === 'active' ? '#2563eb' : '#ffffff',
            color: selectedStatus === 'active' ? '#ffffff' : '#334155',
            border: selectedStatus === 'active' ? '1px solid #2563eb' : '1px solid #cbd5e1',
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          <UserCheck size={14} />
          <span>Active Workforce</span>
        </button>
        <button
          onClick={() => { setSelectedStatus('archived'); setPage(1); }}
          className="btn btn-sm"
          style={{
            background: selectedStatus === 'archived' ? '#d97706' : '#ffffff',
            color: selectedStatus === 'archived' ? '#ffffff' : '#334155',
            border: selectedStatus === 'archived' ? '1px solid #d97706' : '1px solid #cbd5e1',
            fontWeight: 700,
            display: 'flex',
            alignItems: 'center',
            gap: '6px'
          }}
        >
          <Archive size={14} />
          <span>Archived Records</span>
        </button>
        <button
          onClick={() => { setSelectedStatus('all'); setPage(1); }}
          className="btn btn-sm"
          style={{
            background: selectedStatus === 'all' ? '#0f172a' : '#ffffff',
            color: selectedStatus === 'all' ? '#ffffff' : '#334155',
            border: selectedStatus === 'all' ? '1px solid #0f172a' : '1px solid #cbd5e1',
            fontWeight: 700
          }}
        >
          All Employees
        </button>
      </div>

      {/* Advanced Filters & Sorting Card */}
      <div className="card" style={{ padding: '16px 20px', background: '#ffffff', borderRadius: '10px', boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', alignItems: 'center' }}>
          {/* Search */}
          <div style={{ position: 'relative', minWidth: '220px' }}>
            <Search size={15} color="#94a3b8" style={{ position: 'absolute', left: '12px', top: '10px' }} />
            <input
              type="text"
              placeholder="Search by name, code, UAN, bank..."
              className="form-input"
              style={{ paddingLeft: '34px', fontSize: '13px' }}
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
          </div>

          {/* Designation Filter */}
          <div>
            <select
              value={selectedDesignation}
              onChange={(e) => { setSelectedDesignation(e.target.value); setPage(1); }}
              className="form-input"
              style={{ fontSize: '13px' }}
            >
              <option value="">All Designations</option>
              {designations.map(d => (
                <option key={d.id} value={d.id}>{d.name} ({d.alias})</option>
              ))}
            </select>
          </div>

          {/* Contractor Filter */}
          <div>
            <select
              value={selectedContractor}
              onChange={(e) => { setSelectedContractor(e.target.value); setPage(1); }}
              className="form-input"
              style={{ fontSize: '13px' }}
            >
              <option value="">All Contractors</option>
              {contractors.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {/* Circle / Department Filter */}
          <div>
            <select
              value={selectedCircle}
              onChange={(e) => { setSelectedCircle(e.target.value); setPage(1); }}
              className="form-input"
              style={{ fontSize: '13px' }}
            >
              <option value="">All Circles</option>
              {circles.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => { setSelectedStatus(e.target.value); setPage(1); }}
              className="form-input"
              style={{ fontSize: '13px' }}
            >
              <option value="all">Status: All</option>
              <option value="active">Active Only</option>
              <option value="inactive">Inactive Only</option>
              <option value="archived">Archived Only</option>
            </select>
          </div>

          {/* Statutory Applicability Filter */}
          <div>
            <select
              value={selectedStatutory}
              onChange={(e) => { setSelectedStatutory(e.target.value); setPage(1); }}
              className="form-input"
              style={{ fontSize: '13px' }}
            >
              <option value="">Statutory: All</option>
              <option value="epf">EPF Covered</option>
              <option value="esi">ESI Covered</option>
              <option value="lwf">LWF Covered</option>
            </select>
          </div>

          {/* Sort By */}
          <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
            <select
              value={sortBy}
              onChange={(e) => { setSortBy(e.target.value); setPage(1); }}
              className="form-input"
              style={{ fontSize: '13px', flex: 1 }}
            >
              <option value="name">Sort: Name</option>
              <option value="emp_code">Sort: Code</option>
              <option value="designation">Sort: Designation</option>
              <option value="id">Sort: ID</option>
            </select>
            <button
              onClick={() => setSortOrder(sortOrder === 'ASC' ? 'DESC' : 'ASC')}
              className="btn btn-secondary btn-sm"
              style={{ padding: '7px 10px' }}
              title={`Switch order: currently ${sortOrder}`}
            >
              <ArrowUpDown size={14} />
            </button>
          </div>

          {/* Super Admin Creator Filter */}
          {isSuperAdminUser && (
            <div style={{ gridColumn: 'span 2' }}>
              <select
                value={selectedCreatorId}
                onChange={(e) => { setSelectedCreatorId(e.target.value); setPage(1); }}
                className="form-input"
                style={{ borderColor: '#3b82f6', background: '#eff6ff', color: '#1e3a8a', fontWeight: 600, fontSize: '13px' }}
              >
                <option value="">All Creators (Global Plant View)</option>
                {creatorsList.map(u => (
                  <option key={u.id} value={u.id}>Created by: {u.full_name} ({u.username})</option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Bulk Action Toolbar */}
      {selectedIds.length > 0 && (
        <div style={{
          background: '#1e3a8a',
          color: '#ffffff',
          borderRadius: '8px',
          padding: '12px 18px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '12px',
          boxShadow: '0 4px 12px rgba(30, 58, 138, 0.25)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{
              background: '#3b82f6',
              color: '#ffffff',
              padding: '4px 10px',
              borderRadius: '12px',
              fontWeight: 800,
              fontSize: '12px'
            }}>
              {selectedIds.length} Selected
            </span>
            <span style={{ fontSize: '13.5px', fontWeight: 600 }}>
              Bulk Actions for Selected Workforce
            </span>
          </div>

          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', alignItems: 'center' }}>
            <button
              onClick={handleOpenBulkArchive}
              className="btn btn-sm"
              style={{ background: '#d97706', color: '#ffffff', border: 'none', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '5px' }}
              title="Archive selected employees (exclude from future payroll runs without affecting historical records)"
            >
              <Archive size={14} />
              <span>Archive Selected ({selectedIds.length})</span>
            </button>

            {selectedStatus === 'archived' && (
              <button
                onClick={handleOpenBulkRestore}
                className="btn btn-sm"
                style={{ background: '#059669', color: '#ffffff', border: 'none', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '5px' }}
                title="Restore selected archived employees back to active status"
              >
                <RefreshCw size={14} />
                <span>Restore Selected ({selectedIds.length})</span>
              </button>
            )}

            {isSuperAdminUser && (
              <button
                onClick={handleOpenBulkPermanentDelete}
                className="btn btn-sm"
                style={{ background: '#dc2626', color: '#ffffff', border: 'none', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '5px' }}
                title="Permanently delete selected employees (strictly protected by payroll history checks)"
              >
                <Trash2 size={14} />
                <span>Permanently Delete Selected</span>
              </button>
            )}

            <button
              onClick={() => setSelectedIds([])}
              className="btn btn-sm"
              style={{ background: 'rgba(255,255,255,0.15)', color: '#ffffff', border: '1px solid rgba(255,255,255,0.3)', display: 'flex', alignItems: 'center', gap: '5px' }}
              title="Clear selection"
            >
              <X size={14} />
              <span>Clear Selection</span>
            </button>
          </div>
        </div>
      )}

      {/* Employees Table */}
      <div className="table-container" style={{ background: '#ffffff', borderRadius: '10px', boxShadow: '0 1px 3px rgba(0,0,0,0.06)' }}>
        <table className="custom-table">
          <thead>
            <tr>
              <th style={{ width: '40px', textAlign: 'center' }}>
                <input
                  type="checkbox"
                  checked={selectedIds.length > 0 && selectedIds.length === employees.length}
                  onChange={handleSelectAll}
                />
              </th>
              <th>Emp Code</th>
              <th>Name & Father's Name</th>
              <th>Designation</th>
              <th>Contractor / Circle</th>
              <th>UAN & Bank Account</th>
              <th>ESI No</th>
              <th style={{ textAlign: 'center' }}>Statutory</th>
              <th style={{ textAlign: 'right' }}>Wage Rate & Net Salary</th>
              <th style={{ textAlign: 'center' }}>Status</th>
              {isSuperAdminUser && <th style={{ background: '#f8fafc', color: '#1e3a8a' }}>Creator</th>}
              <th style={{ textAlign: 'center', width: '130px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={isSuperAdminUser ? 12 : 11} style={{ textAlign: 'center', padding: '36px', color: '#64748b' }}>
                  Loading employee records...
                </td>
              </tr>
            ) : employees.length === 0 ? (
              <tr>
                <td colSpan={isSuperAdminUser ? 12 : 11} style={{ textAlign: 'center', padding: '36px', color: '#64748b' }}>
                  No matching employees found in your workspace.
                </td>
              </tr>
            ) : (
              employees.map(emp => {
                const isSelected = selectedIds.includes(emp.id);
                const calcSalary = emp.calculated_salary;

                return (
                  <tr key={emp.id} style={{ background: isSelected ? '#eff6ff' : undefined }}>
                    <td style={{ textAlign: 'center' }}>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => handleToggleSelect(emp.id)}
                      />
                    </td>
                    <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace', fontSize: '13px' }}>
                      {emp.emp_code}
                    </td>
                    <td>
                      <div style={{ fontWeight: 600, color: '#0f172a' }}>{emp.name}</div>
                      <div style={{ fontSize: '11.5px', color: '#64748b' }}>S/o {emp.father_name || '—'}</div>
                    </td>
                    <td>
                      <span className="badge" style={{ background: '#f1f5f9', color: '#1e293b', border: '1px solid #cbd5e1', fontWeight: 600 }}>
                        {emp.designation_alias || 'SW'}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: '#1e293b' }}>
                        {emp.contractor_name || 'M/s Sodhi Erectors'}
                      </div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>
                        {emp.circle_name || 'GGSSTP'} {emp.cell ? `• ${emp.cell}` : ''}
                      </div>
                    </td>
                    <td>
                      <div style={{ fontFamily: 'monospace', fontSize: '12px', fontWeight: 600 }}>
                        {maskString(emp.bank_account)}
                      </div>
                      <div style={{ fontSize: '11px', color: '#64748b', fontFamily: 'monospace' }}>
                        UAN: {maskString(emp.uan)}
                      </div>
                    </td>
                    <td style={{ fontFamily: 'monospace', fontSize: '12px' }}>
                      {maskString(emp.esi_number)}
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <span
                          title={emp.epf_applicable !== false ? 'EPF Applicable (12%)' : 'EPF Not Applicable'}
                          style={{
                            fontSize: '10px', fontWeight: 700, padding: '2px 5px', borderRadius: '4px',
                            background: emp.epf_applicable !== false ? '#dcfce7' : '#fee2e2',
                            color: emp.epf_applicable !== false ? '#15803d' : '#b91c1c'
                          }}
                        >
                          EPF
                        </span>
                        <span
                          title={emp.esi_applicable !== false ? 'ESI Applicable (0.75%)' : 'ESI Not Applicable'}
                          style={{
                            fontSize: '10px', fontWeight: 700, padding: '2px 5px', borderRadius: '4px',
                            background: emp.esi_applicable !== false ? '#e0e7ff' : '#fee2e2',
                            color: emp.esi_applicable !== false ? '#4338ca' : '#b91c1c'
                          }}
                        >
                          ESI
                        </span>
                        <span
                          title={emp.lwf_applicable !== false ? 'LWF Applicable (₹5)' : 'LWF Not Applicable'}
                          style={{
                            fontSize: '10px', fontWeight: 700, padding: '2px 5px', borderRadius: '4px',
                            background: emp.lwf_applicable !== false ? '#fef3c7' : '#fee2e2',
                            color: emp.lwf_applicable !== false ? '#b45309' : '#b91c1c'
                          }}
                        >
                          LWF
                        </span>
                      </div>
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ fontWeight: 800, color: '#047857', fontFamily: 'monospace', fontSize: '13px' }}>
                        {calcSalary ? `₹${calcSalary.netPayable.toLocaleString('en-IN')}` : '—'}
                      </div>
                      <div style={{ fontSize: '11px', color: '#1d4ed8', fontWeight: 600, fontFamily: 'monospace' }} title="Proportioned Salary Formula: =(Gross Salary / Total Days) * Present Days">
                        Prop: ₹{calcSalary ? (calcSalary.proportionedSalary || calcSalary.grossSalaryRate).toLocaleString('en-IN') : '—'}
                      </div>
                      <div style={{ fontSize: '10px', color: '#64748b' }}>
                        Gross: ₹{calcSalary ? calcSalary.grossSalaryRate.toLocaleString('en-IN') : '—'}
                      </div>
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      {emp.archived_at ? (
                        <span className="badge" style={{ background: '#fef3c7', color: '#92400e', border: '1px solid #fde68a' }}>Archived</span>
                      ) : emp.is_active ? (
                        <span className="badge badge-active">Active</span>
                      ) : (
                        <span className="badge badge-inactive">Inactive</span>
                      )}
                    </td>
                    {isSuperAdminUser && (
                      <td>
                        <span style={{ fontSize: '11px', padding: '3px 7px', borderRadius: '4px', background: '#f1f5f9', border: '1px solid #cbd5e1', color: '#334155', fontWeight: 600 }}>
                          {(emp as any).creator_name || (emp as any).creator_username || 'Admin'}
                        </span>
                      </td>
                    )}
                    <td style={{ textAlign: 'center' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          onClick={() => handleOpenView(emp)}
                          className="btn btn-secondary btn-sm"
                          style={{ padding: '5px 7px' }}
                          title="View Full Profile & Salary Breakdown"
                        >
                          <Eye size={13} color="#2563eb" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(emp)}
                          className="btn btn-secondary btn-sm"
                          style={{ padding: '5px 7px' }}
                          title="Edit Employee"
                        >
                          <Edit2 size={13} color="#059669" />
                        </button>
                        {emp.archived_at ? (
                          <>
                            <button
                              onClick={() => handleOpenSingleRestore(emp)}
                              className="btn btn-secondary btn-sm"
                              style={{ padding: '5px 7px', borderColor: '#059669', color: '#047857' }}
                              title="Restore Employee to Active"
                            >
                              <RefreshCw size={13} />
                            </button>
                            {isSuperAdminUser && (
                              <button
                                onClick={() => handleOpenSinglePermanentDelete(emp)}
                                className="btn btn-secondary btn-sm"
                                style={{ padding: '5px 7px', borderColor: '#fca5a5', color: '#dc2626' }}
                                title="Permanently Delete Employee (Admin Only)"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => handleOpenSingleArchive(emp)}
                              className="btn btn-secondary btn-sm"
                              style={{ padding: '5px 7px', borderColor: '#f59e0b', color: '#b45309' }}
                              title="Archive Employee (Safe Deactivation)"
                            >
                              <Archive size={13} />
                            </button>
                            {isSuperAdminUser && (
                              <button
                                onClick={() => handleOpenSinglePermanentDelete(emp)}
                                className="btn btn-secondary btn-sm"
                                style={{ padding: '5px 7px', borderColor: '#fca5a5', color: '#dc2626' }}
                                title="Permanently Delete Employee (Admin Only)"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px' }}>
          <div style={{ fontSize: '13px', color: '#64748b' }}>
            Showing page {page} of {totalPages} ({totalCount} total contractual employees)
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="btn btn-secondary btn-sm"
            >
              Previous
            </button>
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="btn btn-secondary btn-sm"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {/* ==================== ADD / EDIT EMPLOYEE MODAL ==================== */}
      {isAddEditModalOpen && editingEmployee && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '900px', maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
            <div className="modal-header">
              <div>
                <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0f172a', margin: 0 }}>
                  {editingEmployee.id ? `Edit Employee Record: ${editingEmployee.name} (${editingEmployee.emp_code})` : 'Register New Contractual Employee'}
                </h3>
                <p style={{ fontSize: '12px', color: '#64748b', margin: '2px 0 0' }}>
                  Complete registration form with live designation-based salary calculation and statutory settings.
                </p>
              </div>
              <button onClick={() => setIsAddEditModalOpen(false)} style={{ color: '#64748b', background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            {/* Modal Tabs */}
            <div style={{ display: 'flex', borderBottom: '1px solid #e2e8f0', background: '#f8fafc', padding: '0 20px' }}>
              <button
                type="button"
                onClick={() => setFormTab('personal')}
                style={{
                  padding: '12px 18px', border: 'none', background: 'none', cursor: 'pointer',
                  fontWeight: formTab === 'personal' ? 700 : 500,
                  color: formTab === 'personal' ? '#2563eb' : '#64748b',
                  borderBottom: formTab === 'personal' ? '3px solid #2563eb' : '3px solid transparent'
                }}
              >
                1. Personal & Employment
              </button>
              <button
                type="button"
                onClick={() => setFormTab('statutory')}
                style={{
                  padding: '12px 18px', border: 'none', background: 'none', cursor: 'pointer',
                  fontWeight: formTab === 'statutory' ? 700 : 500,
                  color: formTab === 'statutory' ? '#2563eb' : '#64748b',
                  borderBottom: formTab === 'statutory' ? '3px solid #2563eb' : '3px solid transparent'
                }}
              >
                2. Identity & Statutory
              </button>
              <button
                type="button"
                onClick={() => setFormTab('salary')}
                style={{
                  padding: '12px 18px', border: 'none', background: 'none', cursor: 'pointer',
                  fontWeight: formTab === 'salary' ? 700 : 500,
                  color: formTab === 'salary' ? '#2563eb' : '#64748b',
                  borderBottom: formTab === 'salary' ? '3px solid #2563eb' : '3px solid transparent'
                }}
              >
                3. Salary Structure & Live Calculation
              </button>
            </div>

            <form onSubmit={handleSaveEmployee} style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
              <div className="modal-body" style={{ overflowY: 'auto', padding: '20px', flex: 1 }}>
                {/* TAB 1: Personal & Employment */}
                {formTab === 'personal' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Employee Code *</label>
                        <div style={{ display: 'flex', gap: '6px' }}>
                          <input
                            type="text"
                            required
                            className="form-input"
                            value={editingEmployee.emp_code || ''}
                            onChange={(e) => setEditingEmployee({ ...editingEmployee, emp_code: e.target.value })}
                          />
                          <button
                            type="button"
                            onClick={() => setEditingEmployee({ ...editingEmployee, emp_code: `EMP-${Math.floor(100 + Math.random() * 900)}` })}
                            className="btn btn-secondary btn-sm"
                            title="Auto-Generate New Code"
                          >
                            <RefreshCw size={13} />
                          </button>
                        </div>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Employee Full Name *</label>
                        <input
                          type="text"
                          required
                          className="form-input"
                          value={editingEmployee.name || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, name: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Father's Name</label>
                        <input
                          type="text"
                          className="form-input"
                          value={editingEmployee.father_name || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, father_name: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Designation *</label>
                        <select
                          className="form-input"
                          value={editingEmployee.designation_id || ''}
                          onChange={(e) => handleDesignationChange(Number(e.target.value))}
                        >
                          {designations.map(d => (
                            <option key={d.id} value={d.id}>{d.name} ({d.alias})</option>
                          ))}
                        </select>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Contractor / Service Provider</label>
                        <select
                          className="form-input"
                          value={editingEmployee.contractor_id || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, contractor_id: Number(e.target.value) || undefined })}
                        >
                          <option value="">Select Contractor</option>
                          {contractors.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Plant Circle</label>
                        <select
                          className="form-input"
                          value={editingEmployee.circle_id || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, circle_id: Number(e.target.value) || undefined })}
                        >
                          <option value="">Select Circle</option>
                          {circles.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Cell / Work Location</label>
                        <input
                          type="text"
                          placeholder="e.g. EM-1, EM-2, EM-3, MM-1"
                          className="form-input"
                          value={editingEmployee.cell || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, cell: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Date of Birth</label>
                        <input
                          type="text"
                          placeholder="DD-MM-YYYY"
                          className="form-input"
                          value={editingEmployee.dob || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, dob: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Date of Joining</label>
                        <input
                          type="text"
                          placeholder="DD.MM.YYYY"
                          className="form-input"
                          value={editingEmployee.date_of_joining || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, date_of_joining: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Qualification</label>
                        <input
                          type="text"
                          placeholder="e.g. ITI, Diploma, 10th"
                          className="form-input"
                          value={editingEmployee.qualification || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, qualification: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Experience (Years)</label>
                        <input
                          type="text"
                          placeholder="e.g. 5"
                          className="form-input"
                          value={editingEmployee.experience_years || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, experience_years: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Hazard Duty Category</label>
                        <select
                          className="form-input"
                          value={editingEmployee.hazard_duty || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, hazard_duty: e.target.value })}
                        >
                          <option value="haz">Hazard Duty (haz)</option>
                          <option value="none">Standard Duty</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid-4">
                      <div className="form-group">
                        <label className="form-label">Age Above 58?</label>
                        <select
                          className="form-input"
                          value={editingEmployee.age_above_58 || 'N'}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, age_above_58: e.target.value })}
                        >
                          <option value="N">No (Below 58)</option>
                          <option value="Y">Yes (Above 58)</option>
                        </select>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Age Above 60?</label>
                        <select
                          className="form-input"
                          value={editingEmployee.above_60 || 'N'}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, above_60: e.target.value })}
                        >
                          <option value="N">No</option>
                          <option value="Y">Yes</option>
                        </select>
                      </div>

                      <div className="form-group">
                        <label className="form-label">More than 3 Yrs?</label>
                        <select
                          className="form-input"
                          value={editingEmployee.more_than_3_yrs || 'NO'}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, more_than_3_yrs: e.target.value })}
                        >
                          <option value="YES">YES</option>
                          <option value="NO">NO</option>
                        </select>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Employment Status</label>
                        <select
                          className="form-input"
                          value={editingEmployee.is_active ? 'active' : 'inactive'}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, is_active: e.target.value === 'active' })}
                        >
                          <option value="active">Active</option>
                          <option value="inactive">Inactive</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 2: Identity & Statutory */}
                {formTab === 'statutory' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    <div className="card" style={{ padding: '16px', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                      <h4 style={{ fontSize: '14px', fontWeight: 700, margin: '0 0 12px', color: '#1e3a8a' }}>
                        Statutory Scheme Applicability
                      </h4>
                      <div className="grid-3">
                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: 600 }}>
                          <input
                            type="checkbox"
                            checked={editingEmployee.epf_applicable !== false}
                            onChange={(e) => setEditingEmployee({ ...editingEmployee, epf_applicable: e.target.checked })}
                          />
                          <span>EPF Covered (12% Deduction & Share)</span>
                        </label>

                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: 600 }}>
                          <input
                            type="checkbox"
                            checked={editingEmployee.esi_applicable !== false}
                            onChange={(e) => setEditingEmployee({ ...editingEmployee, esi_applicable: e.target.checked })}
                          />
                          <span>ESI Covered (0.75% / 3.25%)</span>
                        </label>

                        <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px', fontWeight: 600 }}>
                          <input
                            type="checkbox"
                            checked={editingEmployee.lwf_applicable !== false}
                            onChange={(e) => setEditingEmployee({ ...editingEmployee, lwf_applicable: e.target.checked })}
                          />
                          <span>Labour Welfare Fund (LWF)</span>
                        </label>
                      </div>
                      <div style={{ marginTop: '10px', padding: '8px 12px', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '6px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '12px', color: '#1e40af' }}>
                          💡 <strong>Custom Statutory Amounts:</strong> You can edit individual EPF, ESI, and LWF amounts, delete them, or leave them blank under <strong>Tab 3 (Salary Structure & Live Calculation)</strong>.
                        </span>
                        <button
                          type="button"
                          onClick={() => setFormTab('salary')}
                          className="btn btn-secondary btn-sm"
                          style={{ fontSize: '11px', padding: '3px 8px', color: '#1d4ed8', borderColor: '#93c5fd', whiteSpace: 'nowrap' }}
                        >
                          Go to Tab 3 →
                        </button>
                      </div>
                    </div>

                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">UAN Number</label>
                        <input
                          type="text"
                          className="form-input"
                          value={editingEmployee.uan || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, uan: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">ESI Identifier / Insurance No.</label>
                        <input
                          type="text"
                          className="form-input"
                          value={editingEmployee.esi_number || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, esi_number: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">EPF Statutory Joining Date</label>
                        <input
                          type="text"
                          placeholder="DD.MM.YYYY"
                          className="form-input"
                          value={editingEmployee.epf_statutory_doj || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, epf_statutory_doj: e.target.value })}
                        />
                      </div>
                    </div>

                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Bank Name</label>
                        <input
                          type="text"
                          placeholder="e.g. State Bank of India"
                          className="form-input"
                          value={editingEmployee.bank_name || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, bank_name: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Bank Account Number</label>
                        <input
                          type="text"
                          className="form-input"
                          value={editingEmployee.bank_account || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, bank_account: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">IFSC Code</label>
                        <input
                          type="text"
                          placeholder="e.g. SBIN0050302"
                          className="form-input"
                          value={editingEmployee.ifsc || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, ifsc: e.target.value.toUpperCase() })}
                        />
                      </div>
                    </div>

                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Account Holder Name</label>
                        <input
                          type="text"
                          className="form-input"
                          value={editingEmployee.account_holder_name || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, account_holder_name: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Aadhar Number</label>
                        <input
                          type="text"
                          className="form-input"
                          value={editingEmployee.aadhar_number || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, aadhar_number: e.target.value })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">PAN Number</label>
                        <input
                          type="text"
                          className="form-input"
                          value={editingEmployee.pan_number || ''}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, pan_number: e.target.value.toUpperCase() })}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* TAB 3: Salary Components & Live Calculator */}
                {formTab === 'salary' && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Gross Salary / Wage Rate (₹)</label>
                        <input
                          type="number"
                          className="form-input"
                          value={editingEmployee.default_gross_rate ?? 16530}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, default_gross_rate: Number(e.target.value) })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Special Allowance (₹)</label>
                        <input
                          type="number"
                          className="form-input"
                          value={editingEmployee.default_special_allowance ?? 3802}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, default_special_allowance: Number(e.target.value) })}
                        />
                      </div>

                      <div className="form-group">
                        <label className="form-label">Thermal Allowance Base (₹)</label>
                        <input
                          type="number"
                          className="form-input"
                          value={editingEmployee.default_thermal_allowance ?? 1500}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, default_thermal_allowance: Number(e.target.value) })}
                        />
                      </div>
                    </div>

                    <div className="grid-3">
                      <div className="form-group">
                        <label className="form-label">Monthly Performance Allowance (₹)</label>
                        <input
                          type="number"
                          className="form-input"
                          value={editingEmployee.default_perf_allowance ?? 0}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, default_perf_allowance: Number(e.target.value) })}
                        />
                      </div>

                      <div className="form-group">
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                          <label className="form-label" style={{ margin: 0 }}>Bonus Rate (% of Basic)</label>
                          <div style={{ display: 'flex', gap: '4px' }}>
                            <button
                              type="button"
                              onClick={() => setEditingEmployee({ ...editingEmployee, default_bonus_percentage: 8.33 })}
                              className="btn btn-secondary btn-sm"
                              style={{ fontSize: '10.5px', padding: '1px 6px', height: '22px' }}
                              title="Set standard 8.33% bonus"
                            >
                              8.33% Standard
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingEmployee({ ...editingEmployee, default_bonus_percentage: null })}
                              className="btn btn-secondary btn-sm"
                              style={{ fontSize: '10.5px', padding: '1px 6px', height: '22px', borderColor: '#fca5a5', color: '#dc2626' }}
                              title="Leave blank (evaluates to ₹0 bonus)"
                            >
                              Leave Blank (₹0)
                            </button>
                          </div>
                        </div>
                        <input
                          type="number"
                          step="0.01"
                          placeholder="Leave blank for ₹0 or enter %"
                          className="form-input"
                          value={editingEmployee.default_bonus_percentage !== undefined && editingEmployee.default_bonus_percentage !== null ? editingEmployee.default_bonus_percentage : ''}
                          onChange={(e) => {
                            const val = e.target.value.trim();
                            setEditingEmployee({
                              ...editingEmployee,
                              default_bonus_percentage: val === '' ? null : Number(val)
                            });
                          }}
                        />
                        <span style={{ fontSize: '11px', color: editingEmployee.default_bonus_percentage !== undefined && editingEmployee.default_bonus_percentage !== null && (editingEmployee.default_bonus_percentage as any) !== '' ? '#059669' : '#dc2626', marginTop: '2px', display: 'block', fontWeight: 600 }}>
                          {editingEmployee.default_bonus_percentage !== undefined && editingEmployee.default_bonus_percentage !== null && (editingEmployee.default_bonus_percentage as any) !== ''
                            ? `Active: ${editingEmployee.default_bonus_percentage}% of Basic (Bonus: ₹${liveFormCalculation?.bonus?.toLocaleString('en-IN') || 0})`
                            : '⭕ Blank / 0% — No bonus will be added (₹0)'}
                        </span>
                      </div>

                      <div className="form-group">
                        <label className="form-label">Other Monthly Allowances (₹)</label>
                        <input
                          type="number"
                          className="form-input"
                          value={editingEmployee.other_allowances ?? 0}
                          onChange={(e) => setEditingEmployee({ ...editingEmployee, other_allowances: Number(e.target.value) })}
                        />
                      </div>
                    </div>

                    {/* ==================== STATUTORY CONTRIBUTIONS & DEDUCTIONS CARD ==================== */}
                    <div style={{
                      background: '#ffffff',
                      border: '1.5px solid #3b82f6',
                      borderRadius: '8px',
                      padding: '16px',
                      boxShadow: '0 2px 5px rgba(59, 130, 246, 0.08)'
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap', gap: '8px' }}>
                        <div>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <span style={{ fontSize: '10.5px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.5px', background: '#1e40af', color: '#ffffff', padding: '2px 8px', borderRadius: '4px' }}>
                              STATUTORY MANAGEMENT
                            </span>
                            <h4 style={{ fontSize: '14.5px', fontWeight: 800, margin: 0, color: '#1e3a8a' }}>
                              Statutory Deductions & Contributions (EPF, ESI, LWF)
                            </h4>
                          </div>
                          <p style={{ fontSize: '11.5px', color: '#64748b', margin: '3px 0 0' }}>
                            All statutory amounts are fully editable, can be deleted / left blank (evaluates to ₹0), or calculated via standard Excel formulas.
                          </p>
                        </div>

                        {/* Global Actions Toolbar */}
                        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingEmployee({
                                ...editingEmployee,
                                custom_employee_epf: null,
                                custom_employer_epf: null,
                                custom_employer_epf1: null,
                                custom_employee_esi: null,
                                custom_employer_esi: null,
                                custom_employee_lwf: null,
                                custom_employer_lwf: null
                              });
                            }}
                            className="btn btn-secondary btn-sm"
                            style={{ fontSize: '11px', padding: '4px 10px', fontWeight: 700, borderColor: '#3b82f6', color: '#1d4ed8', background: '#eff6ff' }}
                            title="Auto-calculate all 7 statutory fields from standard Excel formulas"
                          >
                            ⚡ Auto-Calculate All with Excel Formulas
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingEmployee({
                                ...editingEmployee,
                                custom_employee_epf: 0,
                                custom_employer_epf: 0,
                                custom_employer_epf1: 0,
                                custom_employee_esi: 0,
                                custom_employer_esi: 0,
                                custom_employee_lwf: 0,
                                custom_employer_lwf: 0
                              });
                            }}
                            className="btn btn-secondary btn-sm"
                            style={{ fontSize: '11px', padding: '4px 10px', fontWeight: 700, borderColor: '#fca5a5', color: '#dc2626', background: '#fef2f2' }}
                            title="Set all EPF, ESI, and LWF fields to 0 (leave blank / no deductions)"
                          >
                            ⭕ Leave Blank All (₹0 Statutory)
                          </button>
                        </div>
                      </div>

                      <div className="grid-2" style={{ gap: '16px' }}>
                        {/* LEFT COLUMN: Employee Statutory Deductions */}
                        <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '14px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e2e8f0', paddingBottom: '8px', marginBottom: '12px' }}>
                            <span style={{ fontSize: '13px', fontWeight: 700, color: '#991b1b' }}>
                              Employee Deductions (Deducted from Pay)
                            </span>
                            <span style={{ fontSize: '12px', fontWeight: 800, color: '#dc2626', fontFamily: 'monospace' }}>
                              Subtotal: ₹{liveFormCalculation?.totalEmployeeDeductions?.toLocaleString('en-IN') || 0}
                            </span>
                          </div>

                          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                            {/* Employee EPF 12% */}
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                                <label style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>
                                  Employee EPF (12%) Deduction (₹)
                                </label>
                                <div style={{ display: 'flex', gap: '4px' }}>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employee_epf: null })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px' }}
                                    title="Auto-calculate using Excel formula"
                                  >
                                    Auto Formula
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employee_epf: '' })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px', borderColor: '#fca5a5', color: '#dc2626' }}
                                    title="Leave blank (evaluates to ₹0 deduction)"
                                  >
                                    Leave Blank
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                placeholder={`Auto formula: ₹${liveFormCalculation?.autoEmployeeEpf12 || 0}`}
                                className="form-input"
                                value={editingEmployee.custom_employee_epf !== null && editingEmployee.custom_employee_epf !== undefined ? editingEmployee.custom_employee_epf : ''}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  setEditingEmployee({ ...editingEmployee, custom_employee_epf: val === '' ? '' : Number(val) });
                                }}
                                style={{ fontSize: '12.5px' }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginTop: '3px' }}>
                                {editingEmployee.custom_employee_epf === null || editingEmployee.custom_employee_epf === undefined ? (
                                  <span style={{ color: '#2563eb', fontWeight: 600 }}>⚙️ Auto Formula: ₹{liveFormCalculation?.autoEmployeeEpf12}</span>
                                ) : editingEmployee.custom_employee_epf === '' || editingEmployee.custom_employee_epf === 0 || editingEmployee.custom_employee_epf === '0' ? (
                                  <span style={{ color: '#dc2626', fontWeight: 600 }}>⭕ Blank / Deleted (₹0 Deduction)</span>
                                ) : (
                                  <span style={{ color: '#059669', fontWeight: 600 }}>✏️ Custom Amount: ₹{editingEmployee.custom_employee_epf}</span>
                                )}
                                <span style={{ color: '#64748b' }}>Excel MM-1 Col AS</span>
                              </div>
                            </div>

                            {/* Employee ESI 0.75% */}
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                                <label style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>
                                  Employee ESI (0.75%) Deduction (₹)
                                </label>
                                <div style={{ display: 'flex', gap: '4px' }}>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employee_esi: null })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px' }}
                                    title="Auto-calculate using Excel formula"
                                  >
                                    Auto Formula
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employee_esi: '' })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px', borderColor: '#fca5a5', color: '#dc2626' }}
                                    title="Leave blank (evaluates to ₹0 deduction)"
                                  >
                                    Leave Blank
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                placeholder={`Auto formula: ₹${liveFormCalculation?.autoEmployeeEsi075 || 0}`}
                                className="form-input"
                                value={editingEmployee.custom_employee_esi !== null && editingEmployee.custom_employee_esi !== undefined ? editingEmployee.custom_employee_esi : ''}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  setEditingEmployee({ ...editingEmployee, custom_employee_esi: val === '' ? '' : Number(val) });
                                }}
                                style={{ fontSize: '12.5px' }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginTop: '3px' }}>
                                {editingEmployee.custom_employee_esi === null || editingEmployee.custom_employee_esi === undefined ? (
                                  <span style={{ color: '#2563eb', fontWeight: 600 }}>⚙️ Auto Formula: ₹{liveFormCalculation?.autoEmployeeEsi075}</span>
                                ) : editingEmployee.custom_employee_esi === '' || editingEmployee.custom_employee_esi === 0 || editingEmployee.custom_employee_esi === '0' ? (
                                  <span style={{ color: '#dc2626', fontWeight: 600 }}>⭕ Blank / Deleted (₹0 Deduction)</span>
                                ) : (
                                  <span style={{ color: '#059669', fontWeight: 600 }}>✏️ Custom Amount: ₹{editingEmployee.custom_employee_esi}</span>
                                )}
                                <span style={{ color: '#64748b' }}>Excel MM-1 Col AT</span>
                              </div>
                            </div>

                            {/* Employee LWF ₹5 */}
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                                <label style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>
                                  Employee LWF Deduction (₹)
                                </label>
                                <div style={{ display: 'flex', gap: '4px' }}>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employee_lwf: null })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px' }}
                                    title="Auto-calculate using standard ₹5"
                                  >
                                    Auto (₹5)
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employee_lwf: '' })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px', borderColor: '#fca5a5', color: '#dc2626' }}
                                    title="Leave blank (evaluates to ₹0 deduction)"
                                  >
                                    Leave Blank
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                placeholder={`Auto formula: ₹${liveFormCalculation?.autoEmployeeLwf || 5}`}
                                className="form-input"
                                value={editingEmployee.custom_employee_lwf !== null && editingEmployee.custom_employee_lwf !== undefined ? editingEmployee.custom_employee_lwf : ''}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  setEditingEmployee({ ...editingEmployee, custom_employee_lwf: val === '' ? '' : Number(val) });
                                }}
                                style={{ fontSize: '12.5px' }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginTop: '3px' }}>
                                {editingEmployee.custom_employee_lwf === null || editingEmployee.custom_employee_lwf === undefined ? (
                                  <span style={{ color: '#2563eb', fontWeight: 600 }}>⚙️ Standard Rate: ₹{liveFormCalculation?.autoEmployeeLwf}</span>
                                ) : editingEmployee.custom_employee_lwf === '' || editingEmployee.custom_employee_lwf === 0 || editingEmployee.custom_employee_lwf === '0' ? (
                                  <span style={{ color: '#dc2626', fontWeight: 600 }}>⭕ Blank / Deleted (₹0 Deduction)</span>
                                ) : (
                                  <span style={{ color: '#059669', fontWeight: 600 }}>✏️ Custom Amount: ₹{editingEmployee.custom_employee_lwf}</span>
                                )}
                                <span style={{ color: '#64748b' }}>Excel MM-1 Col AU</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* RIGHT COLUMN: Employer Statutory Contributions */}
                        <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '14px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e2e8f0', paddingBottom: '8px', marginBottom: '12px' }}>
                            <span style={{ fontSize: '13px', fontWeight: 700, color: '#166534' }}>
                              Employer Contributions (Added to Gross)
                            </span>
                            <span style={{ fontSize: '12px', fontWeight: 800, color: '#15803d', fontFamily: 'monospace' }}>
                              Subtotal: ₹{liveFormCalculation?.totalEmployerContributions?.toLocaleString('en-IN') || 0}
                            </span>
                          </div>

                          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                            {/* Employer EPF 12% */}
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                                <label style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>
                                  Employer EPF (12%) Share (₹)
                                </label>
                                <div style={{ display: 'flex', gap: '4px' }}>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_epf: null })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px' }}
                                    title="Auto-calculate using Excel formula"
                                  >
                                    Auto Formula
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_epf: '' })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px', borderColor: '#fca5a5', color: '#dc2626' }}
                                    title="Leave blank (evaluates to ₹0 contribution)"
                                  >
                                    Leave Blank
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                placeholder={`Auto formula: ₹${liveFormCalculation?.autoEmployerEpf12 || 0}`}
                                className="form-input"
                                value={editingEmployee.custom_employer_epf !== null && editingEmployee.custom_employer_epf !== undefined ? editingEmployee.custom_employer_epf : ''}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  setEditingEmployee({ ...editingEmployee, custom_employer_epf: val === '' ? '' : Number(val) });
                                }}
                                style={{ fontSize: '12.5px' }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginTop: '3px' }}>
                                {editingEmployee.custom_employer_epf === null || editingEmployee.custom_employer_epf === undefined ? (
                                  <span style={{ color: '#2563eb', fontWeight: 600 }}>⚙️ Auto Formula: ₹{liveFormCalculation?.autoEmployerEpf12}</span>
                                ) : editingEmployee.custom_employer_epf === '' || editingEmployee.custom_employer_epf === 0 || editingEmployee.custom_employer_epf === '0' ? (
                                  <span style={{ color: '#dc2626', fontWeight: 600 }}>⭕ Blank / Deleted (₹0 Contribution)</span>
                                ) : (
                                  <span style={{ color: '#059669', fontWeight: 600 }}>✏️ Custom Amount: ₹{editingEmployee.custom_employer_epf}</span>
                                )}
                                <span style={{ color: '#64748b' }}>Excel MM-1 Col X</span>
                              </div>
                            </div>

                            {/* Employer EPF 1% */}
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                                <label style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>
                                  Employer EPF Admin / EDLI (1%) (₹)
                                </label>
                                <div style={{ display: 'flex', gap: '4px' }}>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_epf1: null })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px' }}
                                    title="Auto-calculate using Excel formula"
                                  >
                                    Auto Formula
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_epf1: '' })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px', borderColor: '#fca5a5', color: '#dc2626' }}
                                    title="Leave blank (evaluates to ₹0 contribution)"
                                  >
                                    Leave Blank
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                placeholder={`Auto formula: ₹${liveFormCalculation?.autoEmployerEpf1 || 0}`}
                                className="form-input"
                                value={editingEmployee.custom_employer_epf1 !== null && editingEmployee.custom_employer_epf1 !== undefined ? editingEmployee.custom_employer_epf1 : ''}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  setEditingEmployee({ ...editingEmployee, custom_employer_epf1: val === '' ? '' : Number(val) });
                                }}
                                style={{ fontSize: '12.5px' }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginTop: '3px' }}>
                                {editingEmployee.custom_employer_epf1 === null || editingEmployee.custom_employer_epf1 === undefined ? (
                                  <span style={{ color: '#2563eb', fontWeight: 600 }}>⚙️ Auto Formula: ₹{liveFormCalculation?.autoEmployerEpf1}</span>
                                ) : editingEmployee.custom_employer_epf1 === '' || editingEmployee.custom_employer_epf1 === 0 || editingEmployee.custom_employer_epf1 === '0' ? (
                                  <span style={{ color: '#dc2626', fontWeight: 600 }}>⭕ Blank / Deleted (₹0 Contribution)</span>
                                ) : (
                                  <span style={{ color: '#059669', fontWeight: 600 }}>✏️ Custom Amount: ₹{editingEmployee.custom_employer_epf1}</span>
                                )}
                                <span style={{ color: '#64748b' }}>Excel MM-1 Col Y</span>
                              </div>
                            </div>

                            {/* Employer ESI 3.25% */}
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                                <label style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>
                                  Employer ESI (3.25%) Share (₹)
                                </label>
                                <div style={{ display: 'flex', gap: '4px' }}>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_esi: null })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px' }}
                                    title="Auto-calculate using Excel formula"
                                  >
                                    Auto Formula
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_esi: '' })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px', borderColor: '#fca5a5', color: '#dc2626' }}
                                    title="Leave blank (evaluates to ₹0 contribution)"
                                  >
                                    Leave Blank
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                placeholder={`Auto formula: ₹${liveFormCalculation?.autoEmployerEsi325 || 0}`}
                                className="form-input"
                                value={editingEmployee.custom_employer_esi !== null && editingEmployee.custom_employer_esi !== undefined ? editingEmployee.custom_employer_esi : ''}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  setEditingEmployee({ ...editingEmployee, custom_employer_esi: val === '' ? '' : Number(val) });
                                }}
                                style={{ fontSize: '12.5px' }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginTop: '3px' }}>
                                {editingEmployee.custom_employer_esi === null || editingEmployee.custom_employer_esi === undefined ? (
                                  <span style={{ color: '#2563eb', fontWeight: 600 }}>⚙️ Auto Formula: ₹{liveFormCalculation?.autoEmployerEsi325}</span>
                                ) : editingEmployee.custom_employer_esi === '' || editingEmployee.custom_employer_esi === 0 || editingEmployee.custom_employer_esi === '0' ? (
                                  <span style={{ color: '#dc2626', fontWeight: 600 }}>⭕ Blank / Deleted (₹0 Contribution)</span>
                                ) : (
                                  <span style={{ color: '#059669', fontWeight: 600 }}>✏️ Custom Amount: ₹{editingEmployee.custom_employer_esi}</span>
                                )}
                                <span style={{ color: '#64748b' }}>Excel MM-1 Col Z</span>
                              </div>
                            </div>

                            {/* Employer LWF ₹20 */}
                            <div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '3px' }}>
                                <label style={{ fontSize: '12px', fontWeight: 600, color: '#334155' }}>
                                  Employer LWF Share (₹)
                                </label>
                                <div style={{ display: 'flex', gap: '4px' }}>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_lwf: null })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px' }}
                                    title="Auto-calculate using standard ₹20"
                                  >
                                    Auto (₹20)
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setEditingEmployee({ ...editingEmployee, custom_employer_lwf: '' })}
                                    className="btn btn-secondary btn-sm"
                                    style={{ fontSize: '10px', padding: '1px 5px', height: '20px', borderColor: '#fca5a5', color: '#dc2626' }}
                                    title="Leave blank (evaluates to ₹0 contribution)"
                                  >
                                    Leave Blank
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                placeholder={`Auto formula: ₹${liveFormCalculation?.autoEmployerLwf || 20}`}
                                className="form-input"
                                value={editingEmployee.custom_employer_lwf !== null && editingEmployee.custom_employer_lwf !== undefined ? editingEmployee.custom_employer_lwf : ''}
                                onChange={(e) => {
                                  const val = e.target.value.trim();
                                  setEditingEmployee({ ...editingEmployee, custom_employer_lwf: val === '' ? '' : Number(val) });
                                }}
                                style={{ fontSize: '12.5px' }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10.5px', marginTop: '3px' }}>
                                {editingEmployee.custom_employer_lwf === null || editingEmployee.custom_employer_lwf === undefined ? (
                                  <span style={{ color: '#2563eb', fontWeight: 600 }}>⚙️ Standard Rate: ₹{liveFormCalculation?.autoEmployerLwf}</span>
                                ) : editingEmployee.custom_employer_lwf === '' || editingEmployee.custom_employer_lwf === 0 || editingEmployee.custom_employer_lwf === '0' ? (
                                  <span style={{ color: '#dc2626', fontWeight: 600 }}>⭕ Blank / Deleted (₹0 Contribution)</span>
                                ) : (
                                  <span style={{ color: '#059669', fontWeight: 600 }}>✏️ Custom Amount: ₹{editingEmployee.custom_employer_lwf}</span>
                                )}
                                <span style={{ color: '#64748b' }}>Excel MM-1 Col AA</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* ATTENDANCE SIMULATION & LIVE SALARY SUMMARY CARD */}
                    {liveFormCalculation && (
                      <div style={{ background: '#f8fafc', border: '1px solid #cbd5e1', borderRadius: '8px', padding: '16px' }}>
                        {/* Attendance Simulation Bar */}
                        <div style={{ background: '#ffffff', border: '1px solid #cbd5e1', borderRadius: '8px', padding: '12px 14px', marginBottom: '14px' }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', flexWrap: 'wrap', gap: '8px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                              <Calculator size={16} color="#2563eb" />
                              <span style={{ fontWeight: 800, color: '#1e3a8a', fontSize: '13px' }}>
                                Attendance Simulation & Proportioned Salary Calculator
                              </span>
                            </div>
                            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                              <button
                                type="button"
                                onClick={() => { setSimTotalDays(30); setSimPresentDays(30); }}
                                className="btn btn-secondary btn-sm"
                                style={{ fontSize: '11px', padding: '3px 8px', fontWeight: simPresentDays === 30 ? 700 : 500, borderColor: simPresentDays === 30 ? '#2563eb' : '#cbd5e1', color: simPresentDays === 30 ? '#2563eb' : '#475569' }}
                              >
                                Full Month (30 Days)
                              </button>
                              <button
                                type="button"
                                onClick={() => { setSimTotalDays(30); setSimPresentDays(7); }}
                                className="btn btn-secondary btn-sm"
                                style={{ fontSize: '11px', padding: '3px 8px', fontWeight: simPresentDays === 7 ? 700 : 500, borderColor: simPresentDays === 7 ? '#2563eb' : '#cbd5e1', color: simPresentDays === 7 ? '#2563eb' : '#475569' }}
                                title="Matches MM-1 sheet sample rows with 7 attended days"
                              >
                                7 Days (MM-1 Sample)
                              </button>
                              <button
                                type="button"
                                onClick={() => { setSimTotalDays(30); setSimPresentDays(15); }}
                                className="btn btn-secondary btn-sm"
                                style={{ fontSize: '11px', padding: '3px 8px', fontWeight: simPresentDays === 15 ? 700 : 500, borderColor: simPresentDays === 15 ? '#2563eb' : '#cbd5e1', color: simPresentDays === 15 ? '#2563eb' : '#475569' }}
                              >
                                15 Days
                              </button>
                              <button
                                type="button"
                                onClick={() => { setSimTotalDays(30); setSimPresentDays(26); }}
                                className="btn btn-secondary btn-sm"
                                style={{ fontSize: '11px', padding: '3px 8px', fontWeight: simPresentDays === 26 ? 700 : 500, borderColor: simPresentDays === 26 ? '#2563eb' : '#cbd5e1', color: simPresentDays === 26 ? '#2563eb' : '#475569' }}
                              >
                                26 Days
                              </button>
                            </div>
                          </div>

                          <div className="grid-2" style={{ gap: '12px' }}>
                            <div>
                              <label style={{ fontSize: '11.5px', fontWeight: 600, color: '#475569', display: 'block', marginBottom: '3px' }}>
                                Total Calendar Days in Month (Days)
                              </label>
                              <input
                                type="number"
                                min={1}
                                max={31}
                                className="form-input"
                                value={simTotalDays}
                                onChange={(e) => setSimTotalDays(Math.max(1, Number(e.target.value) || 30))}
                                style={{ padding: '6px 10px', fontSize: '13px' }}
                              />
                            </div>
                            <div>
                              <label style={{ fontSize: '11.5px', fontWeight: 600, color: '#475569', display: 'block', marginBottom: '3px' }}>
                                Present Attended Days (Present Days)
                              </label>
                              <input
                                type="number"
                                min={0}
                                max={simTotalDays}
                                className="form-input"
                                value={simPresentDays}
                                onChange={(e) => setSimPresentDays(Math.max(0, Number(e.target.value) || 0))}
                                style={{ padding: '6px 10px', fontSize: '13px' }}
                              />
                            </div>
                          </div>
                        </div>

                        {/* EXCEL PROPORTIONED SALARY ROW & LIVE FORMULA */}
                        <div style={{
                          background: '#eff6ff',
                          border: '2px solid #2563eb',
                          borderRadius: '8px',
                          padding: '14px 16px',
                          marginBottom: '14px',
                          boxShadow: '0 2px 4px rgba(37, 99, 235, 0.08)'
                        }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                            <div style={{ flex: 1, minWidth: '280px' }}>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                                <span style={{ fontSize: '10.5px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.5px', background: '#2563eb', color: '#ffffff', padding: '3px 8px', borderRadius: '4px' }}>
                                  EXCEL FORMULA ROW
                                </span>
                                <span style={{ fontSize: '15px', fontWeight: 800, color: '#1e3a8a' }}>
                                  PROPORTIONED SALARY (MM-1 Col P / EMC Col AD)
                                </span>
                              </div>
                              <div style={{ fontFamily: 'monospace', fontSize: '12.5px', fontWeight: 700, color: '#1d4ed8', background: '#dbeafe', padding: '5px 10px', borderRadius: '4px', display: 'inline-block', margin: '4px 0' }}>
                                Formula: =ROUND((Gross Salary Rate / Total Month Days) * Present Days, 0)
                              </div>
                              <div style={{ fontSize: '11.5px', color: '#475569', marginTop: '4px', lineHeight: '1.4' }}>
                                <strong>Excel Reference:</strong> MM-1 Col P `=ROUND((O3/M3)*N3, 0)` | EMC Col AD `=AB3/Z3*AA3`<br />
                                <strong>Statutory Role:</strong> Evaluated for EPF 12% deduction ceiling (&lt; ₹25,000 threshold).
                              </div>
                            </div>
                            <div style={{ textAlign: 'right', background: '#ffffff', padding: '12px 18px', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
                              <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 700, textTransform: 'uppercase' }}>Proportioned Salary</div>
                              <div style={{ fontSize: '24px', fontWeight: 900, color: '#1d4ed8', fontFamily: 'monospace' }}>
                                ₹{liveFormCalculation.proportionedSalary.toLocaleString('en-IN')}
                              </div>
                              <div style={{ fontSize: '11px', color: '#64748b' }}>
                                (₹{liveFormCalculation.grossSalaryRate.toLocaleString('en-IN')} ÷ {liveFormCalculation.totalDays} × {liveFormCalculation.presentDays} days)
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Breakdown Component Cards */}
                        <div className="grid-4" style={{ gap: '10px', marginBottom: '12px' }}>
                          <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #bfdbfe' }}>
                            <div style={{ fontSize: '11px', color: '#1d4ed8', fontWeight: 700 }}>Proportioned Salary (Col P)</div>
                            <div style={{ fontSize: '15px', fontWeight: 800, color: '#1e3a8a' }}>
                              ₹{liveFormCalculation.proportionedSalary.toLocaleString('en-IN')}
                            </div>
                            <div style={{ fontSize: '10px', color: '#64748b' }}>Days-wise prorated</div>
                          </div>

                          <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                            <div style={{ fontSize: '11px', color: '#64748b' }}>Total Basic (Col R)</div>
                            <div style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                              ₹{liveFormCalculation.totalBasic.toLocaleString('en-IN')}
                            </div>
                            <div style={{ fontSize: '10px', color: '#94a3b8' }}>Gross + Special</div>
                          </div>

                          <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                            <div style={{ fontSize: '11px', color: '#64748b' }}>Thermal Allowance (Col S)</div>
                            <div style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                              ₹{liveFormCalculation.thermalAllowance.toLocaleString('en-IN')}
                            </div>
                            <div style={{ fontSize: '10px', color: '#94a3b8' }}>₹1,500 Base</div>
                          </div>

                          <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                            <div style={{ fontSize: '11px', color: '#64748b' }}>Bonus ({liveFormCalculation.bonusPct}%)</div>
                            <div style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                              ₹{liveFormCalculation.bonus.toLocaleString('en-IN')}
                            </div>
                            <div style={{ fontSize: '10px', color: '#94a3b8' }}>On Total Basic</div>
                          </div>
                        </div>

                        <div className="grid-3" style={{ gap: '10px', marginBottom: '14px' }}>
                          <div style={{ background: '#ecfdf5', padding: '12px', borderRadius: '6px', border: '1px solid #a7f3d0' }}>
                            <div style={{ fontSize: '12px', fontWeight: 600, color: '#065f46' }}>Gross Total (Col AB)</div>
                            <div style={{ fontSize: '17px', fontWeight: 800, color: '#047857' }}>
                              ₹{liveFormCalculation.grossTotal.toLocaleString('en-IN')}
                            </div>
                            <div style={{ fontSize: '11px', color: '#059669' }}>Earnings + Employer Contrib.</div>
                          </div>

                          <div style={{ background: '#fef2f2', padding: '12px', borderRadius: '6px', border: '1px solid #fecaca' }}>
                            <div style={{ fontSize: '12px', fontWeight: 600, color: '#991b1b' }}>Employee Deductions (Col AH)</div>
                            <div style={{ fontSize: '17px', fontWeight: 800, color: '#dc2626' }}>
                              ₹{liveFormCalculation.totalEmployeeDeductions.toLocaleString('en-IN')}
                            </div>
                            <div style={{ fontSize: '11px', color: '#b91c1c' }}>
                              EPF: ₹{liveFormCalculation.employeeEpf12} • ESI: ₹{liveFormCalculation.employeeEsi075} • LWF: ₹{liveFormCalculation.employeeLwf}
                            </div>
                          </div>

                          <div style={{ background: '#1e3a8a', padding: '12px', borderRadius: '6px', color: '#ffffff' }}>
                            <div style={{ fontSize: '12px', fontWeight: 600, color: '#93c5fd' }}>Net Payable Salary (Col AI)</div>
                            <div style={{ fontSize: '20px', fontWeight: 900, color: '#ffffff' }}>
                              ₹{liveFormCalculation.netPayable.toLocaleString('en-IN')}
                            </div>
                            <div style={{ fontSize: '11px', color: '#bfdbfe' }}>Net Cash Take-Home</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '14px 20px', display: 'flex', justifyContent: 'space-between', background: '#f8fafc' }}>
                <div style={{ display: 'flex', gap: '8px' }}>
                  {formTab !== 'personal' && (
                    <button type="button" onClick={() => setFormTab(formTab === 'salary' ? 'statutory' : 'personal')} className="btn btn-secondary btn-sm">
                      Back
                    </button>
                  )}
                  {formTab !== 'salary' && (
                    <button type="button" onClick={() => setFormTab(formTab === 'personal' ? 'statutory' : 'salary')} className="btn btn-secondary btn-sm">
                      Next Step
                    </button>
                  )}
                </div>

                <div style={{ display: 'flex', gap: '8px' }}>
                  <button type="button" onClick={() => setIsAddEditModalOpen(false)} className="btn btn-secondary">
                    Cancel
                  </button>
                  <button type="submit" className="btn btn-primary" style={{ fontWeight: 700 }}>
                    Save Employee Permanently
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== VIEW EMPLOYEE DOSSIER MODAL ==================== */}
      {isViewModalOpen && viewingEmployee && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '850px' }}>
            <div className="modal-header">
              <div>
                <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0f172a', margin: 0 }}>
                  Employee Profile Dossier: {viewingEmployee.name}
                </h3>
                <span style={{ fontSize: '12px', color: '#64748b' }}>
                  Code: {viewingEmployee.emp_code} • UAN: {viewingEmployee.uan || 'N/A'} • Status: {viewingEmployee.is_active ? 'Active' : 'Inactive'}
                </span>
              </div>
              <button onClick={() => setIsViewModalOpen(false)} style={{ color: '#64748b', background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body" style={{ maxHeight: '75vh', overflowY: 'auto', padding: '20px' }}>
              {/* Personal Grid */}
              <div style={{ marginBottom: '16px' }}>
                <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#1e3a8a', borderBottom: '1px solid #e2e8f0', paddingBottom: '4px', margin: '0 0 10px' }}>
                  Personal & Employment Details
                </h4>
                <div className="grid-3" style={{ fontSize: '13px', rowGap: '8px' }}>
                  <div><strong>Father's Name:</strong> {viewingEmployee.father_name || '—'}</div>
                  <div><strong>Designation:</strong> {viewingEmployee.designation_alias || 'SW'} ({viewingEmployee.designation_name || 'Skilled'})</div>
                  <div><strong>Contractor:</strong> {viewingEmployee.contractor_name || 'M/s Sodhi Erectors'}</div>
                  <div><strong>Circle / Cell:</strong> {viewingEmployee.circle_name || 'GGSSTP'} / {viewingEmployee.cell || 'EM-1'}</div>
                  <div><strong>Date of Joining:</strong> {viewingEmployee.date_of_joining || '—'}</div>
                  <div><strong>Date of Birth:</strong> {viewingEmployee.dob || '—'}</div>
                  <div><strong>Qualification:</strong> {viewingEmployee.qualification || '—'}</div>
                  <div><strong>Experience:</strong> {viewingEmployee.experience_years ? `${viewingEmployee.experience_years} Years` : '—'}</div>
                  <div><strong>Hazard Duty:</strong> {viewingEmployee.hazard_duty || 'haz'}</div>
                  <div><strong>Age Above 58:</strong> {viewingEmployee.age_above_58 === 'Y' ? 'YES' : 'NO'}</div>
                  <div><strong>More than 3 Yrs:</strong> {viewingEmployee.more_than_3_yrs || 'NO'}</div>
                  <div><strong>More than 5 Yrs:</strong> {viewingEmployee.more_than_5_yrs || 'NO'}</div>
                </div>
              </div>

              {/* Statutory & Bank Grid */}
              <div style={{ marginBottom: '16px' }}>
                <h4 style={{ fontSize: '13px', fontWeight: 700, color: '#1e3a8a', borderBottom: '1px solid #e2e8f0', paddingBottom: '4px', margin: '0 0 10px' }}>
                  Bank & Statutory Coverage
                </h4>
                <div className="grid-3" style={{ fontSize: '13px', rowGap: '8px' }}>
                  <div><strong>Bank Name:</strong> {viewingEmployee.bank_name || 'State Bank of India'}</div>
                  <div><strong>Account Number:</strong> {viewingEmployee.bank_account || '—'}</div>
                  <div><strong>IFSC Code:</strong> {viewingEmployee.ifsc || '—'}</div>
                  <div><strong>UAN Number:</strong> {viewingEmployee.uan || '—'}</div>
                  <div><strong>ESI Number:</strong> {viewingEmployee.esi_number || '—'}</div>
                  <div><strong>EPF Covered:</strong> {viewingEmployee.epf_applicable !== false ? 'YES (12%)' : 'NO'}</div>
                  <div><strong>ESI Covered:</strong> {viewingEmployee.esi_applicable !== false ? 'YES' : 'NO'}</div>
                  <div><strong>LWF Covered:</strong> {viewingEmployee.lwf_applicable !== false ? 'YES (₹5)' : 'NO'}</div>
                  <div><strong>PAN Number:</strong> {viewingEmployee.pan_number || '—'}</div>
                </div>
              </div>

              {/* Salary Breakdown Card */}
              {viewingEmployee.calculated_salary && (
                <div style={{ background: '#f8fafc', border: '1px solid #cbd5e1', borderRadius: '8px', padding: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                    <h4 style={{ fontSize: '13px', fontWeight: 800, color: '#0f172a', margin: 0 }}>
                      Calculated Monthly Salary Breakdown (Standard 30 Days Reference)
                    </h4>
                    <span style={{ fontSize: '11px', color: '#64748b' }}>
                      Auto-calculated per Excel reference formulas
                    </span>
                  </div>

                  {/* PROPORTIONED SALARY ROW & LIVE FORMULA */}
                  <div style={{
                    background: '#eff6ff',
                    border: '2px solid #2563eb',
                    borderRadius: '8px',
                    padding: '14px 16px',
                    marginBottom: '14px',
                    boxShadow: '0 2px 4px rgba(37, 99, 235, 0.08)'
                  }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
                      <div style={{ flex: 1, minWidth: '280px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                          <span style={{ fontSize: '10.5px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.5px', background: '#2563eb', color: '#ffffff', padding: '3px 8px', borderRadius: '4px' }}>
                            EXCEL FORMULA ROW
                          </span>
                          <span style={{ fontSize: '15px', fontWeight: 800, color: '#1e3a8a' }}>
                            PROPORTIONED SALARY (MM-1 Col P / EMC Col AD)
                          </span>
                        </div>
                        <div style={{ fontFamily: 'monospace', fontSize: '12.5px', fontWeight: 700, color: '#1d4ed8', background: '#dbeafe', padding: '5px 10px', borderRadius: '4px', display: 'inline-block', margin: '4px 0' }}>
                          Formula: =ROUND((Gross Salary Rate / Total Month Days) * Present Days, 0)
                        </div>
                        <div style={{ fontSize: '11.5px', color: '#475569', marginTop: '4px', lineHeight: '1.4' }}>
                          <strong>Excel Reference:</strong> MM-1 Sheet Col P `=ROUND((O3/M3)*N3, 0)` | EMC Sheet Col AD `=AB3/Z3*AA3`<br />
                          <strong>Statutory Role:</strong> Evaluated for EPF 12% deduction ceiling (&lt; ₹25,000 threshold).
                        </div>
                      </div>
                      <div style={{ textAlign: 'right', background: '#ffffff', padding: '12px 18px', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
                        <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 700, textTransform: 'uppercase' }}>Proportioned Salary</div>
                        <div style={{ fontSize: '24px', fontWeight: 900, color: '#1d4ed8', fontFamily: 'monospace' }}>
                          ₹{(viewingEmployee.calculated_salary.proportionedSalary || viewingEmployee.calculated_salary.grossSalaryRate).toLocaleString('en-IN')}
                        </div>
                        <div style={{ fontSize: '11px', color: '#64748b' }}>
                          (Standard 30 Days Reference)
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid-4" style={{ gap: '10px', marginBottom: '12px' }}>
                    <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #bfdbfe' }}>
                      <div style={{ fontSize: '11px', color: '#1d4ed8', fontWeight: 700 }}>Proportioned Salary (Col P)</div>
                      <div style={{ fontSize: '15px', fontWeight: 800, color: '#1e3a8a' }}>
                        ₹{(viewingEmployee.calculated_salary.proportionedSalary || viewingEmployee.calculated_salary.grossSalaryRate).toLocaleString('en-IN')}
                      </div>
                    </div>
                    <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Gross Wage Rate</div>
                      <div style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                        ₹{viewingEmployee.calculated_salary.grossSalaryRate.toLocaleString('en-IN')}
                      </div>
                    </div>
                    <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Special Allowance</div>
                      <div style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                        ₹{viewingEmployee.calculated_salary.specialAllowance.toLocaleString('en-IN')}
                      </div>
                    </div>
                    <div style={{ background: '#ffffff', padding: '10px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Total Basic (Col R)</div>
                      <div style={{ fontSize: '15px', fontWeight: 800, color: '#0f172a' }}>
                        ₹{viewingEmployee.calculated_salary.totalBasic.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>

                  <div className="grid-3" style={{ gap: '10px', marginBottom: '16px' }}>
                    <div style={{ background: '#ecfdf5', padding: '12px', borderRadius: '6px', border: '1px solid #a7f3d0' }}>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: '#065f46' }}>Gross Total (Col AB)</div>
                      <div style={{ fontSize: '17px', fontWeight: 800, color: '#047857' }}>
                        ₹{viewingEmployee.calculated_salary.grossTotal.toLocaleString('en-IN')}
                      </div>
                    </div>

                    <div style={{ background: '#fef2f2', padding: '12px', borderRadius: '6px', border: '1px solid #fecaca' }}>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: '#991b1b' }}>Employee Deductions</div>
                      <div style={{ fontSize: '17px', fontWeight: 800, color: '#dc2626' }}>
                        ₹{viewingEmployee.calculated_salary.totalEmployeeDeductions.toLocaleString('en-IN')}
                      </div>
                    </div>

                    <div style={{ background: '#1e3a8a', padding: '12px', borderRadius: '6px', color: '#ffffff' }}>
                      <div style={{ fontSize: '12px', fontWeight: 600, color: '#93c5fd' }}>Net Payable Take-Home</div>
                      <div style={{ fontSize: '20px', fontWeight: 900, color: '#ffffff' }}>
                        ₹{viewingEmployee.calculated_salary.netPayable.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>

                  {/* Reference Excel Formula Breakdown Table */}
                  <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '14px' }}>
                    <h5 style={{ fontSize: '12px', fontWeight: 800, color: '#1e3a8a', margin: '0 0 8px', textTransform: 'uppercase' }}>
                      Reference Excel Formula Breakdown (SALARY SHEET-for EPF Sepf 2026.xlsx)
                    </h5>
                    <div style={{ overflowX: 'auto', border: '1px solid #e2e8f0', borderRadius: '6px' }}>
                      <table style={{ width: '100%', fontSize: '11.5px', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead>
                          <tr style={{ background: '#f1f5f9', color: '#334155', borderBottom: '1px solid #cbd5e1' }}>
                            <th style={{ padding: '7px 10px' }}>Salary Component</th>
                            <th style={{ padding: '7px 10px' }}>Excel Sheet Column</th>
                            <th style={{ padding: '7px 10px' }}>Exact Excel Formula</th>
                            <th style={{ padding: '7px 10px', textAlign: 'right' }}>Calculated Value</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#eff6ff', fontWeight: 700, color: '#1d4ed8' }}>
                            <td style={{ padding: '7px 10px' }}>Proportioned Salary</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col P / EMC Col AD (B.P)</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND((O3/M3)*N3, 0) / =AB3/Z3*AA3</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{(viewingEmployee.calculated_salary.proportionedSalary || viewingEmployee.calculated_salary.grossSalaryRate).toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Gross Salary Rate</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col O / EMC Col AB</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>Fixed Designation Rate</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.grossSalaryRate.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Special Allowance</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col Q / EMC Col AC</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>Fixed Designation Rate</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.specialAllowance.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Total Basic</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col R / EMC Col AE</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND((O3+Q3)*N3/M3, 0)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.totalBasic.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Thermal Allowance</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col S / EMC Col AF</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND(1500*N3/M3, 0)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.thermalAllowance.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Bonus ({viewingEmployee.calculated_salary.bonusPercentage}%)</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col W / EMC Col AJ</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND(R3*8.33%, 0)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.bonus.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Employer EPF Share (12%)</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col X / EMC Col AK</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND(IF(P3&lt;25000, P3*0.12, 3000), 0)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.employerEpf12.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Employer EPF Admin / EDLI (1%)</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col Y / EMC Col AL</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND(IF(P3&lt;25000, P3*0.01, 250), 0)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.employerEpf1.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Employer ESI Share (3.25%)</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col Z / EMC Col AM</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND(IF(Earnings&lt;21000, Earnings*0.0325, 0), 0)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.employerEsi325.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9' }}>
                            <td style={{ padding: '7px 10px' }}>Employer LWF Contribution</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col AA / EMC Col AN</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>Standard ₹20</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.employerLwf.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#ecfdf5', fontWeight: 600 }}>
                            <td style={{ padding: '7px 10px' }}>Gross Total (Col AB)</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col AB / EMC Col AO</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=SUM(V3:AA3)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.grossTotal.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9', color: '#b91c1c' }}>
                            <td style={{ padding: '7px 10px' }}>Employee EPF (12%) Deduction</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col AS / EMC Col AP</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=Employer EPF Share</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.employeeEpf12.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9', color: '#b91c1c' }}>
                            <td style={{ padding: '7px 10px' }}>Employee ESI (0.75%) Deduction</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col AT / EMC Col AQ</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>=ROUND(IF(Earnings&lt;21000, Earnings*0.0075, 0), 0)</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.employeeEsi075.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9', color: '#b91c1c' }}>
                            <td style={{ padding: '7px 10px' }}>Employee LWF Deduction</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col AU / EMC Col AR</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>Standard ₹5</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.employeeLwf.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ borderBottom: '1px solid #f1f5f9', background: '#fef2f2', fontWeight: 600 }}>
                            <td style={{ padding: '7px 10px' }}>Total Employee Deductions</td>
                            <td style={{ padding: '7px 10px' }}>MM-1 Col AS..AU / EMC Col AP..AR</td>
                            <td style={{ padding: '7px 10px', fontFamily: 'monospace' }}>EPF 12% + ESI 0.75% + LWF ₹5</td>
                            <td style={{ padding: '7px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.totalEmployeeDeductions.toLocaleString('en-IN')}</td>
                          </tr>
                          <tr style={{ background: '#1e3a8a', color: '#ffffff', fontWeight: 800 }}>
                            <td style={{ padding: '8px 10px' }}>Net Payable Take-Home</td>
                            <td style={{ padding: '8px 10px' }}>MM-1 Col AI / EMC Col AU</td>
                            <td style={{ padding: '8px 10px', fontFamily: 'monospace' }}>=Gross Total - Combined Deductions</td>
                            <td style={{ padding: '8px 10px', textAlign: 'right', fontFamily: 'monospace' }}>₹{viewingEmployee.calculated_salary.netPayable.toLocaleString('en-IN')}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '14px 20px', display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button
                type="button"
                onClick={() => {
                  setIsViewModalOpen(false);
                  handleOpenEdit(viewingEmployee);
                }}
                className="btn btn-primary"
              >
                Edit Employee
              </button>
              <button type="button" onClick={() => setIsViewModalOpen(false)} className="btn btn-secondary">
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== ARCHIVE CONFIRMATION MODAL ==================== */}
      {isArchiveModalOpen && archivingTarget && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '540px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#92400e', margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Archive size={18} color="#d97706" />
                <span>
                  {archivingTarget.type === 'single'
                    ? 'Confirm Employee Archival'
                    : `Confirm Bulk Archival (${archivingTarget.ids?.length} Employees)`}
                </span>
              </h3>
              <button onClick={() => setIsArchiveModalOpen(false)} style={{ color: '#64748b', background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body" style={{ padding: '20px' }}>
              <p style={{ fontSize: '14px', color: '#1e293b', margin: '0 0 12px' }}>
                {archivingTarget.type === 'single' && archivingTarget.employee ? (
                  <>Are you sure you want to archive <strong>{archivingTarget.employee.name}</strong> ({archivingTarget.employee.emp_code})?</>
                ) : (
                  <>Are you sure you want to archive all <strong>{archivingTarget.ids?.length} selected employees</strong>?</>
                )}
              </p>

              <div style={{ background: '#fef3c7', border: '1px solid #fde68a', borderRadius: '6px', padding: '12px', color: '#92400e', fontSize: '12.5px', marginBottom: '14px' }}>
                <strong>Archival Protection:</strong> Archiving will safely exclude the employee(s) from future and open monthly payroll runs. All historical payslips, past payroll registers, salary sheets, and audit logs remain <strong>permanently intact</strong>.
              </div>

              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '12px', fontWeight: 700, color: '#334155', marginBottom: '4px' }}>
                  Archival Reason / Justification
                </label>
                <input
                  type="text"
                  className="form-input"
                  style={{ fontSize: '13px' }}
                  value={archiveReason}
                  onChange={(e) => setArchiveReason(e.target.value)}
                  placeholder="e.g. Contract completed, transferred, or deactivated"
                />
              </div>

              <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>
                You can reactivate archived employees at any time using the <strong>Restore</strong> action.
              </p>
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '14px 20px', display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button type="button" onClick={() => setIsArchiveModalOpen(false)} className="btn btn-secondary" disabled={archiveLoading}>
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmArchive}
                className="btn btn-sm"
                style={{ background: '#d97706', color: '#ffffff', border: 'none', fontWeight: 700 }}
                disabled={archiveLoading}
              >
                {archiveLoading ? 'Archiving...' : 'Confirm Archival'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== PERMANENT DELETE MODAL (ADMIN ONLY) ==================== */}
      {isPermanentDeleteModalOpen && permanentDeleteTarget && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '600px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#991b1b', margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <AlertCircle size={18} color="#dc2626" />
                <span>
                  {permanentDeleteTarget.type === 'single'
                    ? 'Permanent Employee Deletion'
                    : `Permanent Bulk Deletion (${permanentDeleteTarget.ids?.length} Employees)`}
                </span>
              </h3>
              <button onClick={() => setIsPermanentDeleteModalOpen(false)} style={{ color: '#64748b', background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body" style={{ padding: '20px' }}>
              {deleteEligibility?.loading ? (
                <div style={{ textAlign: 'center', padding: '24px', color: '#64748b' }}>
                  <RefreshCw size={24} className="spin" style={{ margin: '0 auto 8px', display: 'block' }} />
                  <span>Verifying historical payroll records...</span>
                </div>
              ) : deleteEligibility && deleteEligibility.blockedCount > 0 ? (
                <>
                  <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '6px', padding: '14px', color: '#991b1b', fontSize: '13px', marginBottom: '14px' }}>
                    <div style={{ fontWeight: 800, fontSize: '14px', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                      <AlertCircle size={16} />
                      <span>Permanent Deletion Strictly Blocked</span>
                    </div>
                    <div>
                      {deleteEligibility.blockedCount === 1 ? (
                        <>
                          <strong>{deleteEligibility.blockedEmployees[0].name}</strong> ({deleteEligibility.blockedEmployees[0].emp_code}) has <strong>{deleteEligibility.blockedEmployees[0].historyCount} historical payroll record(s)</strong>.
                        </>
                      ) : (
                        <>
                          <strong>{deleteEligibility.blockedCount} of {deleteEligibility.totalChecked} selected employees</strong> have historical payroll records.
                        </>
                      )}
                      <p style={{ margin: '6px 0 0', fontSize: '12.5px', color: '#7f1d1d' }}>
                        Under statutory retention regulations, employee records with historical payroll calculations cannot be permanently erased. Please use <strong>Safe Archival</strong> instead to exclude them from future payroll runs without damaging legal history.
                      </p>
                    </div>
                  </div>

                  {deleteEligibility.blockedEmployees.length > 1 && (
                    <div style={{ maxHeight: '160px', overflowY: 'auto', border: '1px solid #fecaca', borderRadius: '6px', marginBottom: '14px' }}>
                      <table style={{ width: '100%', fontSize: '12px', borderCollapse: 'collapse' }}>
                        <thead>
                          <tr style={{ background: '#fee2e2', color: '#991b1b' }}>
                            <th style={{ padding: '6px 10px', textAlign: 'left' }}>Emp Code</th>
                            <th style={{ padding: '6px 10px', textAlign: 'left' }}>Name</th>
                            <th style={{ padding: '6px 10px', textAlign: 'right' }}>Payroll Records</th>
                          </tr>
                        </thead>
                        <tbody>
                          {deleteEligibility.blockedEmployees.map((b: any) => (
                            <tr key={b.id} style={{ borderBottom: '1px solid #fee2e2' }}>
                              <td style={{ padding: '6px 10px', fontFamily: 'monospace', fontWeight: 700 }}>{b.emp_code}</td>
                              <td style={{ padding: '6px 10px' }}>{b.name}</td>
                              <td style={{ padding: '6px 10px', textAlign: 'right', fontWeight: 700, color: '#dc2626' }}>{b.historyCount}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  <div style={{ background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '6px', padding: '12px', fontSize: '12.5px', color: '#1e40af' }}>
                    💡 <strong>Recommended Action:</strong> Click <strong>"Archive Instead"</strong> to safely deactivate without data loss.
                  </div>
                </>
              ) : (
                <>
                  <div style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: '6px', padding: '14px', color: '#991b1b', fontSize: '13px', marginBottom: '14px' }}>
                    <div style={{ fontWeight: 800, fontSize: '14px', marginBottom: '4px' }}>
                      ⚠️ Irreversible Destruction Warning
                    </div>
                    <p style={{ margin: 0 }}>
                      {permanentDeleteTarget.type === 'single' && permanentDeleteTarget.employee ? (
                        <>Are you sure you want to <strong>PERMANENTLY DELETE {permanentDeleteTarget.employee.name}</strong> ({permanentDeleteTarget.employee.emp_code}) from the database?</>
                      ) : (
                        <>Are you sure you want to <strong>PERMANENTLY DELETE all {permanentDeleteTarget.ids?.length} selected employees</strong> from the database?</>
                      )}
                    </p>
                    <p style={{ margin: '6px 0 0', fontSize: '12px', color: '#7f1d1d' }}>
                      Verified: 0 payroll records exist for these employee(s). Permanent deletion will remove their profiles, personal data, and bank details completely. <strong>This action CANNOT be undone!</strong>
                    </p>
                  </div>
                </>
              )}
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '14px 20px', display: 'flex', justifyContent: 'flex-end', gap: '8px', flexWrap: 'wrap' }}>
              <button type="button" onClick={() => setIsPermanentDeleteModalOpen(false)} className="btn btn-secondary" disabled={permanentDeleteLoading}>
                Cancel
              </button>

              {deleteEligibility && deleteEligibility.blockedCount > 0 ? (
                <>
                  <button
                    type="button"
                    onClick={handleSwitchToArchiveFromDelete}
                    className="btn btn-sm"
                    style={{ background: '#d97706', color: '#ffffff', border: 'none', fontWeight: 700 }}
                  >
                    Archive Instead (Recommended)
                  </button>

                  {deleteEligibility.eligibleCount > 0 && (
                    <button
                      type="button"
                      onClick={() => handleConfirmPermanentDelete(true)}
                      className="btn btn-danger btn-sm"
                      disabled={permanentDeleteLoading}
                    >
                      {permanentDeleteLoading ? 'Deleting...' : `Delete ${deleteEligibility.eligibleCount} Eligible Only`}
                    </button>
                  )}
                </>
              ) : (
                deleteEligibility && deleteEligibility.eligibleCount > 0 && (
                  <button
                    type="button"
                    onClick={() => handleConfirmPermanentDelete(false)}
                    className="btn btn-danger btn-sm"
                    disabled={permanentDeleteLoading}
                  >
                    {permanentDeleteLoading ? 'Permanently Deleting...' : 'Confirm Permanent Deletion'}
                  </button>
                )
              )}
            </div>
          </div>
        </div>
      )}

      {/* ==================== RESTORE CONFIRMATION MODAL ==================== */}
      {isRestoreModalOpen && restoringTarget && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '540px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#047857', margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <RefreshCw size={18} color="#059669" />
                <span>
                  {restoringTarget.type === 'single'
                    ? 'Confirm Employee Restoration'
                    : `Confirm Bulk Restoration (${restoringTarget.ids?.length} Employees)`}
                </span>
              </h3>
              <button onClick={() => setIsRestoreModalOpen(false)} style={{ color: '#64748b', background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body" style={{ padding: '20px' }}>
              <p style={{ fontSize: '14px', color: '#1e293b', margin: '0 0 12px' }}>
                {restoringTarget.type === 'single' && restoringTarget.employee ? (
                  <>Reactivate <strong>{restoringTarget.employee.name}</strong> ({restoringTarget.employee.emp_code}) back to active workforce?</>
                ) : (
                  <>Reactivate all <strong>{restoringTarget.ids?.length} selected archived employees</strong> back to active workforce?</>
                )}
              </p>

              <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '6px', padding: '12px', color: '#065f46', fontSize: '12.5px', marginBottom: '14px' }}>
                <strong>Automatic Payroll Synchronization:</strong> Restoring employee(s) will reactivate them for monthly payroll calculations and automatically include them in draft / unfinalized payroll periods.
              </div>
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '14px 20px', display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button type="button" onClick={() => setIsRestoreModalOpen(false)} className="btn btn-secondary" disabled={restoreLoading}>
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRestore}
                className="btn btn-sm"
                style={{ background: '#059669', color: '#ffffff', border: 'none', fontWeight: 700 }}
                disabled={restoreLoading}
              >
                {restoreLoading ? 'Restoring...' : 'Confirm Restoration'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== EXCEL IMPORT MODAL ==================== */}
      {isImportModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '1200px', width: '95vw', maxHeight: '92vh', display: 'flex', flexDirection: 'column' }}>
            <div className="modal-header" style={{ padding: '16px 20px', borderBottom: '1px solid #e2e8f0' }}>
              <div>
                <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a', margin: 0, display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <FileSpreadsheet size={22} color="#2563eb" />
                  <span>Smart Excel Employee & Column-Mapping Engine</span>
                </h3>
                <span style={{ fontSize: '12.5px', color: '#64748b' }}>
                  Inspects worksheets, maps 55+ destination fields, verifies UAN/ESI/bank accounts, and synchronizes with Monthly Payroll
                </span>
              </div>
              <button onClick={() => setIsImportModalOpen(false)} style={{ color: '#64748b', background: 'none', border: 'none', cursor: 'pointer', padding: '4px' }}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body" style={{ padding: '20px', overflowY: 'auto', flex: 1 }}>
              {/* File Dropzone */}
              {!importPreviewData && !importSuccessResult && (
                <div style={{ border: '2px dashed #93c5fd', borderRadius: '12px', padding: '40px 20px', textAlign: 'center', background: '#f8fafc' }}>
                  <FileSpreadsheet size={44} color="#2563eb" style={{ margin: '0 auto 14px' }} />
                  <h4 style={{ fontSize: '16px', fontWeight: 700, margin: '0 0 6px', color: '#0f172a' }}>
                    Select or Drag & Drop Excel Employee Spreadsheet
                  </h4>
                  <p style={{ fontSize: '13px', color: '#64748b', margin: '0 auto 18px', maxWidth: '520px' }}>
                    Supports <strong>MM-1</strong>, <strong>EMC</strong>, <strong>Operation Circle</strong>, and custom vendor spreadsheets (.xlsx, .xls, .csv).
                  </p>
                  <label className="btn btn-primary" style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '10px 20px', fontWeight: 700 }}>
                    <Upload size={16} />
                    <span>Choose Excel Workbook (.xlsx, .xls, .csv)</span>
                    <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImportFileSelect} style={{ display: 'none' }} />
                  </label>
                  {importLoading && (
                    <div style={{ marginTop: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', color: '#2563eb', fontSize: '13.5px' }}>
                      <RefreshCw size={16} className="spin" />
                      <span>Analyzing workbook structure, detecting header row, and mapping columns...</span>
                    </div>
                  )}
                </div>
              )}

              {/* Inspection, Mapping & Preview Section */}
              {importPreviewData && !importSuccessResult && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  {/* Top Bar: Sheet Selector, Duplicate Strategy, Re-Upload */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px', background: '#f1f5f9', padding: '12px 16px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{ fontSize: '13px', fontWeight: 700, color: '#1e293b' }}>Worksheet:</span>
                        <select
                          value={selectedImportSheet}
                          onChange={(e) => handleImportSheetChange(e.target.value)}
                          className="form-input"
                          style={{ width: '260px', fontSize: '13px', fontWeight: 600, background: '#ffffff' }}
                        >
                          {importSheetNames.length > 1 && (
                            <option value="__ALL__">
                              ✨ All Worksheets (Read & Import Entire Workbook - {importSheetNames.length} Sheets)
                            </option>
                          )}
                          {importSheetNames.map(s => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      </div>

                      {importPreviewData.sheetsSummary && importPreviewData.sheetsSummary.length > 1 && (
                        <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center' }}>
                          <span
                            onClick={() => handleImportSheetChange('__ALL__')}
                            style={{
                              cursor: 'pointer',
                              fontSize: '11px',
                              padding: '2px 8px',
                              borderRadius: '4px',
                              background: selectedImportSheet === '__ALL__' ? '#1e3a8a' : '#e2e8f0',
                              color: selectedImportSheet === '__ALL__' ? '#ffffff' : '#334155',
                              fontWeight: 700
                            }}
                          >
                            ✨ ALL ({importPreviewData.sheetsSummary.reduce((acc: number, s: any) => acc + (s.totalRows || 0), 0)} records)
                          </span>
                          {importPreviewData.sheetsSummary.map((sh: any) => (
                            <span
                              key={sh.sheetName}
                              onClick={() => handleImportSheetChange(sh.sheetName)}
                              style={{
                                cursor: 'pointer',
                                fontSize: '11px',
                                padding: '2px 8px',
                                borderRadius: '4px',
                                background: selectedImportSheet === sh.sheetName ? '#2563eb' : '#e2e8f0',
                                color: selectedImportSheet === sh.sheetName ? '#ffffff' : '#334155',
                                fontWeight: 600
                              }}
                            >
                              📄 {sh.sheetName} ({sh.totalRows})
                            </span>
                          ))}
                        </div>
                      )}

                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{ fontSize: '13px', fontWeight: 700, color: '#1e293b' }}>Import Strategy:</span>
                        <select
                          value={importStrategy}
                          onChange={(e) => setImportStrategy(e.target.value as any)}
                          className="form-input"
                          style={{ width: '220px', fontSize: '13px', fontWeight: 600, background: '#ffffff' }}
                        >
                          <option value="both">Add New & Update Existing</option>
                          <option value="add_only">Add New Employees Only</option>
                          <option value="update_only">Update Existing Employees Only</option>
                        </select>
                      </div>
                    </div>

                    <label className="btn btn-secondary btn-sm" style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                      <Upload size={14} />
                      <span>Change File</span>
                      <input type="file" accept=".xlsx,.xls,.csv" onChange={handleImportFileSelect} style={{ display: 'none' }} />
                    </label>
                  </div>

                  {/* Summary Metric Cards */}
                  <div className="grid-4" style={{ gap: '10px' }}>
                    <div style={{ background: '#eff6ff', padding: '10px 14px', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
                      <div style={{ fontSize: '11px', fontWeight: 600, color: '#1e40af' }}>Total Columns Found</div>
                      <div style={{ fontSize: '18px', fontWeight: 800, color: '#1e3a8a' }}>{importColumns.length}</div>
                      <div style={{ fontSize: '11px', color: '#3b82f6' }}>Header row: Row {Number(importPreviewData.headerRowIndex || 0) + 1}</div>
                    </div>
                    <div style={{ background: '#ecfdf5', padding: '10px 14px', borderRadius: '8px', border: '1px solid #a7f3d0' }}>
                      <div style={{ fontSize: '11px', fontWeight: 600, color: '#065f46' }}>Mapped Columns</div>
                      <div style={{ fontSize: '18px', fontWeight: 800, color: '#047857' }}>
                        {importColumns.filter(c => columnMappings[c.colIndex] && columnMappings[c.colIndex] !== '__EXCLUDE__').length}
                      </div>
                      <div style={{ fontSize: '11px', color: '#059669' }}>
                        Excluded: {importColumns.filter(c => columnMappings[c.colIndex] === '__EXCLUDE__').length}
                      </div>
                    </div>
                    <div style={{ background: '#fef3c7', padding: '10px 14px', borderRadius: '8px', border: '1px solid #fde68a' }}>
                      <div style={{ fontSize: '11px', fontWeight: 600, color: '#92400e' }}>Ready for Import</div>
                      <div style={{ fontSize: '18px', fontWeight: 800, color: '#b45309' }}>
                        {importPreviewData.previewRows.length} Records
                      </div>
                      <div style={{ fontSize: '11px', color: '#d97706' }}>
                        New: {importPreviewData.newCount || 0} | Existing: {importPreviewData.existingCount || 0}
                      </div>
                    </div>
                    <div style={{ background: '#f8fafc', padding: '10px 14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                      <div style={{ fontSize: '11px', fontWeight: 600, color: '#475569' }}>Validation Warnings</div>
                      <div style={{ fontSize: '18px', fontWeight: 800, color: importPreviewData.invalidCount > 0 ? '#dc2626' : '#16a34a' }}>
                        {importPreviewData.invalidCount || 0}
                      </div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>
                        {importPreviewData.invalidCount > 0 ? 'Review warnings below' : 'All records validated cleanly'}
                      </div>
                    </div>
                  </div>

                  {/* Tab Navigation */}
                  <div style={{ display: 'flex', gap: '8px', borderBottom: '2px solid #e2e8f0', paddingBottom: '2px' }}>
                    <button
                      type="button"
                      onClick={() => setActiveImportTab('mapping')}
                      style={{
                        padding: '8px 16px',
                        fontSize: '13px',
                        fontWeight: 700,
                        border: 'none',
                        background: 'none',
                        cursor: 'pointer',
                        color: activeImportTab === 'mapping' ? '#2563eb' : '#64748b',
                        borderBottom: activeImportTab === 'mapping' ? '2px solid #2563eb' : '2px solid transparent',
                        marginBottom: '-4px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px'
                      }}
                    >
                      <Sliders size={15} />
                      <span>Discovered Columns & Target Mapping ({importColumns.length})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveImportTab('preview')}
                      style={{
                        padding: '8px 16px',
                        fontSize: '13px',
                        fontWeight: 700,
                        border: 'none',
                        background: 'none',
                        cursor: 'pointer',
                        color: activeImportTab === 'preview' ? '#2563eb' : '#64748b',
                        borderBottom: activeImportTab === 'preview' ? '2px solid #2563eb' : '2px solid transparent',
                        marginBottom: '-4px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '6px'
                      }}
                    >
                      <FileSpreadsheet size={15} />
                      <span>Employee Data & Salary Calculation Preview ({importPreviewData.previewRows.length})</span>
                    </button>
                  </div>

                  {/* TAB 1: Column Mapping Inventory Table */}
                  {activeImportTab === 'mapping' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ fontSize: '12px', color: '#64748b', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span>
                          Verify or adjust the destination field for each Excel column. Duplicate verification columns (e.g. 2nd UAN) are safely excluded by default.
                        </span>
                        <span style={{ fontWeight: 600, color: '#2563eb' }}>
                          ⚡ Leading zeros & long IDs (UAN, Bank A/C) are preserved as exact text.
                        </span>
                      </div>

                      <div className="table-container" style={{ maxHeight: '420px', overflowY: 'auto' }}>
                        <table className="custom-table" style={{ fontSize: '12px' }}>
                          <thead>
                            <tr style={{ background: '#f8fafc' }}>
                              <th style={{ width: '80px' }}>Col Letter</th>
                              <th style={{ width: '220px' }}>Excel Heading in Worksheet</th>
                              <th style={{ width: '180px' }}>Sample Value (Row 1)</th>
                              <th style={{ width: '280px' }}>Destination Field in Software</th>
                              <th style={{ width: '100px' }}>Status</th>
                              <th>Mapping Reason / Rationale</th>
                            </tr>
                          </thead>
                          <tbody>
                            {importColumns.map((col) => {
                              const currentTarget = columnMappings[col.colIndex] || '__EXCLUDE__';
                              const isExcluded = currentTarget === '__EXCLUDE__';
                              return (
                                <tr key={col.colIndex} style={{ background: isExcluded ? '#fcfcfc' : '#ffffff' }}>
                                  <td style={{ fontFamily: 'monospace', fontWeight: 800, color: isExcluded ? '#94a3b8' : '#1e3a8a' }}>
                                    Col {col.colLetter} ({col.colIndex})
                                  </td>
                                  <td style={{ fontWeight: 600, color: isExcluded ? '#94a3b8' : '#0f172a' }}>
                                    {col.rawHeader}
                                  </td>
                                  <td style={{ fontFamily: 'monospace', fontSize: '11.5px', color: isExcluded ? '#94a3b8' : '#334155' }}>
                                    {col.sampleValue !== undefined && col.sampleValue !== null && col.sampleValue !== '' ? String(col.sampleValue) : '—'}
                                  </td>
                                  <td>
                                    <select
                                      value={currentTarget}
                                      onChange={(e) => handleColumnMappingChange(col.colIndex, e.target.value)}
                                      className="form-input"
                                      style={{
                                        fontSize: '12px',
                                        padding: '4px 8px',
                                        fontWeight: 600,
                                        width: '100%',
                                        borderColor: isExcluded ? '#cbd5e1' : '#2563eb',
                                        background: isExcluded ? '#f8fafc' : '#ffffff',
                                        color: isExcluded ? '#64748b' : '#0f172a'
                                      }}
                                    >
                                      <option value="__EXCLUDE__">⛔ Do Not Import (Exclude Column)</option>
                                      <optgroup label="1. Employee Identification">
                                        <option value="emp_code">Employee Code / ID (emp_code)</option>
                                        <option value="sr_no">Serial Number (sr_no)</option>
                                        <option value="name">Employee Full Name (name)</option>
                                        <option value="father_name">Father's / Husband's Name (father_name)</option>
                                        <option value="designation">Designation / Skill Category (designation)</option>
                                        <option value="contractor">Contractor / Service Provider (contractor)</option>
                                        <option value="circle">Circle Name (circle)</option>
                                        <option value="cell_department">Cell / Department / Office (cell_department)</option>
                                      </optgroup>
                                      <optgroup label="2. Identity & Statutory Numbers">
                                        <option value="uan">UAN (Universal Account Number)</option>
                                        <option value="esi_number">ESI / ESIC Number</option>
                                        <option value="aadhar_number">Aadhaar Card Number</option>
                                        <option value="pan_number">PAN Card Number</option>
                                        <option value="mobile_number">Mobile Phone Number</option>
                                      </optgroup>
                                      <optgroup label="3. Bank & Payment Details">
                                        <option value="bank_account">Bank Account Number</option>
                                        <option value="ifsc">Bank IFSC Code</option>
                                        <option value="bank_name">Bank Name</option>
                                        <option value="account_holder_name">Account Holder Name</option>
                                      </optgroup>
                                      <optgroup label="4. HR & Service Information">
                                        <option value="dob">Date of Birth (dob)</option>
                                        <option value="age_above_58">Age Above 58 (age_above_58)</option>
                                        <option value="date_of_joining">Date of Joining (date_of_joining)</option>
                                        <option value="date_of_exit">Date of Exit (date_of_exit)</option>
                                        <option value="more_than_3_yrs">More than 3 Years (more_than_3_yrs)</option>
                                        <option value="more_than_5_yrs">More than 5 Years (more_than_5_yrs)</option>
                                        <option value="qualification">Educational Qualification</option>
                                        <option value="experience_years">Experience in Years</option>
                                        <option value="qualified_status">Qualified Status (Yes/No)</option>
                                        <option value="hazard_duty">Hazard Duty Classification</option>
                                        <option value="check_status">Verification Check Status</option>
                                      </optgroup>
                                      <optgroup label="5. Attendance & Salary Rates">
                                        <option value="total_days">Total Month Days (30)</option>
                                        <option value="present_days">Present / Duty Days</option>
                                        <option value="gross_salary_rate">Gross Salary Rate / Wage Rate</option>
                                        <option value="proportioned_salary">Proportioned Salary Rate</option>
                                        <option value="special_allowance">Special Allowance Rate</option>
                                        <option value="total_basic">Total Basic Salary</option>
                                        <option value="thermal_allowance">Thermal Allowance (₹1500)</option>
                                        <option value="perf_allowance_monthly">Monthly Performance Allowance</option>
                                        <option value="perf_allowance_days">Days-wise Performance Allowance</option>
                                        <option value="total_earnings_before_bonus">Total Earnings Before Bonus</option>
                                        <option value="bonus">Bonus Amount</option>
                                        <option value="bonus_percentage">Bonus Percentage (%)</option>
                                      </optgroup>
                                      <optgroup label="6. Statutory Deductions & Contributions">
                                        <option value="employee_epf_12">Employee EPF Deduction (12%)</option>
                                        <option value="employee_esi_075">Employee ESI Deduction (0.75%)</option>
                                        <option value="employee_lwf">Employee LWF Deduction (₹5)</option>
                                        <option value="total_employee_deductions">Total Employee Deductions</option>
                                        <option value="employer_epf_12">Employer EPF Contribution (12%)</option>
                                        <option value="employer_epf_1">Employer EPF Admin Charges (1%)</option>
                                        <option value="employer_esi_325">Employer ESI Contribution (3.25%)</option>
                                        <option value="employer_lwf">Employer LWF Contribution (₹20)</option>
                                        <option value="total_employer_contributions">Total Employer Contributions</option>
                                        <option value="combined_deductions">Combined Deductions</option>
                                      </optgroup>
                                      <optgroup label="7. Totals & Net Salary">
                                        <option value="gross_total">Gross Total</option>
                                        <option value="net_payable">Net Payable Salary</option>
                                        <option value="perf_last_drawn">Performance Last Drawn</option>
                                        <option value="perf_as_per_circle">Performance As Per Circle</option>
                                        <option value="perf_difference">Performance Difference</option>
                                      </optgroup>
                                    </select>
                                  </td>
                                  <td>
                                    {isExcluded ? (
                                      <span className="badge" style={{ background: '#f1f5f9', color: '#64748b' }}>Excluded</span>
                                    ) : col.status === 'matched' ? (
                                      <span className="badge badge-active">Auto-Matched</span>
                                    ) : col.status === 'custom' ? (
                                      <span className="badge" style={{ background: '#eff6ff', color: '#1d4ed8' }}>User Mapped</span>
                                    ) : (
                                      <span className="badge" style={{ background: '#fef3c7', color: '#92400e' }}>Needs Review</span>
                                    )}
                                  </td>
                                  <td style={{ fontSize: '11px', color: isExcluded ? '#94a3b8' : '#64748b' }}>
                                    {col.reason}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* TAB 2: Employee Data & Calculations Preview Table */}
                  {activeImportTab === 'preview' && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ fontSize: '12px', color: '#64748b', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span>
                          Showing live calculation breakdown for parsed records from <strong>{selectedImportSheet}</strong>.
                        </span>
                        <span style={{ fontWeight: 600, color: '#047857' }}>
                          ✓ Net Payable = Total Basic + Thermal + Perf + Bonus - Total Employee Deductions
                        </span>
                      </div>

                      <div className="table-container" style={{ maxHeight: '420px', overflowY: 'auto' }}>
                        <table className="custom-table" style={{ fontSize: '12px' }}>
                          <thead>
                            <tr style={{ background: '#f8fafc' }}>
                              <th>Emp Code</th>
                              <th>Employee Name</th>
                              <th>Designation</th>
                              <th>UAN</th>
                              <th>Bank Account</th>
                              <th>Basic Salary</th>
                              <th>Thermal</th>
                              <th>Bonus</th>
                              <th>EPF (12%)</th>
                              <th>ESI (0.75%)</th>
                              <th>LWF (₹5)</th>
                              <th>Total Deductions</th>
                              <th>Net Payable</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {importPreviewData.previewRows.slice(0, 100).map((r: any, idx: number) => {
                              const calc = r.salaryPreview;
                              return (
                                <tr key={idx}>
                                  <td style={{ fontFamily: 'monospace', fontWeight: 800, color: '#1e3a8a' }}>{r.empCode}</td>
                                  <td style={{ fontWeight: 600 }}>{r.name}</td>
                                  <td><span className="badge" style={{ background: '#f1f5f9' }}>{r.designationAlias || 'SW'}</span></td>
                                  <td style={{ fontFamily: 'monospace', fontSize: '11px' }}>{r.uan || '—'}</td>
                                  <td style={{ fontFamily: 'monospace', fontSize: '11px' }}>{r.bankAccount || '—'}</td>
                                  <td style={{ fontFamily: 'monospace' }}>
                                    ₹{calc ? Number(calc.totalBasic).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td style={{ fontFamily: 'monospace' }}>
                                    ₹{calc ? Number(calc.thermalAllowance).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td style={{ fontFamily: 'monospace' }}>
                                    ₹{calc ? Number(calc.bonus).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td style={{ fontFamily: 'monospace', color: '#dc2626' }}>
                                    ₹{calc ? Number(calc.employeeEpf12).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td style={{ fontFamily: 'monospace', color: '#dc2626' }}>
                                    ₹{calc ? Number(calc.employeeEsi075).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td style={{ fontFamily: 'monospace', color: '#dc2626' }}>
                                    ₹{calc ? Number(calc.employeeLwf).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td style={{ fontFamily: 'monospace', fontWeight: 700, color: '#b91c1c' }}>
                                    ₹{calc ? Number(calc.totalEmployeeDeductions).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td style={{ fontFamily: 'monospace', fontWeight: 800, color: '#047857' }}>
                                    ₹{calc ? Number(calc.netPayable).toLocaleString('en-IN') : '—'}
                                  </td>
                                  <td>
                                    {r.isExisting ? (
                                      <span className="badge" style={{ background: '#fef3c7', color: '#92400e' }}>Update Match</span>
                                    ) : (
                                      <span className="badge badge-active">Add New</span>
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Success Result Report */}
              {importSuccessResult && (
                <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '8px', padding: '24px', textAlign: 'center' }}>
                  <CheckCircle2 size={40} color="#059669" style={{ margin: '0 auto 12px' }} />
                  <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#065f46', margin: '0 0 8px' }}>
                    Employee Import Completed Successfully!
                  </h3>
                  <p style={{ fontSize: '14px', color: '#047857', margin: '0 0 16px' }}>
                    Successfully processed {importSuccessResult.totalProcessed} records.
                  </p>
                  <div style={{ display: 'inline-flex', gap: '20px', background: '#ffffff', padding: '12px 24px', borderRadius: '6px', border: '1px solid #d1fae5' }}>
                    <div><strong>Created:</strong> {importSuccessResult.createdCount}</div>
                    <div><strong>Updated:</strong> {importSuccessResult.updatedCount}</div>
                    <div><strong>Skipped:</strong> {importSuccessResult.skippedCount}</div>
                  </div>
                  {importSuccessResult.synchronizedPayrollPeriods > 0 && (
                    <div style={{ marginTop: '14px', fontSize: '13px', color: '#047857', background: '#d1fae5', padding: '8px 12px', borderRadius: '6px', display: 'inline-block' }}>
                      ⚡ <strong>Monthly Payroll Synchronized:</strong> Automatically updated <strong>{importSuccessResult.synchronizedPayrollPeriods} open payroll period(s)</strong> ({importSuccessResult.synchronizedPayrollAdded || 0} added, {importSuccessResult.synchronizedPayrollUpdated || 0} updated).
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '14px 20px', display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button type="button" onClick={() => setIsImportModalOpen(false)} className="btn btn-secondary">
                {importSuccessResult ? 'Close' : 'Cancel'}
              </button>
              {importPreviewData && !importSuccessResult && (
                <button
                  type="button"
                  onClick={handleConfirmImport}
                  className="btn btn-primary"
                  disabled={importLoading}
                  style={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: '6px' }}
                >
                  {importLoading ? (
                    <>
                      <RefreshCw size={15} className="spin" />
                      <span>Importing & Synchronizing...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 size={16} />
                      <span>
                        {selectedImportSheet === '__ALL__'
                          ? `Confirm & Import All Sheets (${importPreviewData.previewRows.length} Employees Across ${importSheetNames.length} Sheets)`
                          : `Confirm & Import (${importPreviewData.previewRows.length} Employees from ${selectedImportSheet})`}
                      </span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ==================== SALARY UPLOAD MODAL ==================== */}
      {isSalaryUploadModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '900px', maxHeight: '90vh', display: 'flex', flexDirection: 'column' }}>
            <div className="modal-header">
              <div>
                <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0f172a', margin: 0 }}>
                  Upload & Update Salary Rates from Excel
                </h3>
                <span style={{ fontSize: '12px', color: '#64748b' }}>
                  Update wage rates, special allowances, thermal, performance allowances, and bonus % for existing employees with live diff preview.
                </span>
              </div>
              <button onClick={() => setIsSalaryUploadModalOpen(false)} style={{ color: '#64748b', background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={20} />
              </button>
            </div>

            <div className="modal-body" style={{ padding: '20px', overflowY: 'auto', flex: 1 }}>
              {!salaryPreviewData && !salarySuccessResult && (
                <div style={{ border: '2px dashed #cbd5e1', borderRadius: '8px', padding: '36px', textAlign: 'center', background: '#f8fafc' }}>
                  <DollarSign size={36} color="#059669" style={{ margin: '0 auto 12px' }} />
                  <h4 style={{ fontSize: '15px', fontWeight: 700, margin: '0 0 6px', color: '#0f172a' }}>
                    Select Salary Rates Spreadsheet
                  </h4>
                  <p style={{ fontSize: '13px', color: '#64748b', margin: '0 0 16px' }}>
                    Upload spreadsheet with columns: Emp Code / UAN, Gross Salary, Special Allowance, Thermal, Perf Allowance, Bonus %
                  </p>
                  <label className="btn btn-primary" style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                    <Upload size={15} />
                    <span>Browse Salary File (.xlsx, .xls, .csv)</span>
                    <input type="file" accept=".xlsx,.xls,.csv" onChange={handleSalaryFileSelect} style={{ display: 'none' }} />
                  </label>
                  {salaryLoading && <p style={{ fontSize: '13px', color: '#059669', marginTop: '12px' }}>Analyzing salary changes and calculating net differences...</p>}
                </div>
              )}

              {/* Salary Preview Diff Table */}
              {salaryPreviewData && !salarySuccessResult && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div className="grid-3" style={{ gap: '10px' }}>
                    <div style={{ background: '#ecfdf5', padding: '10px 14px', borderRadius: '6px', border: '1px solid #a7f3d0' }}>
                      <div style={{ fontSize: '11px', color: '#065f46' }}>Matched Employees</div>
                      <div style={{ fontSize: '18px', fontWeight: 800, color: '#047857' }}>{salaryPreviewData.matchedCount}</div>
                    </div>
                    <div style={{ background: '#fef2f2', padding: '10px 14px', borderRadius: '6px', border: '1px solid #fecaca' }}>
                      <div style={{ fontSize: '11px', color: '#991b1b' }}>Unmatched Rows</div>
                      <div style={{ fontSize: '18px', fontWeight: 800, color: '#dc2626' }}>{salaryPreviewData.unmatchedCount}</div>
                    </div>
                    <div style={{ background: '#eff6ff', padding: '10px 14px', borderRadius: '6px', border: '1px solid #bfdbfe' }}>
                      <div style={{ fontSize: '11px', color: '#1e40af' }}>Total In Spreadsheet</div>
                      <div style={{ fontSize: '18px', fontWeight: 800, color: '#1e3a8a' }}>{salaryPreviewData.totalRows}</div>
                    </div>
                  </div>

                  <div className="table-container" style={{ maxHeight: '350px', overflowY: 'auto' }}>
                    <table className="custom-table" style={{ fontSize: '12px' }}>
                      <thead>
                        <tr>
                          <th>Emp Code</th>
                          <th>Name</th>
                          <th>Old Gross → New Gross</th>
                          <th>Old Special → New Special</th>
                          <th>Old Net → New Net</th>
                          <th>Net Change</th>
                        </tr>
                      </thead>
                      <tbody>
                        {salaryPreviewData.matchedRows.map((r: any, idx: number) => (
                          <tr key={idx}>
                            <td style={{ fontFamily: 'monospace', fontWeight: 700 }}>{r.empCode}</td>
                            <td>{r.name}</td>
                            <td>₹{r.oldGross} → <strong>₹{r.newGross}</strong></td>
                            <td>₹{r.oldSpecial} → <strong>₹{r.newSpecial}</strong></td>
                            <td style={{ fontWeight: 700, fontFamily: 'monospace' }}>
                              ₹{r.oldNetPayable} → <strong style={{ color: '#047857' }}>₹{r.newNetPayable}</strong>
                            </td>
                            <td style={{ fontWeight: 700, color: r.netDifference >= 0 ? '#047857' : '#dc2626' }}>
                              {r.netDifference >= 0 ? `+₹${r.netDifference}` : `-₹${Math.abs(r.netDifference)}`}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Salary Update Success Report */}
              {salarySuccessResult && (
                <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '8px', padding: '24px', textAlign: 'center' }}>
                  <CheckCircle2 size={40} color="#059669" style={{ margin: '0 auto 12px' }} />
                  <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#065f46', margin: '0 0 8px' }}>
                    Salary Structures Updated Successfully!
                  </h3>
                  <p style={{ fontSize: '14px', color: '#047857', margin: 0 }}>
                    Successfully updated rates and allowances for <strong>{salarySuccessResult.updatedCount} employees</strong>.
                  </p>
                  {salarySuccessResult.synchronizedPayrollPeriods > 0 && (
                    <div style={{ marginTop: '14px', fontSize: '13px', color: '#047857', background: '#d1fae5', padding: '8px 12px', borderRadius: '6px', display: 'inline-block' }}>
                      ⚡ <strong>Monthly Payroll Synchronized:</strong> Automatically updated <strong>{salarySuccessResult.synchronizedPayrollPeriods} open payroll period(s)</strong> with updated salary structures.
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', padding: '14px 20px', display: 'flex', justifyContent: 'flex-end', gap: '8px' }}>
              <button type="button" onClick={() => setIsSalaryUploadModalOpen(false)} className="btn btn-secondary">
                {salarySuccessResult ? 'Close' : 'Cancel'}
              </button>
              {salaryPreviewData && !salarySuccessResult && (
                <button
                  type="button"
                  onClick={handleConfirmSalaryUpload}
                  className="btn btn-primary"
                  disabled={salaryLoading}
                  style={{ fontWeight: 700 }}
                >
                  {salaryLoading ? 'Updating...' : `Confirm Salary Updates (${salaryPreviewData.matchedRows.length} Employees)`}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
