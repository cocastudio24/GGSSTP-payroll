import React, { useState } from 'react';
import { apiRequest, getToken } from '../api';
import { DiscoveredColumn, ExcelInspectResponse } from '../types';
import { FileSpreadsheet, Upload, CheckCircle2, AlertTriangle, Layers, Play, Sliders, RefreshCw } from 'lucide-react';

interface ImportViewProps {
  onRefreshAll: () => void;
}

export const ImportView: React.FC<ImportViewProps> = ({ onRefreshAll }) => {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [inspectData, setInspectData] = useState<ExcelInspectResponse | null>(null);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [columnMappings, setColumnMappings] = useState<Record<number, string>>({});
  const [activeTab, setActiveTab] = useState<'mapping' | 'preview'>('mapping');
  const [importStrategy, setImportStrategy] = useState<'both' | 'add_only' | 'update_only'>('both');
  const [committing, setCommitting] = useState(false);
  const [commitMessage, setCommitMessage] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setInspectData(null);
      setCommitMessage(null);
    }
  };

  const handleUploadAndInspect = async () => {
    if (!file) return;
    try {
      setUploading(true);
      const formData = new FormData();
      formData.append('file', file);
      if (selectedSheet) {
        formData.append('sheetName', selectedSheet);
      }

      const token = getToken();
      const response = await fetch('/api/import/inspect', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
      });
      const data: ExcelInspectResponse = await response.json();
      if (!response.ok) throw new Error((data as any).error || 'Failed to inspect workbook');

      setInspectData(data);
      setSelectedSheet(data.selectedSheet);

      const initialMap: Record<number, string> = {};
      if (data.columns) {
        data.columns.forEach((c) => {
          initialMap[c.colIndex] = c.proposedField;
        });
      }
      setColumnMappings(initialMap);
      setActiveTab('mapping');
    } catch (err: any) {
      alert(`Failed to inspect workbook: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleSheetChange = async (sheetName: string) => {
    if (!file) return;
    try {
      setUploading(true);
      setSelectedSheet(sheetName);
      const formData = new FormData();
      formData.append('file', file);
      formData.append('sheetName', sheetName);

      const token = getToken();
      const response = await fetch('/api/import/inspect', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
      });
      const data: ExcelInspectResponse = await response.json();
      if (!response.ok) throw new Error((data as any).error || 'Failed to load sheet');

      setInspectData(data);
      const initialMap: Record<number, string> = {};
      if (data.columns) {
        data.columns.forEach((c) => {
          initialMap[c.colIndex] = c.proposedField;
        });
      }
      setColumnMappings(initialMap);
    } catch (err: any) {
      alert(`Failed to load sheet: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleColumnMappingChange = (colIndex: number, newFieldKey: string) => {
    setColumnMappings(prev => ({
      ...prev,
      [colIndex]: newFieldKey
    }));
    if (inspectData && inspectData.columns) {
      setInspectData({
        ...inspectData,
        columns: inspectData.columns.map(c => {
          if (c.colIndex !== colIndex) return c;
          return {
            ...c,
            proposedField: newFieldKey,
            status: newFieldKey === '__EXCLUDE__' ? 'excluded' : 'custom',
            reason: newFieldKey === '__EXCLUDE__' ? 'Manually excluded by user' : 'Manually mapped by user'
          };
        })
      });
    }
  };

  const handleCommit = async () => {
    if (!file || !inspectData || !selectedSheet) return;

    try {
      setCommitting(true);
      const formData = new FormData();
      formData.append('file', file);
      formData.append('sheetName', selectedSheet);
      formData.append('mapping', JSON.stringify(columnMappings));
      formData.append('headerRow', String(inspectData.headerRowIndex || 0));
      formData.append('strategy', importStrategy);
      formData.append('month', '9');
      formData.append('year', '2026');

      const token = getToken();
      const response = await fetch('/api/import/execute', {
        method: 'POST',
        headers: token ? { 'Authorization': `Bearer ${token}` } : {},
        body: formData
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to commit mapped import');

      setCommitMessage(data.message || `Successfully committed ${data.result.totalProcessed} records to Monthly Payroll!`);
      onRefreshAll();
    } catch (err: any) {
      alert(`Commit failed: ${err.message}`);
    } finally {
      setCommitting(false);
    }
  };

  const handleSeedReferenceWorkbook = async () => {
    if (!window.confirm('Seed reference data from MM-1 and EMC sheets into September 2026?')) return;
    try {
      setCommitting(true);
      const res = await apiRequest<{ message: string }>('/import/seed-reference', {
        method: 'POST'
      });
      setCommitMessage(res.message);
      onRefreshAll();
    } catch (err: any) {
      alert(`Seed failed: ${err.message}`);
    } finally {
      setCommitting(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div>
        <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Smart Excel Import & Column-Mapping Engine</h2>
        <p style={{ fontSize: '12.5px', color: '#64748b' }}>
          Upload contractual payroll registers (supports MM-1, EMC, and Operation Circle multi-sheet formats) with intelligent column mapping and statutory deduction synchronization
        </p>
      </div>

      {/* One-Click Reference Seeder Card */}
      <div className="card" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #172554 100%)', color: '#ffffff', borderColor: '#1e3a8a' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: '16px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <FileSpreadsheet size={20} color="#f59e0b" />
              <span>Reference Workbook Auto-Loader (SALARY SHEET-for EPF Sepf 2026.xlsx)</span>
            </div>
            <p style={{ fontSize: '12.5px', color: '#bfdbfe', marginTop: '4px' }}>
              Instantly load and reconcile the reference employees across MM-1 and EMC worksheets into September 2026.
            </p>
          </div>
          <button
            onClick={handleSeedReferenceWorkbook}
            disabled={committing}
            className="btn btn-primary"
            style={{ background: '#f59e0b', color: '#0f172a', fontWeight: 700, borderColor: '#f59e0b' }}
          >
            <Play size={16} fill="#0f172a" />
            <span>Load Reference Sheets</span>
          </button>
        </div>
      </div>

      {commitMessage && (
        <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '10px', padding: '16px', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <CheckCircle2 size={20} color="#059669" />
          <span style={{ fontWeight: 600, color: '#065f46', fontSize: '13.5px' }}>{commitMessage}</span>
        </div>
      )}

      {/* File Upload Box */}
      <div className="card">
        <div className="card-header">
          <div className="card-title">
            <Upload size={18} color="#1e3a8a" />
            <span>Upload New Spreadsheet (.xlsx, .xls)</span>
          </div>
        </div>

        <div style={{ border: '2px dashed #cbd5e1', borderRadius: '10px', padding: '30px', textAlign: 'center', background: '#f8fafc' }}>
          <input
            type="file"
            accept=".xlsx, .xls, .csv"
            onChange={handleFileChange}
            id="excel-file-input"
            style={{ display: 'none' }}
          />
          <label htmlFor="excel-file-input" style={{ cursor: 'pointer', display: 'inline-flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
            <FileSpreadsheet size={36} color="#1e3a8a" />
            <span style={{ fontWeight: 600, color: '#1e3a8a', fontSize: '14px' }}>
              {file ? file.name : 'Click to select or drop Excel workbook'}
            </span>
            <span style={{ fontSize: '12px', color: '#64748b' }}>
              Supports XLSX files with MM-1, EMC, and Operation Circle worksheets
            </span>
          </label>
        </div>

        {file && (
          <div style={{ marginTop: '16px', display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
            <button
              onClick={handleUploadAndInspect}
              disabled={uploading}
              className="btn btn-primary"
            >
              {uploading ? 'Analyzing Workbook...' : 'Inspect Sheets & Headers'}
            </button>
          </div>
        )}
      </div>

      {/* Parsed Inspection, Column Mapping & Preview */}
      {inspectData && (
        <div className="card">
          <div className="card-header" style={{ flexWrap: 'wrap', gap: '12px' }}>
            <div className="card-title">
              <Layers size={18} color="#1e3a8a" />
              <span>Inspection & Mapping: {inspectData.fileName}</span>
            </div>
            <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ fontSize: '13px', fontWeight: 600 }}>Worksheet:</span>
                <select
                  value={selectedSheet}
                  onChange={(e) => handleSheetChange(e.target.value)}
                  className="form-input"
                  style={{ width: 'auto', fontWeight: 600 }}
                >
                  {inspectData.sheetNames.length > 1 && (
                    <option value="__ALL__">
                      ✨ All Worksheets (Read & Import All {inspectData.sheetNames.length} Sheets)
                    </option>
                  )}
                  {inspectData.sheetNames.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              {inspectData.sheetsSummary && inspectData.sheetsSummary.length > 1 && (
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center' }}>
                  <span
                    onClick={() => handleSheetChange('__ALL__')}
                    style={{
                      cursor: 'pointer',
                      fontSize: '11px',
                      padding: '2px 8px',
                      borderRadius: '4px',
                      background: selectedSheet === '__ALL__' ? '#1e3a8a' : '#e2e8f0',
                      color: selectedSheet === '__ALL__' ? '#ffffff' : '#334155',
                      fontWeight: 700
                    }}
                  >
                    ✨ ALL ({inspectData.sheetsSummary.reduce((acc, s) => acc + (s.totalRows || 0), 0)} records)
                  </span>
                  {inspectData.sheetsSummary.map((sh) => (
                    <span
                      key={sh.sheetName}
                      onClick={() => handleSheetChange(sh.sheetName)}
                      style={{
                        cursor: 'pointer',
                        fontSize: '11px',
                        padding: '2px 8px',
                        borderRadius: '4px',
                        background: selectedSheet === sh.sheetName ? '#2563eb' : '#e2e8f0',
                        color: selectedSheet === sh.sheetName ? '#ffffff' : '#334155',
                        fontWeight: 600
                      }}
                    >
                      📄 {sh.sheetName} ({sh.totalRows})
                    </span>
                  ))}
                </div>
              )}

              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ fontSize: '13px', fontWeight: 600 }}>Strategy:</span>
                <select
                  value={importStrategy}
                  onChange={(e) => setImportStrategy(e.target.value as any)}
                  className="form-input"
                  style={{ width: 'auto', fontSize: '12.5px' }}
                >
                  <option value="both">Add & Update</option>
                  <option value="add_only">Add Only</option>
                  <option value="update_only">Update Only</option>
                </select>
              </div>

              <button
                onClick={handleCommit}
                disabled={committing}
                className="btn btn-success btn-sm"
                style={{ fontWeight: 700 }}
              >
                {committing
                  ? 'Saving & Synchronizing...'
                  : selectedSheet === '__ALL__'
                  ? `Commit All Sheets (${inspectData.totalRows} records) to Payroll`
                  : `Commit "${selectedSheet}" to Payroll`}
              </button>
            </div>
          </div>

          {/* Metric Summary */}
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #e2e8f0' }}>
            <div className="grid-4" style={{ gap: '10px' }}>
              <div style={{ background: '#eff6ff', padding: '10px 14px', borderRadius: '6px', border: '1px solid #bfdbfe' }}>
                <div style={{ fontSize: '11px', color: '#1e40af' }}>Total Columns Found</div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: '#1e3a8a' }}>{inspectData.totalColumns}</div>
              </div>
              <div style={{ background: '#ecfdf5', padding: '10px 14px', borderRadius: '6px', border: '1px solid #a7f3d0' }}>
                <div style={{ fontSize: '11px', color: '#065f46' }}>Mapped Columns</div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: '#047857' }}>
                  {inspectData.columns.filter(c => columnMappings[c.colIndex] && columnMappings[c.colIndex] !== '__EXCLUDE__').length}
                </div>
              </div>
              <div style={{ background: '#fef3c7', padding: '10px 14px', borderRadius: '6px', border: '1px solid #fde68a' }}>
                <div style={{ fontSize: '11px', color: '#92400e' }}>Ready for Import</div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: '#b45309' }}>{inspectData.previewRows.length} Records</div>
              </div>
              <div style={{ background: '#f8fafc', padding: '10px 14px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontSize: '11px', color: '#475569' }}>Excluded Columns</div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: '#475569' }}>
                  {inspectData.columns.filter(c => columnMappings[c.colIndex] === '__EXCLUDE__').length}
                </div>
              </div>
            </div>

            {/* Tab switch */}
            <div style={{ display: 'flex', gap: '8px', borderBottom: '2px solid #e2e8f0', marginTop: '16px' }}>
              <button
                type="button"
                onClick={() => setActiveTab('mapping')}
                style={{
                  padding: '8px 16px',
                  fontSize: '13px',
                  fontWeight: 700,
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  color: activeTab === 'mapping' ? '#2563eb' : '#64748b',
                  borderBottom: activeTab === 'mapping' ? '2px solid #2563eb' : '2px solid transparent',
                  marginBottom: '-2px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                <Sliders size={15} />
                <span>Column Mapping & Inventory ({inspectData.columns.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                style={{
                  padding: '8px 16px',
                  fontSize: '13px',
                  fontWeight: 700,
                  border: 'none',
                  background: 'none',
                  cursor: 'pointer',
                  color: activeTab === 'preview' ? '#2563eb' : '#64748b',
                  borderBottom: activeTab === 'preview' ? '2px solid #2563eb' : '2px solid transparent',
                  marginBottom: '-2px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                <FileSpreadsheet size={15} />
                <span>Employee Records & Calculations Preview ({inspectData.previewRows.length})</span>
              </button>
            </div>
          </div>

          {/* TAB 1: Column Mapping */}
          {activeTab === 'mapping' && (
            <div className="table-container" style={{ padding: '0 20px 20px' }}>
              <table className="custom-table" style={{ fontSize: '12px' }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th style={{ width: '80px' }}>Col Letter</th>
                    <th style={{ width: '220px' }}>Excel Heading in Worksheet</th>
                    <th style={{ width: '180px' }}>Sample Value (Row 1)</th>
                    <th style={{ width: '280px' }}>Destination Field in Software</th>
                    <th style={{ width: '100px' }}>Status</th>
                    <th>Mapping Reason</th>
                  </tr>
                </thead>
                <tbody>
                  {inspectData.columns.map((col) => {
                    const currentTarget = columnMappings[col.colIndex] || '__EXCLUDE__';
                    const isExcluded = currentTarget === '__EXCLUDE__';
                    return (
                      <tr key={col.colIndex} style={{ background: isExcluded ? '#fcfcfc' : '#ffffff' }}>
                        <td style={{ fontFamily: 'monospace', fontWeight: 800, color: isExcluded ? '#94a3b8' : '#1e3a8a' }}>
                          Col {col.colLetter} ({col.colIndex})
                        </td>
                        <td style={{ fontWeight: 600, color: isExcluded ? '#94a3b8' : '#0f172a' }}>
                          {col.rawHeader}
                        </td>
                        <td style={{ fontFamily: 'monospace', fontSize: '11.5px', color: isExcluded ? '#94a3b8' : '#334155' }}>
                          {col.sampleValue !== undefined && col.sampleValue !== null && col.sampleValue !== '' ? String(col.sampleValue) : '—'}
                        </td>
                        <td>
                          <select
                            value={currentTarget}
                            onChange={(e) => handleColumnMappingChange(col.colIndex, e.target.value)}
                            className="form-input"
                            style={{
                              fontSize: '12px',
                              padding: '4px 8px',
                              fontWeight: 600,
                              width: '100%',
                              borderColor: isExcluded ? '#cbd5e1' : '#2563eb',
                              background: isExcluded ? '#f8fafc' : '#ffffff',
                              color: isExcluded ? '#64748b' : '#0f172a'
                            }}
                          >
                            <option value="__EXCLUDE__">⛔ Do Not Import (Exclude Column)</option>
                            <optgroup label="1. Employee Identification">
                              <option value="emp_code">Employee Code / ID (emp_code)</option>
                              <option value="sr_no">Serial Number (sr_no)</option>
                              <option value="name">Employee Full Name (name)</option>
                              <option value="father_name">Father's / Husband's Name (father_name)</option>
                              <option value="designation">Designation / Skill Category (designation)</option>
                              <option value="contractor">Contractor / Service Provider (contractor)</option>
                              <option value="circle">Circle Name (circle)</option>
                              <option value="cell_department">Cell / Department / Office (cell_department)</option>
                            </optgroup>
                            <optgroup label="2. Identity & Statutory Numbers">
                              <option value="uan">UAN (Universal Account Number)</option>
                              <option value="esi_number">ESI / ESIC Number</option>
                              <option value="aadhar_number">Aadhaar Card Number</option>
                              <option value="pan_number">PAN Card Number</option>
                              <option value="mobile_number">Mobile Phone Number</option>
                            </optgroup>
                            <optgroup label="3. Bank & Payment Details">
                              <option value="bank_account">Bank Account Number</option>
                              <option value="ifsc">Bank IFSC Code</option>
                              <option value="bank_name">Bank Name</option>
                              <option value="account_holder_name">Account Holder Name</option>
                            </optgroup>
                            <optgroup label="4. HR & Service Information">
                              <option value="dob">Date of Birth (dob)</option>
                              <option value="age_above_58">Age Above 58 (age_above_58)</option>
                              <option value="date_of_joining">Date of Joining (date_of_joining)</option>
                              <option value="date_of_exit">Date of Exit (date_of_exit)</option>
                              <option value="more_than_3_yrs">More than 3 Years</option>
                              <option value="more_than_5_yrs">More than 5 Years</option>
                              <option value="qualification">Educational Qualification</option>
                              <option value="experience_years">Experience in Years</option>
                              <option value="qualified_status">Qualified Status (Yes/No)</option>
                              <option value="hazard_duty">Hazard Duty Classification</option>
                              <option value="check_status">Verification Check Status</option>
                            </optgroup>
                            <optgroup label="5. Attendance & Salary Rates">
                              <option value="total_days">Total Month Days (30)</option>
                              <option value="present_days">Present / Duty Days</option>
                              <option value="gross_salary_rate">Gross Salary Rate / Wage Rate</option>
                              <option value="proportioned_salary">Proportioned Salary Rate</option>
                              <option value="special_allowance">Special Allowance Rate</option>
                              <option value="total_basic">Total Basic Salary</option>
                              <option value="thermal_allowance">Thermal Allowance (₹1500)</option>
                              <option value="perf_allowance_monthly">Monthly Performance Allowance</option>
                              <option value="perf_allowance_days">Days-wise Performance Allowance</option>
                              <option value="total_earnings_before_bonus">Total Earnings Before Bonus</option>
                              <option value="bonus">Bonus Amount</option>
                              <option value="bonus_percentage">Bonus Percentage (%)</option>
                            </optgroup>
                            <optgroup label="6. Statutory Deductions & Contributions">
                              <option value="employee_epf_12">Employee EPF Deduction (12%)</option>
                              <option value="employee_esi_075">Employee ESI Deduction (0.75%)</option>
                              <option value="employee_lwf">Employee LWF Deduction (₹5)</option>
                              <option value="total_employee_deductions">Total Employee Deductions</option>
                              <option value="employer_epf_12">Employer EPF Contribution (12%)</option>
                              <option value="employer_epf_1">Employer EPF Admin Charges (1%)</option>
                              <option value="employer_esi_325">Employer ESI Contribution (3.25%)</option>
                              <option value="employer_lwf">Employer LWF Contribution (₹20)</option>
                              <option value="total_employer_contributions">Total Employer Contributions</option>
                              <option value="combined_deductions">Combined Deductions</option>
                            </optgroup>
                            <optgroup label="7. Totals & Net Salary">
                              <option value="gross_total">Gross Total</option>
                              <option value="net_payable">Net Payable Salary</option>
                              <option value="perf_last_drawn">Performance Last Drawn</option>
                              <option value="perf_as_per_circle">Performance As Per Circle</option>
                              <option value="perf_difference">Performance Difference</option>
                            </optgroup>
                          </select>
                        </td>
                        <td>
                          {isExcluded ? (
                            <span className="badge" style={{ background: '#f1f5f9', color: '#64748b' }}>Excluded</span>
                          ) : col.status === 'matched' ? (
                            <span className="badge badge-active">Auto-Matched</span>
                          ) : col.status === 'custom' ? (
                            <span className="badge" style={{ background: '#eff6ff', color: '#1d4ed8' }}>User Mapped</span>
                          ) : (
                            <span className="badge" style={{ background: '#fef3c7', color: '#92400e' }}>Needs Review</span>
                          )}
                        </td>
                        <td style={{ fontSize: '11px', color: isExcluded ? '#94a3b8' : '#64748b' }}>
                          {col.reason}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB 2: Employee Records Preview */}
          {activeTab === 'preview' && (
            <div className="table-container" style={{ padding: '0 20px 20px' }}>
              <table className="custom-table" style={{ fontSize: '12px' }}>
                <thead>
                  <tr style={{ background: '#f8fafc' }}>
                    <th>Emp Code</th>
                    <th>Name</th>
                    <th>Designation</th>
                    <th>UAN</th>
                    <th>Bank Account</th>
                    <th>Days</th>
                    <th>Present</th>
                    <th>Basic Salary</th>
                    <th>Thermal</th>
                    <th>Monthly Perf</th>
                    <th>Bonus</th>
                    <th>EPF (12%)</th>
                    <th>ESI (0.75%)</th>
                    <th>Total Deductions</th>
                    <th>Net Payable</th>
                  </tr>
                </thead>
                <tbody>
                  {inspectData.previewRows.slice(0, 50).map((row: any, i: number) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>{row.empCode}</td>
                      <td style={{ fontWeight: 600 }}>{row.name}</td>
                      <td><span className="badge" style={{ background: '#f1f5f9' }}>{row.designationAlias}</span></td>
                      <td style={{ fontFamily: 'monospace', fontSize: '11px' }}>{row.uan || '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: '11px' }}>{row.bankAccount || '—'}</td>
                      <td>{row.totalDays}</td>
                      <td style={{ fontWeight: 600 }}>{row.presentDays}</td>
                      <td style={{ fontFamily: 'monospace' }}>₹{row.totalBasic || '—'}</td>
                      <td style={{ fontFamily: 'monospace' }}>₹{row.thermalAllowance || '—'}</td>
                      <td style={{ fontFamily: 'monospace' }}>₹{row.perfAllowanceMonthly || '—'}</td>
                      <td style={{ fontFamily: 'monospace' }}>₹{row.bonus || '—'}</td>
                      <td style={{ fontFamily: 'monospace', color: '#dc2626' }}>₹{row.customEmployeeEpf || row.employeeEpf12 || '—'}</td>
                      <td style={{ fontFamily: 'monospace', color: '#dc2626' }}>₹{row.customEmployeeEsi || row.employeeEsi075 || '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontWeight: 700, color: '#b91c1c' }}>₹{row.importedTotalEmployeeDeductions || row.totalEmployeeDeductions || '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontWeight: 800, color: '#047857' }}>₹{row.importedNetPayable || row.netPayable || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div style={{ padding: '10px 14px', fontSize: '12px', color: '#64748b', background: '#f8fafc', borderTop: '1px solid #e2e8f0' }}>
                Showing first 50 of {inspectData.previewRows.length} parsed records from {selectedSheet}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
