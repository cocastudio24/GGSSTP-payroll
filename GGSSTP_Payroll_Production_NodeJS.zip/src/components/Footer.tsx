import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard, Users, Calculator, Sliders, Award, Building2,
  FileSpreadsheet, Download, CheckCircle2, ShieldCheck, History,
  Settings, Clock, Calendar, ArrowUp, Shield, MessageSquare,
  Building, MapPin, Zap, ExternalLink, RefreshCw
} from 'lucide-react';

interface FooterProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole?: string;
  onOpenChat?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  currentTab,
  setCurrentTab,
  userRole,
  onOpenChat
}) => {
  const [currentDateTime, setCurrentDateTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const scrollToTop = () => {
    const scrollContainer = document.querySelector('.view-scroll-container');
    if (scrollContainer) {
      scrollContainer.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleNavClick = (tabId: string) => {
    setCurrentTab(tabId);
    scrollToTop();
  };

  // Grouped Quick Navigation Links
  const quickLinkSections = [
    {
      title: 'Core Operations',
      links: [
        { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard },
        { id: 'employees', label: 'Employee Master Roster', icon: Users },
        { id: 'payroll', label: 'Monthly Payroll Processing', icon: Calculator },
        { id: 'reconciliation', label: 'Formula Reconciliation', icon: CheckCircle2 }
      ]
    },
    {
      title: 'Statutory & Rules Master',
      links: [
        { id: 'formula-rules', label: 'Formula & Rules Engine', icon: Sliders },
        { id: 'designations', label: 'Designations & Wage Rates', icon: Award },
        { id: 'contractors', label: 'Contractors & Circle Mapping', icon: Building2 },
        { id: 'settings', label: 'Statutory EPF / ESI / LWF Rates', icon: Settings }
      ]
    },
    {
      title: 'Data & Compliance Reports',
      links: [
        { id: 'import', label: 'Excel Import Center', icon: FileSpreadsheet },
        { id: 'export', label: 'Compliance Reports & Bank Sheets', icon: Download },
        { id: 'reconciliation', label: 'Formula-Preserved Excel Exports', icon: CheckCircle2 }
      ]
    },
    {
      title: 'Administration & System',
      links: [
        ...(userRole === 'Super Administrator' ? [{ id: 'users', label: 'User & Security Management', icon: ShieldCheck }] : []),
        { id: 'audit', label: 'Activity & Audit Logs', icon: History },
        { id: 'settings', label: 'System Settings & Backups', icon: Settings },
        ...(onOpenChat ? [{ id: 'chat', label: 'Team Chat & Secure File Sharing', icon: MessageSquare, isChat: true }] : [])
      ]
    }
  ];

  // Time, Month, and Year formatting
  const formattedTime = currentDateTime.toLocaleTimeString('en-IN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });
  const formattedMonth = currentDateTime.toLocaleString('en-IN', { month: 'long' });
  const formattedYear = currentDateTime.getFullYear();
  const formattedFullDate = currentDateTime.toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <footer className="portal-footer" style={{
      background: 'linear-gradient(180deg, #0f172a 0%, #090d16 100%)',
      color: '#e2e8f0',
      borderTop: '3px solid #1e3a8a',
      marginTop: 'auto',
      width: '100%',
      boxSizing: 'border-box',
      fontSize: '13px'
    }}>
      {/* ================= TIER 1: BRANDING & SYSTEM STATUS BAR ================= */}
      <div style={{
        padding: '24px 32px 18px',
        borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{
            background: 'linear-gradient(135deg, #1e3a8a 0%, #172554 100%)',
            padding: '10px',
            borderRadius: '10px',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
          }}>
            <Zap size={22} color="#f59e0b" fill="#f59e0b" />
          </div>
          <div>
            <div style={{ fontSize: '16px', fontWeight: 800, color: '#ffffff', letterSpacing: '0.3px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span>PUNJAB STATE POWER CORPORATION LIMITED</span>
              <span style={{ fontSize: '11px', background: '#1e3a8a', color: '#93c5fd', padding: '2px 8px', borderRadius: '4px', fontWeight: 700 }}>
                PSPCL / PSEB
              </span>
            </div>
            <div style={{ fontSize: '12.5px', color: '#94a3b8', marginTop: '2px' }}>
              Guru Gobind Singh Super Thermal Plant (GGSSTP), Rupnagar — Contractual Labour & Salary Payroll Portal
            </div>
          </div>
        </div>

        {/* Live System Operational Status & Back to Top */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            background: 'rgba(5, 150, 105, 0.12)',
            border: '1px solid rgba(16, 185, 129, 0.25)',
            padding: '6px 14px',
            borderRadius: '20px'
          }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#10b981',
              boxShadow: '0 0 8px #10b981',
              display: 'inline-block'
            }} />
            <span style={{ fontSize: '11.5px', fontWeight: 700, color: '#34d399', letterSpacing: '0.4px' }}>
              SYSTEM OPERATIONAL • ENCRYPTED
            </span>
          </div>

          <button
            onClick={scrollToTop}
            title="Scroll to Top of Page"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid rgba(255, 255, 255, 0.12)',
              color: '#cbd5e1',
              padding: '6px 14px',
              borderRadius: '8px',
              fontSize: '12px',
              fontWeight: 600,
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.16)';
              e.currentTarget.style.color = '#ffffff';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(255, 255, 255, 0.08)';
              e.currentTarget.style.color = '#cbd5e1';
            }}
          >
            <ArrowUp size={14} />
            <span>Top</span>
          </button>
        </div>
      </div>

      {/* ================= TIER 2: EXPANDED QUICK NAVIGATION LINKS ================= */}
      <div style={{
        padding: '28px 32px 24px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: '24px',
        borderBottom: '1px solid rgba(255, 255, 255, 0.08)'
      }}>
        {quickLinkSections.map((section, sIdx) => (
          <div key={sIdx} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{
              fontSize: '12px',
              fontWeight: 800,
              color: '#38bdf8',
              textTransform: 'uppercase',
              letterSpacing: '0.8px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}>
              <span>{section.title}</span>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
              {section.links.map((link: any, lIdx: number) => {
                const Icon = link.icon;
                const isActive = currentTab === link.id && !link.isChat;
                return (
                  <button
                    key={lIdx}
                    onClick={() => {
                      if (link.isChat && onOpenChat) {
                        onOpenChat();
                      } else {
                        handleNavClick(link.id);
                      }
                    }}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '9px',
                      padding: '7px 10px',
                      borderRadius: '6px',
                      background: isActive ? 'rgba(30, 58, 138, 0.55)' : 'transparent',
                      color: isActive ? '#ffffff' : '#94a3b8',
                      border: isActive ? '1px solid rgba(59, 130, 246, 0.4)' : '1px solid transparent',
                      textAlign: 'left',
                      fontSize: '12.5px',
                      fontWeight: isActive ? 700 : 500,
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                    onMouseEnter={(e) => {
                      if (!isActive) {
                        e.currentTarget.style.background = 'rgba(255, 255, 255, 0.06)';
                        e.currentTarget.style.color = '#f1f5f9';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!isActive) {
                        e.currentTarget.style.background = 'transparent';
                        e.currentTarget.style.color = '#94a3b8';
                      }
                    }}
                  >
                    <Icon size={14} color={isActive ? '#60a5fa' : '#64748b'} />
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {link.label}
                    </span>
                    {isActive && (
                      <span style={{
                        marginLeft: 'auto',
                        width: '6px',
                        height: '6px',
                        borderRadius: '50%',
                        background: '#38bdf8'
                      }} />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* ================= TIER 3: LIVE TELEMETRY (TIME, MONTH, YEAR & SITE UPDATED) ================= */}
      <div style={{
        padding: '16px 32px',
        background: 'rgba(0, 0, 0, 0.25)',
        borderBottom: '1px solid rgba(255, 255, 255, 0.06)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '14px',
        fontSize: '12px'
      }}>
        {/* Left: Dynamic Live Clock with Time, Month, and Year */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: '#94a3b8' }}>
            <Clock size={15} color="#38bdf8" />
            <span style={{ fontWeight: 600 }}>Live Server Clock:</span>
          </div>

          {/* Time Badge */}
          <div style={{
            background: 'rgba(15, 23, 42, 0.8)',
            border: '1px solid rgba(56, 189, 248, 0.3)',
            padding: '3px 10px',
            borderRadius: '6px',
            fontFamily: 'monospace',
            color: '#38bdf8',
            fontWeight: 700,
            fontSize: '13px',
            letterSpacing: '0.5px'
          }}>
            {formattedTime}
          </div>

          {/* Month Badge */}
          <div style={{
            background: 'rgba(15, 23, 42, 0.8)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            padding: '3px 10px',
            borderRadius: '6px',
            color: '#f8fafc',
            fontWeight: 700,
            fontSize: '12px'
          }}>
            Month: <span style={{ color: '#fbbf24' }}>{formattedMonth}</span>
          </div>

          {/* Year Badge */}
          <div style={{
            background: 'rgba(15, 23, 42, 0.8)',
            border: '1px solid rgba(255, 255, 255, 0.15)',
            padding: '3px 10px',
            borderRadius: '6px',
            color: '#f8fafc',
            fontWeight: 700,
            fontSize: '12px'
          }}>
            Year: <span style={{ color: '#34d399' }}>{formattedYear}</span>
          </div>

          <span style={{ color: '#64748b', fontSize: '11.5px' }}>
            ({formattedFullDate})
          </span>
        </div>

        {/* Right: When Site Was Updated */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#94a3b8' }}>
          <RefreshCw size={14} color="#10b981" />
          <span>Site Last Updated:</span>
          <span style={{
            color: '#f1f5f9',
            fontWeight: 700,
            background: 'rgba(255, 255, 255, 0.08)',
            padding: '3px 10px',
            borderRadius: '6px',
            border: '1px solid rgba(255, 255, 255, 0.1)'
          }}>
            October 11, 2026 • 17:30 IST
          </span>
          <span style={{ color: '#64748b', fontSize: '11px' }}>| Build v2.4.2</span>
        </div>
      </div>

      {/* ================= TIER 4: OFFICIAL COPYRIGHT & LEGAL JURISDICTION ================= */}
      <div style={{
        padding: '18px 32px 22px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '12px',
        fontSize: '12px',
        color: '#94a3b8'
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
          {/* EXACT MANDATORY COPYRIGHT STRING */}
          <div style={{ color: '#ffffff', fontWeight: 700, fontSize: '13px', letterSpacing: '0.2px' }}>
            © 2026 Punjab State Power Corporation Limited PSEB Head Office, The MALL, Patiala
          </div>
          <div style={{ fontSize: '11.5px', color: '#64748b' }}>
            All Rights Reserved. Official Payroll Management & Statutory Labour Records System for GGSSTP Rupnagar Thermal Plant.
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', fontSize: '11.5px', color: '#64748b' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <MapPin size={13} color="#94a3b8" />
            PSEB Head Office, The Mall, Patiala - 147001
          </span>
          <span>•</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
            <Shield size={13} color="#10b981" />
            ISO 9001 / Cyber Compliance
          </span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
