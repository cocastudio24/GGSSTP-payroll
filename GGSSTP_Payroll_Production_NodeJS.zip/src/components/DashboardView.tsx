import React, { useState, useMemo } from 'react';
import { DashboardStats, DashboardEmployeeItem, CircleWorkforceStats } from '../types';
import {
  Users, DollarSign, AlertTriangle, ShieldAlert,
  Building, CheckCircle, TrendingUp, Award, Layers,
  ChevronRight, Search, X, Calendar, ArrowRight, ExternalLink
} from 'lucide-react';

interface DashboardViewProps {
  stats: DashboardStats | null;
  loading: boolean;
  onNavigateTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ stats, loading, onNavigateTab }) => {
  // Active Circle Tab
  const [activeCircleTab, setActiveCircleTab] = useState<string>('EMC');
  const [circleSearch, setCircleSearch] = useState('');

  // Contractor Modal / Drilldown
  const [selectedContractor, setSelectedContractor] = useState<{
    id?: number;
    contractor: string;
    count: number;
    totalNetPayable?: number;
    totalEmployeeDeductions?: number;
    totalEmployeeEpf?: number;
    totalEmployeeEsi?: number;
    totalEmployeeLwf?: number;
    employees?: DashboardEmployeeItem[];
  } | null>(null);
  const [contractorSearch, setContractorSearch] = useState('');

  // Designation Modal / Drilldown
  const [selectedDesignation, setSelectedDesignation] = useState<{
    designation: string;
    alias?: string;
    count: number;
    totalNetPayable?: number;
    totalEmployeeDeductions?: number;
    totalEmployeeEpf?: number;
    totalEmployeeEsi?: number;
    totalEmployeeLwf?: number;
    employees?: DashboardEmployeeItem[];
  } | null>(null);
  // Circle workforce data - MUST be declared before any conditional return to adhere to React Hook rules
  const availableCircles: CircleWorkforceStats[] = useMemo(() => {
    if (!stats) return [];
    const circleWorkforce = stats.circleWorkforce;
    if (circleWorkforce?.allCircles && circleWorkforce.allCircles.length > 0) {
      return circleWorkforce.allCircles;
    }
    const list: CircleWorkforceStats[] = [];
    if (circleWorkforce?.emc && circleWorkforce.emc.totalCount > 0) list.push(circleWorkforce.emc);
    if (circleWorkforce?.mm1 && circleWorkforce.mm1.totalCount > 0) list.push(circleWorkforce.mm1);
    if (list.length === 0) {
      if (circleWorkforce?.emc) list.push(circleWorkforce.emc);
      if (circleWorkforce?.mm1) list.push(circleWorkforce.mm1);
    }
    return list;
  }, [stats]);

  const currentCircle = useMemo(() => {
    if (!availableCircles.length) return null;
    const match = availableCircles.find(c =>
      c.circleName.toLowerCase().includes(activeCircleTab.toLowerCase()) ||
      activeCircleTab.toLowerCase().includes(c.circleName.toLowerCase())
    );
    return match || availableCircles[0];
  }, [availableCircles, activeCircleTab]);

  if (loading || !stats) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '300px' }}>
        <div style={{ fontSize: '15px', color: '#64748b' }}>Loading dashboard telemetry...</div>
      </div>
    );
  }

  const {
    employeeOverview = {} as any,
    employeesByDesignation = [],
    employeesByContractor = [],
    employeesByCircle = [],
    circleWorkforce,
    payrollStats = {} as any
  } = stats;

  const formatCurrency = (val: number) => {
    return '₹' + Number(val || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Finalized': return <span className="badge badge-finalized">Finalized & Locked</span>;
      case 'Approved': return <span className="badge badge-approved">Approved</span>;
      case 'Under Review': return <span className="badge badge-under-review">Under Review</span>;
      case 'Calculated': return <span className="badge badge-calculated">Calculated</span>;
      default: return <span className="badge badge-draft">Draft</span>;
    }
  };

  const filteredCircleEmployees = (currentCircle?.employees || []).filter(e => {
    if (!circleSearch.trim()) return true;
    const q = circleSearch.toLowerCase();
    return (
      (e.name || '').toLowerCase().includes(q) ||
      (e.emp_code || '').toLowerCase().includes(q) ||
      (e.contractor_name || '').toLowerCase().includes(q) ||
      (e.designation_name || '').toLowerCase().includes(q)
    );
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Title & Status Banner */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#ffffff', padding: '20px 24px', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
        <div>
          <h1 style={{ fontSize: '20px', fontWeight: 800, color: '#0f172a' }}>
            Guru Gobind Singh Super Thermal Plant, Rupnagar
          </h1>
          <p style={{ fontSize: '13px', color: '#64748b', marginTop: '2px' }}>
            Contractual Labor Operations & Statutory Payroll Reconciliation — {payrollStats?.periodName || 'System Active'}
          </p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <span style={{ fontSize: '13px', fontWeight: 600, color: '#475569' }}>Payroll Status:</span>
          {getStatusBadge(payrollStats?.status || 'Draft')}
          <button
            onClick={() => onNavigateTab('payroll')}
            className="btn btn-primary btn-sm"
          >
            Manage Payroll
          </button>
        </div>
      </div>

      {/* Warning / Data Quality Alerts */}
      {(Number(employeeOverview?.missing_bank) > 0 || Number(employeeOverview?.missing_uan) > 0 || Number(employeeOverview?.missing_esi) > 0) && (
        <div style={{ background: '#fffbeb', border: '1px solid #fde68a', borderRadius: '10px', padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <AlertTriangle size={20} color="#d97706" />
            <div>
              <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#92400e' }}>
                Pending Employee Data Verification Detected
              </div>
              <div style={{ fontSize: '12px', color: '#b45309', marginTop: '1px' }}>
                {Number(employeeOverview?.missing_bank) > 0 && `${employeeOverview.missing_bank} missing bank accounts. `}
                {Number(employeeOverview?.missing_uan) > 0 && `${employeeOverview.missing_uan} missing UAN numbers. `}
                {Number(employeeOverview?.missing_esi) > 0 && `${employeeOverview.missing_esi} missing ESI identifiers.`}
              </div>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('employees')}
            className="btn btn-secondary btn-sm"
            style={{ borderColor: '#d97706', color: '#92400e' }}
          >
            Review Employees
          </button>
        </div>
      )}

      {/* Key Financial Metrics Cards */}
      <div className="grid-4">
        <div className="stat-card" style={{ borderLeft: '4px solid #1e3a8a' }}>
          <div className="stat-card-title">Total Active Contractual Staff</div>
          <div className="stat-card-value" style={{ color: '#1e3a8a' }}>{employeeOverview?.active || 0}</div>
          <div className="stat-card-sub">{payrollStats?.totalEmployeesPaid || 0} in current payroll run</div>
        </div>

        <div className="stat-card" style={{ borderLeft: '4px solid #059669' }}>
          <div className="stat-card-title">Total Gross Earnings</div>
          <div className="stat-card-value" style={{ color: '#059669' }}>{formatCurrency(payrollStats?.totalGrossEarnings)}</div>
          <div className="stat-card-sub">Basic + Thermal + Perf + Bonus</div>
        </div>

        <div className="stat-card" style={{ borderLeft: '4px solid #dc2626' }}>
          <div className="stat-card-title">Employee Deductions</div>
          <div className="stat-card-value" style={{ color: '#dc2626' }}>{formatCurrency(payrollStats.totalEmployeeDeductions)}</div>
          <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap', marginTop: '4px', fontSize: '11px', color: '#64748b' }}>
            <span>EPF: <strong style={{ color: '#b91c1c' }}>{formatCurrency(payrollStats.totalEmployeeEpf)}</strong></span>
            <span>•</span>
            <span>ESI: <strong style={{ color: '#c2410c' }}>{formatCurrency(payrollStats.totalEmployeeEsi)}</strong></span>
            <span>•</span>
            <span>LWF: <strong style={{ color: '#15803d' }}>{formatCurrency(payrollStats.totalEmployeeLwf)}</strong></span>
          </div>
        </div>

        <div className="stat-card" style={{ borderLeft: '4px solid #0891b2' }}>
          <div className="stat-card-title">Net Payable Salary</div>
          <div className="stat-card-value" style={{ color: '#0891b2' }}>{formatCurrency(payrollStats.totalNetPayable)}</div>
          <div className="stat-card-sub">Total direct worker disbursement</div>
        </div>
      </div>

      {/* Statutory Deductions Individual Breakdown Strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '14px', marginTop: '-8px' }}>
        <div style={{ background: '#fff', border: '1px solid #fee2e2', borderLeft: '4px solid #dc2626', borderRadius: '10px', padding: '14px 18px', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: '11.5px', fontWeight: 700, color: '#991b1b', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
              Employee EPF (12%)
            </div>
            <span style={{ fontSize: '10.5px', background: '#fee2e2', color: '#991b1b', fontWeight: 700, padding: '2px 7px', borderRadius: '4px' }}>
              Wage Ceiling ₹25,000
            </span>
          </div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#b91c1c', fontFamily: 'monospace', marginTop: '6px' }}>
            {formatCurrency(payrollStats.totalEmployeeEpf)}
          </div>
          <div style={{ fontSize: '11.5px', color: '#7f1d1d', marginTop: '2px' }}>
            Employees' Provident Fund Deductions
          </div>
        </div>

        <div style={{ background: '#fff', border: '1px solid #ffedd5', borderLeft: '4px solid #ea580c', borderRadius: '10px', padding: '14px 18px', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: '11.5px', fontWeight: 700, color: '#9a3412', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
              Employee ESI (0.75%)
            </div>
            <span style={{ fontSize: '10.5px', background: '#ffedd5', color: '#9a3412', fontWeight: 700, padding: '2px 7px', borderRadius: '4px' }}>
              Wage Limit ≤ ₹21,000
            </span>
          </div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#c2410c', fontFamily: 'monospace', marginTop: '6px' }}>
            {formatCurrency(payrollStats.totalEmployeeEsi)}
          </div>
          <div style={{ fontSize: '11.5px', color: '#7c2d12', marginTop: '2px' }}>
            State Insurance Statutory Deductions
          </div>
        </div>

        <div style={{ background: '#fff', border: '1px solid #dcfce7', borderLeft: '4px solid #16a34a', borderRadius: '10px', padding: '14px 18px', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: '11.5px', fontWeight: 700, color: '#166534', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
              Employee LWF (₹5)
            </div>
            <span style={{ fontSize: '10.5px', background: '#dcfce7', color: '#166534', fontWeight: 700, padding: '2px 7px', borderRadius: '4px' }}>
              Punjab Statutory Rate
            </span>
          </div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#15803d', fontFamily: 'monospace', marginTop: '6px' }}>
            {formatCurrency(payrollStats.totalEmployeeLwf)}
          </div>
          <div style={{ fontSize: '11.5px', color: '#14532d', marginTop: '2px' }}>
            Punjab Labour Welfare Fund Deductions
          </div>
        </div>

        <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderLeft: '4px solid #475569', borderRadius: '10px', padding: '14px 18px', boxShadow: '0 1px 3px rgba(0,0,0,0.04)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: '11.5px', fontWeight: 700, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
              Total Employee Deductions
            </div>
            <span style={{ fontSize: '10.5px', background: '#f1f5f9', color: '#475569', fontWeight: 700, padding: '2px 7px', borderRadius: '4px' }}>
              EPF + ESI + LWF
            </span>
          </div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#0f172a', fontFamily: 'monospace', marginTop: '6px' }}>
            {formatCurrency(payrollStats.totalEmployeeDeductions)}
          </div>
          <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
            Combined Total Recovered from Workers
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION 1: WORKING EMPLOYEES IN EMC CIRCLE & MM-1 CIRCLE                 */}
      {/* ========================================================================= */}
      <div className="card" style={{ padding: '20px', borderTop: '4px solid #1e3a8a' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Layers size={22} color="#1e3a8a" />
              <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a', margin: 0 }}>
                Operational Circles Workforce {availableCircles.length > 0 ? `(${availableCircles.map(c => c.circleName).join(' & ')})` : ''}
              </h2>
            </div>
            <p style={{ fontSize: '12.5px', color: '#64748b', marginTop: '3px' }}>
              Complete roster and compensation breakdown of contractual employees deployed across plant circles (Sorted Alphabetically by Name)
            </p>
          </div>

          {/* Circle Tabs Selector */}
          <div style={{ display: 'flex', background: '#f1f5f9', padding: '4px', borderRadius: '8px', gap: '4px', flexWrap: 'wrap' }}>
            {availableCircles.map(circle => {
              const isSelected = currentCircle?.circleName === circle.circleName;
              return (
                <button
                  key={circle.circleName}
                  onClick={() => { setActiveCircleTab(circle.circleName); setCircleSearch(''); }}
                  style={{
                    padding: '6px 16px',
                    borderRadius: '6px',
                    border: 'none',
                    fontWeight: 700,
                    fontSize: '13px',
                    cursor: 'pointer',
                    background: isSelected ? '#1e3a8a' : 'transparent',
                    color: isSelected ? '#ffffff' : '#475569',
                    transition: 'all 0.15s ease'
                  }}
                >
                  {circle.circleName} ({circle.totalCount || 0} Staff)
                </button>
              );
            })}
          </div>
        </div>

        {/* Circle Key Statistics Bar */}
        {currentCircle && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '14px', marginBottom: '16px', background: '#f8fafc', padding: '14px 18px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Circle Division</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#1e3a8a' }}>{currentCircle.circleName}</div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>Active deployed staff</div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Total Personnel</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a' }}>{currentCircle.totalCount} Employees</div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>100% active status</div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Basic Wages Sum</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#1e3a8a', fontFamily: 'monospace' }}>
                ₹{currentCircle.totalBasic.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>Proportionate basic</div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Total Deductions</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#dc2626', fontFamily: 'monospace' }}>
                ₹{Number(currentCircle.totalEmployeeDeductions || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </div>
              <div style={{ fontSize: '10.5px', color: '#64748b' }}>
                EPF: ₹{Number(currentCircle.totalEmployeeEpf || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })} • ESI: ₹{Number(currentCircle.totalEmployeeEsi || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })} • LWF: ₹{Number(currentCircle.totalEmployeeLwf || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Net Disbursement</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#059669', fontFamily: 'monospace' }}>
                ₹{currentCircle.totalNetPayable.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>Net payable amount</div>
            </div>
          </div>
        )}

        {/* Circle Employee Search Bar */}
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '14px' }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <Search size={16} color="#94a3b8" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder={`Search employees in ${currentCircle?.circleName || activeCircleTab} Circle by name, code, contractor, designation...`}
              className="form-input"
              style={{ paddingLeft: '36px' }}
              value={circleSearch}
              onChange={(e) => setCircleSearch(e.target.value)}
            />
          </div>
          <span style={{ fontSize: '12px', color: '#64748b', whiteSpace: 'nowrap' }}>
            Showing <strong>{filteredCircleEmployees.length}</strong> of {currentCircle?.totalCount || 0} employees (Sorted A–Z)
          </span>
        </div>

        {/* Circle Employee Table */}
        <div className="table-container" style={{ maxHeight: '420px', overflowY: 'auto' }}>
          <table className="custom-table">
            <thead>
              <tr>
                <th style={{ width: '40px', textAlign: 'center' }}>#</th>
                <th>Employee Name (A–Z)</th>
                <th>Emp Code</th>
                <th>Designation</th>
                <th>Service Provider / Contractor</th>
                <th style={{ textAlign: 'center' }}>Present Days</th>
                <th className="num">Gross Rate</th>
                <th className="num">Total Basic</th>
                <th className="num" style={{ color: '#b91c1c' }}>EPF 12% (₹)</th>
                <th className="num" style={{ color: '#c2410c' }}>ESI 0.75% (₹)</th>
                <th className="num" style={{ color: '#15803d' }}>LWF (₹)</th>
                <th className="num" style={{ color: '#dc2626' }}>Total Ded (₹)</th>
                <th className="num" style={{ background: '#eff6ff', color: '#1e3a8a' }}>Net Payable (₹)</th>
              </tr>
            </thead>
            <tbody>
              {filteredCircleEmployees.length === 0 ? (
                <tr>
                  <td colSpan={13} style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    No employees found matching "{circleSearch}".
                  </td>
                </tr>
              ) : (
                filteredCircleEmployees.map((emp, idx) => (
                  <tr key={emp.id}>
                    <td style={{ textAlign: 'center', color: '#94a3b8', fontSize: '12px' }}>{idx + 1}</td>
                    <td>
                      <div style={{ fontWeight: 700, color: '#0f172a' }}>{emp.name}</div>
                      {emp.uan && <div style={{ fontSize: '11px', color: '#64748b', fontFamily: 'monospace' }}>UAN: {emp.uan}</div>}
                    </td>
                    <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>
                      {emp.emp_code}
                    </td>
                    <td>
                      <span className="badge" style={{ background: '#f1f5f9', color: '#1e293b' }}>
                        {emp.designation_alias || 'SW'}
                      </span>
                    </td>
                    <td style={{ fontSize: '12px', color: '#475569' }}>
                      {emp.contractor_name}
                    </td>
                    <td style={{ textAlign: 'center', fontWeight: 600 }}>
                      {emp.present_days}
                    </td>
                    <td className="num">₹{Number(emp.gross_salary_rate || 0).toLocaleString('en-IN')}</td>
                    <td className="num">₹{Number(emp.total_basic || 0).toLocaleString('en-IN')}</td>
                    <td className="num" style={{ color: '#b91c1c', fontFamily: 'monospace' }}>
                      ₹{Number(emp.employee_epf_12 || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="num" style={{ color: '#c2410c', fontFamily: 'monospace' }}>
                      ₹{Number(emp.employee_esi_075 || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="num" style={{ color: '#15803d', fontFamily: 'monospace' }}>
                      ₹{Number(emp.employee_lwf || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="num" style={{ color: '#dc2626', fontWeight: 700, fontFamily: 'monospace' }}>
                      ₹{Number(emp.total_employee_deductions || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                    <td className="num" style={{ fontWeight: 800, color: '#1e3a8a', background: '#eff6ff' }}>
                      ₹{Number(emp.net_payable || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* SECTION 2: ORGANIZATIONAL BREAKDOWNS (DESIGNATIONS & CONTRACTORS)        */}
      {/* ========================================================================= */}
      <div className="grid-2">
        {/* Designation Distribution (Sorted by name inside each designation) */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">
              <Award size={18} color="#1e3a8a" />
              <span>Employees by Designation (Click to View Staff Sorted A–Z)</span>
            </div>
            <button onClick={() => onNavigateTab('designations')} className="btn btn-secondary btn-sm">Rates Master</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {employeesByDesignation.map((d, i) => (
              <div
                key={i}
                onClick={() => { setSelectedDesignation(d); setDesignationSearch(''); }}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '12px 14px',
                  background: '#f8fafc',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  border: '1px solid #e2e8f0',
                  transition: 'all 0.15s ease'
                }}
                className="hover-card-row"
                title={`Click to view all ${d.count} employees sorted alphabetically by name`}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span className="badge" style={{ background: '#1e3a8a', color: '#ffffff', fontWeight: 700 }}>
                    {d.alias || 'DES'}
                  </span>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>{d.designation}</div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Click to view employee names list</div>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontWeight: 800, fontSize: '14px', background: '#e2e8f0', padding: '3px 10px', borderRadius: '6px', color: '#1e293b' }}>
                    {d.count} Workers
                  </span>
                  <ChevronRight size={16} color="#94a3b8" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Contractor Breakdown (CLICKABLE: opens full employee names list!) */}
        <div className="card">
          <div className="card-header">
            <div className="card-title">
              <Building size={18} color="#d97706" />
              <span>Employees by Contractor (Click Any Contractor to View Staff)</span>
            </div>
            <button onClick={() => onNavigateTab('contractors')} className="btn btn-secondary btn-sm">Contractors Master</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {employeesByContractor.map((c, i) => (
              <div
                key={i}
                onClick={() => { setSelectedContractor(c); setContractorSearch(''); }}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '12px 14px',
                  background: '#f8fafc',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  border: '1px solid #e2e8f0',
                  transition: 'all 0.15s ease'
                }}
                className="hover-card-row"
                title={`Click to view all ${c.count} employee names under ${c.contractor}`}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Building size={16} color="#d97706" />
                  <div>
                    <div style={{ fontWeight: 700, fontSize: '13px', color: '#0f172a', maxWidth: '280px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {c.contractor}
                    </div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Click to see working employee names</div>
                  </div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontWeight: 800, fontSize: '13px', background: '#fef3c7', color: '#92400e', padding: '3px 10px', borderRadius: '6px' }}>
                    {c.count} Workers
                  </span>
                  <ChevronRight size={16} color="#d97706" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* CONTRACTOR EMPLOYEES MODAL (Triggered by clicking on any Contractor)     */}
      {/* ========================================================================= */}
      {selectedContractor && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '960px', width: '95%' }}>
            <div className="modal-header" style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '14px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Building size={20} color="#d97706" />
                  <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0f172a' }}>
                    {selectedContractor.contractor}
                  </h3>
                </div>
                <div style={{ fontSize: '12.5px', color: '#64748b', marginTop: '3px' }}>
                  Total Assigned Workforce: <strong style={{ color: '#d97706' }}>{selectedContractor.count} Employees</strong>
                  {selectedContractor.totalNetPayable ? ` • Net Payout: ₹${Number(selectedContractor.totalNetPayable).toLocaleString('en-IN', { maximumFractionDigits: 0 })}` : ''}
                  {selectedContractor.totalEmployeeDeductions ? ` • Deductions: ₹${Number(selectedContractor.totalEmployeeDeductions).toLocaleString('en-IN', { maximumFractionDigits: 0 })} (EPF: ₹${Number(selectedContractor.totalEmployeeEpf || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })} | ESI: ₹${Number(selectedContractor.totalEmployeeEsi || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })} | LWF: ₹${Number(selectedContractor.totalEmployeeLwf || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })})` : ''}
                </div>
              </div>
              <button onClick={() => setSelectedContractor(null)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>

            <div className="modal-body" style={{ maxHeight: '68vh', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {/* Search Inside Contractor Modal */}
              <div style={{ position: 'relative' }}>
                <Search size={16} color="#94a3b8" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                <input
                  type="text"
                  placeholder="Filter employees by name or code..."
                  className="form-input"
                  style={{ paddingLeft: '36px' }}
                  value={contractorSearch}
                  onChange={(e) => setContractorSearch(e.target.value)}
                />
              </div>

              {/* Employee Names Table */}
              <div className="table-container">
                <table className="custom-table">
                  <thead>
                    <tr>
                      <th style={{ width: '40px', textAlign: 'center' }}>#</th>
                      <th>Employee Name (Sorted A–Z)</th>
                      <th>Emp Code</th>
                      <th>Designation</th>
                      <th>Circle / Unit</th>
                      <th style={{ textAlign: 'center' }}>Days</th>
                      <th className="num" style={{ color: '#b91c1c' }}>EPF 12% (₹)</th>
                      <th className="num" style={{ color: '#c2410c' }}>ESI 0.75% (₹)</th>
                      <th className="num" style={{ color: '#15803d' }}>LWF (₹)</th>
                      <th className="num" style={{ color: '#dc2626' }}>Total Ded (₹)</th>
                      <th className="num" style={{ background: '#eff6ff', color: '#1e3a8a' }}>Net Payable (₹)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(selectedContractor.employees || [])
                      .filter(e => {
                        if (!contractorSearch.trim()) return true;
                        const q = contractorSearch.toLowerCase();
                        return e.name.toLowerCase().includes(q) || e.emp_code.toLowerCase().includes(q);
                      })
                      .map((emp, idx) => (
                        <tr key={emp.id}>
                          <td style={{ textAlign: 'center', color: '#94a3b8', fontSize: '12px' }}>{idx + 1}</td>
                          <td>
                            <div style={{ fontWeight: 700, color: '#0f172a' }}>{emp.name}</div>
                            {emp.uan && <div style={{ fontSize: '11px', color: '#64748b' }}>UAN: {emp.uan}</div>}
                          </td>
                          <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>
                            {emp.emp_code}
                          </td>
                          <td>
                            <span className="badge" style={{ background: '#f1f5f9', color: '#1e293b' }}>
                              {emp.designation_alias || 'SW'}
                            </span>
                          </td>
                          <td style={{ fontSize: '12px', color: '#475569' }}>
                            {emp.circle_name}
                          </td>
                          <td style={{ textAlign: 'center', fontWeight: 600 }}>
                            {emp.present_days}
                          </td>
                          <td className="num" style={{ color: '#b91c1c', fontFamily: 'monospace' }}>
                            ₹{Number(emp.employee_epf_12 || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ color: '#c2410c', fontFamily: 'monospace' }}>
                            ₹{Number(emp.employee_esi_075 || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ color: '#15803d', fontFamily: 'monospace' }}>
                            ₹{Number(emp.employee_lwf || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ color: '#dc2626', fontWeight: 700, fontFamily: 'monospace' }}>
                            ₹{Number(emp.total_employee_deductions || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ fontWeight: 800, color: '#1e3a8a', background: '#eff6ff' }}>
                            ₹{Number(emp.net_payable).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', paddingTop: '12px' }}>
              <button onClick={() => setSelectedContractor(null)} className="btn btn-primary">
                Close List
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DESIGNATION EMPLOYEES MODAL (Triggered by clicking on any Designation)   */}
      {/* ========================================================================= */}
      {selectedDesignation && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '960px', width: '95%' }}>
            <div className="modal-header" style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '14px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Award size={20} color="#1e3a8a" />
                  <h3 style={{ fontSize: '17px', fontWeight: 800, color: '#0f172a' }}>
                    {selectedDesignation.designation} ({selectedDesignation.alias || 'SW'})
                  </h3>
                </div>
                <div style={{ fontSize: '12.5px', color: '#64748b', marginTop: '3px' }}>
                  Total Staff: <strong style={{ color: '#1e3a8a' }}>{selectedDesignation.count} Employees</strong>
                  {selectedDesignation.totalNetPayable ? ` • Net Payout: ₹${Number(selectedDesignation.totalNetPayable).toLocaleString('en-IN', { maximumFractionDigits: 0 })}` : ''}
                  {selectedDesignation.totalEmployeeDeductions ? ` • Deductions: ₹${Number(selectedDesignation.totalEmployeeDeductions).toLocaleString('en-IN', { maximumFractionDigits: 0 })} (EPF: ₹${Number(selectedDesignation.totalEmployeeEpf || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })} | ESI: ₹${Number(selectedDesignation.totalEmployeeEsi || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })} | LWF: ₹${Number(selectedDesignation.totalEmployeeLwf || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })})` : ''}
                </div>
              </div>
              <button onClick={() => setSelectedDesignation(null)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>

            <div className="modal-body" style={{ maxHeight: '68vh', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {/* Search Inside Designation Modal */}
              <div style={{ position: 'relative' }}>
                <Search size={16} color="#94a3b8" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                <input
                  type="text"
                  placeholder="Filter employees by name, code, contractor..."
                  className="form-input"
                  style={{ paddingLeft: '36px' }}
                  value={designationSearch}
                  onChange={(e) => setDesignationSearch(e.target.value)}
                />
              </div>

              {/* Employee Names Table */}
              <div className="table-container">
                <table className="custom-table">
                  <thead>
                    <tr>
                      <th style={{ width: '40px', textAlign: 'center' }}>#</th>
                      <th>Employee Name (Sorted A–Z)</th>
                      <th>Emp Code</th>
                      <th>Service Provider / Contractor</th>
                      <th>Circle / Unit</th>
                      <th style={{ textAlign: 'center' }}>Days</th>
                      <th className="num" style={{ color: '#b91c1c' }}>EPF 12% (₹)</th>
                      <th className="num" style={{ color: '#c2410c' }}>ESI 0.75% (₹)</th>
                      <th className="num" style={{ color: '#15803d' }}>LWF (₹)</th>
                      <th className="num" style={{ color: '#dc2626' }}>Total Ded (₹)</th>
                      <th className="num" style={{ background: '#eff6ff', color: '#1e3a8a' }}>Net Payable (₹)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(selectedDesignation.employees || [])
                      .filter(e => {
                        if (!designationSearch.trim()) return true;
                        const q = designationSearch.toLowerCase();
                        return (
                          e.name.toLowerCase().includes(q) ||
                          e.emp_code.toLowerCase().includes(q) ||
                          e.contractor_name.toLowerCase().includes(q)
                        );
                      })
                      .map((emp, idx) => (
                        <tr key={emp.id}>
                          <td style={{ textAlign: 'center', color: '#94a3b8', fontSize: '12px' }}>{idx + 1}</td>
                          <td>
                            <div style={{ fontWeight: 700, color: '#0f172a' }}>{emp.name}</div>
                            {emp.uan && <div style={{ fontSize: '11px', color: '#64748b' }}>UAN: {emp.uan}</div>}
                          </td>
                          <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>
                            {emp.emp_code}
                          </td>
                          <td style={{ fontSize: '12px', color: '#475569' }}>
                            {emp.contractor_name}
                          </td>
                          <td style={{ fontSize: '12px', color: '#475569' }}>
                            {emp.circle_name}
                          </td>
                          <td style={{ textAlign: 'center', fontWeight: 600 }}>
                            {emp.present_days}
                          </td>
                          <td className="num" style={{ color: '#b91c1c', fontFamily: 'monospace' }}>
                            ₹{Number(emp.employee_epf_12 || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ color: '#c2410c', fontFamily: 'monospace' }}>
                            ₹{Number(emp.employee_esi_075 || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ color: '#15803d', fontFamily: 'monospace' }}>
                            ₹{Number(emp.employee_lwf || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ color: '#dc2626', fontWeight: 700, fontFamily: 'monospace' }}>
                            ₹{Number(emp.total_employee_deductions || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                          <td className="num" style={{ fontWeight: 800, color: '#1e3a8a', background: '#eff6ff' }}>
                            ₹{Number(emp.net_payable).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', paddingTop: '12px' }}>
              <button onClick={() => setSelectedDesignation(null)} className="btn btn-primary">
                Close List
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DashboardView;
