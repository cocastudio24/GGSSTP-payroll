import React from 'react';
import {
  LayoutDashboard, Users, Calculator, Award, Building2,
  FileSpreadsheet, Download, CheckCircle2, ShieldCheck,
  History, Settings, Zap, Sliders, X
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  userRole?: string;
  isOpen?: boolean;
  onMouseEnter?: () => void;
  onMouseLeave?: () => void;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  userRole,
  isOpen = false,
  onMouseEnter,
  onMouseLeave,
  onClose
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard Overview', icon: LayoutDashboard },
    { id: 'employees', label: 'Employee Master', icon: Users },
    { id: 'payroll', label: 'Monthly Payroll', icon: Calculator },
    { id: 'formula-rules', label: 'Formula & Rules Engine', icon: Sliders, adminOnly: true },
    { id: 'designations', label: 'Designations & Rates', icon: Award },
    { id: 'contractors', label: 'Contractors & Circles', icon: Building2 },
    { id: 'import', label: 'Excel Import Center', icon: FileSpreadsheet },
    { id: 'export', label: 'Reports & Exports', icon: Download },
    { id: 'reconciliation', label: 'Formula Reconciliation', icon: CheckCircle2 },
    { id: 'users', label: 'User Management', icon: ShieldCheck, adminOnly: true },
    { id: 'audit', label: 'Audit Logs', icon: History },
    { id: 'settings', label: 'Settings & Backups', icon: Settings }
  ];

  const isSuper = Boolean(userRole && (userRole === 'Super Administrator' || userRole === 'SUPER_ADMIN' || userRole.toUpperCase().includes('SUPER')));
  const filteredItems = navItems.filter(item => {
    if (item.adminOnly && !isSuper) return false;
    return true;
  });

  return (
    <>
      {isOpen && (
        <div
          className="sidebar-backdrop"
          onClick={onClose}
          onMouseEnter={onMouseEnter}
        />
      )}
      <aside
        className={`sidebar ${isOpen ? 'sidebar-open' : 'sidebar-closed'}`}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
      >
        <div className="sidebar-header">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
            <div className="sidebar-brand-title">
              <Zap size={20} color="#f59e0b" fill="#f59e0b" />
              <span>GGSSTP FUNCTIONS</span>
            </div>
            {onClose && (
              <button
                onClick={onClose}
                title="Close Functions Menu"
                style={{
                  color: '#94a3b8',
                  background: 'rgba(255, 255, 255, 0.08)',
                  border: 'none',
                  borderRadius: '6px',
                  padding: '5px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'background 0.15s'
                }}
              >
                <X size={16} />
              </button>
            )}
          </div>
          <div className="sidebar-brand-sub">Navigation & Administrative Modules</div>
        </div>

        <nav className="sidebar-nav">
          {filteredItems.map(item => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                className={`nav-item ${isActive ? 'active' : ''}`}
                onClick={() => {
                  setCurrentTab(item.id);
                  if (onClose) onClose();
                }}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="sidebar-footer">
          <div style={{ color: '#94a3b8', fontSize: '11px' }}>Contractual Labor Cell</div>
          <div style={{ color: '#64748b', fontSize: '10px', marginTop: '2px' }}>v2.0.0 (Production Verified)</div>
        </div>
      </aside>
    </>
  );
};
