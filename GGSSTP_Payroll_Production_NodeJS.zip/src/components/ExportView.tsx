import React, { useState, useEffect } from 'react';
import { PayrollPeriod } from '../types';
import { downloadFile, apiRequest } from '../api';
import { Download, FileSpreadsheet, CreditCard, ShieldCheck, Printer, Users } from 'lucide-react';

interface ExportViewProps {
  period: PayrollPeriod | null;
  userRole?: string;
}

export const ExportView: React.FC<ExportViewProps> = ({ period, userRole }) => {
  const [selectedCreatorId, setSelectedCreatorId] = useState<string>('');
  const [creatorsList, setCreatorsList] = useState<Array<{ id: number; username: string; full_name: string }>>([]);

  const isSuperAdminUser = Boolean(userRole && userRole.toUpperCase().includes('SUPER'));

  useEffect(() => {
    if (isSuperAdminUser) {
      apiRequest<{ users: Array<{ id: number; username: string; full_name: string }> }>('/users')
        .then(res => {
          if (res && res.users) {
            setCreatorsList(res.users);
          }
        })
        .catch(err => console.error('Failed to load user creators in ExportView:', err));
    }
  }, [isSuperAdminUser]);

  if (!period) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
        <p style={{ color: '#64748b' }}>Please select a payroll period above to generate reports and exports.</p>
      </div>
    );
  }

  const handleDownloadFormulasExcel = () => {
    let url = `/export/payroll-xlsx/${period.id}`;
    if (selectedCreatorId) url += `?creatorId=${selectedCreatorId}`;
    downloadFile(
      url,
      `GGSSTP_Payroll_Register_${period.month_name}_${period.year}.xlsx`
    );
  };

  const handleDownloadBankSheet = () => {
    let url = `/export/bank-payment/${period.id}`;
    if (selectedCreatorId) url += `?creatorId=${selectedCreatorId}`;
    downloadFile(
      url,
      `GGSSTP_Bank_Disbursement_${period.month_name}_${period.year}.xlsx`
    );
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Reporting & Formula-Preserving Exports</h2>
          <p style={{ fontSize: '12.5px', color: '#64748b' }}>
            Export genuine Microsoft Excel workbooks with live recalculating formulas for {period.month_name} {period.year}
          </p>
        </div>

        {isSuperAdminUser && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', background: '#f8fafc', padding: '6px 12px', borderRadius: '8px', border: '1px solid #cbd5e1' }}>
            <Users size={16} color="#1e3a8a" />
            <span style={{ fontSize: '12.5px', fontWeight: 700, color: '#1e3a8a' }}>Scope:</span>
            <select
              value={selectedCreatorId}
              onChange={(e) => setSelectedCreatorId(e.target.value)}
              className="form-input"
              style={{ padding: '4px 10px', fontSize: '12.5px', borderColor: '#3b82f6', background: '#eff6ff', color: '#1e3a8a', fontWeight: 600 }}
              title="Super Admin Master Control: Filter export data by record creator"
            >
              <option value="">All Creators (Global Plant View)</option>
              {creatorsList.map(u => (
                <option key={u.id} value={u.id}>{u.full_name} ({u.username})</option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="grid-3">
        {/* Main Formula Excel Workbook Card */}
        <div className="card" style={{ borderTop: '4px solid #1e3a8a', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <FileSpreadsheet size={22} color="#1e3a8a" />
              <span style={{ fontSize: '16px', fontWeight: 700 }}>Formula-Preserving Payroll Register</span>
            </div>
            <p style={{ fontSize: '12.5px', color: '#64748b', lineHeight: 1.6 }}>
              Full master payroll sheet formatted with genuine Excel formulas across all columns (<code>=ROUND(...)</code>, <code>=SUM(...)</code>, <code>=IF(...)</code>), auto-filter, and rate cards.
            </p>
            <div style={{ marginTop: '12px', background: '#eff6ff', padding: '8px 12px', borderRadius: '6px', fontSize: '12px', color: '#1e3a8a' }}>
              ✓ Recalculates dynamically when opened in Excel or LibreOffice
            </div>
          </div>
          <button
            onClick={handleDownloadFormulasExcel}
            className="btn btn-primary"
            style={{ marginTop: '20px' }}
          >
            <Download size={16} />
            <span>Download .XLSX with Formulas</span>
          </button>
        </div>

        {/* Bank Payment Disbursement Card */}
        <div className="card" style={{ borderTop: '4px solid #059669', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <CreditCard size={22} color="#059669" />
              <span style={{ fontSize: '16px', fontWeight: 700 }}>Bank Disbursement Sheet</span>
            </div>
            <p style={{ fontSize: '12.5px', color: '#64748b', lineHeight: 1.6 }}>
              Disbursement statement formatted for direct submission to State Bank of India (SBI) with Employee Name, Bank Account Number, IFSC Code, and Net Payable Salary.
            </p>
            <div style={{ marginTop: '12px', background: '#ecfdf5', padding: '8px 12px', borderRadius: '6px', fontSize: '12px', color: '#065f46' }}>
              ✓ Formatted for bank salary transfer batch upload
            </div>
          </div>
          <button
            onClick={handleDownloadBankSheet}
            className="btn btn-success"
            style={{ marginTop: '20px' }}
          >
            <Download size={16} />
            <span>Download Bank Sheet (.xlsx)</span>
          </button>
        </div>

        {/* Print Summary */}
        <div className="card" style={{ borderTop: '4px solid #d97706', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <Printer size={22} color="#d97706" />
              <span style={{ fontSize: '16px', fontWeight: 700 }}>Printable Audit Statement</span>
            </div>
            <p style={{ fontSize: '12.5px', color: '#64748b', lineHeight: 1.6 }}>
              Print-ready executive summary with circular division totals, employer statutory liability breakdown, and auditor sign-off sections.
            </p>
            <div style={{ marginTop: '12px', background: '#fffbeb', padding: '8px 12px', borderRadius: '6px', fontSize: '12px', color: '#92400e' }}>
              ✓ Includes GGSSTP administrative approval blocks
            </div>
          </div>
          <button
            onClick={() => window.print()}
            className="btn btn-secondary"
            style={{ marginTop: '20px' }}
          >
            <Printer size={16} />
            <span>Print Current Summary</span>
          </button>
        </div>
      </div>
    </div>
  );
};
