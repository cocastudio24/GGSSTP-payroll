import React, { useState } from 'react';
import { Designation } from '../types';
import { apiRequest } from '../api';
import { Award, Plus, Edit2, Calendar, Check, X, ShieldAlert } from 'lucide-react';

interface DesignationViewProps {
  designations: Designation[];
  onRefresh: () => void;
  userRole?: string;
}

export const DesignationView: React.FC<DesignationViewProps> = ({ designations, onRefresh, userRole }) => {
  const [editingDesig, setEditingDesig] = useState<Designation | null>(null);
  const [grossRate, setGrossRate] = useState<number>(0);
  const [specialAllowance, setSpecialAllowance] = useState<number>(0);
  const [thermalAllowance, setThermalAllowance] = useState<number>(1500);
  const [perfDefault, setPerfDefault] = useState<number>(225);
  const [effectiveFrom, setEffectiveFrom] = useState<string>(new Date().toISOString().split('T')[0]);

  // Add new designation modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newAlias, setNewAlias] = useState('');

  const handleStartEdit = (d: Designation) => {
    setEditingDesig(d);
    setGrossRate(Number(d.gross_salary_rate) || 0);
    setSpecialAllowance(Number(d.special_allowance) || 0);
    setThermalAllowance(Number(d.thermal_allowance) || 1500);
    setPerfDefault(Number(d.perf_allowance_default) || 225);
    setEffectiveFrom(new Date().toISOString().split('T')[0]);
  };

  const handleSaveRates = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDesig) return;

    try {
      await apiRequest(`/designations/${editingDesig.id}/rates`, {
        method: 'PUT',
        body: JSON.stringify({
          grossSalaryRate: grossRate,
          specialAllowance,
          thermalAllowance,
          perfAllowanceDefault: perfDefault,
          effectiveFrom
        })
      });
      setEditingDesig(null);
      onRefresh();
      alert('Salary rates updated with effective date preserved.');
    } catch (err: any) {
      alert(`Update failed: ${err.message}`);
    }
  };

  const handleCreateDesignation = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiRequest('/designations', {
        method: 'POST',
        body: JSON.stringify({
          name: newName,
          alias: newAlias,
          grossSalaryRate: grossRate,
          specialAllowance,
          thermalAllowance,
          perfAllowanceDefault: perfDefault
        })
      });
      setIsAddOpen(false);
      setNewName('');
      setNewAlias('');
      onRefresh();
      alert('New designation created successfully.');
    } catch (err: any) {
      alert(`Failed to create designation: ${err.message}`);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Designation Salary Structures & Rates</h2>
          <p style={{ fontSize: '12.5px', color: '#64748b' }}>
            Reference salary card matching GGSSTP September 2026 contractual labor rates
          </p>
        </div>
        {userRole === 'Super Administrator' && (
          <button onClick={() => setIsAddOpen(true)} className="btn btn-primary btn-sm">
            <Plus size={16} />
            <span>Add Designation</span>
          </button>
        )}
      </div>

      {/* Notice Banner */}
      <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '10px', padding: '14px 18px', display: 'flex', alignItems: 'center', gap: '12px' }}>
        <ShieldAlert size={20} color="#1e3a8a" />
        <div style={{ fontSize: '12.5px', color: '#334155' }}>
          <strong>Effective Date Preservation:</strong> Rate adjustments create new versioned rate records. Previously finalized payroll months retain their approved historical rates unless explicitly reopened.
        </div>
      </div>

      {/* Designation Cards Grid */}
      <div className="grid-2">
        {designations.map(d => (
          <div key={d.id} className="card" style={{ borderTop: '4px solid #1e3a8a' }}>
            <div className="card-header">
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Award size={18} color="#1e3a8a" />
                  <span style={{ fontSize: '16px', fontWeight: 700 }}>{d.name}</span>
                  <span className="badge" style={{ background: '#eff6ff', color: '#1e3a8a', border: '1px solid #bfdbfe' }}>
                    {d.alias}
                  </span>
                </div>
                <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                  {d.employee_count || 0} active workers assigned
                </div>
              </div>
              <button onClick={() => handleStartEdit(d)} className="btn btn-secondary btn-sm">
                <Edit2 size={13} />
                <span>Adjust Rates</span>
              </button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px', background: '#f8fafc', padding: '14px', borderRadius: '8px' }}>
              <div>
                <div style={{ fontSize: '11.5px', color: '#64748b' }}>Gross Salary Rate</div>
                <div style={{ fontSize: '17px', fontWeight: 800, color: '#1e3a8a', fontFamily: 'monospace' }}>
                  ₹{Number(d.gross_salary_rate || 0).toLocaleString('en-IN')}
                </div>
              </div>

              <div>
                <div style={{ fontSize: '11.5px', color: '#64748b' }}>Special Allowance</div>
                <div style={{ fontSize: '17px', fontWeight: 800, color: '#047857', fontFamily: 'monospace' }}>
                  ₹{Number(d.special_allowance || 0).toLocaleString('en-IN')}
                </div>
              </div>

              <div>
                <div style={{ fontSize: '11.5px', color: '#64748b' }}>Default Thermal Allowance</div>
                <div style={{ fontSize: '15px', fontWeight: 700, color: '#1e293b', fontFamily: 'monospace' }}>
                  ₹{Number(d.thermal_allowance || 1500).toLocaleString('en-IN')}
                </div>
              </div>

              <div>
                <div style={{ fontSize: '11.5px', color: '#64748b' }}>Default Performance All.</div>
                <div style={{ fontSize: '15px', fontWeight: 700, color: '#1e293b', fontFamily: 'monospace' }}>
                  ₹{Number(d.perf_allowance_default || 225).toLocaleString('en-IN')}
                </div>
              </div>
            </div>

            <div style={{ marginTop: '12px', fontSize: '11px', color: '#64748b', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <Calendar size={12} />
              <span>Effective From: {d.effective_from ? new Date(d.effective_from).toLocaleDateString() : 'Initial Configuration'}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Rates Modal */}
      {editingDesig && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '500px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>
                Adjust Salary Rates: {editingDesig.name} ({editingDesig.alias})
              </h3>
              <button onClick={() => setEditingDesig(null)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSaveRates}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Gross Salary Rate (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    className="form-input"
                    value={grossRate}
                    onChange={(e) => setGrossRate(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Special Allowance (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    className="form-input"
                    value={specialAllowance}
                    onChange={(e) => setSpecialAllowance(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Default Thermal Allowance (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    className="form-input"
                    value={thermalAllowance}
                    onChange={(e) => setThermalAllowance(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Default Performance Allowance (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    className="form-input"
                    value={perfDefault}
                    onChange={(e) => setPerfDefault(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Effective From Date</label>
                  <input
                    type="date"
                    required
                    className="form-input"
                    value={effectiveFrom}
                    onChange={(e) => setEffectiveFrom(e.target.value)}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setEditingDesig(null)} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Apply Effective Rate Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
