import React, { useState, useEffect } from 'react';
import { PayrollPeriod, PayrollEntry, Designation, Contractor } from '../types';
import { apiRequest, downloadFile } from '../api';
import {
  Calculator, CheckCircle2, RefreshCw, FileText,
  AlertTriangle, Lock, Unlock, Edit3, Save, X, Info,
  Calendar, Sliders, DollarSign, ShieldAlert, Check,
  ChevronRight, Users, ArrowUpRight, FileSpreadsheet,
  Upload, Plus, FileUp, Zap, Grid, Eye, Printer, FileDown, Trash2
} from 'lucide-react';
import { CreatePeriodModal } from './CreatePeriodModal';
import { BulkAllowancesRatesModal } from './BulkAllowancesRatesModal';
import { PayslipModal } from './PayslipModal';

interface PayrollViewProps {
  period: PayrollPeriod | null;
  periods?: PayrollPeriod[];
  onSelectPeriod?: (id: number) => void;
  onRefreshPeriod: () => void;
  onPeriodCreated?: (id: number) => void;
  designations: Designation[];
  contractors: Contractor[];
  userRole?: string;
  columnPreset?: string;
  onSelectColumnPreset?: (preset: string) => void;
  onUnsavedStateChange?: (hasUnsaved: boolean, saveAction?: () => Promise<boolean>) => void;
}

export const PayrollView: React.FC<PayrollViewProps> = ({
  period,
  periods,
  onSelectPeriod,
  onRefreshPeriod,
  onPeriodCreated,
  designations,
  contractors,
  userRole,
  columnPreset = 'all',
  onSelectColumnPreset,
  onUnsavedStateChange
}) => {
  const [activePreset, setActivePreset] = useState<string>(columnPreset || 'all');
  useEffect(() => {
    if (columnPreset) setActivePreset(columnPreset);
  }, [columnPreset]);

  const handleSelectPreset = (p: string) => {
    setActivePreset(p);
    if (onSelectColumnPreset) onSelectColumnPreset(p);
  };

  const [entries, setEntries] = useState<PayrollEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedDesignation, setSelectedDesignation] = useState('');
  const [selectedContractor, setSelectedContractor] = useState('');
  const [selectedCreatorId, setSelectedCreatorId] = useState<string>('');
  const [creatorsList, setCreatorsList] = useState<Array<{ id: number; username: string; full_name: string }>>([]);
  const isSuperAdminUser = Boolean(userRole && (userRole.toUpperCase().includes('SUPER')));

  // Payslip Modal & Row Dropdown state
  const [payslipModalEntryId, setPayslipModalEntryId] = useState<number | null>(null);
  const [autoPrintPayslip, setAutoPrintPayslip] = useState<boolean>(false);
  const [activePayslipDropdownId, setActivePayslipDropdownId] = useState<number | null>(null);

  useEffect(() => {
    const handleGlobalClick = () => setActivePayslipDropdownId(null);
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, []);

  useEffect(() => {
    if (isSuperAdminUser) {
      apiRequest<{ users: Array<{ id: number; username: string; full_name: string }> }>('/users')
        .then(res => {
          if (res && res.users) {
            setCreatorsList(res.users);
          }
        })
        .catch(() => {});
    }
  }, [isSuperAdminUser]);

  // Toast notification
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  // Quick inline edit state
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editPresentDays, setEditPresentDays] = useState<number>(0);
  const [editPerfAllowance, setEditPerfAllowance] = useState<number>(0);
  const [editBonus, setEditBonus] = useState<number>(0);

  // Full Component Edit Modal state
  const [fullEditEntry, setFullEditEntry] = useState<PayrollEntry | null>(null);
  const [compDesignationId, setCompDesignationId] = useState<number | ''>('');
  const [compPresentDays, setCompPresentDays] = useState<number>(0);
  const [compGrossRate, setCompGrossRate] = useState<number>(0);
  const [compSpecialAll, setCompSpecialAll] = useState<number>(0);
  const [compThermalAll, setCompThermalAll] = useState<number>(0);
  const [compThermalAuto, setCompThermalAuto] = useState<boolean>(true);
  const [compPerfMonthly, setCompPerfMonthly] = useState<number>(0);
  const [compBonus, setCompBonus] = useState<number>(0);
  const [compBonusPercentage, setCompBonusPercentage] = useState<number>(8.33);
  const [compBonusAuto, setCompBonusAuto] = useState<boolean>(true);
  const [compPerfLastDrawn, setCompPerfLastDrawn] = useState<number>(0);
  const [compPerfAsPerCircle, setCompPerfAsPerCircle] = useState<number>(0);
  
  // Custom statutory overrides in full edit
  const [compEmpEpf, setCompEmpEpf] = useState<number>(0);
  const [compEmpEpfCustom, setCompEmpEpfCustom] = useState<boolean>(false);
  const [compEmpEsi, setCompEmpEsi] = useState<number>(0);
  const [compEmpEsiCustom, setCompEmpEsiCustom] = useState<boolean>(false);
  const [compEmpLwf, setCompEmpLwf] = useState<number>(5);
  const [compEmpLwfCustom, setCompEmpLwfCustom] = useState<boolean>(false);
  
  const [compEmployerEpf12, setCompEmployerEpf12] = useState<number>(0);
  const [compEmployerEpf1, setCompEmployerEpf1] = useState<number>(0);
  const [compEmployerEsi, setCompEmployerEsi] = useState<number>(0);
  const [compEmployerLwf, setCompEmployerLwf] = useState<number>(20);
  const [compRememberRates, setCompRememberRates] = useState<boolean>(true);

  // Direct Net Payable Edit Modal state
  const [directEditEntry, setDirectEditEntry] = useState<PayrollEntry | null>(null);
  const [directNetValue, setDirectNetValue] = useState<number>(0);
  const [directReason, setDirectReason] = useState<string>('');
  const [directSaving, setDirectSaving] = useState<boolean>(false);

  // Generate / Recalculate Net Payable Modal state
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState<boolean>(false);
  const [generateScope, setGenerateScope] = useState<'all' | 'selected'>('all');
  const [generateMode, setGenerateMode] = useState<'formula' | 'adopt_excel'>('formula');
  const [generateRounding, setGenerateRounding] = useState<'round_50_up' | 'exact' | 'floor' | 'ceil'>('round_50_up');
  const [generatingSalaries, setGeneratingSalaries] = useState<boolean>(false);

  // Batch Attendance Modal
  const [isBatchAttendanceOpen, setIsBatchAttendanceOpen] = useState(false);
  const [batchDays, setBatchDays] = useState<number>(30);
  const [batchTarget, setBatchTarget] = useState<'all' | 'filtered'>('all');
  const [batchSaving, setBatchSaving] = useState(false);

  // Cycle Days Modal
  const [isCycleDaysOpen, setIsCycleDaysOpen] = useState(false);
  const [cycleTotalDays, setCycleTotalDays] = useState<number>(30);

  // Period creation modal state
  const [isCreatePeriodOpen, setIsCreatePeriodOpen] = useState(false);

  // Multi-selection checkboxes
  const [selectedEntryIds, setSelectedEntryIds] = useState<number[]>([]);

  // Bulk Allowances & Rates Modal state
  const [isBulkEditOpen, setIsBulkEditOpen] = useState(false);

  // Multi-Row Spreadsheet Grid Mode
  const [isGridEditMode, setIsGridEditMode] = useState(false);
  const [gridChanges, setGridChanges] = useState<Record<number, {
    present_days?: number;
    gross_salary_rate?: number;
    special_allowance?: number;
    thermal_allowance?: number;
    perf_allowance_monthly?: number;
    bonus?: number;
  }>>({});
  const [gridSaving, setGridSaving] = useState(false);

  // Upload Excel Salary Sheet modal state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [parseResult, setParseResult] = useState<any | null>(null);
  const [selectedImportSheet, setSelectedImportSheet] = useState<string>('all');
  const [committingSheet, setCommittingSheet] = useState(false);

  // Formula inspection modal
  const [inspectEntry, setInspectEntry] = useState<PayrollEntry | null>(null);

  // Override modal
  const [overrideEntry, setOverrideEntry] = useState<PayrollEntry | null>(null);
  const [overrideField, setOverrideField] = useState('net_payable');
  const [overrideValue, setOverrideValue] = useState<number>(0);
  const [overrideReason, setOverrideReason] = useState('');

  const fetchEntries = async () => {
    if (!period) return;
    try {
      setLoading(true);
      let query = `/payroll/entries?periodId=${period.id}&limit=200`;
      if (search) query += `&search=${encodeURIComponent(search)}`;
      if (selectedDesignation) query += `&designationId=${selectedDesignation}`;
      if (selectedContractor) query += `&contractorId=${selectedContractor}`;
      if (selectedCreatorId) query += `&creatorId=${selectedCreatorId}`;

      const res = await apiRequest<{ entries: PayrollEntry[] }>(query);
      setEntries(res.entries);
    } catch (err: any) {
      showNotification('error', `Error fetching payroll entries: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEntries();
    if (period) {
      setCycleTotalDays(period.total_days || 30);
    }
  }, [period?.id, search, selectedDesignation, selectedContractor, selectedCreatorId]);

  // Inline Quick Edit Handlers
  const handleStartQuickEdit = (entry: PayrollEntry) => {
    setEditingId(entry.id);
    setEditPresentDays(Number(entry.present_days));
    setEditPerfAllowance(Number(entry.perf_allowance_monthly));
    setEditBonus(Number(entry.bonus));
  };

  const handleSaveQuickEdit = async (id: number) => {
    try {
      await apiRequest(`/payroll/entries/${id}`, {
        method: 'PUT',
        body: JSON.stringify({
          present_days: editPresentDays,
          perf_allowance_monthly: editPerfAllowance,
          bonus: editBonus
        })
      });
      setEditingId(null);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', 'Employee attendance & allowance updated.');
    } catch (err: any) {
      showNotification('error', `Quick save failed: ${err.message}`);
    }
  };

  // Open Full Component Edit Modal
  const handleOpenFullEdit = (entry: PayrollEntry) => {
    setFullEditEntry(entry);
    setCompDesignationId(entry.designation_id || '');
    setCompPresentDays(Number(entry.present_days));
    setCompGrossRate(Number(entry.gross_salary_rate));
    setCompSpecialAll(Number(entry.special_allowance));
    setCompThermalAll(Number(entry.thermal_allowance));
    setCompThermalAuto(true);
    setCompPerfMonthly(Number(entry.perf_allowance_monthly));
    const bonusPct = entry.bonus_percentage !== undefined && entry.bonus_percentage !== null ? Number(entry.bonus_percentage) : 8.33;
    setCompBonusPercentage(bonusPct);
    setCompBonusAuto(!entry.is_overridden);
    setCompBonus(Number(entry.bonus));

    setCompPerfLastDrawn(Number(entry.perf_last_drawn || 0));
    setCompPerfAsPerCircle(Number(entry.perf_as_per_circle || 0));

    setCompEmpEpf(Number(entry.employee_epf_12));
    setCompEmpEpfCustom(false);
    setCompEmpEsi(Number(entry.employee_esi_075));
    setCompEmpEsiCustom(false);
    setCompEmpLwf(Number(entry.employee_lwf));
    setCompEmpLwfCustom(false);

    setCompEmployerEpf12(Number(entry.employer_epf_12));
    setCompEmployerEpf1(Number(entry.employer_epf_1));
    setCompEmployerEsi(Number(entry.employer_esi_325));
    setCompEmployerLwf(Number(entry.employer_lwf));
  };

  // Live Recalculate Preview for Full Edit Modal
  const calculatePreview = () => {
    if (!fullEditEntry || !period) return null;
    const totalDays = period.total_days || 30;
    const presentDays = Math.max(0, Math.min(totalDays, compPresentDays));

    const propSalary = (compGrossRate / totalDays) * presentDays;
    const totalBasic = Math.round(((compGrossRate + compSpecialAll) * presentDays) / totalDays);
    
    const thermal = compThermalAuto
      ? Math.round((1500 * presentDays) / totalDays)
      : compThermalAll;

    const perfDays = (compPerfMonthly / totalDays) * presentDays;
    const totalEarnings = totalBasic + thermal + perfDays;

    // Bonus (Auto 8.33% of Basic unless overridden)
    const autoBonus = Math.round((totalBasic * compBonusPercentage) / 100);
    const finalBonus = compBonusAuto ? autoBonus : compBonus;

    // EMC Performance Allowance Circle Comparison
    const perfDiff = compPerfLastDrawn - compPerfAsPerCircle;

    // EPF
    const autoEmpEpf = Math.round(propSalary < 25000 ? propSalary * 0.12 : 3000);
    const finalEmpEpf = compEmpEpfCustom ? compEmpEpf : autoEmpEpf;

    // ESI
    const autoEmpEsi = Math.round(totalEarnings < 21000 ? totalEarnings * 0.0075 : 0);
    const finalEmpEsi = compEmpEsiCustom ? compEmpEsi : autoEmpEsi;

    // LWF
    const finalEmpLwf = compEmpLwfCustom ? compEmpLwf : 5;

    const totalDeductions = finalEmpEpf + finalEmpEsi + finalEmpLwf;
    const netPayable = totalEarnings + finalBonus - totalDeductions;

    return {
      propSalary,
      totalBasic,
      thermal,
      perfDays,
      totalEarnings,
      autoBonus,
      finalBonus,
      perfDiff,
      finalEmpEpf,
      finalEmpEsi,
      finalEmpLwf,
      totalDeductions,
      netPayable
    };
  };

  const preview = calculatePreview();

  // Save Full Component Edit
  const handleSaveFullEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullEditEntry) return;

    try {
      const payload: any = {
        designation_id: compDesignationId || undefined,
        present_days: compPresentDays,
        gross_salary_rate: compGrossRate,
        special_allowance: compSpecialAll,
        perf_allowance_monthly: compPerfMonthly,
        bonus_percentage: compBonusPercentage,
        bonus: compBonusAuto ? undefined : compBonus,
        perf_last_drawn: compPerfLastDrawn,
        perf_as_per_circle: compPerfAsPerCircle
      };

      if (!compThermalAuto) {
        payload.thermal_allowance = compThermalAll;
      }
      if (compEmpEpfCustom) {
        payload.employee_epf_12 = compEmpEpf;
        payload.employer_epf_12 = compEmployerEpf12;
        payload.employer_epf_1 = compEmployerEpf1;
      }
      if (compEmpEsiCustom) {
        payload.employee_esi_075 = compEmpEsi;
        payload.employer_esi_325 = compEmployerEsi;
      }
      if (compEmpLwfCustom) {
        payload.employee_lwf = compEmpLwf;
        payload.employer_lwf = compEmployerLwf;
      }

      payload.rememberRates = compRememberRates;

      await apiRequest(`/payroll/entries/${fullEditEntry.id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });

      setFullEditEntry(null);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', `Components saved for ${fullEditEntry.emp_name}.`);
    } catch (err: any) {
      showNotification('error', `Failed to save components: ${err.message}`);
    }
  };

  // Direct Net Payable Edit Handlers
  const handleOpenDirectEdit = (entry: PayrollEntry) => {
    setDirectEditEntry(entry);
    setDirectNetValue(Number(entry.net_payable));
    setDirectReason('');
  };

  const handleSaveDirectEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!directEditEntry) return;
    try {
      setDirectSaving(true);
      await apiRequest(`/payroll/entries/${directEditEntry.id}/net-payable`, {
        method: 'PUT',
        body: JSON.stringify({
          netPayable: directNetValue,
          isOverridden: true,
          reason: directReason || 'Direct user adjustment in Monthly Payroll'
        })
      });
      setDirectEditEntry(null);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', `Net Payable updated to ₹${directNetValue.toLocaleString('en-IN')} for ${directEditEntry.emp_name}`);
    } catch (err: any) {
      showNotification('error', `Failed to update Net Payable: ${err.message}`);
    } finally {
      setDirectSaving(false);
    }
  };

  // Clear Single Salary Handler
  const handleClearSingleSalary = async (entry: PayrollEntry) => {
    if (!window.confirm(`Are you sure you want to clear the salary calculation for ${entry.emp_name}?\n\nThis will reset attendance to 0 days and net payable to ₹0.00.`)) {
      return;
    }
    try {
      await apiRequest(`/payroll/entries/${entry.id}/salary`, {
        method: 'DELETE'
      });
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', `Cleared salary calculation for ${entry.emp_name}`);
    } catch (err: any) {
      showNotification('error', `Failed to clear salary: ${err.message}`);
    }
  };

  // Bulk Clear Selected Salaries Handler
  const handleBulkClearSalaries = async () => {
    if (!period || selectedEntryIds.length === 0) return;
    const selectedEmployees = selectedEntryIds.map(id => entries.find(e => e.id === id)?.employee_id).filter(Boolean);
    if (!window.confirm(`Are you sure you want to clear and reset salary calculations for ${selectedEntryIds.length} selected employee(s)?\n\nTheir attendance and Net Payable will be reset to 0.`)) {
      return;
    }
    try {
      const res = await apiRequest<{ message: string; clearedCount: number }>(`/payroll/periods/${period.id}/bulk-delete-salaries`, {
        method: 'POST',
        body: JSON.stringify({ employeeIds: selectedEmployees })
      });
      setSelectedEntryIds([]);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', res.message || `Cleared salaries for ${res.clearedCount} employees.`);
    } catch (err: any) {
      showNotification('error', `Failed to clear salaries: ${err.message}`);
    }
  };

  // Generate / Recalculate Net Payable Handler
  const handleExecuteGenerate = async () => {
    if (!period) return;
    try {
      setGeneratingSalaries(true);
      const empIds = generateScope === 'selected' && selectedEntryIds.length > 0
        ? selectedEntryIds.map(id => entries.find(e => e.id === id)?.employee_id).filter(Boolean)
        : undefined;
      const res = await apiRequest<{ message: string; updatedCount: number }>(`/payroll/periods/${period.id}/generate-salaries`, {
        method: 'POST',
        body: JSON.stringify({
          employeeIds: empIds,
          mode: generateMode,
          roundingMode: generateRounding,
          adoptExcel: generateMode === 'adopt_excel'
        })
      });
      setIsGenerateModalOpen(false);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', res.message || `Generated Net Payable for ${res.updatedCount} employees.`);
    } catch (err: any) {
      showNotification('error', `Generation failed: ${err.message}`);
    } finally {
      setGeneratingSalaries(false);
    }
  };

  // Batch Attendance Updater
  const handleExecuteBatchAttendance = async () => {
    if (!period) return;
    try {
      setBatchSaving(true);
      const targetIds = batchTarget === ('selected' as any)
        ? selectedEntryIds.map(id => entries.find(e => e.id === id)?.employee_id).filter(Boolean)
        : batchTarget === 'filtered'
          ? entries.map(e => e.employee_id)
          : undefined;
      await apiRequest('/payroll/attendance/batch', {
        method: 'POST',
        body: JSON.stringify({
          periodId: period.id,
          days: batchDays,
          employeeIds: targetIds
        })
      });
      setIsBatchAttendanceOpen(false);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', `Batch attendance of ${batchDays} days applied successfully.`);
    } catch (err: any) {
      showNotification('error', `Batch attendance failed: ${err.message}`);
    } finally {
      setBatchSaving(false);
    }
  };

  // Multi-Selection Handlers
  const handleSelectAllEntries = () => {
    if (selectedEntryIds.length === entries.length) {
      setSelectedEntryIds([]);
    } else {
      setSelectedEntryIds(entries.map(e => e.id));
    }
  };

  const handleToggleSelectEntry = (id: number) => {
    setSelectedEntryIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  // Multi-Row Grid Handlers
  const handleGridCellChange = (id: number, field: string, val: number) => {
    setGridChanges(prev => ({
      ...prev,
      [id]: {
        ...(prev[id] || {}),
        [field]: val
      }
    }));
  };

  const handleSaveAllGridChanges = async (): Promise<boolean> => {
    if (!period) return false;
    const changedIds = Object.keys(gridChanges).map(Number);
    if (changedIds.length === 0) {
      showNotification('error', 'No unsaved cell changes detected.');
      return true;
    }

    try {
      setGridSaving(true);
      const rows = changedIds.map(id => ({
        id,
        ...gridChanges[id]
      }));

      const res = await apiRequest<any>('/payroll/batch-save-grid', {
        method: 'POST',
        body: JSON.stringify({
          periodId: period.id,
          rows
        })
      });

      setGridChanges({});
      setIsGridEditMode(false);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', res.message || `Saved all changes for ${rows.length} rows in 1 click!`);
      return true;
    } catch (err: any) {
      showNotification('error', `Failed to save grid changes: ${err.message}`);
      return false;
    } finally {
      setGridSaving(false);
    }
  };

  useEffect(() => {
    const hasUnsaved = Object.keys(gridChanges).length > 0;
    if (onUnsavedStateChange) {
      onUnsavedStateChange(hasUnsaved, handleSaveAllGridChanges);
    }
  }, [gridChanges, period?.id]);

  useEffect(() => {
    return () => {
      if (onUnsavedStateChange) {
        onUnsavedStateChange(false);
      }
    };
  }, []);

  const handleCancelGridEdit = () => {
    if (Object.keys(gridChanges).length > 0) {
      if (!window.confirm('Discard all unsaved grid edits?')) return;
    }
    setGridChanges({});
    setIsGridEditMode(false);
  };

  // Update Cycle Total Days
  const handleUpdateCycleDays = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!period) return;
    try {
      await apiRequest(`/payroll/periods/${period.id}/days`, {
        method: 'PUT',
        body: JSON.stringify({ totalDays: cycleTotalDays })
      });
      setIsCycleDaysOpen(false);
      onRefreshPeriod();
      fetchEntries();
      showNotification('success', `Payroll period total days updated to ${cycleTotalDays}.`);
    } catch (err: any) {
      showNotification('error', `Failed to update cycle days: ${err.message}`);
    }
  };

  // Upload and parse Excel salary sheet
  const handleUploadSalaryFile = async () => {
    if (!uploadFile) return;
    try {
      setUploading(true);
      const formData = new FormData();
      formData.append('file', uploadFile);

      const res = await apiRequest<any>('/import/upload', {
        method: 'POST',
        body: formData
      });

      setParseResult(res);
      setSelectedImportSheet('all');
      showNotification('success', `Excel workbook parsed: ${res.sheetCount} sheets detected.`);
    } catch (err: any) {
      showNotification('error', `Failed to parse Excel file: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  // Commit imported Excel rows into current payroll period
  const handleCommitSalarySheet = async () => {
    if (!parseResult || !period) return;
    try {
      setCommittingSheet(true);
      let targetRows: any[] = [];
      if (selectedImportSheet === 'all') {
        Object.values(parseResult.parsedData).forEach((sheetRows: any) => {
          if (Array.isArray(sheetRows)) {
            targetRows.push(...sheetRows);
          }
        });
      } else {
        targetRows = parseResult.parsedData[selectedImportSheet] || [];
      }

      if (targetRows.length === 0) {
        showNotification('error', 'No valid employee records found in the selected sheet.');
        return;
      }

      await apiRequest<any>('/import/commit', {
        method: 'POST',
        body: JSON.stringify({
          rows: targetRows,
          periodId: period.id,
          month: period.month,
          year: period.year
        })
      });

      setIsUploadModalOpen(false);
      setUploadFile(null);
      setParseResult(null);
      showNotification('success', `Successfully applied ${targetRows.length} employee records to ${period.month_name} ${period.year}!`);
      onRefreshPeriod();
      fetchEntries();
    } catch (err: any) {
      showNotification('error', `Failed to apply salary sheet: ${err.message}`);
    } finally {
      setCommittingSheet(false);
    }
  };

  const handleRecalculateAll = async () => {
    if (!period) return;
    if (!window.confirm('Recalculate all employees in this payroll period using active formula rules?')) return;
    try {
      await apiRequest('/payroll/recalculate-all', {
        method: 'POST',
        body: JSON.stringify({ periodId: period.id })
      });
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', 'All payroll entries recalculated successfully.');
    } catch (err: any) {
      showNotification('error', `Recalculate failed: ${err.message}`);
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!period) return;
    const notes = prompt(`Confirm transition to ${newStatus}. Enter optional authorization notes:`);
    if (notes === null) return;

    try {
      await apiRequest(`/payroll/periods/${period.id}/status`, {
        method: 'POST',
        body: JSON.stringify({ status: newStatus, justification: notes })
      });
      onRefreshPeriod();
      showNotification('success', `Cycle transitioned to ${newStatus}.`);
    } catch (err: any) {
      showNotification('error', `Status update failed: ${err.message}`);
    }
  };

  const handleSaveOverride = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideEntry) return;
    try {
      await apiRequest(`/payroll/entries/${overrideEntry.id}/override`, {
        method: 'POST',
        body: JSON.stringify({
          fieldName: overrideField,
          overrideValue,
          reason: overrideReason
        })
      });
      setOverrideEntry(null);
      fetchEntries();
      onRefreshPeriod();
      showNotification('success', 'Manual override recorded in audit history.');
    } catch (err: any) {
      showNotification('error', `Override failed: ${err.message}`);
    }
  };

  if (!period) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
        <p style={{ color: '#64748b' }}>No active payroll period selected. Please create or select one above.</p>
      </div>
    );
  }

  const isFinalized = period.status === 'Finalized';

  // Compute live aggregates from entries
  const totalEmployees = entries.length;
  const sumNetPayable = entries.reduce((acc, curr) => acc + Number(curr.net_payable || 0), 0);
  const sumBasic = entries.reduce((acc, curr) => acc + Number(curr.total_basic || 0), 0);
  const sumEmpEpf = entries.reduce((acc, curr) => acc + Number(curr.employee_epf_12 || 0), 0);
  const sumEmpEsi = entries.reduce((acc, curr) => acc + Number(curr.employee_esi_075 || 0), 0);
  const sumEmployerCost = entries.reduce((acc, curr) => acc + (Number(curr.gross_total || 0) + Number(curr.bonus || 0)), 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Toast Notification */}
      {notification && (
        <div style={{
          padding: '12px 18px',
          borderRadius: '8px',
          fontSize: '13px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          background: notification.type === 'success' ? '#ecfdf5' : '#fef2f2',
          border: `1px solid ${notification.type === 'success' ? '#a7f3d0' : '#fecaca'}`,
          color: notification.type === 'success' ? '#065f46' : '#991b1b'
        }}>
          {notification.type === 'success' ? <CheckCircle2 size={18} color="#059669" /> : <AlertTriangle size={18} color="#dc2626" />}
          <span style={{ fontWeight: 600 }}>{notification.message}</span>
        </div>
      )}

      {/* KPI Stats Strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '14px' }}>
        <div className="card" style={{ padding: '14px 18px', borderLeft: '4px solid #1e3a8a' }}>
          <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Filtered Workforce</div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#0f172a', marginTop: '4px' }}>{totalEmployees} Staff</div>
          <div style={{ fontSize: '11px', color: '#64748b', marginTop: '2px' }}>Period: {period.total_days} Days</div>
        </div>

        <div className="card" style={{ padding: '14px 18px', borderLeft: '4px solid #059669' }}>
          <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Total Net Payable</div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#059669', marginTop: '4px', fontFamily: 'monospace' }}>
            ₹{sumNetPayable.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div style={{ fontSize: '11px', color: '#64748b', marginTop: '2px' }}>Direct Bank Disbursement</div>
        </div>

        <div className="card" style={{ padding: '14px 18px', borderLeft: '4px solid #2563eb' }}>
          <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Basic Wages Sum</div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#1e3a8a', marginTop: '4px', fontFamily: 'monospace' }}>
            ₹{sumBasic.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div style={{ fontSize: '11px', color: '#64748b', marginTop: '2px' }}>Gross Wage Proportion</div>
        </div>

        <div className="card" style={{ padding: '14px 18px', borderLeft: '4px solid #dc2626' }}>
          <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Emp EPF & ESI Deducted</div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#dc2626', marginTop: '4px', fontFamily: 'monospace' }}>
            ₹{(sumEmpEpf + sumEmpEsi).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div style={{ fontSize: '11px', color: '#64748b', marginTop: '2px' }}>EPF: ₹{sumEmpEpf.toLocaleString()} | ESI: ₹{sumEmpEsi.toLocaleString()}</div>
        </div>

        <div className="card" style={{ padding: '14px 18px', borderLeft: '4px solid #d97706' }}>
          <div style={{ fontSize: '11px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase' }}>Est. Employer Cost</div>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#d97706', marginTop: '4px', fontFamily: 'monospace' }}>
            ₹{sumEmployerCost.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
          <div style={{ fontSize: '11px', color: '#64748b', marginTop: '2px' }}>Gross + Contributions + Bonus</div>
        </div>
      </div>

      {/* Workflow Stepper & Period Controls */}
      <div className="card" style={{ padding: '16px 20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            {periods && periods.length > 0 && onSelectPeriod && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <span style={{ fontSize: '12px', fontWeight: 600, color: '#64748b' }}>Select Month:</span>
                <select
                  value={period.id}
                  onChange={(e) => onSelectPeriod(Number(e.target.value))}
                  className="form-input"
                  style={{ width: 'auto', padding: '4px 10px', fontSize: '13px', fontWeight: 700, color: '#1e3a8a' }}
                >
                  {periods.map(p => (
                    <option key={p.id} value={p.id}>
                      {p.month_name} {p.year} ({p.status})
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => setIsCreatePeriodOpen(true)}
                  className="btn btn-secondary btn-sm"
                  style={{ padding: '4px 8px', fontSize: '11px', display: 'flex', alignItems: 'center', gap: '4px' }}
                  title="Create a new payroll period for any month"
                >
                  <Plus size={12} color="#1e3a8a" />
                  <span>New Month</span>
                </button>
              </div>
            )}
            <div style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span>{period.month_name} {period.year}</span>
              <span className="badge" style={{ background: '#eff6ff', color: '#1e3a8a', border: '1px solid #bfdbfe' }}>
                {period.total_days} Calendar Days
              </span>
              <span className="badge" style={{
                background: period.status === 'Finalized' ? '#fef2f2' : '#ecfdf5',
                color: period.status === 'Finalized' ? '#991b1b' : '#065f46',
                border: period.status === 'Finalized' ? '1px solid #fecaca' : '1px solid #a7f3d0'
              }}>
                {period.status}
              </span>
            </div>
            <div style={{ fontSize: '12px', color: '#64748b', marginTop: '3px' }}>
              {period.finalized_at ? `Locked on ${new Date(period.finalized_at).toLocaleDateString()}` : 'Active calculation workspace'}
            </div>
          </div>

          <div style={{ display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap' }}>
            {/* Upload Excel Salary Sheet Button */}
            <button
              onClick={() => { setIsUploadModalOpen(true); setUploadFile(null); setParseResult(null); }}
              className="btn btn-sm"
              style={{ background: '#059669', color: '#ffffff', border: '1px solid #059669', display: 'flex', alignItems: 'center', gap: '6px' }}
              disabled={isFinalized}
              title="Upload pre-prepared Excel salary sheet (.xlsx) for this month"
            >
              <FileSpreadsheet size={14} />
              <span>Upload Excel Salary Sheet</span>
            </button>

            {/* 1-Click Multi-Edit Allowances & Rates */}
            <button
              onClick={() => setIsBulkEditOpen(true)}
              className="btn btn-sm"
              style={{
                background: '#2563eb', color: '#ffffff', border: '1px solid #1d4ed8',
                display: 'flex', alignItems: 'center', gap: '6px', fontWeight: 600,
                boxShadow: '0 1px 2px rgba(37, 99, 235, 0.2)'
              }}
              disabled={isFinalized}
              title="Bulk edit all allowances, performance, and wage rates in 1 click"
            >
              <Zap size={14} />
              <span>⚡ Bulk Edit Allowances & Rates</span>
            </button>

            {/* Multi-Row Grid Mode Toggle */}
            <button
              onClick={() => {
                if (isGridEditMode) handleCancelGridEdit();
                else setIsGridEditMode(true);
              }}
              className={`btn btn-sm ${isGridEditMode ? 'btn-warning' : 'btn-secondary'}`}
              style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
              disabled={isFinalized}
              title="Toggle multi-row spreadsheet edit mode to modify multiple rows simultaneously"
            >
              <Grid size={14} />
              <span>{isGridEditMode ? 'Exit Grid Mode' : '✏️ Multi-Row Grid Mode'}</span>
            </button>

            {/* Attendance Tools */}
            <button
              onClick={() => setIsCycleDaysOpen(true)}
              className="btn btn-secondary btn-sm"
              disabled={isFinalized}
              title="Configure Calendar / Payroll Days"
            >
              <Calendar size={14} />
              <span>Cycle Days ({period.total_days})</span>
            </button>

            <button
              onClick={() => setIsBatchAttendanceOpen(true)}
              className="btn btn-secondary btn-sm"
              disabled={isFinalized}
              title="Bulk Attendance Tool"
            >
              <Users size={14} />
              <span>Batch Attendance</span>
            </button>

            <button onClick={handleRecalculateAll} className="btn btn-secondary btn-sm" disabled={isFinalized}>
              <RefreshCw size={14} />
              <span>Recalculate All</span>
            </button>

            {/* Generate Net Payable Button */}
            <button
              onClick={() => setIsGenerateModalOpen(true)}
              className="btn btn-sm"
              style={{ background: '#1e3a8a', color: '#ffffff', display: 'flex', alignItems: 'center', gap: '6px' }}
              disabled={isFinalized}
              title="Generate / Recalculate Net Payable with configurable rounding or adopt Excel Net Payable"
            >
              <Zap size={14} />
              <span>⚡ Generate Net Payable</span>
            </button>

            {/* Workflow state buttons */}
            {period.status === 'Draft' && (
              <button onClick={() => handleStatusChange('Calculated')} className="btn btn-primary btn-sm">
                Mark Calculated
              </button>
            )}
            {period.status === 'Calculated' && (
              <button onClick={() => handleStatusChange('Under Review')} className="btn btn-primary btn-sm">
                Submit Under Review
              </button>
            )}
            {period.status === 'Under Review' && (
              <button onClick={() => handleStatusChange('Approved')} className="btn btn-success btn-sm">
                Approve Payroll
              </button>
            )}
            {period.status === 'Approved' && (
              <button onClick={() => handleStatusChange('Finalized')} className="btn btn-primary btn-sm">
                <Lock size={14} />
                <span>Finalize & Lock Payroll</span>
              </button>
            )}
            {isFinalized && userRole === 'Super Administrator' && (
              <button onClick={() => handleStatusChange('Reopened')} className="btn btn-danger btn-sm">
                <Unlock size={14} />
                <span>Reopen Payroll</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="card" style={{ padding: '14px 20px' }}>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '220px' }}>
            <input
              type="text"
              placeholder="Search employee by name, code, UAN, or account..."
              className="form-input"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div style={{ width: '190px' }}>
            <select
              value={selectedDesignation}
              onChange={(e) => setSelectedDesignation(e.target.value)}
              className="form-input"
            >
              <option value="">All Designations</option>
              {designations.map(d => (
                <option key={d.id} value={d.id}>{d.alias} — {d.name}</option>
              ))}
            </select>
          </div>
          <div style={{ width: '230px' }}>
            <select
              value={selectedContractor}
              onChange={(e) => setSelectedContractor(e.target.value)}
              className="form-input"
            >
              <option value="">All Contractors / Agencies</option>
              {contractors.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {isSuperAdminUser && (
            <div style={{ width: '240px' }}>
              <select
                value={selectedCreatorId}
                onChange={(e) => setSelectedCreatorId(e.target.value)}
                className="form-input"
                style={{
                  border: '1.5px solid #2563eb',
                  background: '#eff6ff',
                  fontWeight: 600,
                  color: '#1e3a8a'
                }}
                title="Super Admin Master Filter: View records entered by specific account"
              >
                <option value="">👤 All Accounts (Global Plant)</option>
                {creatorsList.map(u => (
                  <option key={u.id} value={u.id}>
                    {u.full_name} ({u.username})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Multi-Select Action Banner */}
      {selectedEntryIds.length > 0 && !isGridEditMode && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: '12px',
          background: '#eff6ff', border: '1px solid #bfdbfe',
          borderRadius: '8px', padding: '10px 16px', flexWrap: 'wrap'
        }}>
          <span style={{ fontWeight: 700, color: '#1e3a8a', fontSize: '13px' }}>
            ✓ {selectedEntryIds.length} Employees Selected
          </span>
          <button
            onClick={() => setIsBulkEditOpen(true)}
            className="btn btn-primary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}
          >
            <Zap size={13} />
            <span>Edit Allowances & Rates for Selected ({selectedEntryIds.length})</span>
          </button>
          <button
            onClick={() => {
              setBatchTarget('selected' as any);
              setIsBatchAttendanceOpen(true);
            }}
            className="btn btn-secondary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}
          >
            <Calendar size={13} />
            <span>Assign Attendance to Selected</span>
          </button>
          <button
            onClick={handleBulkClearSalaries}
            className="btn btn-secondary btn-sm"
            style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', color: '#dc2626', borderColor: '#fca5a5', background: '#fff5f5' }}
            title="Clear and reset salary calculations for selected employees"
          >
            <Trash2 size={13} />
            <span>Clear Salaries ({selectedEntryIds.length})</span>
          </button>
          <button
            onClick={() => setSelectedEntryIds([])}
            className="btn btn-secondary btn-sm"
            style={{ color: '#64748b' }}
          >
            Clear Selection
          </button>
        </div>
      )}

      {/* Column Presets Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '8px',
        padding: '8px 14px',
        background: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: '8px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '12px', fontWeight: 700, color: '#334155', display: 'flex', alignItems: 'center', gap: '4px' }}>
            <Grid size={14} color="#1e3a8a" />
            <span>Columns View:</span>
          </span>
          {[
            { id: 'all', label: '📋 All Columns (Master)' },
            { id: 'attendance', label: '📅 Attendance & Wages' },
            { id: 'allowances', label: '🎁 Allowances & Earnings' },
            { id: 'statutory', label: '⚖️ Statutory EPF/ESI/LWF' },
            { id: 'disbursal', label: '💳 Net Disbursal & Bank' }
          ].map(p => (
            <button
              key={p.id}
              onClick={() => handleSelectPreset(p.id)}
              className="btn btn-sm"
              style={{
                padding: '3px 10px',
                fontSize: '11px',
                fontWeight: activePreset === p.id ? 700 : 500,
                background: activePreset === p.id ? '#1e3a8a' : '#f8fafc',
                color: activePreset === p.id ? '#ffffff' : '#475569',
                border: `1px solid ${activePreset === p.id ? '#1e3a8a' : '#cbd5e1'}`
              }}
            >
              {p.label}
            </button>
          ))}
        </div>
        <div style={{ fontSize: '11px', color: '#64748b' }}>
          Workforce Entries: <strong style={{ color: '#1e3a8a' }}>{entries.length}</strong>
        </div>
      </div>

      {/* Grid Edit Mode Sticky Bar */}
      {isGridEditMode && (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          background: '#fffbeb', border: '2px solid #fcd34d',
          borderRadius: '8px', padding: '12px 18px', flexWrap: 'wrap', gap: '10px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ fontSize: '18px' }}>✏️</span>
            <div>
              <div style={{ fontWeight: 800, color: '#92400e', fontSize: '14px' }}>
                Multi-Row Grid Edit Mode Active
              </div>
              <div style={{ fontSize: '12px', color: '#b45309' }}>
                Edit Attendance, Gross Rates, Thermal All., Performance Allowance, and Bonus directly across rows. Click Save All to apply in 1-click.
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{
              fontSize: '12.5px', fontWeight: 700,
              color: Object.keys(gridChanges).length > 0 ? '#b45309' : '#64748b',
              background: '#ffffff', padding: '4px 10px', borderRadius: '4px', border: '1px solid #fde68a'
            }}>
              {Object.keys(gridChanges).length} Rows Changed
            </span>
            <button
              onClick={handleSaveAllGridChanges}
              disabled={gridSaving || Object.keys(gridChanges).length === 0}
              className="btn btn-success btn-sm"
              style={{
                display: 'inline-flex', alignItems: 'center', gap: '6px',
                padding: '6px 16px', fontWeight: 700, fontSize: '13px'
              }}
            >
              <Save size={14} />
              <span>{gridSaving ? 'Saving...' : `💾 Save All Changes (${Object.keys(gridChanges).length}) (1-Click)`}</span>
            </button>
            <button
              onClick={handleCancelGridEdit}
              className="btn btn-secondary btn-sm"
            >
              <X size={14} />
              <span>Cancel & Discard</span>
            </button>
          </div>
        </div>
      )}

      {/* Payroll Table */}
      <div className="table-container">
        <table className="custom-table">
          <thead>
            <tr>
              <th style={{ width: '38px', textAlign: 'center' }}>
                <input
                  type="checkbox"
                  checked={entries.length > 0 && selectedEntryIds.length === entries.length}
                  onChange={handleSelectAllEntries}
                  title="Select / Deselect All Rows"
                />
              </th>
              <th>Emp Code</th>
              <th>Employee & Agency</th>
              <th>Designation</th>
              {(activePreset === 'all' || activePreset === 'attendance') && (
                <th style={{ textAlign: 'center', background: '#f8fafc' }}>
                  Attendance
                  <div style={{ fontSize: '10px', color: '#64748b', fontWeight: 500 }}>Pres / Total</div>
                </th>
              )}
              {(activePreset === 'all' || activePreset === 'attendance') && (
                <th className="num">Gross Rate</th>
              )}
              {(activePreset === 'all' || activePreset === 'attendance' || activePreset === 'allowances' || activePreset === 'statutory') && (
                <th className="num">Total Basic</th>
              )}
              {(activePreset === 'all' || activePreset === 'allowances') && (
                <th className="num">Thermal All.</th>
              )}
              {(activePreset === 'all' || activePreset === 'allowances') && (
                <th className="num">Perf. All.</th>
              )}
              {(activePreset === 'all' || activePreset === 'allowances') && (
                <th className="num">
                  Bonus
                  <div style={{ fontSize: '10px', color: '#166534', fontWeight: 500 }}>8.33% Basic</div>
                </th>
              )}
              {(activePreset === 'all' || activePreset === 'allowances') && (
                <th className="num" style={{ background: '#f0fdf4', color: '#166534' }}>
                  Circle Diff
                  <div style={{ fontSize: '10px', color: '#15803d', fontWeight: 500 }}>AZ - BA</div>
                </th>
              )}
              {(activePreset === 'all' || activePreset === 'statutory') && (
                <th className="num" style={{ background: '#fff1f2', color: '#be123c' }}>
                  EPF (12%)
                  <div style={{ fontSize: '10px', color: '#9f1239', fontWeight: 500 }}>Emp Share</div>
                </th>
              )}
              {(activePreset === 'all' || activePreset === 'statutory') && (
                <th className="num" style={{ background: '#fff1f2', color: '#be123c' }}>
                  ESI (0.75%)
                  <div style={{ fontSize: '10px', color: '#9f1239', fontWeight: 500 }}>Emp Share</div>
                </th>
              )}
              {(activePreset === 'all' || activePreset === 'statutory') && (
                <th className="num" style={{ background: '#fff1f2', color: '#be123c' }}>
                  LWF
                  <div style={{ fontSize: '10px', color: '#9f1239', fontWeight: 500 }}>₹5</div>
                </th>
              )}
              {(activePreset === 'all' || activePreset === 'statutory' || activePreset === 'disbursal') && (
                <th className="num" style={{ color: '#dc2626' }}>Total Deductions</th>
              )}
              <th className="num" style={{ background: '#eff6ff', color: '#1e3a8a' }}>Net Payable (₹)</th>
              <th style={{ textAlign: 'center', width: '125px' }}>Payslip</th>
              <th style={{ textAlign: 'center' }}>Manage</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={20} style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                  Loading payroll records...
                </td>
              </tr>
            ) : entries.length === 0 ? (
              <tr>
                <td colSpan={20} style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                  No payroll entries match the search criteria.
                </td>
              </tr>
            ) : (
              entries.map(entry => {
                const isQuickEditing = editingId === entry.id;
                const isRowChanged = Boolean(gridChanges[entry.id]);
                return (
                  <tr key={entry.id} style={{ background: isRowChanged ? '#fef9c3' : (entry.is_overridden ? '#fef3c7' : undefined) }}>
                    <td style={{ textAlign: 'center' }}>
                      <input
                        type="checkbox"
                        checked={selectedEntryIds.includes(entry.id)}
                        onChange={() => handleToggleSelectEntry(entry.id)}
                      />
                    </td>
                    <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>
                      {entry.emp_code}
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{entry.emp_name}</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>{entry.contractor_name || 'Direct / Unassigned'}</div>
                    </td>
                    <td>
                      <span className="badge" style={{ background: '#f1f5f9', color: '#1e293b' }}>
                        {entry.designation_alias || 'SW'}
                      </span>
                    </td>
                    {(activePreset === 'all' || activePreset === 'attendance') && (
                      <td style={{ textAlign: 'center' }}>
                        {isGridEditMode ? (
                          <input
                            type="number"
                            style={{ width: '56px', padding: '3px', textAlign: 'center', fontWeight: 700, border: '1px solid #2563eb', borderRadius: '4px' }}
                            value={gridChanges[entry.id]?.present_days !== undefined ? gridChanges[entry.id]!.present_days : entry.present_days}
                            onChange={(e) => handleGridCellChange(entry.id, 'present_days', Number(e.target.value))}
                            min="0"
                            max={entry.period_total_days || period.total_days || 31}
                          />
                        ) : isQuickEditing ? (
                          <input
                            type="number"
                            style={{ width: '56px', padding: '3px', textAlign: 'center', fontWeight: 700 }}
                            value={editPresentDays}
                            onChange={(e) => setEditPresentDays(Number(e.target.value))}
                          />
                        ) : (
                          <span style={{ fontWeight: 700, color: '#0f172a', background: '#f8fafc', padding: '3px 8px', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
                            {entry.present_days} / {entry.period_total_days || period.total_days || 30}
                          </span>
                        )}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'attendance') && (
                      <td className="num">
                        {isGridEditMode ? (
                          <input
                            type="number"
                            style={{ width: '78px', padding: '3px', textAlign: 'right', fontWeight: 600, border: '1px solid #2563eb', borderRadius: '4px' }}
                            value={gridChanges[entry.id]?.gross_salary_rate !== undefined ? gridChanges[entry.id]!.gross_salary_rate : entry.gross_salary_rate}
                            onChange={(e) => handleGridCellChange(entry.id, 'gross_salary_rate', Number(e.target.value))}
                          />
                        ) : (
                          `₹${Number(entry.gross_salary_rate).toLocaleString('en-IN')}`
                        )}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'attendance' || activePreset === 'allowances' || activePreset === 'statutory') && (
                      <td className="num">₹{Number(entry.total_basic).toLocaleString('en-IN')}</td>
                    )}
                    {(activePreset === 'all' || activePreset === 'allowances') && (
                      <td className="num">
                        {isGridEditMode ? (
                          <input
                            type="number"
                            style={{ width: '68px', padding: '3px', textAlign: 'right', border: '1px solid #2563eb', borderRadius: '4px' }}
                            value={gridChanges[entry.id]?.thermal_allowance !== undefined ? gridChanges[entry.id]!.thermal_allowance : entry.thermal_allowance}
                            onChange={(e) => handleGridCellChange(entry.id, 'thermal_allowance', Number(e.target.value))}
                          />
                        ) : (
                          `₹${Number(entry.thermal_allowance).toLocaleString('en-IN')}`
                        )}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'allowances') && (
                      <td className="num">
                        {isGridEditMode ? (
                          <input
                            type="number"
                            title="Monthly Base Performance Allowance"
                            style={{ width: '68px', padding: '3px', textAlign: 'right', border: '1px solid #2563eb', borderRadius: '4px' }}
                            value={gridChanges[entry.id]?.perf_allowance_monthly !== undefined ? gridChanges[entry.id]!.perf_allowance_monthly : entry.perf_allowance_monthly}
                            onChange={(e) => handleGridCellChange(entry.id, 'perf_allowance_monthly', Number(e.target.value))}
                          />
                        ) : isQuickEditing ? (
                          <input
                            type="number"
                            style={{ width: '65px', padding: '3px', textAlign: 'right' }}
                            value={editPerfAllowance}
                            onChange={(e) => setEditPerfAllowance(Number(e.target.value))}
                          />
                        ) : (
                          `₹${Number(entry.perf_allowance_days).toLocaleString('en-IN')}`
                        )}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'allowances') && (
                      <td className="num">
                        {isGridEditMode ? (
                          <input
                            type="number"
                            style={{ width: '62px', padding: '3px', textAlign: 'right', border: '1px solid #2563eb', borderRadius: '4px' }}
                            value={gridChanges[entry.id]?.bonus !== undefined ? gridChanges[entry.id]!.bonus : entry.bonus}
                            onChange={(e) => handleGridCellChange(entry.id, 'bonus', Number(e.target.value))}
                          />
                        ) : isQuickEditing ? (
                          <input
                            type="number"
                            style={{ width: '55px', padding: '3px', textAlign: 'right' }}
                            value={editBonus}
                            onChange={(e) => setEditBonus(Number(e.target.value))}
                          />
                        ) : (
                          <div>
                            <div style={{ fontWeight: 600 }}>₹{Number(entry.bonus).toLocaleString('en-IN')}</div>
                            <div style={{ fontSize: '10px', color: '#166534' }}>
                              {entry.bonus_percentage ?? 8.33}%
                            </div>
                          </div>
                        )}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'allowances') && (
                      <td className="num" style={{ background: '#f0fdf4', fontSize: '12px' }} title={`Last Drawn (AZ): ₹${entry.perf_last_drawn || 0} | Circle (BA): ₹${entry.perf_as_per_circle || 0}`}>
                        <span style={{ fontWeight: 700, color: (Number(entry.perf_difference) || 0) < 0 ? '#dc2626' : '#166534' }}>
                          ₹{Number(entry.perf_difference || 0).toLocaleString('en-IN')}
                        </span>
                        <div style={{ fontSize: '10px', color: '#64748b' }}>
                          {entry.perf_last_drawn || 0} - {entry.perf_as_per_circle || 0}
                        </div>
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'statutory') && (
                      <td className="num" style={{ background: '#fff1f2' }}>
                        ₹{Number(entry.employee_epf_12).toLocaleString('en-IN')}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'statutory') && (
                      <td className="num" style={{ background: '#fff1f2' }}>
                        ₹{Number(entry.employee_esi_075).toLocaleString('en-IN')}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'statutory') && (
                      <td className="num" style={{ background: '#fff1f2' }}>
                        ₹{Number(entry.employee_lwf).toLocaleString('en-IN')}
                      </td>
                    )}
                    {(activePreset === 'all' || activePreset === 'statutory' || activePreset === 'disbursal') && (
                      <td className="num" style={{ color: '#dc2626', fontWeight: 600 }}>
                        ₹{Number(entry.total_employee_deductions).toLocaleString('en-IN')}
                      </td>
                    )}
                    <td className="num" style={{ fontWeight: 800, color: '#1e3a8a', background: '#eff6ff', fontSize: '13.5px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px', flexWrap: 'nowrap' }}>
                        <span>
                          ₹{Number(entry.net_payable).toLocaleString('en-IN', {
                            minimumFractionDigits: Number(entry.net_payable) % 1 !== 0 ? 2 : 0,
                            maximumFractionDigits: 2
                          })}
                        </span>
                        {entry.imported_net_payable !== undefined && entry.imported_net_payable !== null && (
                          <span
                            style={{ fontSize: '9.5px', background: '#dcfce7', color: '#166534', padding: '1px 5px', borderRadius: '4px', fontWeight: 700, whiteSpace: 'nowrap' }}
                            title={`Imported from Excel: ₹${Number(entry.imported_net_payable).toLocaleString('en-IN')}`}
                          >
                            Excel Match
                          </span>
                        )}
                        {entry.is_overridden && (
                          <span
                            style={{ fontSize: '9.5px', background: '#fef3c7', color: '#92400e', padding: '1px 5px', borderRadius: '4px', fontWeight: 700, whiteSpace: 'nowrap' }}
                            title="Net Payable value locked / manually edited"
                          >
                            Locked
                          </span>
                        )}
                        <button
                          onClick={() => handleOpenDirectEdit(entry)}
                          disabled={isFinalized}
                          className="btn btn-secondary btn-sm"
                          style={{ padding: '2px 5px', fontSize: '11px', border: '1px solid #cbd5e1' }}
                          title="Edit Net Payable Salary directly"
                        >
                          <Edit3 size={11} />
                        </button>
                      </div>
                    </td>
                    <td style={{ textAlign: 'center', whiteSpace: 'nowrap' }}>
                      <div style={{ position: 'relative', display: 'inline-block' }}>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActivePayslipDropdownId(activePayslipDropdownId === entry.id ? null : entry.id);
                          }}
                          className="btn btn-primary btn-sm"
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '4px',
                            background: '#1e40af',
                            color: '#ffffff',
                            padding: '4px 9px',
                            fontSize: '11px',
                            borderRadius: '5px',
                            fontWeight: 700
                          }}
                          title="Generate, preview and download employee payslip"
                        >
                          <FileText size={12} />
                          <span>Payslip ▼</span>
                        </button>
                        {activePayslipDropdownId === entry.id && (
                          <div
                            onClick={(e) => e.stopPropagation()}
                            style={{
                              position: 'absolute',
                              right: 0,
                              top: '100%',
                              marginTop: '4px',
                              background: '#ffffff',
                              borderRadius: '8px',
                              boxShadow: '0 10px 30px rgba(0, 0, 0, 0.2), 0 0 0 1px rgba(0, 0, 0, 0.08)',
                              zIndex: 100,
                              minWidth: '205px',
                              padding: '6px 0',
                              textAlign: 'left'
                            }}
                          >
                            <button
                              onClick={() => {
                                setActivePayslipDropdownId(null);
                                setAutoPrintPayslip(false);
                                setPayslipModalEntryId(entry.id);
                              }}
                              style={{
                                display: 'flex', alignItems: 'center', gap: '8px',
                                width: '100%', padding: '8px 14px', border: 'none',
                                background: 'none', cursor: 'pointer', fontSize: '12px',
                                color: '#1e293b', fontWeight: 600, textAlign: 'left'
                              }}
                              onMouseEnter={(e) => (e.currentTarget.style.background = '#f1f5f9')}
                              onMouseLeave={(e) => (e.currentTarget.style.background = 'none')}
                            >
                              <Eye size={14} color="#2563eb" />
                              <span>Preview Payslip</span>
                            </button>

                            <button
                              onClick={async () => {
                                setActivePayslipDropdownId(null);
                                try {
                                  const filename = `Payslip_${entry.emp_code}_${period?.month_name || 'Month'}_${period?.year || 2026}.pdf`;
                                  await downloadFile(`/export/payslip-pdf/${entry.id}`, filename);
                                  showNotification('success', `PDF Payslip downloaded for ${entry.emp_name}`);
                                } catch (err: any) {
                                  showNotification('error', `PDF download failed: ${err.message}`);
                                }
                              }}
                              style={{
                                display: 'flex', alignItems: 'center', gap: '8px',
                                width: '100%', padding: '8px 14px', border: 'none',
                                background: 'none', cursor: 'pointer', fontSize: '12px',
                                color: '#1e293b', fontWeight: 600, textAlign: 'left'
                              }}
                              onMouseEnter={(e) => (e.currentTarget.style.background = '#f1f5f9')}
                              onMouseLeave={(e) => (e.currentTarget.style.background = 'none')}
                            >
                              <FileDown size={14} color="#dc2626" />
                              <span>Download Payslip as PDF</span>
                            </button>

                            <button
                              onClick={async () => {
                                setActivePayslipDropdownId(null);
                                try {
                                  const filename = `Payslip_${entry.emp_code}_${period?.month_name || 'Month'}_${period?.year || 2026}.xlsx`;
                                  await downloadFile(`/export/payslip-xlsx/${entry.id}`, filename);
                                  showNotification('success', `Excel Payslip downloaded for ${entry.emp_name}`);
                                } catch (err: any) {
                                  showNotification('error', `Excel download failed: ${err.message}`);
                                }
                              }}
                              style={{
                                display: 'flex', alignItems: 'center', gap: '8px',
                                width: '100%', padding: '8px 14px', border: 'none',
                                background: 'none', cursor: 'pointer', fontSize: '12px',
                                color: '#1e293b', fontWeight: 600, textAlign: 'left'
                              }}
                              onMouseEnter={(e) => (e.currentTarget.style.background = '#f1f5f9')}
                              onMouseLeave={(e) => (e.currentTarget.style.background = 'none')}
                            >
                              <FileSpreadsheet size={14} color="#16a34a" />
                              <span>Download Payslip as Excel</span>
                            </button>

                            <button
                              onClick={() => {
                                setActivePayslipDropdownId(null);
                                setAutoPrintPayslip(true);
                                setPayslipModalEntryId(entry.id);
                              }}
                              style={{
                                display: 'flex', alignItems: 'center', gap: '8px',
                                width: '100%', padding: '8px 14px', border: 'none',
                                background: 'none', cursor: 'pointer', fontSize: '12px',
                                color: '#1e293b', fontWeight: 600, textAlign: 'left'
                              }}
                              onMouseEnter={(e) => (e.currentTarget.style.background = '#f1f5f9')}
                              onMouseLeave={(e) => (e.currentTarget.style.background = 'none')}
                            >
                              <Printer size={14} color="#475569" />
                              <span>Print Payslip</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </td>
                    <td style={{ textAlign: 'center' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        {isGridEditMode ? (
                          isRowChanged ? (
                            <span style={{ fontSize: '11px', fontWeight: 700, color: '#d97706', background: '#fef3c7', padding: '2px 6px', borderRadius: '4px' }}>
                              Modified
                            </span>
                          ) : (
                            <span style={{ color: '#94a3b8', fontSize: '12px' }}>--</span>
                          )
                        ) : isQuickEditing ? (
                          <>
                            <button
                              onClick={() => handleSaveQuickEdit(entry.id)}
                              className="btn btn-success btn-sm"
                              title="Save Quick Edit"
                            >
                              <Save size={13} />
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="btn btn-secondary btn-sm"
                              title="Cancel"
                            >
                              <X size={13} />
                            </button>
                          </>
                        ) : (
                          <>
                            <button
                              onClick={() => handleOpenFullEdit(entry)}
                              disabled={isFinalized}
                              className="btn btn-secondary btn-sm"
                              title="Edit Comprehensive Allowances, Deductions & EPF/ESI"
                            >
                              <Sliders size={13} />
                              <span>Edit</span>
                            </button>
                            <button
                              onClick={() => setInspectEntry(entry)}
                              className="btn btn-secondary btn-sm"
                              title="Inspect Formula Calculation"
                            >
                              <Info size={13} />
                            </button>
                            <button
                              onClick={() => {
                                setOverrideEntry(entry);
                                setOverrideValue(Number(entry.net_payable));
                                setOverrideReason('');
                              }}
                              disabled={isFinalized}
                              className="btn btn-secondary btn-sm"
                              title="Audit Override"
                            >
                              <FileText size={13} />
                            </button>
                            <button
                              onClick={() => handleClearSingleSalary(entry)}
                              disabled={isFinalized}
                              className="btn btn-secondary btn-sm"
                              style={{ color: '#dc2626' }}
                              title="Clear / Reset Salary calculation for this employee"
                            >
                              <Trash2 size={13} />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Full Component Edit Modal */}
      {fullEditEntry && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '820px' }}>
            <div className="modal-header" style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '14px' }}>
              <div>
                <h3 style={{ fontSize: '16.5px', fontWeight: 800, color: '#0f172a' }}>
                  Edit Components: {fullEditEntry.emp_name} ({fullEditEntry.emp_code})
                </h3>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                  Designation: <strong style={{ color: '#1e3a8a' }}>{fullEditEntry.designation_alias}</strong> • Agency: {fullEditEntry.contractor_name || 'N/A'}
                </div>
              </div>
              <button onClick={() => setFullEditEntry(null)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>

            <form onSubmit={handleSaveFullEdit}>
              <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '16px', maxHeight: '72vh', overflowY: 'auto' }}>
                
                {/* Section 1: Attendance & Base Wages */}
                <div style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                  <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#1e3a8a', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <Calendar size={16} />
                    <span>Designation, Attendance & Base Wage Rates</span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: '12px' }}>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Designation</label>
                      <select
                        className="form-input"
                        value={compDesignationId}
                        onChange={(e) => {
                          const val = e.target.value ? Number(e.target.value) : '';
                          setCompDesignationId(val);
                          if (val) {
                            const d = designations.find(des => des.id === val);
                            if (d) {
                              if (d.gross_salary_rate !== undefined && d.gross_salary_rate !== null) {
                                setCompGrossRate(Number(d.gross_salary_rate));
                              }
                              if (d.special_allowance !== undefined && d.special_allowance !== null) {
                                setCompSpecialAll(Number(d.special_allowance));
                              }
                              if (d.perf_allowance_default !== undefined && d.perf_allowance_default !== null) {
                                setCompPerfMonthly(Number(d.perf_allowance_default));
                              }
                            }
                          }
                        }}
                      >
                        <option value="">Keep Existing ({fullEditEntry.designation_alias || 'Current'})</option>
                        {designations.map(d => (
                          <option key={d.id} value={d.id}>
                            {d.alias} - {d.name} (₹{Number(d.gross_salary_rate || 0).toLocaleString('en-IN')})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Present Days (out of {period.total_days}) *</label>
                      <input
                        type="number"
                        step="0.5"
                        min="0"
                        max={period.total_days}
                        required
                        className="form-input"
                        value={compPresentDays}
                        onChange={(e) => setCompPresentDays(Number(e.target.value))}
                      />
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Gross Wage Rate (₹) *</label>
                      <input
                        type="number"
                        step="1"
                        required
                        className="form-input"
                        value={compGrossRate}
                        onChange={(e) => setCompGrossRate(Number(e.target.value))}
                      />
                    </div>
                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Special Allowance (₹)</label>
                      <input
                        type="number"
                        step="1"
                        className="form-input"
                        value={compSpecialAll}
                        onChange={(e) => setCompSpecialAll(Number(e.target.value))}
                      />
                    </div>
                  </div>
                </div>

                {/* Section 2: Allowances, Bonus & EMC Circle Comparison */}
                <div style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                  <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#1e3a8a', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <DollarSign size={16} />
                    <span>Thermal, Performance, Bonus Allowances & EMC Comparison</span>
                  </div>
                  <div className="grid-3" style={{ marginBottom: '12px' }}>
                    <div className="form-group" style={{ margin: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                        <label className="form-label" style={{ margin: 0 }}>Thermal All. (₹)</label>
                        <label style={{ fontSize: '11px', color: '#64748b', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                          <input
                            type="checkbox"
                            checked={compThermalAuto}
                            onChange={(e) => setCompThermalAuto(e.target.checked)}
                          />
                          Auto ₹1,500
                        </label>
                      </div>
                      <input
                        type="number"
                        step="1"
                        disabled={compThermalAuto}
                        className="form-input"
                        value={compThermalAuto ? preview?.thermal : compThermalAll}
                        onChange={(e) => setCompThermalAll(Number(e.target.value))}
                      />
                    </div>

                    <div className="form-group" style={{ margin: 0 }}>
                      <label className="form-label">Monthly Perf. All. (₹)</label>
                      <input
                        type="number"
                        step="1"
                        className="form-input"
                        value={compPerfMonthly}
                        onChange={(e) => setCompPerfMonthly(Number(e.target.value))}
                      />
                      <span style={{ fontSize: '10.5px', color: '#64748b' }}>Prorated: ₹{preview?.perfDays.toFixed(2)}</span>
                    </div>

                    <div className="form-group" style={{ margin: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                        <label className="form-label" style={{ margin: 0 }}>Bonus (₹)</label>
                        <label style={{ fontSize: '11px', color: '#166534', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                          <input
                            type="checkbox"
                            checked={compBonusAuto}
                            onChange={(e) => setCompBonusAuto(e.target.checked)}
                          />
                          Auto ({compBonusPercentage}%)
                        </label>
                      </div>
                      <div style={{ display: 'flex', gap: '6px' }}>
                        <input
                          type="number"
                          step="0.01"
                          style={{ width: '70px' }}
                          className="form-input"
                          title="Bonus percentage of basic salary (default 8.33%)"
                          value={compBonusPercentage}
                          onChange={(e) => setCompBonusPercentage(Number(e.target.value))}
                        />
                        <input
                          type="number"
                          step="1"
                          disabled={compBonusAuto}
                          className="form-input"
                          style={{ flex: 1 }}
                          value={compBonusAuto ? preview?.finalBonus : compBonus}
                          onChange={(e) => setCompBonus(Number(e.target.value))}
                        />
                      </div>
                      <span style={{ fontSize: '10.5px', color: '#64748b' }}>
                        {compBonusAuto ? `Auto: ₹${preview?.finalBonus} (${compBonusPercentage}% of Basic ₹${preview?.totalBasic})` : 'Custom manual bonus override'}
                      </span>
                    </div>
                  </div>

                  {/* EMC Circle Performance Allowance Comparison Sub-section */}
                  <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: '10px' }}>
                    <div style={{ fontSize: '12px', fontWeight: 700, color: '#334155', marginBottom: '8px' }}>
                      EMC Circle Performance Allowance Comparison (Cols AZ, BA, BB)
                    </div>
                    <div className="grid-3">
                      <div className="form-group" style={{ margin: 0 }}>
                        <label className="form-label">Last Drawn Perf. All. (AZ)</label>
                        <input
                          type="number"
                          step="1"
                          className="form-input"
                          value={compPerfLastDrawn}
                          onChange={(e) => setCompPerfLastDrawn(Number(e.target.value))}
                        />
                      </div>
                      <div className="form-group" style={{ margin: 0 }}>
                        <label className="form-label">Circle Perf. All. (BA)</label>
                        <input
                          type="number"
                          step="1"
                          className="form-input"
                          value={compPerfAsPerCircle}
                          onChange={(e) => setCompPerfAsPerCircle(Number(e.target.value))}
                        />
                      </div>
                      <div className="form-group" style={{ margin: 0 }}>
                        <label className="form-label">Difference = AZ - BA (BB)</label>
                        <input
                          type="number"
                          readOnly
                          disabled
                          className="form-input"
                          style={{ fontWeight: 700, color: (preview?.perfDiff || 0) < 0 ? '#dc2626' : '#166534', background: '#f1f5f9' }}
                          value={preview?.perfDiff ?? 0}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Section 3: Statutory Deductions (EPF, ESI, LWF) */}
                <div style={{ background: '#fef2f2', padding: '14px', borderRadius: '8px', border: '1px solid #fecaca' }}>
                  <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#991b1b', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <ShieldAlert size={16} />
                    <span>Statutory Employee Deductions (EPF, ESI, LWF)</span>
                  </div>

                  <div className="grid-3">
                    {/* Employee EPF */}
                    <div className="form-group" style={{ margin: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                        <label className="form-label" style={{ margin: 0 }}>Employee EPF (12%)</label>
                        <label style={{ fontSize: '11px', color: '#dc2626', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                          <input
                            type="checkbox"
                            checked={compEmpEpfCustom}
                            onChange={(e) => setCompEmpEpfCustom(e.target.checked)}
                          />
                          Custom Override
                        </label>
                      </div>
                      <input
                        type="number"
                        step="1"
                        disabled={!compEmpEpfCustom}
                        className="form-input"
                        value={compEmpEpfCustom ? compEmpEpf : preview?.finalEmpEpf}
                        onChange={(e) => setCompEmpEpf(Number(e.target.value))}
                      />
                    </div>

                    {/* Employee ESI */}
                    <div className="form-group" style={{ margin: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                        <label className="form-label" style={{ margin: 0 }}>Employee ESI (0.75%)</label>
                        <label style={{ fontSize: '11px', color: '#dc2626', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                          <input
                            type="checkbox"
                            checked={compEmpEsiCustom}
                            onChange={(e) => setCompEmpEsiCustom(e.target.checked)}
                          />
                          Custom Override
                        </label>
                      </div>
                      <input
                        type="number"
                        step="1"
                        disabled={!compEmpEsiCustom}
                        className="form-input"
                        value={compEmpEsiCustom ? compEmpEsi : preview?.finalEmpEsi}
                        onChange={(e) => setCompEmpEsi(Number(e.target.value))}
                      />
                    </div>

                    {/* Employee LWF */}
                    <div className="form-group" style={{ margin: 0 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                        <label className="form-label" style={{ margin: 0 }}>Employee LWF (₹)</label>
                        <label style={{ fontSize: '11px', color: '#dc2626', display: 'flex', alignItems: 'center', gap: '4px', cursor: 'pointer' }}>
                          <input
                            type="checkbox"
                            checked={compEmpLwfCustom}
                            onChange={(e) => setCompEmpLwfCustom(e.target.checked)}
                          />
                          Custom Override
                        </label>
                      </div>
                      <input
                        type="number"
                        step="1"
                        disabled={!compEmpLwfCustom}
                        className="form-input"
                        value={compEmpLwfCustom ? compEmpLwf : 5}
                        onChange={(e) => setCompEmpLwf(Number(e.target.value))}
                      />
                    </div>
                  </div>
                </div>

                {/* Section 4: Live Recalculation Bar */}
                {preview && (
                  <div style={{ background: '#eff6ff', padding: '16px', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ display: 'flex', gap: '20px' }}>
                        <div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>Total Basic</div>
                          <div style={{ fontSize: '15px', fontWeight: 800, color: '#1e3a8a', fontFamily: 'monospace' }}>
                            ₹{preview.totalBasic}
                          </div>
                        </div>
                        <div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>Total Earnings</div>
                          <div style={{ fontSize: '15px', fontWeight: 800, color: '#1e3a8a', fontFamily: 'monospace' }}>
                            ₹{preview.totalEarnings.toFixed(2)}
                          </div>
                        </div>
                        <div>
                          <div style={{ fontSize: '11px', color: '#64748b' }}>Total Deductions</div>
                          <div style={{ fontSize: '15px', fontWeight: 800, color: '#dc2626', fontFamily: 'monospace' }}>
                            ₹{preview.totalDeductions}
                          </div>
                        </div>
                      </div>

                      <div style={{ textAlign: 'right' }}>
                        <div style={{ fontSize: '11px', color: '#1e3a8a', fontWeight: 700 }}>LIVE RECALCULATED NET PAYABLE</div>
                        <div style={{ fontSize: '22px', fontWeight: 900, color: '#1e3a8a', fontFamily: 'monospace' }}>
                          ₹{preview.netPayable.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Remember Rates Option */}
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', background: '#f8fafc', borderRadius: '6px', border: '1px solid #e2e8f0', marginTop: '4px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '13px', color: '#1e293b', fontWeight: 600, margin: 0 }}>
                    <input
                      type="checkbox"
                      checked={compRememberRates}
                      onChange={(e) => setCompRememberRates(e.target.checked)}
                      style={{ width: '16px', height: '16px', accentColor: '#2563eb' }}
                    />
                    <span>Remember updated rates in Employee Master (permanently save across future payrolls)</span>
                  </label>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Persists wage rates to profile</span>
                </div>
              </div>

              <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', paddingTop: '14px' }}>
                <button type="button" onClick={() => setFullEditEntry(null)} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  <Save size={16} />
                  <span>Commit Component Updates</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Batch Attendance Modal */}
      {isBatchAttendanceOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '480px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Users size={18} color="#1e3a8a" />
                <span>Bulk Attendance Manager</span>
              </h3>
              <button onClick={() => setIsBatchAttendanceOpen(false)}><X size={20} /></button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: '12.5px', color: '#64748b', marginBottom: '14px' }}>
                Quickly apply present days across all employees or currently filtered workforce in this payroll cycle.
              </p>

              <div className="form-group">
                <label className="form-label">Target Audience</label>
                <select
                  className="form-input"
                  value={batchTarget}
                  onChange={(e) => setBatchTarget(e.target.value as any)}
                >
                  <option value="all">All Employees in Cycle ({period.employee_count || entries.length} workers)</option>
                  <option value="filtered">Currently Filtered Workforce ({entries.length} workers)</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Present Days to Assign</label>
                <input
                  type="number"
                  min="0"
                  max={period.total_days}
                  className="form-input"
                  value={batchDays}
                  onChange={(e) => setBatchDays(Number(e.target.value))}
                />
              </div>

              <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                <button type="button" onClick={() => setBatchDays(period.total_days || 30)} className="btn btn-secondary btn-sm">
                  Full Month ({period.total_days} Days)
                </button>
                <button type="button" onClick={() => setBatchDays(26)} className="btn btn-secondary btn-sm">
                  26 Working Days
                </button>
                <button type="button" onClick={() => setBatchDays(0)} className="btn btn-secondary btn-sm">
                  0 Days (Absent)
                </button>
              </div>
            </div>
            <div className="modal-footer">
              <button type="button" onClick={() => setIsBatchAttendanceOpen(false)} className="btn btn-secondary">
                Cancel
              </button>
              <button
                type="button"
                disabled={batchSaving}
                onClick={handleExecuteBatchAttendance}
                className="btn btn-primary"
              >
                {batchSaving ? 'Applying...' : `Assign ${batchDays} Days to ${batchTarget === 'all' ? 'All' : 'Filtered'}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cycle Days Modal */}
      {isCycleDaysOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '420px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Set Payroll Cycle Total Days</h3>
              <button onClick={() => setIsCycleDaysOpen(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleUpdateCycleDays}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Total Days in {period.month_name} {period.year} *</label>
                  <input
                    type="number"
                    min="1"
                    max="31"
                    required
                    className="form-input"
                    value={cycleTotalDays}
                    onChange={(e) => setCycleTotalDays(Number(e.target.value))}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>
                    Standard September month is 30 days. Proportional calculations will adjust based on this value.
                  </span>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setIsCycleDaysOpen(false)} className="btn btn-secondary">Cancel</button>
                <button type="submit" className="btn btn-primary">Update Cycle Days</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Formula Inspection Modal */}
      {inspectEntry && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '650px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>
                Formula Breakdown: {inspectEntry.emp_name} ({inspectEntry.emp_code})
              </h3>
              <button onClick={() => setInspectEntry(null)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>
            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px', fontSize: '13px' }}>
              <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '4px' }}>1. Total Basic Calculation</div>
                <code style={{ color: '#047857' }}>
                  ROUND((GrossRate + SpecialAllowance) * PresentDays / TotalDays, 0)
                </code>
                <div style={{ marginTop: '4px' }}>
                  = ROUND(({inspectEntry.gross_salary_rate} + {inspectEntry.special_allowance}) * {inspectEntry.present_days} / {inspectEntry.period_total_days || 30}, 0) = <strong>₹{inspectEntry.total_basic}</strong>
                </div>
              </div>

              <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '4px' }}>2. Thermal Allowance</div>
                <code style={{ color: '#047857' }}>ROUND(1500 * PresentDays / TotalDays, 0)</code>
                <div style={{ marginTop: '4px' }}>
                  = ROUND(1500 * {inspectEntry.present_days} / {inspectEntry.period_total_days || 30}, 0) = <strong>₹{inspectEntry.thermal_allowance}</strong>
                </div>
              </div>

              <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '4px' }}>3. EPF Deductions (12%) & Employer Share</div>
                <code style={{ color: '#047857' }}>Wage Base = Proportioned Salary (₹{Number(inspectEntry.proportioned_salary).toFixed(2)})</code>
                <div style={{ marginTop: '4px' }}>
                  Employee EPF 12%: <strong>₹{inspectEntry.employee_epf_12}</strong> | Employer EPF 12%: <strong>₹{inspectEntry.employer_epf_12}</strong> | 1% Admin: <strong>₹{inspectEntry.employer_epf_1}</strong>
                </div>
              </div>

              <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '4px' }}>4. ESI Deductions (0.75%) & LWF (₹5)</div>
                <code style={{ color: '#047857' }}>ROUND(IF(TotalEarnings &lt; 21000, TotalEarnings * 0.0075, 0), 0)</code>
                <div style={{ marginTop: '4px' }}>
                  Employee ESI: <strong>₹{inspectEntry.employee_esi_075}</strong> | Employee LWF: <strong>₹{inspectEntry.employee_lwf}</strong>
                </div>
              </div>

              <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '4px' }}>5. Bonus & Performance Circle Comparison</div>
                <code style={{ color: '#047857' }}>Bonus: ROUND(TotalBasic * {inspectEntry.bonus_percentage ?? 8.33} / 100, 0) = ₹{inspectEntry.bonus}</code>
                <div style={{ marginTop: '4px' }}>
                  EMC Circle Diff (Cols AZ - BA): Last Drawn ₹{inspectEntry.perf_last_drawn || 0} - Circle Rate ₹{inspectEntry.perf_as_per_circle || 0} = <strong>₹{inspectEntry.perf_difference || 0}</strong>
                </div>
              </div>

              <div style={{ background: '#eff6ff', padding: '14px', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
                <div style={{ fontWeight: 700, color: '#1e3a8a', marginBottom: '4px' }}>6. Final Net Payable Salary</div>
                <div>
                  Total Earnings (₹{inspectEntry.total_earnings_before_bonus}) + Bonus (₹{inspectEntry.bonus}) - Total Deductions (₹{inspectEntry.total_employee_deductions})
                  = <strong style={{ fontSize: '16px', color: '#1e3a8a' }}>₹{Number(inspectEntry.net_payable).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button onClick={() => setInspectEntry(null)} className="btn btn-primary">Close Breakdown</button>
            </div>
          </div>
        </div>
      )}

      {/* Manual Override Modal */}
      {overrideEntry && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '550px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>
                Audit Field Override: {overrideEntry.emp_name}
              </h3>
              <button onClick={() => setOverrideEntry(null)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>
            <form onSubmit={handleSaveOverride}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Select Field to Override</label>
                  <select
                    className="form-input"
                    value={overrideField}
                    onChange={(e) => setOverrideField(e.target.value)}
                  >
                    <option value="net_payable">Net Payable Salary</option>
                    <option value="thermal_allowance">Thermal Allowance</option>
                    <option value="bonus">Bonus</option>
                    <option value="special_allowance">Special Allowance</option>
                    <option value="employee_epf_12">Employee EPF 12%</option>
                    <option value="employee_esi_075">Employee ESI 0.75%</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Override Value (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    className="form-input"
                    value={overrideValue}
                    onChange={(e) => setOverrideValue(Number(e.target.value))}
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Justification / Audit Reason *</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Provide mandatory operational or statutory reason for this manual override..."
                    className="form-input"
                    value={overrideReason}
                    onChange={(e) => setOverrideReason(e.target.value)}
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setOverrideEntry(null)} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Commit Override
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create New Payroll Period Modal */}
      <CreatePeriodModal
        isOpen={isCreatePeriodOpen}
        onClose={() => setIsCreatePeriodOpen(false)}
        onPeriodCreated={(newId) => {
          if (onPeriodCreated) onPeriodCreated(newId);
          else if (onSelectPeriod) onSelectPeriod(newId);
          onRefreshPeriod();
        }}
      />

      {/* Upload Prepared Excel Salary Sheet Modal */}
      {isUploadModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '680px', width: '92%' }}>
            <div className="modal-header" style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '14px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <FileSpreadsheet size={20} color="#059669" />
                <h3 style={{ fontSize: '16.5px', fontWeight: 800, color: '#0f172a', margin: 0 }}>
                  Upload Prepared Excel Salary Sheet: {period.month_name} {period.year}
                </h3>
              </div>
              <button onClick={() => setIsUploadModalOpen(false)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>

            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '16px', maxHeight: '72vh', overflowY: 'auto' }}>
              <p style={{ fontSize: '12.5px', color: '#64748b', margin: 0 }}>
                Import an existing contractual salary workbook (.xlsx) directly into <strong>{period.month_name} {period.year}</strong>.
                Supports multi-worksheet registers (MM-1, EMC, Operation Circle) and auto-populates employee details, attendance, allowances, and statutory contributions.
              </p>

              {/* Step 1: File Selection & Parse */}
              <div style={{ border: '2px dashed #cbd5e1', borderRadius: '8px', padding: '20px', textAlign: 'center', background: '#f8fafc' }}>
                <input
                  type="file"
                  id="excelFileInput"
                  accept=".xlsx, .xls"
                  style={{ display: 'none' }}
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      setUploadFile(e.target.files[0]);
                      setParseResult(null);
                    }
                  }}
                />
                <label htmlFor="excelFileInput" style={{ cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
                  <Upload size={32} color="#059669" />
                  <span style={{ fontSize: '13.5px', fontWeight: 600, color: '#1e3a8a' }}>
                    {uploadFile ? uploadFile.name : 'Click to select or drag and drop your Excel salary sheet'}
                  </span>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>
                    Supports reference format e.g. "SALARY SHEET-for EPF Sepf 2026.xlsx" (.xlsx, .xls up to 25MB)
                  </span>
                </label>

                {uploadFile && !parseResult && (
                  <div style={{ marginTop: '14px' }}>
                    <button
                      type="button"
                      disabled={uploading}
                      onClick={handleUploadSalaryFile}
                      className="btn btn-primary btn-sm"
                    >
                      {uploading ? 'Analyzing and Parsing Workbook...' : 'Inspect & Parse Excel Sheets'}
                    </button>
                  </div>
                )}
              </div>

              {/* Step 2: Worksheet Breakdown & Preview */}
              {parseResult && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', padding: '12px 16px', borderRadius: '8px' }}>
                    <div style={{ fontWeight: 700, fontSize: '13.5px', color: '#065f46', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <CheckCircle2 size={16} />
                      <span>Workbook Parsed Successfully ({parseResult.sheets?.length || 0} Worksheets Detected)</span>
                    </div>
                    <div style={{ fontSize: '12px', color: '#047857', marginTop: '4px' }}>
                      Total rows detected: {parseResult.sheets?.reduce((acc: number, s: any) => acc + s.totalRows, 0) || 0} employee records across worksheets.
                    </div>
                  </div>

                  <div className="form-group" style={{ margin: 0 }}>
                    <label className="form-label">Select Worksheet to Import</label>
                    <select
                      className="form-input"
                      value={selectedImportSheet}
                      onChange={(e) => setSelectedImportSheet(e.target.value)}
                    >
                      <option value="all">
                        Import All Worksheets Combined ({parseResult.sheets?.reduce((acc: number, s: any) => acc + s.totalRows, 0)} records) [Recommended]
                      </option>
                      {parseResult.sheets?.map((s: any) => (
                        <option key={s.sheetName} value={s.sheetName}>
                          Worksheet: {s.sheetName} ({s.totalRows} employees)
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Quick Preview Table */}
                  <div style={{ border: '1px solid #e2e8f0', borderRadius: '6px', overflow: 'hidden' }}>
                    <div style={{ background: '#f8fafc', padding: '8px 12px', fontSize: '12px', fontWeight: 700, color: '#475569', borderBottom: '1px solid #e2e8f0' }}>
                      Preview of Sample Employee Rows:
                    </div>
                    <div style={{ maxHeight: '180px', overflowY: 'auto' }}>
                      <table className="custom-table" style={{ fontSize: '11.5px', margin: 0 }}>
                        <thead>
                          <tr>
                            <th>Emp Code</th>
                            <th>Name</th>
                            <th>Designation</th>
                            <th>Present Days</th>
                            <th className="num">Gross Rate</th>
                            <th>Contractor</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(selectedImportSheet === 'all'
                            ? (Object.values(parseResult.parsedData)[0] as any[]) || []
                            : (parseResult.parsedData[selectedImportSheet] as any[]) || []
                          ).slice(0, 5).map((r: any, idx: number) => (
                            <tr key={idx}>
                              <td style={{ fontWeight: 700, color: '#1e3a8a', fontFamily: 'monospace' }}>{r.empCode}</td>
                              <td style={{ fontWeight: 600 }}>{r.name}</td>
                              <td>{r.designationAlias}</td>
                              <td>{r.presentDays} / {r.totalDays}</td>
                              <td className="num">₹{r.grossSalaryRate || '—'}</td>
                              <td style={{ fontSize: '11px', color: '#64748b' }}>{r.contractorName || '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', paddingTop: '14px' }}>
              <button
                type="button"
                onClick={() => setIsUploadModalOpen(false)}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              {parseResult && (
                <button
                  type="button"
                  disabled={committingSheet}
                  onClick={handleCommitSalarySheet}
                  className="btn btn-primary"
                  style={{ background: '#059669', borderColor: '#059669' }}
                >
                  <FileSpreadsheet size={15} />
                  <span>
                    {committingSheet
                      ? 'Committing & Calculating...'
                      : `Commit Sheet to ${period.month_name} ${period.year}`}
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 1-Click Multi-Edit Allowances, Performance & Rates Modal */}
      <BulkAllowancesRatesModal
        isOpen={isBulkEditOpen}
        onClose={() => setIsBulkEditOpen(false)}
        periodId={period.id}
        monthName={period.month_name}
        year={period.year}
        totalDays={period.total_days}
        selectedCount={selectedEntryIds.length}
        selectedEntryIds={selectedEntryIds}
        filteredCount={entries.length}
        totalCount={period.employee_count || entries.length}
        designations={designations}
        contractors={contractors}
        activeDesignationFilter={selectedDesignation}
        activeContractorFilter={selectedContractor}
        onSuccess={(msg) => {
          showNotification('success', msg);
          setSelectedEntryIds([]);
          fetchEntries();
          onRefreshPeriod();
        }}
      />

      {/* Employee Payslip Preview & Export Modal */}
      {payslipModalEntryId !== null && (
        <PayslipModal
          entryId={payslipModalEntryId}
          autoPrint={autoPrintPayslip}
          onClose={() => {
            setPayslipModalEntryId(null);
            setAutoPrintPayslip(false);
          }}
        />
      )}

      {/* Direct Net Payable Edit Modal */}
      {directEditEntry && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '480px' }}>
            <div className="modal-header" style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '12px' }}>
              <div>
                <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Edit3 size={18} color="#2563eb" />
                  <span>Edit Net Payable Salary</span>
                </h3>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                  {directEditEntry.emp_name} ({directEditEntry.emp_code}) • {directEditEntry.designation_alias}
                </div>
              </div>
              <button onClick={() => setDirectEditEntry(null)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>

            <form onSubmit={handleSaveDirectEdit}>
              <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px', paddingTop: '16px' }}>
                <div style={{ background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                  <div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Current Net Payable</div>
                    <div style={{ fontSize: '16px', fontWeight: 700, color: '#1e3a8a' }}>
                      ₹{Number(directEditEntry.net_payable).toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Imported from Excel</div>
                    <div style={{ fontSize: '16px', fontWeight: 700, color: '#059669' }}>
                      {directEditEntry.imported_net_payable !== undefined && directEditEntry.imported_net_payable !== null
                        ? `₹${Number(directEditEntry.imported_net_payable).toLocaleString('en-IN', { maximumFractionDigits: 2 })}`
                        : '—'}
                    </div>
                  </div>
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label" style={{ fontWeight: 700, color: '#1e293b' }}>
                    New Net Payable Salary (₹)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    className="form-input"
                    style={{ fontSize: '16px', fontWeight: 700, color: '#1e3a8a' }}
                    value={directNetValue}
                    onChange={(e) => setDirectNetValue(Number(e.target.value))}
                  />
                  <div style={{ fontSize: '11px', color: '#64748b', marginTop: '4px' }}>
                    Direct manual override will lock this employee's net payable value from automatic recalculations.
                  </div>
                </div>

                {directEditEntry.imported_net_payable !== undefined && directEditEntry.imported_net_payable !== null && (
                  <button
                    type="button"
                    onClick={() => setDirectNetValue(Number(directEditEntry.imported_net_payable))}
                    className="btn btn-secondary btn-sm"
                    style={{ alignSelf: 'flex-start', fontSize: '12px', color: '#059669', borderColor: '#a7f3d0' }}
                  >
                    Match Excel Sheet Value (₹{Number(directEditEntry.imported_net_payable).toLocaleString('en-IN')})
                  </button>
                )}

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Reason / Adjustment Note</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="e.g. Rate adjustment / Verified as per Excel Sheet"
                    value={directReason}
                    onChange={(e) => setDirectReason(e.target.value)}
                  />
                </div>
              </div>

              <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', paddingTop: '14px', marginTop: '16px' }}>
                <button type="button" onClick={() => setDirectEditEntry(null)} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" disabled={directSaving} className="btn btn-primary">
                  <Save size={15} />
                  <span>{directSaving ? 'Saving...' : 'Save & Lock Net Payable'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Generate Net Payable Modal */}
      {isGenerateModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '540px' }}>
            <div className="modal-header" style={{ borderBottom: '1px solid #e2e8f0', paddingBottom: '12px' }}>
              <div>
                <h3 style={{ fontSize: '16px', fontWeight: 800, color: '#0f172a', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <Zap size={18} color="#d97706" />
                  <span>Generate & Calculate Net Payable Salary</span>
                </h3>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>
                  Cycle: {period.month_name} {period.year} • Total Days: {period.total_days || 30}
                </div>
              </div>
              <button onClick={() => setIsGenerateModalOpen(false)} style={{ color: '#64748b' }}><X size={20} /></button>
            </div>

            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '16px', paddingTop: '16px' }}>
              {/* Scope Selection */}
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label" style={{ fontWeight: 700 }}>Calculation Scope</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px', border: generateScope === 'all' ? '2px solid #2563eb' : '1px solid #e2e8f0', borderRadius: '6px', background: generateScope === 'all' ? '#eff6ff' : '#fff', cursor: 'pointer' }}>
                    <input
                      type="radio"
                      name="calcScope"
                      checked={generateScope === 'all'}
                      onChange={() => setGenerateScope('all')}
                    />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '13px', color: '#1e293b' }}>All Employees</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Process entire {period.month_name} workforce ({entries.length})</div>
                    </div>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px', border: generateScope === 'selected' ? '2px solid #2563eb' : '1px solid #e2e8f0', borderRadius: '6px', background: generateScope === 'selected' ? '#eff6ff' : '#fff', cursor: 'pointer' }}>
                    <input
                      type="radio"
                      name="calcScope"
                      checked={generateScope === 'selected'}
                      onChange={() => setGenerateScope('selected')}
                      disabled={selectedEntryIds.length === 0}
                    />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '13px', color: '#1e293b' }}>Selected Rows ({selectedEntryIds.length})</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Only process checked rows in table</div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Mode Selection */}
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label" style={{ fontWeight: 700 }}>Calculation Mode</label>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', padding: '10px', border: generateMode === 'formula' ? '2px solid #2563eb' : '1px solid #e2e8f0', borderRadius: '6px', background: generateMode === 'formula' ? '#eff6ff' : '#fff', cursor: 'pointer' }}>
                    <input
                      type="radio"
                      name="calcMode"
                      style={{ marginTop: '2px' }}
                      checked={generateMode === 'formula'}
                      onChange={() => setGenerateMode('formula')}
                    />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '13px', color: '#1e293b' }}>Statutory Calculation Engine (Recommended)</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>
                        Calculates Basic, Allowances, EPF (12%), ESI (0.75%), LWF, and Net Payable using GGSSTP formulas.
                      </div>
                    </div>
                  </label>

                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', padding: '10px', border: generateMode === 'adopt_excel' ? '2px solid #059669' : '1px solid #e2e8f0', borderRadius: '6px', background: generateMode === 'adopt_excel' ? '#ecfdf5' : '#fff', cursor: 'pointer' }}>
                    <input
                      type="radio"
                      name="calcMode"
                      style={{ marginTop: '2px' }}
                      checked={generateMode === 'adopt_excel'}
                      onChange={() => setGenerateMode('adopt_excel')}
                    />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: '13px', color: '#065f46' }}>Adopt Net Payable Directly from Uploaded Excel Sheet</div>
                      <div style={{ fontSize: '11px', color: '#047857' }}>
                        Locks Net Payable exactly to the uploaded Excel Sheet figures down to exact rupees and paise.
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Rounding Options if formula mode */}
              {generateMode === 'formula' && (
                <div className="form-group" style={{ margin: 0, background: '#f8fafc', padding: '12px', borderRadius: '6px', border: '1px solid #e2e8f0' }}>
                  <label className="form-label" style={{ fontWeight: 700, color: '#1e293b' }}>
                    Net Payable Rounding Rule (Statutory EPF, ESI & LWF)
                  </label>
                  <select
                    className="form-input"
                    value={generateRounding}
                    onChange={(e) => setGenerateRounding(e.target.value as any)}
                  >
                    <option value="round_50_up">
                      Round to Nearest Rupee (≥ 0.50 rounds up) [Recommended / GGSSTP Rule]
                    </option>
                    <option value="exact">
                      Exact Decimals (Preserve paise e.g. ₹4,639.50)
                    </option>
                    <option value="floor">
                      Floor (Round down to nearest rupee)
                    </option>
                    <option value="ceil">
                      Ceil (Round up to nearest rupee)
                    </option>
                  </select>
                  <div style={{ fontSize: '11px', color: '#64748b', marginTop: '4px' }}>
                    Statutory contributions EPF (12%), ESI (0.75%), and LWF (₹5) use standard Indian statutory rounding.
                  </div>
                </div>
              )}
            </div>

            <div className="modal-footer" style={{ borderTop: '1px solid #e2e8f0', paddingTop: '14px', marginTop: '16px' }}>
              <button type="button" onClick={() => setIsGenerateModalOpen(false)} className="btn btn-secondary">
                Cancel
              </button>
              <button
                type="button"
                disabled={generatingSalaries}
                onClick={handleExecuteGenerate}
                className="btn btn-primary"
                style={{ background: '#d97706', borderColor: '#d97706' }}
              >
                <Zap size={15} />
                <span>{generatingSalaries ? 'Calculating & Updating...' : 'Generate Net Payable'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PayrollView;
