import React, { useState, useEffect } from 'react';
import { apiRequest, setToken } from '../api';
import { ShieldCheck, Plus, UserX, UserCheck, X, Edit3, Trash2, AlertTriangle, CheckCircle2, Key } from 'lucide-react';

interface UserAccount {
  id: number;
  username: string;
  full_name: string;
  role: string;
  is_active: boolean;
  created_at: string;
  updated_at?: string;
}

export const UserView: React.FC = () => {
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [loading, setLoading] = useState(true);

  // Add User Modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Payroll Operator');

  // Edit User Modal
  const [editUser, setEditUser] = useState<UserAccount | null>(null);
  const [editUsername, setEditUsername] = useState('');
  const [editFullName, setEditFullName] = useState('');
  const [editRole, setEditRole] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editIsActive, setEditIsActive] = useState(true);

  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const res = await apiRequest<{ users: UserAccount[] }>('/users');
      setUsers(res.users);
    } catch (err: any) {
      showNotification('error', `Error fetching users: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiRequest('/users', {
        method: 'POST',
        body: JSON.stringify({ username, fullName, password, role })
      });
      setIsAddOpen(false);
      setUsername('');
      setFullName('');
      setPassword('');
      fetchUsers();
      showNotification('success', `User account "${username}" created successfully.`);
    } catch (err: any) {
      showNotification('error', `Failed to create user: ${err.message}`);
    }
  };

  const handleStartEdit = (u: UserAccount) => {
    setEditUser(u);
    setEditUsername(u.username);
    setEditFullName(u.full_name);
    setEditRole(u.role);
    setEditPassword('');
    setEditIsActive(u.is_active);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editUser) return;
    try {
      const res = await apiRequest<{ user: UserAccount; token?: string }>(`/users/${editUser.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          username: editUsername,
          fullName: editFullName,
          role: editRole,
          isActive: editIsActive,
          password: editPassword.trim() ? editPassword.trim() : undefined
        })
      });
      if (res.token) {
        setToken(res.token);
      }
      setEditUser(null);
      await fetchUsers();
      showNotification('success', `User "${editUsername}" updated successfully in database.`);
    } catch (err: any) {
      showNotification('error', `Failed to update user: ${err.message}`);
    }
  };

  const handleDeleteUser = async (u: UserAccount) => {
    if (!window.confirm(`Are you sure you want to permanently delete user "${u.username}" (${u.full_name})?\n\nThis action cannot be undone.`)) {
      return;
    }

    try {
      await apiRequest(`/users/${u.id}`, {
        method: 'DELETE'
      });
      fetchUsers();
      showNotification('success', `User "${u.username}" deleted successfully.`);
    } catch (err: any) {
      showNotification('error', `Failed to delete user: ${err.message}`);
    }
  };

  const handleToggleUser = async (u: UserAccount) => {
    try {
      await apiRequest(`/users/${u.id}`, {
        method: 'PUT',
        body: JSON.stringify({ isActive: !u.is_active })
      });
      fetchUsers();
      showNotification('success', `User "${u.username}" status toggled.`);
    } catch (err: any) {
      showNotification('error', `Update failed: ${err.message}`);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Toast Notification */}
      {notification && (
        <div style={{
          padding: '12px 18px',
          borderRadius: '8px',
          fontSize: '13px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          background: notification.type === 'success' ? '#ecfdf5' : '#fef2f2',
          border: `1px solid ${notification.type === 'success' ? '#a7f3d0' : '#fecaca'}`,
          color: notification.type === 'success' ? '#065f46' : '#991b1b'
        }}>
          {notification.type === 'success' ? <CheckCircle2 size={18} color="#059669" /> : <AlertTriangle size={18} color="#dc2626" />}
          <span style={{ fontWeight: 600 }}>{notification.message}</span>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>System User & Role Management</h2>
          <p style={{ fontSize: '12.5px', color: '#64748b' }}>Configure authorized operators, approvers, and payroll administrators</p>
        </div>
        <button onClick={() => setIsAddOpen(true)} className="btn btn-primary btn-sm">
          <Plus size={15} />
          <span>Add User Account</span>
        </button>
      </div>

      <div className="table-container">
        <table className="custom-table">
          <thead>
            <tr>
              <th>Username</th>
              <th>Full Name</th>
              <th>Assigned Role</th>
              <th>Status</th>
              <th>Created On</th>
              <th style={{ textAlign: 'center' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={6} style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>Loading users...</td>
              </tr>
            ) : users.map(u => (
              <tr key={u.id}>
                <td style={{ fontWeight: 700, fontFamily: 'monospace', color: '#1e3a8a' }}>{u.username}</td>
                <td style={{ fontWeight: 600 }}>{u.full_name}</td>
                <td>
                  <span className="badge" style={{ background: '#f1f5f9', color: '#1e293b', border: '1px solid #cbd5e1' }}>
                    {u.role}
                  </span>
                </td>
                <td>
                  {u.is_active ? <span className="badge badge-active">Active</span> : <span className="badge badge-inactive">Deactivated</span>}
                </td>
                <td style={{ fontSize: '12px', color: '#64748b' }}>
                  {new Date(u.created_at).toLocaleDateString()}
                </td>
                <td style={{ textAlign: 'center' }}>
                  <div style={{ display: 'inline-flex', gap: '6px' }}>
                    <button
                      onClick={() => handleStartEdit(u)}
                      className="btn btn-secondary btn-sm"
                      title="Edit User Details & Role"
                    >
                      <Edit3 size={13} />
                      <span>Edit</span>
                    </button>
                    <button
                      onClick={() => handleToggleUser(u)}
                      className={`btn ${u.is_active ? 'btn-secondary' : 'btn-success'} btn-sm`}
                      title={u.is_active ? 'Deactivate User' : 'Activate User'}
                    >
                      {u.is_active ? <UserX size={13} /> : <UserCheck size={13} />}
                    </button>
                    <button
                      onClick={() => handleDeleteUser(u)}
                      className="btn btn-danger btn-sm"
                      title="Permanently Delete User"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add User Modal */}
      {isAddOpen && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '480px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Add System User Account</h3>
              <button onClick={() => setIsAddOpen(false)}><X size={20} /></button>
            </div>
            <form onSubmit={handleCreateUser}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Username *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Initial Password *</label>
                  <input
                    type="password"
                    required
                    className="form-input"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Role Designation</label>
                  <select
                    className="form-input"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                  >
                    <option value="Super Administrator">Super Administrator</option>
                    <option value="Payroll Administrator">Payroll Administrator</option>
                    <option value="Payroll Operator">Payroll Operator</option>
                    <option value="Approver / Auditor">Approver / Auditor</option>
                    <option value="Read-Only User">Read-Only User</option>
                  </select>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setIsAddOpen(false)} className="btn btn-secondary">Cancel</button>
                <button type="submit" className="btn btn-primary">Create User</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editUser && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '480px' }}>
            <div className="modal-header">
              <h3 style={{ fontSize: '16px', fontWeight: 700 }}>Edit User: {editUser.username}</h3>
              <button onClick={() => setEditUser(null)}><X size={20} /></button>
            </div>
            <form onSubmit={handleSaveEdit}>
              <div className="modal-body">
                <div className="form-group">
                  <label className="form-label">Username *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    value={editUsername}
                    onChange={(e) => setEditUsername(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input
                    type="text"
                    required
                    className="form-input"
                    value={editFullName}
                    onChange={(e) => setEditFullName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Assigned Role</label>
                  <select
                    className="form-input"
                    value={editRole}
                    onChange={(e) => setEditRole(e.target.value)}
                  >
                    <option value="Super Administrator">Super Administrator</option>
                    <option value="Payroll Administrator">Payroll Administrator</option>
                    <option value="Payroll Operator">Payroll Operator</option>
                    <option value="Approver / Auditor">Approver / Auditor</option>
                    <option value="Read-Only User">Read-Only User</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Account Status</label>
                  <select
                    className="form-input"
                    value={editIsActive ? 'true' : 'false'}
                    onChange={(e) => setEditIsActive(e.target.value === 'true')}
                  >
                    <option value="true">Active Account</option>
                    <option value="false">Deactivated Account</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Reset Password (leave empty to keep unchanged)</label>
                  <div style={{ position: 'relative' }}>
                    <input
                      type="password"
                      className="form-input"
                      placeholder="Enter new password or leave blank"
                      value={editPassword}
                      onChange={(e) => setEditPassword(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" onClick={() => setEditUser(null)} className="btn btn-secondary">Cancel</button>
                <button type="submit" className="btn btn-primary">Save User Changes</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserView;
