import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, User } from '../types';
import { apiRequest } from '../api';
import {
  X, Send, Paperclip, FileSpreadsheet, FileText, Image as ImageIcon,
  Download, Users, Shield, Clock, CheckCircle2, AlertCircle, File, Sparkles
} from 'lucide-react';

interface TeamChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
}

export const TeamChatModal: React.FC<TeamChatModalProps> = ({
  isOpen,
  onClose,
  currentUser
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [sending, setSending] = useState(false);
  const [plantUsers, setPlantUsers] = useState<any[]>([]);
  const [isDragging, setIsDragging] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Fetch messages from backend
  const fetchMessages = async () => {
    try {
      const res = await apiRequest<{ messages: ChatMessage[] }>('/chat/messages');
      setMessages(res.messages || []);
    } catch (err) {
      console.error('Failed to fetch chat messages:', err);
    }
  };

  // Fetch plant personnel
  const fetchUsers = async () => {
    try {
      const res = await apiRequest<{ users: any[] }>('/chat/users');
      setPlantUsers(res.users || []);
    } catch (err) {
      console.error('Failed to fetch chat users:', err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchMessages();
      fetchUsers();
      const interval = setInterval(fetchMessages, 3500); // Poll every 3.5 seconds
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  // Handle Send Message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !selectedFile) return;

    try {
      setSending(true);
      const formData = new FormData();
      if (inputText.trim()) {
        formData.append('message', inputText.trim());
      }
      if (selectedFile) {
        formData.append('file', selectedFile);
      }

      const token = localStorage.getItem('token');
      const response = await fetch('/api/chat/messages', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to send message');
      }

      setInputText('');
      setSelectedFile(null);
      await fetchMessages();
    } catch (err: any) {
      alert(`Could not send message: ${err.message}`);
    } finally {
      setSending(false);
    }
  };

  // Handle Drag and Drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const formatFileSize = (bytes?: number | null) => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  // Determine icon for file
  const renderFileIcon = (fileName?: string | null) => {
    const name = (fileName || '').toLowerCase();
    if (name.endsWith('.xlsx') || name.endsWith('.xls') || name.endsWith('.csv')) {
      return <FileSpreadsheet size={22} color="#059669" />;
    }
    if (name.endsWith('.pdf')) {
      return <FileText size={22} color="#dc2626" />;
    }
    if (name.endsWith('.png') || name.endsWith('.jpg') || name.endsWith('.jpeg')) {
      return <ImageIcon size={22} color="#2563eb" />;
    }
    return <File size={22} color="#64748b" />;
  };

  return (
    <div className="modal-overlay" style={{ background: 'rgba(15, 23, 42, 0.75)', zIndex: 100 }}>
      <div
        className="modal-content"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        style={{
          maxWidth: '720px',
          height: '85vh',
          display: 'flex',
          flexDirection: 'column',
          borderRadius: '16px',
          boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.5)',
          overflow: 'hidden',
          background: '#ffffff',
          position: 'relative'
        }}
      >
        {/* Drag Overlay Notice */}
        {isDragging && (
          <div
            style={{
              position: 'absolute',
              inset: 0,
              background: 'rgba(30, 58, 138, 0.85)',
              zIndex: 50,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#ffffff',
              gap: '12px'
            }}
          >
            <Paperclip size={48} />
            <div style={{ fontSize: '18px', fontWeight: 800 }}>Drop File Here to Share with Plant Team</div>
            <div style={{ fontSize: '13px', color: '#93c5fd' }}>Share Excel salary sheets, reports, PDFs or circulars</div>
          </div>
        )}

        {/* Modal Header */}
        <div
          style={{
            background: 'linear-gradient(135deg, #1e3a8a 0%, #0f172a 100%)',
            color: '#ffffff',
            padding: '16px 22px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div
              style={{
                width: '40px',
                height: '40px',
                background: 'linear-gradient(135deg, #d97706 0%, #f59e0b 100%)',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#0f172a'
              }}
            >
              <Users size={20} />
            </div>
            <div>
              <div style={{ fontSize: '16px', fontWeight: 800, letterSpacing: '0.3px' }}>
                Plant Personnel Team Chat & File Sharing
              </div>
              <div style={{ fontSize: '11.5px', color: '#93c5fd', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <span style={{ width: '7px', height: '7px', background: '#10b981', borderRadius: '50%', display: 'inline-block' }} />
                <span>GGSSTP Enterprise Channel • {plantUsers.length} Authorized Personnel</span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="btn btn-secondary btn-sm"
            style={{
              background: 'rgba(255, 255, 255, 0.15)',
              border: 'none',
              color: '#ffffff',
              borderRadius: '50%',
              width: '32px',
              height: '32px',
              padding: 0
            }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Personnel Quick Bar */}
        <div
          style={{
            background: '#f8fafc',
            borderBottom: '1px solid #e2e8f0',
            padding: '8px 18px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            overflowX: 'auto',
            fontSize: '11px',
            color: '#64748b'
          }}
        >
          <span style={{ fontWeight: 700, color: '#334155', textTransform: 'uppercase' }}>Plant Roles:</span>
          {plantUsers.map((u, i) => (
            <span
              key={i}
              style={{
                background: '#ffffff',
                border: '1px solid #cbd5e1',
                padding: '2px 8px',
                borderRadius: '999px',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                whiteSpace: 'nowrap'
              }}
            >
              <span style={{ width: '5px', height: '5px', background: '#059669', borderRadius: '50%' }} />
              <strong>{u.full_name || u.username}</strong> ({u.role})
            </span>
          ))}
        </div>

        {/* Messages Feed */}
        <div
          style={{
            flex: 1,
            padding: '18px 20px',
            overflowY: 'auto',
            display: 'flex',
            flexDirection: 'column',
            gap: '14px',
            background: '#f1f5f9'
          }}
        >
          {messages.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '50px 20px', color: '#64748b' }}>
              <div style={{ display: 'inline-flex', padding: '16px', background: '#e2e8f0', borderRadius: '50%', marginBottom: '12px' }}>
                <Users size={30} color="#1e3a8a" />
              </div>
              <div style={{ fontSize: '15px', fontWeight: 700, color: '#0f172a' }}>No Messages in Plant Channel Yet</div>
              <p style={{ fontSize: '12.5px', marginTop: '4px' }}>
                Start communication or share salary sheets, circulars, or verification queries below.
              </p>
            </div>
          ) : (
            messages.map((msg) => {
              const isSelf = msg.user_name === currentUser.fullName || msg.user_name === currentUser.username;
              return (
                <div
                  key={msg.id}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: isSelf ? 'flex-end' : 'flex-start',
                    maxWidth: '100%'
                  }}
                >
                  {/* Sender Header */}
                  <div
                    style={{
                      fontSize: '11px',
                      color: '#64748b',
                      marginBottom: '3px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  >
                    <span style={{ fontWeight: 700, color: isSelf ? '#1e3a8a' : '#0f172a' }}>
                      {msg.user_name}
                    </span>
                    <span
                      style={{
                        fontSize: '9.5px',
                        background: isSelf ? '#dbeafe' : '#e2e8f0',
                        color: isSelf ? '#1e40af' : '#475569',
                        padding: '1px 5px',
                        borderRadius: '4px',
                        fontWeight: 600
                      }}
                    >
                      {msg.user_role}
                    </span>
                    <span>{formatTime(msg.created_at)}</span>
                  </div>

                  {/* Message Bubble */}
                  <div
                    style={{
                      maxWidth: '75%',
                      background: isSelf ? '#1e3a8a' : '#ffffff',
                      color: isSelf ? '#ffffff' : '#0f172a',
                      borderRadius: isSelf ? '14px 14px 2px 14px' : '14px 14px 14px 2px',
                      padding: '10px 14px',
                      boxShadow: '0 2px 5px rgba(0,0,0,0.06)',
                      fontSize: '13.5px',
                      lineHeight: '1.45',
                      border: isSelf ? 'none' : '1px solid #e2e8f0'
                    }}
                  >
                    {msg.message && <div style={{ wordBreak: 'break-word' }}>{msg.message}</div>}

                    {/* Shared File Attachment Box */}
                    {msg.file_url && (
                      <div
                        style={{
                          marginTop: msg.message ? '10px' : '0',
                          background: isSelf ? 'rgba(255, 255, 255, 0.12)' : '#f8fafc',
                          border: isSelf ? '1px solid rgba(255, 255, 255, 0.25)' : '1px solid #cbd5e1',
                          borderRadius: '8px',
                          padding: '8px 12px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: '10px'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', overflow: 'hidden' }}>
                          {renderFileIcon(msg.file_name)}
                          <div style={{ overflow: 'hidden' }}>
                            <div
                              style={{
                                fontSize: '12px',
                                fontWeight: 700,
                                whiteSpace: 'nowrap',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                maxWidth: '200px',
                                color: isSelf ? '#ffffff' : '#0f172a'
                              }}
                              title={msg.file_name || ''}
                            >
                              {msg.file_name}
                            </div>
                            <div style={{ fontSize: '10.5px', color: isSelf ? '#bfdbfe' : '#64748b' }}>
                              {formatFileSize(msg.file_size)}
                            </div>
                          </div>
                        </div>

                        <a
                          href={msg.file_url}
                          download={msg.file_name || 'download'}
                          className="btn btn-secondary btn-sm"
                          style={{
                            padding: '4px 8px',
                            fontSize: '11px',
                            background: isSelf ? '#ffffff' : '#1e3a8a',
                            color: isSelf ? '#1e3a8a' : '#ffffff',
                            border: 'none',
                            fontWeight: 700,
                            display: 'inline-flex',
                            gap: '4px'
                          }}
                        >
                          <Download size={12} />
                          <span>Download</span>
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Selected Attachment Preview Banner */}
        {selectedFile && (
          <div
            style={{
              background: '#ecfdf5',
              borderTop: '1px solid #a7f3d0',
              padding: '8px 18px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              fontSize: '12px',
              color: '#065f46'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Paperclip size={14} color="#059669" />
              <span>Ready to send: <strong>{selectedFile.name}</strong> ({formatFileSize(selectedFile.size)})</span>
            </div>
            <button
              onClick={() => setSelectedFile(null)}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                color: '#b91c1c',
                fontSize: '12px',
                fontWeight: 700
              }}
            >
              Remove
            </button>
          </div>
        )}

        {/* Footer Input Form */}
        <form
          onSubmit={handleSendMessage}
          style={{
            background: '#ffffff',
            borderTop: '1px solid #e2e8f0',
            padding: '12px 18px',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}
        >
          {/* File Picker Trigger */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                setSelectedFile(e.target.files[0]);
              }
            }}
            style={{ display: 'none' }}
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="Attach Excel Sheet, PDF, or Document"
            className="btn btn-secondary"
            style={{
              padding: '9px 12px',
              borderRadius: '8px',
              border: '1px solid #cbd5e1'
            }}
          >
            <Paperclip size={16} color="#1e3a8a" />
          </button>

          {/* Message Text Input */}
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type message or attach a salary sheet to share..."
            className="form-input"
            style={{
              flex: 1,
              padding: '9px 14px',
              fontSize: '13.5px',
              borderRadius: '8px',
              border: '1px solid #cbd5e1'
            }}
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={sending || (!inputText.trim() && !selectedFile)}
            className="btn btn-primary"
            style={{
              padding: '9px 16px',
              borderRadius: '8px',
              fontWeight: 700,
              background: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)',
              border: 'none',
              display: 'inline-flex',
              gap: '6px'
            }}
          >
            <Send size={15} />
            <span>{sending ? 'Sending...' : 'Send'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
