import React, { useState } from 'react';
import { apiRequest, setToken } from '../api';
import { User } from '../types';
import { Zap, Shield, Lock, User as UserIcon, Eye, EyeOff, ShieldCheck, Info } from 'lucide-react';

interface LoginModalProps {
  onSuccess: (user: User) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onSuccess }) => {
  // Username and password kept completely blank by default
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [roleInfoNotice, setRoleInfoNotice] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setError('Please enter both your Username and Password.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await apiRequest<{ token: string; user: User }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username: username.trim(), password })
      });
      setToken(res.token);
      onSuccess(res.user);
    } catch (err: any) {
      setError(err.message || 'Invalid username or password. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Roles permitted to login - clicking provides role clarification only, NEVER populates credentials
  const authorizedRoles = [
    { title: 'Super Administrator', desc: 'Full System Control & Circle Config', badge: 'Tier 1' },
    { title: 'Payroll Administrator', desc: 'Salary Sheet, Rates & Approvals', badge: 'Tier 2' },
    { title: 'Circle / Agency Operator', desc: 'EMC/MM-1 Circles & Contractor Entry', badge: 'Tier 3' },
    { title: 'Accounts & Audit Officer', desc: 'Statutory Verification & Audit Trail', badge: 'Tier 4' }
  ];

  const handleRoleCardClick = (roleTitle: string) => {
    // Informational only: Do NOT enter username or password
    setRoleInfoNotice(`Role: ${roleTitle}. Please enter your assigned official credentials above.`);
    setTimeout(() => setRoleInfoNotice(null), 4000);
  };

  return (
    <div
      className="modal-overlay"
      style={{
        background: 'radial-gradient(circle at 50% 20%, #1e293b 0%, #0f172a 55%, #020617 100%)',
        padding: '24px 16px',
        overflowY: 'auto'
      }}
    >
      <div
        className="modal-content"
        style={{
          maxWidth: '460px',
          borderRadius: '16px',
          boxShadow: '0 25px 60px -15px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.08)',
          background: '#ffffff',
          overflow: 'hidden',
          animation: 'fadeIn 0.2s ease-out'
        }}
      >
        {/* Plant Header Branding */}
        <div
          style={{
            background: 'linear-gradient(135deg, #1e3a8a 0%, #0f172a 100%)',
            padding: '28px 24px 22px 24px',
            textAlign: 'center',
            color: '#ffffff',
            position: 'relative'
          }}
        >
          {/* Emblem Icon */}
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: '54px',
              height: '54px',
              background: 'linear-gradient(135deg, #d97706 0%, #f59e0b 100%)',
              borderRadius: '50%',
              marginBottom: '12px',
              boxShadow: '0 4px 14px rgba(245, 158, 11, 0.4), inset 0 1px 1px rgba(255, 255, 255, 0.4)'
            }}
          >
            <Zap size={28} color="#0f172a" fill="#0f172a" />
          </div>

          <h1
            style={{
              fontSize: '17px',
              fontWeight: 800,
              letterSpacing: '0.6px',
              margin: '0 0 4px 0',
              textTransform: 'uppercase',
              color: '#ffffff'
            }}
          >
            GGSSTP PAYROLL PORTAL
          </h1>

          <div
            style={{
              fontSize: '12.5px',
              fontWeight: 500,
              color: '#93c5fd',
              letterSpacing: '0.2px'
            }}
          >
            Guru Gobind Singh Super Thermal Plant
          </div>

          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '6px',
              marginTop: '10px',
              background: 'rgba(255, 255, 255, 0.1)',
              padding: '3px 10px',
              borderRadius: '9999px',
              fontSize: '11px',
              color: '#e2e8f0'
            }}
          >
            <ShieldCheck size={12} color="#10b981" />
            <span>PSPCL Rupnagar • Contractual Labour Management</span>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div
            style={{
              margin: '16px 20px 0 20px',
              background: '#fef2f2',
              border: '1px solid #fecaca',
              color: '#b91c1c',
              padding: '11px 14px',
              borderRadius: '8px',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            <Info size={16} style={{ flexShrink: 0 }} />
            <span>{error}</span>
          </div>
        )}

        {/* Role Notice Tooltip/Info */}
        {roleInfoNotice && (
          <div
            style={{
              margin: '16px 20px 0 20px',
              background: '#eff6ff',
              border: '1px solid #bfdbfe',
              color: '#1e3a8a',
              padding: '10px 14px',
              borderRadius: '8px',
              fontSize: '12.5px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}
          >
            <Info size={15} style={{ flexShrink: 0 }} />
            <span>{roleInfoNotice}</span>
          </div>
        )}

        {/* Main Authentication Form */}
        <form onSubmit={handleLogin} style={{ padding: '20px 24px 22px 24px' }}>
          {/* Username Field */}
          <div className="form-group" style={{ marginBottom: '16px' }}>
            <label
              className="form-label"
              htmlFor="ggsstp-username"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '7px',
                fontSize: '13px',
                fontWeight: 600,
                color: '#334155',
                marginBottom: '6px'
              }}
            >
              <UserIcon size={15} color="#1e3a8a" />
              <span>Username or Employee ID</span>
            </label>
            <div style={{ position: 'relative' }}>
              <input
                id="ggsstp-username"
                type="text"
                required
                autoComplete="username"
                className="form-input"
                placeholder="Enter your Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                style={{
                  width: '100%',
                  padding: '10px 14px',
                  fontSize: '13.5px',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  background: '#f8fafc',
                  outline: 'none',
                  transition: 'border-color 0.15s, background-color 0.15s'
                }}
              />
            </div>
          </div>

          {/* Password Field with Show/Hide Eye Toggle */}
          <div className="form-group" style={{ marginBottom: '20px' }}>
            <label
              className="form-label"
              htmlFor="ggsstp-password"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '7px',
                fontSize: '13px',
                fontWeight: 600,
                color: '#334155',
                marginBottom: '6px'
              }}
            >
              <Lock size={15} color="#1e3a8a" />
              <span>Password</span>
            </label>
            <div style={{ position: 'relative' }}>
              <input
                id="ggsstp-password"
                type={showPassword ? 'text' : 'password'}
                required
                autoComplete="current-password"
                className="form-input"
                placeholder="Enter your Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{
                  width: '100%',
                  padding: '10px 44px 10px 14px', // Space on right for the eye toggle
                  fontSize: '13.5px',
                  borderRadius: '8px',
                  border: '1px solid #cbd5e1',
                  background: '#f8fafc',
                  outline: 'none',
                  transition: 'border-color 0.15s, background-color 0.15s'
                }}
              />
              {/* Show / Hide Password Button */}
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                tabIndex={-1}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                title={showPassword ? 'Hide password' : 'Show password'}
                style={{
                  position: 'absolute',
                  right: '10px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'none',
                  border: 'none',
                  padding: '6px',
                  cursor: 'pointer',
                  color: showPassword ? '#1e3a8a' : '#64748b',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderRadius: '6px',
                  transition: 'color 0.15s'
                }}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {/* Submit Sign In Button */}
          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary"
            style={{
              width: '100%',
              padding: '11px 16px',
              fontSize: '14px',
              fontWeight: 700,
              borderRadius: '8px',
              background: loading ? '#64748b' : 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%)',
              boxShadow: '0 4px 12px rgba(30, 58, 138, 0.25)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px',
              border: 'none',
              color: '#ffffff',
              cursor: loading ? 'not-allowed' : 'pointer'
            }}
          >
            {loading ? (
              <span>Authenticating Personnel...</span>
            ) : (
              <>
                <Shield size={16} />
                <span>Sign In to Plant Portal</span>
              </>
            )}
          </button>

          {/* Quick Login Roles Information (Reference only - DOES NOT fill or modify credentials) */}
          <div
            style={{
              marginTop: '22px',
              borderTop: '1px solid #f1f5f9',
              paddingTop: '16px'
            }}
          >
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: '10px'
              }}
            >
              <div
                style={{
                  fontSize: '11px',
                  color: '#475569',
                  fontWeight: 700,
                  textTransform: 'uppercase',
                  letterSpacing: '0.6px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '5px'
                }}
              >
                <Shield size={12} color="#1e3a8a" />
                <span>Authorized Plant Access Roles</span>
              </div>
              <span
                style={{
                  fontSize: '10px',
                  background: '#f1f5f9',
                  color: '#64748b',
                  padding: '2px 6px',
                  borderRadius: '4px',
                  fontWeight: 600
                }}
              >
                Who Can Log In
              </span>
            </div>

            {/* Informational Cards for Permitted Roles */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(2, 1fr)',
                gap: '8px'
              }}
            >
              {authorizedRoles.map((role) => (
                <div
                  key={role.title}
                  onClick={() => handleRoleCardClick(role.title)}
                  title={`Authorized Role: ${role.title}. Enter your personal username & password above.`}
                  style={{
                    background: '#f8fafc',
                    border: '1px solid #e2e8f0',
                    borderRadius: '8px',
                    padding: '8px 10px',
                    cursor: 'pointer',
                    transition: 'all 0.15s ease',
                    textAlign: 'left'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#f1f5f9';
                    e.currentTarget.style.borderColor = '#cbd5e1';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = '#f8fafc';
                    e.currentTarget.style.borderColor = '#e2e8f0';
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginBottom: '2px'
                    }}
                  >
                    <span
                      style={{
                        fontSize: '11.5px',
                        fontWeight: 700,
                        color: '#0f172a'
                      }}
                    >
                      {role.title}
                    </span>
                    <span
                      style={{
                        fontSize: '9.5px',
                        background: '#e0f2fe',
                        color: '#0369a1',
                        padding: '1px 5px',
                        borderRadius: '4px',
                        fontWeight: 600
                      }}
                    >
                      {role.badge}
                    </span>
                  </div>
                  <div
                    style={{
                      fontSize: '10.5px',
                      color: '#64748b',
                      lineHeight: '1.25'
                    }}
                  >
                    {role.desc}
                  </div>
                </div>
              ))}
            </div>

            <div
              style={{
                marginTop: '10px',
                textAlign: 'center',
                fontSize: '11px',
                color: '#94a3b8',
                fontStyle: 'italic'
              }}
            >
              Self-service security: Credentials are not pre-filled. Enter your allocated plant ID & password.
            </div>
          </div>
        </form>

        {/* Security & Regulatory Footer */}
        <div
          style={{
            background: '#f8fafc',
            borderTop: '1px solid #e2e8f0',
            padding: '12px 20px',
            textAlign: 'center',
            fontSize: '11px',
            color: '#64748b',
            display: 'flex',
            flexDirection: 'column',
            gap: '4px',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Lock size={12} color="#059669" />
            <span style={{ fontWeight: 600, color: '#334155' }}>
              Restricted Portal • PSPCL IT Security & Compliance Protected
            </span>
          </div>
          <div style={{ color: '#475569', fontWeight: 600, fontSize: '11px' }}>
            © 2026 Punjab State Power Corporation Limited PSEB Head Office, The MALL, Patiala
          </div>
          <div style={{ color: '#94a3b8', fontSize: '10.5px' }}>
            Site Last Updated: October 11, 2026 • Guru Gobind Singh Super Thermal Plant, Rupnagar
          </div>
        </div>
      </div>
    </div>
  );
};
