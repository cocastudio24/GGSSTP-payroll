import React, { useState, useEffect } from 'react';
import { PayrollRuleSet } from '../types';
import { apiRequest } from '../api';
import { Calculator, Save, RotateCcw, ShieldCheck, CheckCircle2, Play } from 'lucide-react';

interface FormulaRulesViewProps {
  onRefreshAll?: () => void;
}

export const FormulaRulesView: React.FC<FormulaRulesViewProps> = ({ onRefreshAll }) => {
  const [rules, setRules] = useState<PayrollRuleSet[]>([]);
  const [activeRule, setActiveRule] = useState<PayrollRuleSet | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  // Live Formula Simulator State
  const [simDays, setSimDays] = useState(30);
  const [simPresent, setSimPresent] = useState(7);
  const [simGrossRate, setSimGrossRate] = useState(16530); // SW
  const [simSpecial, setSimSpecial] = useState(3802);
  const [simPerfMonthly, setSimPerfMonthly] = useState(225);

  const fetchRules = async () => {
    try {
      setLoading(true);
      const res = await apiRequest<{ rules: PayrollRuleSet[] }>('/payroll/rules');
      setRules(res.rules);
      const active = res.rules.find(r => r.is_active) || res.rules[0] || null;
      setActiveRule(active ? { ...active } : null);
    } catch (err: any) {
      alert(`Error loading formula rules: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRules();
  }, []);

  const handleSaveRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRule) return;

    try {
      setSaving(true);
      setSaveSuccess(null);
      const res = await apiRequest<{ rule: PayrollRuleSet }>(`/payroll/rules/${activeRule.id}`, {
        method: 'PUT',
        body: JSON.stringify(activeRule)
      });
      setActiveRule(res.rule);
      setSaveSuccess('Formula rules and statutory deduction percentages updated successfully!');
      if (onRefreshAll) onRefreshAll();
    } catch (err: any) {
      alert(`Failed to save rules: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleResetReference = async () => {
    if (!activeRule) return;
    if (!window.confirm('Reset all formulas and percentages back to official GGSSTP September 2026 reference standards?')) return;

    const resetValues: Partial<PayrollRuleSet> = {
      name: 'GGSSTP Reference Rule Set (Sep 2026)',
      epf_wage_cap: 25000,
      epf_employer_rate: 0.12,
      epf_max_cap: 3000,
      epf_admin_rate: 0.01,
      epf_admin_max_cap: 250,
      epf_employee_rate: 0.12,
      esi_threshold: 21000,
      esi_employer_rate: 0.0325,
      esi_employee_rate: 0.0075,
      employer_lwf: 20,
      employee_lwf: 5,
      thermal_allowance_base: 1500
    };

    setActiveRule({
      ...activeRule,
      ...resetValues
    });
  };

  // Run Simulator calculations
  const calculateSim = () => {
    if (!activeRule || simDays <= 0) return null;
    const propSalary = (simGrossRate / simDays) * simPresent;
    const totalBasic = Math.round(((simGrossRate + simSpecial) * simPresent) / simDays);
    const thermal = Math.round((Number(activeRule.thermal_allowance_base) * simPresent) / simDays);
    const perfDays = (simPerfMonthly / simDays) * simPresent;
    const totalEarnings = totalBasic + thermal + perfDays;

    const empEpfRate = Number(activeRule.epf_employee_rate);
    const emplyrEpfRate = Number(activeRule.epf_employer_rate);
    const epfCap = Number(activeRule.epf_wage_cap);
    const epfMax = Number(activeRule.epf_max_cap);

    const empEpf = Math.round(propSalary < epfCap ? propSalary * empEpfRate : epfMax);
    const emplyrEpf = Math.round(propSalary < epfCap ? propSalary * emplyrEpfRate : epfMax);

    const esiThresh = Number(activeRule.esi_threshold);
    const esiEmpRate = Number(activeRule.esi_employee_rate);
    const esiEmplyrRate = Number(activeRule.esi_employer_rate);

    const empEsi = Math.round(totalEarnings < esiThresh ? totalEarnings * esiEmpRate : 0);
    const emplyrEsi = Math.round(totalEarnings < esiThresh ? totalEarnings * esiEmplyrRate : 0);

    const empLwf = Number(activeRule.employee_lwf);
    const emplyrLwf = Number(activeRule.employer_lwf);

    const empDeductions = empEpf + empEsi + empLwf;
    const emplyrCost = emplyrEpf + emplyrEsi + emplyrLwf;
    const netPayable = totalEarnings - empDeductions;

    return {
      propSalary,
      totalBasic,
      thermal,
      totalEarnings,
      empEpf,
      emplyrEpf,
      empEsi,
      emplyrEsi,
      empLwf,
      emplyrLwf,
      empDeductions,
      netPayable
    };
  };

  const simResult = calculateSim();

  if (loading || !activeRule) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '40px' }}>
        <p style={{ color: '#64748b' }}>Loading formula rules engine...</p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#0f172a' }}>Formula & Statutory Deduction Engine</h2>
          <p style={{ fontSize: '12.5px', color: '#64748b' }}>
            Configure calculation formulas, contribution percentages, wage caps, and allowances across the software
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={handleResetReference} type="button" className="btn btn-secondary btn-sm">
            <RotateCcw size={14} />
            <span>Reset to Reference Defaults</span>
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', color: '#065f46', padding: '12px 16px', borderRadius: '8px', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <CheckCircle2 size={18} color="#059669" />
          <span>{saveSuccess}</span>
        </div>
      )}

      {/* Main Formula Rules Editor */}
      <form onSubmit={handleSaveRule}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
          
          {/* EPF Formula Section */}
          <div className="card" style={{ borderTop: '4px solid #1e3a8a' }}>
            <div className="card-header">
              <div className="card-title">
                <Calculator size={18} color="#1e3a8a" />
                <span>EPF Contribution & Deduction Formulas</span>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div className="grid-2">
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Employer EPF Share (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    value={(Number(activeRule.epf_employer_rate) * 100).toFixed(2)}
                    onChange={(e) => setActiveRule({ ...activeRule, epf_employer_rate: Number(e.target.value) / 100 })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: 12.00%</span>
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Employee EPF Deduction (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    value={(Number(activeRule.epf_employee_rate) * 100).toFixed(2)}
                    onChange={(e) => setActiveRule({ ...activeRule, epf_employee_rate: Number(e.target.value) / 100 })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: 12.00%</span>
                </div>
              </div>

              <div className="grid-2">
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">EPF Admin / Inspection Fee (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    value={(Number(activeRule.epf_admin_rate) * 100).toFixed(2)}
                    onChange={(e) => setActiveRule({ ...activeRule, epf_admin_rate: Number(e.target.value) / 100 })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: 1.00%</span>
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">EPF Wage Ceiling Threshold (₹)</label>
                  <input
                    type="number"
                    step="1"
                    className="form-input"
                    value={activeRule.epf_wage_cap}
                    onChange={(e) => setActiveRule({ ...activeRule, epf_wage_cap: Number(e.target.value) })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: ₹25,000 (Max Cap ₹3,000)</span>
                </div>
              </div>

              <div style={{ background: '#f8fafc', padding: '10px 12px', borderRadius: '6px', fontSize: '12px', color: '#475569', border: '1px solid #e2e8f0' }}>
                <strong>Formula:</strong> <code>=ROUND(IF(ProportionedSalary &lt; {activeRule.epf_wage_cap}, ProportionedSalary * {(Number(activeRule.epf_employer_rate) * 100).toFixed(0)}%, {activeRule.epf_max_cap}), 0)</code>
              </div>
            </div>
          </div>

          {/* ESI & LWF Formula Section */}
          <div className="card" style={{ borderTop: '4px solid #059669' }}>
            <div className="card-header">
              <div className="card-title">
                <ShieldCheck size={18} color="#059669" />
                <span>ESI & Labour Welfare Fund (LWF) Rules</span>
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              <div className="grid-2">
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Employer ESI Share (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    value={(Number(activeRule.esi_employer_rate) * 100).toFixed(2)}
                    onChange={(e) => setActiveRule({ ...activeRule, esi_employer_rate: Number(e.target.value) / 100 })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: 3.25%</span>
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Employee ESI Deduction (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="form-input"
                    value={(Number(activeRule.esi_employee_rate) * 100).toFixed(2)}
                    onChange={(e) => setActiveRule({ ...activeRule, esi_employee_rate: Number(e.target.value) / 100 })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: 0.75%</span>
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">ESI Wage Ceiling (₹)</label>
                  <input
                    type="number"
                    step="1"
                    className="form-input"
                    value={activeRule.esi_threshold}
                    onChange={(e) => setActiveRule({ ...activeRule, esi_threshold: Number(e.target.value) })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: ₹21,000</span>
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Employer LWF (₹)</label>
                  <input
                    type="number"
                    step="1"
                    className="form-input"
                    value={activeRule.employer_lwf}
                    onChange={(e) => setActiveRule({ ...activeRule, employer_lwf: Number(e.target.value) })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: ₹20</span>
                </div>

                <div className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">Employee LWF (₹)</label>
                  <input
                    type="number"
                    step="1"
                    className="form-input"
                    value={activeRule.employee_lwf}
                    onChange={(e) => setActiveRule({ ...activeRule, employee_lwf: Number(e.target.value) })}
                  />
                  <span style={{ fontSize: '11px', color: '#64748b' }}>Reference: ₹5</span>
                </div>
              </div>

              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Default Monthly Thermal Allowance Base (₹)</label>
                <input
                  type="number"
                  step="1"
                  className="form-input"
                  value={activeRule.thermal_allowance_base}
                  onChange={(e) => setActiveRule({ ...activeRule, thermal_allowance_base: Number(e.target.value) })}
                />
                <span style={{ fontSize: '11px', color: '#64748b' }}>Prorated as: <code>=ROUND({activeRule.thermal_allowance_base} * Present / Total, 0)</code></span>
              </div>
            </div>
          </div>
        </div>

        <div style={{ marginTop: '16px', display: 'flex', justifyContent: 'flex-end', gap: '12px' }}>
          <button type="submit" disabled={saving} className="btn btn-primary">
            <Save size={16} />
            <span>{saving ? 'Saving...' : 'Apply & Save Formula Changes'}</span>
          </button>
        </div>
      </form>

      {/* Interactive Live Formula Simulator */}
      <div className="card" style={{ background: '#f8fafc', borderColor: '#cbd5e1' }}>
        <div className="card-header">
          <div className="card-title">
            <Play size={18} color="#1e3a8a" fill="#1e3a8a" />
            <span>Interactive Live Formula Simulator & Validator</span>
          </div>
          <span style={{ fontSize: '12px', color: '#64748b' }}>
            Test formula responses in real-time before applying changes to live payroll
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '12px', marginBottom: '16px' }}>
          <div>
            <label className="form-label">Gross Wage Rate (₹)</label>
            <input
              type="number"
              className="form-input"
              value={simGrossRate}
              onChange={(e) => setSimGrossRate(Number(e.target.value))}
            />
          </div>
          <div>
            <label className="form-label">Special Allowance (₹)</label>
            <input
              type="number"
              className="form-input"
              value={simSpecial}
              onChange={(e) => setSimSpecial(Number(e.target.value))}
            />
          </div>
          <div>
            <label className="form-label">Total Days</label>
            <input
              type="number"
              className="form-input"
              value={simDays}
              onChange={(e) => setSimDays(Number(e.target.value))}
            />
          </div>
          <div>
            <label className="form-label">Present Days</label>
            <input
              type="number"
              className="form-input"
              value={simPresent}
              onChange={(e) => setSimPresent(Number(e.target.value))}
            />
          </div>
          <div>
            <label className="form-label">Monthly Perf. All. (₹)</label>
            <input
              type="number"
              className="form-input"
              value={simPerfMonthly}
              onChange={(e) => setSimPerfMonthly(Number(e.target.value))}
            />
          </div>
        </div>

        {simResult && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '12px', background: '#ffffff', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>Total Basic</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#1e3a8a', fontFamily: 'monospace' }}>
                ₹{simResult.totalBasic}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>Thermal All.</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#1e3a8a', fontFamily: 'monospace' }}>
                ₹{simResult.thermal}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>EPF 12% (Emp)</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#dc2626', fontFamily: 'monospace' }}>
                ₹{simResult.empEpf}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>ESI (Emp)</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#dc2626', fontFamily: 'monospace' }}>
                ₹{simResult.empEsi}
              </div>
            </div>
            <div>
              <div style={{ fontSize: '11px', color: '#64748b' }}>Total Deductions</div>
              <div style={{ fontSize: '16px', fontWeight: 800, color: '#dc2626', fontFamily: 'monospace' }}>
                ₹{simResult.empDeductions}
              </div>
            </div>
            <div style={{ background: '#eff6ff', padding: '6px 10px', borderRadius: '6px', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '11px', color: '#1e3a8a', fontWeight: 700 }}>NET PAYABLE</div>
              <div style={{ fontSize: '18px', fontWeight: 900, color: '#1e3a8a', fontFamily: 'monospace' }}>
                ₹{simResult.netPayable.toFixed(2)}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
