import React from 'react';

export default function NotFoundPage() {
  return (
    <div style={{ padding: '60px 20px', textAlign: 'center', fontFamily: 'system-ui, -apple-system, sans-serif' }}>
      <h1 style={{ fontSize: '32px', color: '#0f172a', fontWeight: 800 }}>404 - Page Not Found</h1>
      <p style={{ color: '#64748b', fontSize: '15px', marginTop: '8px' }}>
        The requested GGSSTP resource or page could not be found.
      </p>
      <div style={{ marginTop: '20px' }}>
        <a href="/" style={{
          display: 'inline-block', background: '#1e3a8a', color: '#ffffff',
          padding: '10px 20px', borderRadius: '6px', textDecoration: 'none', fontWeight: 600
        }}>
          Return to GGSSTP Dashboard
        </a>
      </div>
    </div>
  );
}
