const XLSX = require('xlsx');
const path = require('path');
const { autoMapHeader, normalizeHeader, TARGET_FIELDS, formatIdentifierText, formatNumericValue } = require('../dist/excel/columnDictionary');

function parseSheetWithMapping(sheet, mapping, headerRow, sheetName) {
  const range = XLSX.utils.decode_range(sheet['!ref']);
  const rows = [];

  const getCell = (r, c) => sheet[XLSX.utils.encode_cell({ r, c })];
  const cleanStr = (val) => (val !== null && val !== undefined ? String(val).trim() : '');

  for (let r = headerRow + 1; r <= range.e.r; r++) {
    const rowObj = {
      sourceSheet: sheetName,
      sourceRow: r + 1,
      totalDays: 30,
      presentDays: 30,
      customData: {}
    };

    let hasAnyData = false;

    for (let c = 0; c <= range.e.c; c++) {
      const fieldKey = mapping[c];
      if (!fieldKey || fieldKey === '__EXCLUDE__') continue;

      const cell = getCell(r, c);
      if (!cell || cell.v === undefined || cell.v === null || cell.v === '') continue;

      hasAnyData = true;
      const rawVal = cell.v;

      switch (fieldKey) {
        case 'emp_code':
          rowObj.empCode = formatIdentifierText(rawVal);
          break;
        case 'sr_no':
          rowObj.srNo = formatIdentifierText(rawVal);
          break;
        case 'name':
          rowObj.name = cleanStr(rawVal);
          break;
        case 'father_name':
          rowObj.fatherName = cleanStr(rawVal);
          break;
        case 'designation':
          rowObj.designation = cleanStr(rawVal);
          break;
        case 'circle':
          rowObj.circleName = cleanStr(rawVal);
          break;
        case 'cell_department':
          rowObj.cell = cleanStr(rawVal);
          rowObj.departmentName = cleanStr(rawVal);
          break;
        case 'contractor':
          rowObj.contractorName = cleanStr(rawVal);
          break;
        case 'uan':
          rowObj.uan = formatIdentifierText(rawVal);
          break;
        case 'esi_number':
          rowObj.esiNumber = formatIdentifierText(rawVal);
          break;
        case 'aadhar_number':
          rowObj.aadharNumber = formatIdentifierText(rawVal);
          break;
        case 'pan_number':
          rowObj.panNumber = cleanStr(rawVal);
          break;
        case 'mobile_number':
          rowObj.mobileNumber = formatIdentifierText(rawVal);
          break;
        case 'bank_account':
          rowObj.bankAccount = formatIdentifierText(rawVal);
          break;
        case 'ifsc':
          rowObj.ifsc = cleanStr(rawVal).toUpperCase();
          break;
        case 'bank_name':
          rowObj.bankName = cleanStr(rawVal);
          break;
        case 'dob':
          rowObj.dob = cleanStr(rawVal);
          break;
        case 'age_above_58':
          rowObj.ageAbove58 = cleanStr(rawVal).toUpperCase().startsWith('Y') ? 'Y' : 'N';
          break;
        case 'above_60':
          rowObj.above60 = cleanStr(rawVal);
          break;
        case 'date_of_joining':
          rowObj.dateOfJoining = cleanStr(rawVal);
          break;
        case 'date_of_exit':
          rowObj.dateOfExit = cleanStr(rawVal);
          break;
        case 'more_than_3_yrs':
          rowObj.moreThan3Yrs = cleanStr(rawVal);
          break;
        case 'more_than_5_yrs':
          rowObj.moreThan5Yrs = cleanStr(rawVal);
          break;
        case 'qualification':
          rowObj.qualification = cleanStr(rawVal);
          break;
        case 'experience_years':
          rowObj.experienceYears = cleanStr(rawVal);
          break;
        case 'qualified_status':
          rowObj.qualifiedStatus = cleanStr(rawVal);
          break;
        case 'hazard_duty':
          rowObj.hazardDuty = cleanStr(rawVal);
          break;
        case 'check_status':
          rowObj.checkStatus = cleanStr(rawVal);
          break;
        case 'total_days':
          rowObj.totalDays = formatNumericValue(rawVal) || 30;
          break;
        case 'present_days':
          rowObj.presentDays = formatNumericValue(rawVal) || 0;
          break;
        case 'gross_salary_rate':
          rowObj.grossSalaryRate = formatNumericValue(rawVal);
          break;
        case 'proportioned_salary':
          rowObj.proportionedSalary = formatNumericValue(rawVal);
          break;
        case 'special_allowance':
          rowObj.specialAllowance = formatNumericValue(rawVal);
          break;
        case 'total_basic':
          rowObj.totalBasic = formatNumericValue(rawVal);
          break;
        case 'thermal_allowance':
          rowObj.thermalAllowance = formatNumericValue(rawVal);
          break;
        case 'perf_allowance_monthly':
          rowObj.perfAllowanceMonthly = formatNumericValue(rawVal);
          break;
        case 'perf_allowance_days':
          rowObj.perfAllowanceDays = formatNumericValue(rawVal);
          break;
        case 'total_earnings_before_bonus':
          rowObj.totalEarningsBeforeBonus = formatNumericValue(rawVal);
          break;
        case 'bonus':
          rowObj.bonus = formatNumericValue(rawVal);
          break;
        case 'bonus_percentage':
          rowObj.bonusPercentage = formatNumericValue(rawVal);
          break;
        case 'employer_epf_12':
          rowObj.employerEpf12 = formatNumericValue(rawVal);
          break;
        case 'employer_epf_1':
          rowObj.employerEpf1 = formatNumericValue(rawVal);
          break;
        case 'employer_esi_325':
          rowObj.employerEsi325 = formatNumericValue(rawVal);
          break;
        case 'employer_lwf':
          rowObj.employerLwf = formatNumericValue(rawVal);
          break;
        case 'gross_total':
          rowObj.grossTotal = formatNumericValue(rawVal);
          break;
        case 'employee_epf_12':
          rowObj.employeeEpf12 = formatNumericValue(rawVal);
          break;
        case 'employee_esi_075':
          rowObj.employeeEsi075 = formatNumericValue(rawVal);
          break;
        case 'employee_lwf':
          rowObj.employeeLwf = formatNumericValue(rawVal);
          break;
        case 'total_employee_deductions':
          rowObj.totalEmployeeDeductions = formatNumericValue(rawVal);
          break;
        case 'total_employer_contributions':
          rowObj.totalEmployerContributions = formatNumericValue(rawVal);
          break;
        case 'combined_deductions':
          rowObj.combinedDeductions = formatNumericValue(rawVal);
          break;
        case 'net_payable':
          rowObj.netPayable = formatNumericValue(rawVal);
          break;
        case 'perf_last_drawn':
          rowObj.perfLastDrawn = formatNumericValue(rawVal);
          break;
        case 'perf_as_per_circle':
          rowObj.perfAsPerCircle = formatNumericValue(rawVal);
          break;
        case 'perf_difference':
          rowObj.perfDifference = formatNumericValue(rawVal);
          break;
        default:
          rowObj.customData[fieldKey] = rawVal;
      }
    }

    if (!hasAnyData || (!rowObj.name && !rowObj.empCode)) continue;
    if (/^(total|grand total|emp code|employee name)$/i.test(rowObj.name || '') || /^(total|grand total)$/i.test(rowObj.empCode || '')) continue;

    if (!rowObj.empCode) {
      rowObj.empCode = rowObj.srNo ? `EMP-${rowObj.srNo}` : `EMP-${sheetName}-${r}`;
    }

    rows.push(rowObj);
  }

  return rows;
}

const wb = XLSX.readFile('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const sheetMM1 = wb.Sheets['MM-1'];
const mappingMM1 = {};
// Build mapping for MM-1
const rangeMM1 = XLSX.utils.decode_range(sheetMM1['!ref']);
const allHeadersMM1 = [];
for (let c = 0; c <= rangeMM1.e.c; c++) {
  const cell = sheetMM1[XLSX.utils.encode_cell({ r: 0, c })];
  const val = cell && cell.v !== undefined ? String(cell.v).trim().replace(/\n/g, ' ') : '';
  allHeadersMM1.push({ colIndex: c, rawHeader: val });
}
for (let c = 0; c <= rangeMM1.e.c; c++) {
  const res = autoMapHeader(allHeadersMM1[c].rawHeader, c, allHeadersMM1);
  mappingMM1[c] = res.targetFieldKey;
}

const rowsMM1 = parseSheetWithMapping(sheetMM1, mappingMM1, 0, 'MM-1');
console.log('Total MM-1 Parsed Rows:', rowsMM1.length);
console.log('Sample Row 0 (Simranjeet Singh):', JSON.stringify({
  empCode: rowsMM1[0].empCode,
  name: rowsMM1[0].name,
  uan: rowsMM1[0].uan,
  esiNumber: rowsMM1[0].esiNumber,
  bankAccount: rowsMM1[0].bankAccount,
  ifsc: rowsMM1[0].ifsc,
  designation: rowsMM1[0].designation,
  contractor: rowsMM1[0].contractorName,
  grossSalaryRate: rowsMM1[0].grossSalaryRate,
  proportionedSalary: rowsMM1[0].proportionedSalary,
  specialAllowance: rowsMM1[0].specialAllowance,
  totalBasic: rowsMM1[0].totalBasic,
  thermalAllowance: rowsMM1[0].thermalAllowance,
  perfAllowanceMonthly: rowsMM1[0].perfAllowanceMonthly,
  perfAllowanceDays: rowsMM1[0].perfAllowanceDays,
  totalEarningsBeforeBonus: rowsMM1[0].totalEarningsBeforeBonus,
  employeeEpf12: rowsMM1[0].employeeEpf12,
  employeeEsi075: rowsMM1[0].employeeEsi075,
  employeeLwf: rowsMM1[0].employeeLwf,
  totalEmployeeDeductions: rowsMM1[0].totalEmployeeDeductions,
  employerEpf12: rowsMM1[0].employerEpf12,
  employerEpf1: rowsMM1[0].employerEpf1,
  employerEsi325: rowsMM1[0].employerEsi325,
  employerLwf: rowsMM1[0].employerLwf,
  totalEmployerContributions: rowsMM1[0].totalEmployerContributions,
  combinedDeductions: rowsMM1[0].combinedDeductions,
  netPayable: rowsMM1[0].netPayable
}, null, 2));
