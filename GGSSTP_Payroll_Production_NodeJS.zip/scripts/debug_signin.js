const { spawn } = require('child_process');

async function debugSignIn() {
  const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  const debuggingPort = 9228;

  const browserProc = spawn(edgePath, [
    '--remote-debugging-port=' + debuggingPort,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    'http://localhost:5000'
  ]);

  await new Promise(r => setTimeout(r, 2000));

  try {
    const targetsRes = await fetch('http://127.0.0.1:' + debuggingPort + '/json/list');
    const targets = await targetsRes.json();
    const appTarget = targets.find(t => t.url.includes('5000'));
    if (!appTarget) {
      console.log('App target not found:', targets.map(t => t.url));
      return;
    }

    const ws = new WebSocket(appTarget.webSocketDebuggerUrl);

    let msgId = 1;
    function send(method, params = {}) {
      const id = msgId++;
      ws.send(JSON.stringify({ id, method, params }));
      return id;
    }

    await new Promise((resolve) => {
      ws.onopen = () => {
        send('Runtime.enable');
        send('Page.enable');
        send('Console.enable');
        setTimeout(resolve, 1000);
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.method === 'Runtime.consoleAPICalled') {
          console.log('[CONSOLE ' + msg.params.type + ']', msg.params.args.map(a => a.value || a.description || JSON.stringify(a)).join(' '));
        } else if (msg.method === 'Runtime.exceptionThrown') {
          console.error('CRITICAL EXCEPTION THROWN:', JSON.stringify(msg.params.exceptionDetails, null, 2));
        }
      };
    });

    console.log('Executing login script in browser...');
    const loginScript = `
      (async () => {
        window.addEventListener('error', (e) => {
          console.error('WINDOW ERROR EVENT:', e.message, e.filename, e.lineno, e.error ? e.error.stack : '');
        });
        window.addEventListener('unhandledrejection', (e) => {
          console.error('UNHANDLED REJECTION:', e.reason);
        });

        const userInput = document.querySelector('input[type="text"]') || document.querySelector('input');
        const passInput = document.querySelector('input[type="password"]');
        const submitBtn = document.querySelector('button[type="submit"]') || Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Sign In') || b.textContent.includes('Login'));

        if (!userInput || !passInput || !submitBtn) {
          return { error: 'Inputs or button not found' };
        }

        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
        nativeSetter.call(userInput, 'admin');
        userInput.dispatchEvent(new Event('input', { bubbles: true }));

        nativeSetter.call(passInput, 'admin@ggsstp2026');
        passInput.dispatchEvent(new Event('input', { bubbles: true }));

        await new Promise(r => setTimeout(r, 200));
        submitBtn.click();
        return { success: true };
      })()
    `;

    send('Runtime.evaluate', { expression: loginScript, awaitPromise: true });

    // Wait 3 seconds to capture all logs/exceptions during login & dashboard render
    await new Promise(r => setTimeout(r, 3000));

    // Test clicking Employees tab
    const navEmployeesScript = `
      (async () => {
        const buttons = Array.from(document.querySelectorAll('button, a, div'));
        const empBtn = buttons.find(b => b.textContent.trim() === 'Employees');
        if (empBtn) {
          empBtn.click();
          await new Promise(r => setTimeout(r, 1000));
          return { clicked: true, text: empBtn.textContent.trim(), bodyLen: document.body.innerHTML.length };
        }
        return { clicked: false };
      })()
    `;
    const navId = send('Runtime.evaluate', { expression: navEmployeesScript, awaitPromise: true });

    await new Promise(r => setTimeout(r, 2000));

    // Get current HTML
    const checkId = send('Runtime.evaluate', { expression: 'document.body.innerHTML' });

    await new Promise((resolve) => {
      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.id === checkId) {
          console.log('Post-navigation HTML length:', msg.result.result.value ? msg.result.result.value.length : 0);
          console.log('Post-navigation HTML snippet:', msg.result.result.value ? msg.result.result.value.slice(0, 300) : '');
          resolve();
        } else if (msg.method === 'Runtime.exceptionThrown') {
          console.error('CRITICAL EXCEPTION THROWN:', JSON.stringify(msg.params.exceptionDetails, null, 2));
        }
      };
      setTimeout(resolve, 3000);
    });

    ws.close();
  } catch (err) {
    console.error('Error during test:', err);
  } finally {
    browserProc.kill();
  }
}

debugSignIn();
