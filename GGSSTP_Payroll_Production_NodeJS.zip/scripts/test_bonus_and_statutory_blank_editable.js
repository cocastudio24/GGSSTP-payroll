/**
 * Automated Verification Script:
 * 1. Bonus 8.33% of Basic Salary can be left blank (calculates bonus as ₹0).
 * 2. EPF, ESI, LWF for Employee and Employer:
 *    - Editable to custom values
 *    - Delete / leave blank (evaluates to ₹0)
 *    - Auto formula calculation
 * 3. Exact formula balancing:
 *    - Gross Total = Earnings Before Bonus + Bonus + all 4 Employer Contributions
 *    - Combined Deductions = Employee Deductions + Employer Contributions
 *    - Net Payable = Gross Total - Combined Deductions = (Earnings + Bonus) - Employee Deductions
 */

const { calculatePayroll, INITIAL_RATES } = require('../dist/engine/payrollCalculator');

let passed = 0;
let failed = 0;

function assert(condition, testName, details = '') {
  if (condition) {
    console.log(`[PASS] ${testName}`);
    passed++;
  } else {
    console.error(`[FAIL] ${testName}: ${details}`);
    failed++;
  }
}

console.log('================================================================');
console.log('TEST SUITE: BONUS BLANK & STATUTORY EDITABLE/BLANK VERIFICATION');
console.log('================================================================\n');

// -------------------------------------------------------------
// PART 1: BONUS OPTION TO LEAVE BLANK / SET 0% / 8.33%
// -------------------------------------------------------------
console.log('--- TEST GROUP 1: BONUS CALCULATION WITH BLANK / 0 / 8.33% ---');

// Standard 8.33% bonus
const calcStandardBonus = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30
});
assert(calcStandardBonus.bonusPercentage === 8.33, 'Default bonus percentage is 8.33%');
assert(calcStandardBonus.totalBasic === 20332, 'Total Basic is ₹20,332');
assert(calcStandardBonus.bonus === 1694, 'Standard 8.33% Bonus is ₹1,694 (ROUND(20332 * 0.0833, 0))');

// Blank bonus percentage: empty string ""
const calcBlankStringBonus = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  bonusPercentage: ''
});
assert(calcBlankStringBonus.bonusPercentage === 0, 'Empty string bonus percentage evaluates to 0%');
assert(calcBlankStringBonus.bonus === 0, 'Empty string bonus evaluates to ₹0');

// Blank bonus percentage: null
const calcNullBonus = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  bonusPercentage: null
});
assert(calcNullBonus.bonusPercentage === 0, 'Null bonus percentage evaluates to 0%');
assert(calcNullBonus.bonus === 0, 'Null bonus evaluates to ₹0');

// Explicit 0% bonus
const calcZeroBonus = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  bonusPercentage: 0
});
assert(calcZeroBonus.bonusPercentage === 0, '0% bonus percentage evaluates to 0%');
assert(calcZeroBonus.bonus === 0, '0% bonus evaluates to ₹0');

// Custom bonus percentage (e.g. 5%)
const calc5PctBonus = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  bonusPercentage: 5
});
assert(calc5PctBonus.bonusPercentage === 5, '5% bonus percentage preserved');
assert(calc5PctBonus.bonus === Math.round(20332 * 0.05), `5% bonus is ₹${calc5PctBonus.bonus}`);

// -------------------------------------------------------------
// PART 2: STATUTORY DEDUCTIONS & CONTRIBUTIONS (EDIT, DELETE, LEAVE BLANK)
// -------------------------------------------------------------
console.log('\n--- TEST GROUP 2: STATUTORY EDITS & LEAVE BLANK (EPF, ESI, LWF) ---');

// Standard auto formula baseline
const autoBase = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30
});
assert(autoBase.proportionedSalary === 16530, 'Proportioned salary is ₹16,530');
assert(autoBase.employerEpf12 === 1984, 'Auto Employer EPF 12% is ₹1,984');
assert(autoBase.employerEpf1 === 165, 'Auto Employer EPF 1% is ₹165');
assert(autoBase.employerEsi325 === 0, 'Auto Employer ESI 3.25% is ₹0 (earnings > 21K)');
assert(autoBase.employerLwf === 20, 'Auto Employer LWF is ₹20');
assert(autoBase.employeeEpf12 === 1984, 'Auto Employee EPF 12% is ₹1,984');
assert(autoBase.employeeEsi075 === 0, 'Auto Employee ESI 0.75% is ₹0');
assert(autoBase.employeeLwf === 5, 'Auto Employee LWF is ₹5');

// Case A: Custom values for EPF, ESI, LWF
const customStat = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  customEmployeeEpf: 1500,
  customEmployerEpf: 1500,
  customEmployerEpf1: 125,
  customEmployeeEsi: 100,
  customEmployerEsi: 350,
  customEmployeeLwf: 10,
  customEmployerLwf: 30
});
assert(customStat.employeeEpf12 === 1500, 'Custom Employee EPF 12% is ₹1,500');
assert(customStat.employerEpf12 === 1500, 'Custom Employer EPF 12% is ₹1,500');
assert(customStat.employerEpf1 === 125, 'Custom Employer EPF 1% is ₹125');
assert(customStat.employeeEsi075 === 100, 'Custom Employee ESI 0.75% is ₹100');
assert(customStat.employerEsi325 === 350, 'Custom Employer ESI 3.25% is ₹350');
assert(customStat.employeeLwf === 10, 'Custom Employee LWF is ₹10');
assert(customStat.employerLwf === 30, 'Custom Employer LWF is ₹30');
assert(customStat.totalEmployeeDeductions === (1500 + 100 + 10), 'Total Employee Deductions is ₹1,610');
assert(customStat.totalEmployerContributions === (1500 + 125 + 350 + 30), 'Total Employer Contributions is ₹2,005');

// Case B: Leave Blank / Delete (evaluate as 0)
const blankStat = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  customEmployeeEpf: '',
  customEmployerEpf: '',
  customEmployerEpf1: '',
  customEmployeeEsi: '',
  customEmployerEsi: '',
  customEmployeeLwf: '',
  customEmployerLwf: ''
});
assert(blankStat.employeeEpf12 === 0, 'Blank Employee EPF evaluates to ₹0');
assert(blankStat.employerEpf12 === 0, 'Blank Employer EPF 12% evaluates to ₹0');
assert(blankStat.employerEpf1 === 0, 'Blank Employer EPF 1% evaluates to ₹0');
assert(blankStat.employeeEsi075 === 0, 'Blank Employee ESI evaluates to ₹0');
assert(blankStat.employerEsi325 === 0, 'Blank Employer ESI evaluates to ₹0');
assert(blankStat.employeeLwf === 0, 'Blank Employee LWF evaluates to ₹0');
assert(blankStat.employerLwf === 0, 'Blank Employer LWF evaluates to ₹0');
assert(blankStat.totalEmployeeDeductions === 0, 'Total Employee Deductions is ₹0 when all left blank');
assert(blankStat.totalEmployerContributions === 0, 'Total Employer Contributions is ₹0 when all left blank');

// Case C: Null statutory inputs evaluate to 0 (leave blank)
const nullStat = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  customEmployeeEpf: null,
  customEmployerEpf: null,
  customEmployerEpf1: null,
  customEmployeeEsi: null,
  customEmployerEsi: null,
  customEmployeeLwf: null,
  customEmployerLwf: null
});
assert(nullStat.employeeEpf12 === 0, 'Null Employee EPF evaluates to ₹0');
assert(nullStat.employerEpf12 === 0, 'Null Employer EPF 12% evaluates to ₹0');
assert(nullStat.employerEpf1 === 0, 'Null Employer EPF 1% evaluates to ₹0');
assert(nullStat.totalEmployeeDeductions === 0, 'Null Employee Deductions evaluates to ₹0');
assert(nullStat.totalEmployerContributions === 0, 'Null Employer Contributions evaluates to ₹0');

// -------------------------------------------------------------
// PART 3: COMPLETE MATHEMATICAL INTEGRITY & RECONCILIATION
// -------------------------------------------------------------
console.log('\n--- TEST GROUP 3: COMPLETE FORMULA INTEGRITY WITH BOTH BLANK BONUS & BLANK STATUTORY ---');

const testCombo = calculatePayroll({
  designationAlias: 'SW',
  grossSalaryRate: 16530,
  specialAllowanceRate: 3802,
  totalDays: 30,
  presentDays: 30,
  bonusPercentage: null, // Blank bonus
  customEmployeeEpf: 0,  // Blank statutory
  customEmployerEpf: 0,
  customEmployerEpf1: 0,
  customEmployeeEsi: 0,
  customEmployerEsi: 0,
  customEmployeeLwf: 0,
  customEmployerLwf: 0
});

assert(testCombo.bonus === 0, 'Bonus is ₹0 when blank');
assert(testCombo.totalEmployeeDeductions === 0, 'Employee deductions is ₹0');
assert(testCombo.totalEmployerContributions === 0, 'Employer contributions is ₹0');
assert(testCombo.grossTotal === testCombo.totalEarningsBeforeBonus, 'Gross Total strictly equals Earnings Before Bonus when no bonus and no employer contrib');
assert(testCombo.netPayable === testCombo.grossTotal, 'Net Payable strictly equals Gross Total when no deductions');
assert(testCombo.combinedDeductions === 0, 'Combined Deductions is ₹0');

console.log('\n================================================================');
console.log(`SUMMARY: ${passed} PASSED, ${failed} FAILED`);
console.log('================================================================');

if (failed > 0) {
  process.exit(1);
} else {
  process.exit(0);
}
