const XLSX = require('xlsx');
const path = require('path');
const file = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const wb = XLSX.readFile(file);
const wsMM1 = wb.Sheets['MM-1'];

console.log('--- MM-1 Headers and Rows ---');
// Let's print row 2 (headers) and row 3, row 6
for (let r = 0; r <= 6; r++) {
  const cells = [];
  for (let c = 0; c <= 55; c++) {
    const addr = XLSX.utils.encode_cell({ r, c });
    const cell = wsMM1[addr];
    if (cell) {
      cells.push(`${addr}:${cell.v}${cell.f ? ' (F:' + cell.f + ')' : ''}`);
    }
  }
  if (cells.length > 0) {
    console.log(`\nRow ${r + 1}:`);
    for (let i = 0; i < cells.length; i += 10) {
      console.log('  ' + cells.slice(i, i + 10).join(' | '));
    }
  }
}
