const fs = require('fs');
const path = require('path');
const { ZipArchive } = require('archiver');

const rootDir = path.resolve(__dirname, '..');
const zipFile = path.join(rootDir, 'GGSSTP_Payroll_Production_NodeJS.zip');

console.log('1. Preparing archive output stream...');
if (fs.existsSync(zipFile)) {
  fs.unlinkSync(zipFile);
}

const output = fs.createWriteStream(zipFile);
const archive = new ZipArchive({
  zlib: { level: 9 },
  forceLocalTime: true,
  forceZip64: false
});

output.on('close', function () {
  const stats = fs.statSync(zipFile);
  console.log('================================================================');
  console.log('✅ 100% HEALTHY STANDARD ZIP ARCHIVE GENERATED SUCCESSFULLY!');
  console.log(`Path: ${zipFile}`);
  console.log(`Total Bytes: ${archive.pointer()} (${(stats.size / (1024 * 1024)).toFixed(2)} MB)`);
  console.log('================================================================');
});

archive.on('warning', function (err) {
  if (err.code === 'ENOENT') {
    console.warn(err);
  } else {
    throw err;
  }
});

archive.on('error', function (err) {
  console.error('Archive error:', err);
  throw err;
});

archive.pipe(output);

console.log('2. Appending files and directories to zip...');

// Recursive helper to add directories with standard POSIX headers and permissions
function addDirectoryCleanly(sourceDir, zipSubDir) {
  if (!fs.existsSync(sourceDir)) return;

  // Add explicit directory record
  archive.append(null, { name: zipSubDir.endsWith('/') ? zipSubDir : `${zipSubDir}/`, mode: 0o755 });

  const entries = fs.readdirSync(sourceDir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(sourceDir, entry.name);
    const archivePath = path.posix.join(zipSubDir, entry.name);

    // Strictly skip any node_modules folder
    if (entry.name === 'node_modules') {
      console.log(`  [SKIPPED] ${archivePath} (node_modules directory)`);
      continue;
    }

    // Strictly skip version control and cache folders
    if (entry.name === '.git' || entry.name === '.github' || entry.name === '.cache') {
      continue;
    }

    // Strictly skip OS metadata files
    if (entry.name === '.DS_Store' || entry.name === 'Thumbs.db') {
      continue;
    }

    // Strictly skip blocked script formats
    if (entry.name.endsWith('.ps1')) {
      console.log(`  [SKIPPED] ${archivePath} (.ps1 blocked file)`);
      continue;
    }

    // Strictly skip transient server PID files
    if (entry.name === 'postmaster.pid' || entry.name.endsWith('.pid')) {
      console.log(`  [SKIPPED] ${archivePath} (transient lock/pid file)`);
      continue;
    }

    // Skip temporary / test database dirs
    if (zipSubDir === 'data' && (entry.name === 'test_pg' || entry.name === 'backups')) {
      continue;
    }

    if (entry.isDirectory()) {
      if (zipSubDir === 'client' && entry.name === 'dist') continue;
      addDirectoryCleanly(fullPath, archivePath);
    } else {
      archive.file(fullPath, { name: archivePath, mode: 0o644 });
    }
  }
}

// Root configuration & documentation files
const rootFiles = [
  'package.json',
  'package-lock.json',
  'index.html',
  'index.js',
  'server.js',
  'vite.config.mts',
  'tsconfig.json',
  'tsconfig.server.json',
  '.env',
  '.env.example',
  'Dockerfile',
  'docker-compose.yml',
  'cloudbuild.yaml',
  '.dockerignore',
  'README.md',
  'FORMULA_AUDIT_REPORT.md',
  'HOW_TO_RUN_ON_SERVER.txt',
  'start_ggsstp.bat'
];

for (const file of rootFiles) {
  const p = path.join(rootDir, file);
  if (fs.existsSync(p)) {
    archive.file(p, { name: file, mode: 0o644 });
  }
}

// 1. Add dist folder (pre-compiled production build)
addDirectoryCleanly(path.join(rootDir, 'dist'), 'dist');

// 2. Add src folder (React frontend source code)
addDirectoryCleanly(path.join(rootDir, 'src'), 'src');

// 3. Add server folder (Node.js Express backend source code)
addDirectoryCleanly(path.join(rootDir, 'server'), 'server');

// 4. Add client folder cleanly if present
if (fs.existsSync(path.join(rootDir, 'client'))) {
  addDirectoryCleanly(path.join(rootDir, 'client'), 'client');
}

// 5. Add public folder (icons, favicons)
if (fs.existsSync(path.join(rootDir, 'public'))) {
  addDirectoryCleanly(path.join(rootDir, 'public'), 'public');
}

// 6. Add reference_files folder (includes official Excel sheets and user_prompt_184_employees.csv)
addDirectoryCleanly(path.join(rootDir, 'reference_files'), 'reference_files');

// 7. Add scripts folder
addDirectoryCleanly(path.join(rootDir, 'scripts'), 'scripts');

console.log('3. Finalizing clean, standard zip archive (database cluster safely auto-bootstraps on first run)...');
archive.finalize();
