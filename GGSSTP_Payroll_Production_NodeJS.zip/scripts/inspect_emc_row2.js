const XLSX = require('xlsx');
const wb = XLSX.readFile('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const sheet = wb.Sheets['EMC'];
const range = XLSX.utils.decode_range(sheet['!ref']);

console.log('EMC Row 1 Headers:');
for (let c = 0; c <= range.e.c; c++) {
  const h = sheet[XLSX.utils.encode_cell({ r: 1, c })]?.v;
  const v = sheet[XLSX.utils.encode_cell({ r: 2, c })]?.v;
  console.log(`Col ${c}: ${h} => Row 2: ${v}`);
}
