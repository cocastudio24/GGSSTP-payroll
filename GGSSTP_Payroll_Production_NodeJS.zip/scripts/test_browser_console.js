const { spawn } = require('child_process');

async function testConsole() {
  const edgePath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
  const debuggingPort = 9225;

  const browserProc = spawn(edgePath, [
    `--remote-debugging-port=${debuggingPort}`,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    'http://localhost:5000'
  ]);

  await new Promise(r => setTimeout(r, 2000));

  try {
    const targetsRes = await fetch(`http://127.0.0.1:${debuggingPort}/json/list`);
    const targets = await targetsRes.json();
    const appTarget = targets.find(t => t.url.includes('5000'));
    if (!appTarget) {
      console.log('App target not found in Edge targets:', targets.map(t => t.url));
      return;
    }

    console.log('Connecting to WebSocket:', appTarget.webSocketDebuggerUrl);
    const ws = new WebSocket(appTarget.webSocketDebuggerUrl);

    await new Promise((resolve) => {
      ws.onopen = () => {
        // Enable Console and Runtime
        ws.send(JSON.stringify({ id: 1, method: 'Console.enable' }));
        ws.send(JSON.stringify({ id: 2, method: 'Runtime.enable' }));
        ws.send(JSON.stringify({ id: 3, method: 'Page.enable' }));
        setTimeout(resolve, 3000);
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.method === 'Runtime.consoleAPICalled') {
          console.log(`[BROWSER CONSOLE ${msg.params.type.toUpperCase()}]:`, msg.params.args.map(a => a.value || a.description || JSON.stringify(a)).join(' '));
        } else if (msg.method === 'Runtime.exceptionThrown') {
          console.error('[BROWSER EXCEPTION!]:', msg.params.exceptionDetails);
        }
      };

      ws.onerror = (err) => {
        console.error('WS Error:', err);
        resolve();
      };
    });

    // Evaluate document.body.innerHTML
    ws.send(JSON.stringify({
      id: 4,
      method: 'Runtime.evaluate',
      params: { expression: 'document.body.innerHTML' }
    }));

    await new Promise((resolve) => {
      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.id === 4) {
          console.log('Page body HTML length:', msg.result.result.value?.length);
          console.log('Page body HTML sample:', msg.result.result.value?.slice(0, 300));
          resolve();
        }
      };
      setTimeout(resolve, 2000);
    });

    ws.close();
  } catch (err) {
    console.error('Error during test:', err);
  } finally {
    browserProc.kill();
  }

  process.exit(0);
}

testConsole();
