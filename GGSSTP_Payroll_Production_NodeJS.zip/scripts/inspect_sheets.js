const XLSX = require('xlsx');
const ExcelJS = require('exceljs');
const path = require('path');
const fs = require('fs');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');

async function inspect() {
  console.log('Loading with SheetJS...');
  const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });
  console.log('Sheet names:', workbook.SheetNames);

  for (const sheetName of workbook.SheetNames) {
    const sheet = workbook.Sheets[sheetName];
    const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
    console.log(`\n================ SHEET: ${sheetName} ================`);
    console.log(`Range: ${sheet['!ref']} (Rows ${range.s.r + 1} to ${range.e.r + 1}, Cols ${range.s.c + 1} to ${range.e.c + 1})`);

    // Let's print the first 60 rows of column A and B to understand the layout
    console.log('--- Rows in Column A & B (first 65 rows) ---');
    for (let r = 0; r <= Math.min(65, range.e.r); r++) {
      const cellA = sheet[XLSX.utils.encode_cell({ r, c: 0 })];
      const cellB = sheet[XLSX.utils.encode_cell({ r, c: 1 })];
      const cellC = sheet[XLSX.utils.encode_cell({ r, c: 2 })];
      const valA = cellA ? cellA.v : '';
      const valB = cellB ? cellB.v : '';
      const valC = cellC ? cellC.v : '';
      if (valA || valB || valC) {
        console.log(`Row ${r + 1}: [A] "${valA}" | [B] "${valB}" | [C] "${valC}"`);
      }
    }
  }
}

inspect().catch(console.error);
