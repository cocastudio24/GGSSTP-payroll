const { db } = require('../dist/database/db');
const crypto = require('crypto');

async function migrateMultiUserIsolation() {
  console.log('================================================================');
  console.log('STARTING MULTI-USER DATA ISOLATION DATABASE MIGRATION');
  console.log('================================================================\n');

  await db.init();

  // 1. Add UUID to users table
  console.log('1. Updating users table with UUID...');
  await db.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS uuid VARCHAR(64);`);
  const usersRes = await db.query(`SELECT id, uuid FROM users;`);
  for (const u of usersRes.rows) {
    if (!u.uuid) {
      const userUuid = crypto.randomUUID();
      await db.query(`UPDATE users SET uuid = $1 WHERE id = $2;`, [userUuid, u.id]);
    }
  }

  // 2. Add owner_user_id to employees
  console.log('2. Adding owner_user_id to employees...');
  await db.query(`ALTER TABLE employees ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE employees SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  try {
    await db.query(`ALTER TABLE employees DROP CONSTRAINT IF EXISTS employees_emp_code_key;`);
  } catch (e) {
    console.log('Note on dropping constraint:', e.message);
  }
  await db.query(`CREATE INDEX IF NOT EXISTS idx_employees_owner ON employees(owner_user_id);`);

  // 3. Add owner_user_id to payroll_periods
  console.log('3. Adding owner_user_id to payroll_periods...');
  await db.query(`ALTER TABLE payroll_periods ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE payroll_periods SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  try {
    await db.query(`ALTER TABLE payroll_periods DROP CONSTRAINT IF EXISTS payroll_periods_year_month_key;`);
  } catch (e) {
    console.log('Note on dropping constraint:', e.message);
  }
  await db.query(`CREATE INDEX IF NOT EXISTS idx_payroll_periods_owner ON payroll_periods(owner_user_id);`);

  // 4. Add owner_user_id to payroll_entries
  console.log('4. Adding owner_user_id to payroll_entries...');
  await db.query(`ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE payroll_entries SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  await db.query(`CREATE INDEX IF NOT EXISTS idx_payroll_entries_owner ON payroll_entries(owner_user_id);`);

  // 5. Add owner_user_id to contractors
  console.log('5. Adding owner_user_id to contractors...');
  await db.query(`ALTER TABLE contractors ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE contractors SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  try {
    await db.query(`ALTER TABLE contractors DROP CONSTRAINT IF EXISTS contractors_name_key;`);
  } catch (e) {}
  await db.query(`CREATE INDEX IF NOT EXISTS idx_contractors_owner ON contractors(owner_user_id);`);

  // 6. Add owner_user_id to circles and departments
  console.log('6. Adding owner_user_id to circles and departments...');
  await db.query(`ALTER TABLE circles ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE circles SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  try {
    await db.query(`ALTER TABLE circles DROP CONSTRAINT IF EXISTS circles_name_key;`);
  } catch (e) {}
  await db.query(`CREATE INDEX IF NOT EXISTS idx_circles_owner ON circles(owner_user_id);`);

  await db.query(`ALTER TABLE departments ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE departments SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  await db.query(`CREATE INDEX IF NOT EXISTS idx_departments_owner ON departments(owner_user_id);`);

  // 7. Add owner_user_id to designations and rates
  console.log('7. Adding owner_user_id to designations and designation_salary_rates...');
  await db.query(`ALTER TABLE designations ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE designations SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  try {
    await db.query(`ALTER TABLE designations DROP CONSTRAINT IF EXISTS designations_name_key;`);
    await db.query(`ALTER TABLE designations DROP CONSTRAINT IF EXISTS designations_alias_key;`);
  } catch (e) {}
  await db.query(`CREATE INDEX IF NOT EXISTS idx_designations_owner ON designations(owner_user_id);`);

  await db.query(`ALTER TABLE designation_salary_rates ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE designation_salary_rates SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  await db.query(`CREATE INDEX IF NOT EXISTS idx_designation_salary_rates_owner ON designation_salary_rates(owner_user_id);`);

  // 8. Add owner_user_id to payroll_rule_sets
  console.log('8. Adding owner_user_id to payroll_rule_sets...');
  await db.query(`ALTER TABLE payroll_rule_sets ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE payroll_rule_sets SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);
  await db.query(`CREATE INDEX IF NOT EXISTS idx_payroll_rule_sets_owner ON payroll_rule_sets(owner_user_id);`);

  // 9. Add owner_user_id to payroll_overrides, import_jobs, audit_logs
  console.log('9. Adding owner_user_id to overrides, imports, audit logs...');
  await db.query(`ALTER TABLE payroll_overrides ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE payroll_overrides SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);

  await db.query(`ALTER TABLE import_jobs ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE import_jobs SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);

  await db.query(`ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;`);
  await db.query(`UPDATE audit_logs SET owner_user_id = 1 WHERE owner_user_id IS NULL;`);

  // 10. Verification of counts
  console.log('\n--- VERIFICATION OF OWNER-ISOLATED DATA ---');
  const empCount = await db.query(`SELECT owner_user_id, COUNT(*) as count FROM employees GROUP BY owner_user_id;`);
  console.log('Employees by owner:', empCount.rows);

  const peCount = await db.query(`SELECT owner_user_id, COUNT(*) as count FROM payroll_entries GROUP BY owner_user_id;`);
  console.log('Payroll entries by owner:', peCount.rows);

  const ppCount = await db.query(`SELECT owner_user_id, COUNT(*) as count FROM payroll_periods GROUP BY owner_user_id;`);
  console.log('Payroll periods by owner:', ppCount.rows);

  console.log('\n✅ MIGRATION COMPLETED SUCCESSFULLY!');
  process.exit(0);
}

migrateMultiUserIsolation().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
