const XLSX = require('xlsx');

function listHeaders(filename, sheetName, headerRow) {
  const wb = XLSX.readFile(filename);
  const sheet = wb.Sheets[sheetName];
  const range = XLSX.utils.decode_range(sheet['!ref']);
  console.log('\n========================================');
  console.log(filename + ' :: ' + sheetName);
  console.log('========================================');
  for (let c = 0; c <= range.e.c; c++) {
    const cell = sheet[XLSX.utils.encode_cell({ r: headerRow, c })];
    const val = cell && cell.v !== undefined ? String(cell.v).trim().replace(/\n/g, ' ') : '';
    const cellAbove = headerRow > 0 ? sheet[XLSX.utils.encode_cell({ r: headerRow - 1, c })] : null;
    const valAbove = cellAbove && cellAbove.v !== undefined ? String(cellAbove.v).trim().replace(/\n/g, ' ') : '';
    
    const sampleCell = sheet[XLSX.utils.encode_cell({ r: headerRow + 1, c })];
    const sampleVal = sampleCell && sampleCell.v !== undefined ? String(sampleCell.v).slice(0, 30) : '';

    console.log(`${XLSX.utils.encode_col(c)} (col ${c}): [${valAbove ? valAbove + ' / ' : ''}${val}] => sample: "${sampleVal}"`);
  }
}

listHeaders('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx', 'MM-1', 0);
listHeaders('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx', 'EMC', 1);
listHeaders('reference_files/SALARY OP AND c&i.xlsx', 'operation circle', 1);
