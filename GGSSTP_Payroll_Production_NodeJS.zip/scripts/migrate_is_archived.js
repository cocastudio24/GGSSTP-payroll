const { PGlite } = require('@electric-sql/pglite');
const path = require('path');

async function migrate() {
  const dbPath = path.resolve(__dirname, '../data/ggsstp_pg');
  console.log('Connecting to PGlite at:', dbPath);
  const db = new PGlite(dbPath);

  console.log('Running ALTER TABLE employees ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT FALSE;');
  await db.query(`ALTER TABLE employees ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT FALSE;`);
  
  console.log('Syncing is_archived with archived_at...');
  await db.query(`UPDATE employees SET is_archived = (archived_at IS NOT NULL) WHERE is_archived IS NULL;`);

  console.log('Querying sample rows...');
  const res = await db.query(`SELECT id, emp_code, name, is_active, is_archived, archived_at FROM employees LIMIT 5;`);
  console.log('Sample rows:', res.rows);

  // Test the exact query that failed
  console.log('Testing query from previewSalaryUpdateImport...');
  const testRes = await db.query(`
    SELECT e.id, e.name, e.is_active, COALESCE(e.is_archived, FALSE) as is_archived, e.archived_at
    FROM employees e
    WHERE e.is_active = TRUE AND COALESCE(e.is_archived, FALSE) = FALSE AND e.archived_at IS NULL
    LIMIT 5;
  `);
  console.log('Test query succeeded! Rows returned:', testRes.rows.length);
}

migrate()
  .then(() => {
    console.log('✅ is_archived column migration completed successfully!');
    process.exit(0);
  })
  .catch(err => {
    console.error('❌ Migration failed:', err);
    process.exit(1);
  });
