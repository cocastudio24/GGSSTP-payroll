const path = require('path');
const fs = require('fs');

async function runArchiveDeleteSyncTests() {
  console.log('========================================================================');
  console.log('STARTING EMPLOYEE ARCHIVE, PERMANENT DELETE & PAYROLL SYNC TEST SUITE');
  console.log('========================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  }

  process.env.PG_DATA_DIR = path.resolve(__dirname, '../data/test_sync_pg');
  const { db } = require('../dist/database/db');
  const { calculatePayroll, INITIAL_RATES } = require('../dist/engine/payrollCalculator');
  const { ExcelImporter } = require('../dist/excel/excelImporter');
  const { syncPeriodWithActiveEmployees, syncEmployeesWithOpenPayrollPeriods } = require('../dist/services/payrollSyncService');

  await db.init();
  console.log('Database connected.\n');

  // Find admin user
  const userRes = await db.query(`SELECT id FROM users WHERE username = 'admin' LIMIT 1;`);
  const adminId = userRes.rows[0]?.id || 1;

  // Get SW designation
  const desigRes = await db.query(`SELECT id FROM designations WHERE alias = 'SW' LIMIT 1;`);
  const swDesigId = desigRes.rows[0]?.id || 1;

  // ==========================================
  // TEST GROUP 1: SINGLE ARCHIVE & RESTORE
  // ==========================================
  console.log('--- TEST GROUP 1: Single Archive & Restore ---');
  const empCode1 = `SYNC-TEST-01-${Date.now().toString().slice(-4)}`;
  const ins1 = await db.query(`
    INSERT INTO employees (owner_user_id, created_by_user_id, emp_code, name, designation_id, default_gross_rate, default_special_allowance, is_active)
    VALUES ($1, $1, $2, 'JASWINDER SINGH', $3, 16530, 3802, TRUE)
    RETURNING *;
  `, [adminId, empCode1, swDesigId]);
  const emp1 = ins1.rows[0];

  assert(emp1.is_active === true && emp1.archived_at === null, 'Newly created employee is active and not archived');

  // Archive employee
  const archRes1 = await db.query(`
    UPDATE employees SET
      is_active = FALSE,
      archived_at = CURRENT_TIMESTAMP,
      archived_by_user_id = $1,
      archived_reason = 'Completed fixed term contract',
      updated_at = CURRENT_TIMESTAMP
    WHERE id = $2
    RETURNING *;
  `, [adminId, emp1.id]);
  const archivedEmp1 = archRes1.rows[0];

  assert(archivedEmp1.is_active === false, 'Archived employee has is_active = false');
  assert(archivedEmp1.archived_at !== null, 'Archived employee has archived_at timestamp');
  assert(archivedEmp1.archived_reason === 'Completed fixed term contract', 'Archived reason is recorded accurately');

  // Restore employee
  const restRes1 = await db.query(`
    UPDATE employees SET
      is_active = TRUE,
      archived_at = NULL,
      archived_by_user_id = NULL,
      archived_reason = NULL,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = $1
    RETURNING *;
  `, [emp1.id]);
  const restoredEmp1 = restRes1.rows[0];

  assert(restoredEmp1.is_active === true, 'Restored employee has is_active = true');
  assert(restoredEmp1.archived_at === null, 'Restored employee has archived_at cleared to null');
  assert(restoredEmp1.archived_reason === null, 'Restored employee has archived_reason cleared to null');

  // ==========================================
  // TEST GROUP 2: BULK ARCHIVE & BULK RESTORE
  // ==========================================
  console.log('\n--- TEST GROUP 2: Bulk Archive & Bulk Restore ---');
  const bulkCodeA = `BULK-A-${Date.now().toString().slice(-4)}`;
  const bulkCodeB = `BULK-B-${Date.now().toString().slice(-4)}`;

  const insA = await db.query(`
    INSERT INTO employees (owner_user_id, created_by_user_id, emp_code, name, designation_id, default_gross_rate, is_active)
    VALUES ($1, $1, $2, 'MANPREET SINGH', $3, 16530, TRUE) RETURNING id;
  `, [adminId, bulkCodeA, swDesigId]);
  const insB = await db.query(`
    INSERT INTO employees (owner_user_id, created_by_user_id, emp_code, name, designation_id, default_gross_rate, is_active)
    VALUES ($1, $1, $2, 'GURPREET SINGH', $3, 16530, TRUE) RETURNING id;
  `, [adminId, bulkCodeB, swDesigId]);

  const bulkIds = [insA.rows[0].id, insB.rows[0].id];

  // Bulk Archive
  const bulkArchRes = await db.query(`
    UPDATE employees SET
      is_active = FALSE,
      archived_at = CURRENT_TIMESTAMP,
      archived_by_user_id = $1,
      archived_reason = 'Bulk annual maintenance deactivation',
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ANY($2) AND owner_user_id = $1
    RETURNING id, is_active, archived_at;
  `, [adminId, bulkIds]);

  assert(bulkArchRes.rowCount === 2, 'Bulk archive updated exactly 2 records');
  assert(bulkArchRes.rows.every(r => r.is_active === false && r.archived_at !== null), 'All bulk archived records are deactivated');

  // Bulk Restore
  const bulkRestRes = await db.query(`
    UPDATE employees SET
      is_active = TRUE,
      archived_at = NULL,
      archived_by_user_id = NULL,
      archived_reason = NULL,
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ANY($1) AND owner_user_id = $2
    RETURNING id, is_active, archived_at;
  `, [bulkIds, adminId]);

  assert(bulkRestRes.rowCount === 2, 'Bulk restore reactivated exactly 2 records');
  assert(bulkRestRes.rows.every(r => r.is_active === true && r.archived_at === null), 'All bulk restored records are active');

  // ========================================================
  // TEST GROUP 3: CHECK DELETE ELIGIBILITY & HISTORY SAFEGUARD
  // ========================================================
  console.log('\n--- TEST GROUP 3: Check Delete Eligibility & History Safeguard ---');

  // Create an employee with 0 history
  const noHistCode = `NOHIST-${Date.now().toString().slice(-4)}`;
  const insNoHist = await db.query(`
    INSERT INTO employees (owner_user_id, created_by_user_id, emp_code, name, designation_id, is_active)
    VALUES ($1, $1, $2, 'NO HISTORY TEST EMP', $3, TRUE) RETURNING id, emp_code, name;
  `, [adminId, noHistCode, swDesigId]);
  const noHistEmp = insNoHist.rows[0];

  // Create a period and payroll entry for emp1 (giving emp1 historical payroll records)
  const periodRes = await db.query(`
    INSERT INTO payroll_periods (owner_user_id, created_by_user_id, year, month, month_name, total_days, status)
    VALUES ($1, $1, 2026, 9, 'September', 30, 'Draft')
    RETURNING id;
  `, [adminId]);
  const testPeriodId = periodRes.rows[0].id;

  await db.query(`
    INSERT INTO payroll_entries (owner_user_id, payroll_period_id, employee_id, present_days, gross_salary_rate, net_payable)
    VALUES ($1, $2, $3, 30, 16530, 16500);
  `, [adminId, testPeriodId, emp1.id]);

  // Query eligibility check logic
  const eligCheck = await db.query(`
    SELECT e.id, e.emp_code, e.name, COUNT(pe.id) as history_count
    FROM employees e
    LEFT JOIN payroll_entries pe ON e.id = pe.employee_id
    WHERE e.id = ANY($1)
    GROUP BY e.id, e.emp_code, e.name;
  `, [[emp1.id, noHistEmp.id]]);

  const blockedList = eligCheck.rows.filter(r => Number(r.history_count) > 0);
  const eligibleList = eligCheck.rows.filter(r => Number(r.history_count) === 0);

  assert(blockedList.length === 1 && blockedList[0].id === emp1.id, 'Employee with payroll records is flagged as BLOCKED for permanent deletion');
  assert(Number(blockedList[0].history_count) >= 1, 'Blocked employee reports exact payroll records count');
  assert(eligibleList.length === 1 && eligibleList[0].id === noHistEmp.id, 'Employee with 0 payroll records is flagged as ELIGIBLE for permanent deletion');

  // ========================================================
  // TEST GROUP 4: PERMANENT DELETE ENFORCEMENT
  // ========================================================
  console.log('\n--- TEST GROUP 4: Permanent Delete Enforcement ---');

  // Attempting hard delete on employee with history: must be blocked
  let blockedCaught = false;
  const historyCheck = await db.query(`SELECT COUNT(*) as count FROM payroll_entries WHERE employee_id = $1;`, [emp1.id]);
  const hCount = Number(historyCheck.rows[0]?.count || 0);
  if (hCount > 0) {
    blockedCaught = true;
    console.log(`[PASS] Verified delete block: Employee ${emp1.name} has ${hCount} history records; hard delete is rejected with 409 error.`);
    passed++;
  } else {
    assert(false, 'Should have detected historical records for emp1');
  }

  // Hard delete on eligible employee with 0 history: succeeds
  const delRes = await db.query(`DELETE FROM employees WHERE id = $1 RETURNING id;`, [noHistEmp.id]);
  assert(delRes.rowCount === 1, 'Permanent deletion succeeded on employee with 0 payroll history');

  const checkDeleted = await db.query(`SELECT id FROM employees WHERE id = $1;`, [noHistEmp.id]);
  assert(checkDeleted.rows.length === 0, 'Permanently deleted employee no longer exists in database');

  // ========================================================
  // TEST GROUP 5: MONTHLY PAYROLL AUTO-SYNCHRONIZATION
  // ========================================================
  console.log('\n--- TEST GROUP 5: Monthly Payroll Auto-Synchronization ---');

  // Create another new active employee
  const syncEmpCode = `AUTOSYNC-${Date.now().toString().slice(-4)}`;
  const insSyncEmp = await db.query(`
    INSERT INTO employees (
      owner_user_id, created_by_user_id, emp_code, name, designation_id,
      default_gross_rate, default_special_allowance, default_thermal_allowance, default_bonus_percentage,
      is_active
    ) VALUES ($1, $1, $2, 'RAVINDER SINGH', $3, 16530, 3802, 1500, 8.33, TRUE)
    RETURNING *;
  `, [adminId, syncEmpCode, swDesigId]);
  const syncEmp = insSyncEmp.rows[0];

  // Run synchronization for the open test period
  const syncRes = await syncPeriodWithActiveEmployees(testPeriodId, adminId);
  assert(syncRes !== null, 'syncPeriodWithActiveEmployees executed successfully');
  assert(syncRes.addedCount >= 1, `syncPeriodWithActiveEmployees added ${syncRes.addedCount} new active employee(s) to open period`);

  // Verify entry was created in open period for syncEmp
  const entryCheck = await db.query(`
    SELECT * FROM payroll_entries WHERE payroll_period_id = $1 AND employee_id = $2;
  `, [testPeriodId, syncEmp.id]);
  assert(entryCheck.rows.length === 1, 'Newly added active employee now has a payroll entry in the open period');
  const entry = entryCheck.rows[0];
  assert(Number(entry.gross_salary_rate) === 16530, 'Payroll entry has correct gross rate');
  assert(Number(entry.net_payable) > 0, 'Payroll entry has calculated net payable');

  // Update employee salary rate
  await db.query(`
    UPDATE employees SET default_gross_rate = 17835 WHERE id = $1;
  `, [syncEmp.id]);

  // Re-sync open period
  const syncResUpdate = await syncPeriodWithActiveEmployees(testPeriodId, adminId);
  assert(syncResUpdate.updatedCount >= 1, 'Sync updated existing unfinalized payroll entry with new salary rate');

  const updatedEntryCheck = await db.query(`
    SELECT gross_salary_rate FROM payroll_entries WHERE payroll_period_id = $1 AND employee_id = $2;
  `, [testPeriodId, syncEmp.id]);
  assert(Number(updatedEntryCheck.rows[0]?.gross_salary_rate) === 17835, 'Payroll entry reflects updated employee salary rate');

  // Archive employee -> re-sync should remove them from open period
  await db.query(`
    UPDATE employees SET is_active = FALSE, archived_at = CURRENT_TIMESTAMP WHERE id = $1;
  `, [syncEmp.id]);

  const syncResArchive = await syncPeriodWithActiveEmployees(testPeriodId, adminId);
  assert(syncResArchive.removedCount >= 1, 'Sync removed archived employee from unfinalized payroll period');

  const afterArchiveCheck = await db.query(`
    SELECT * FROM payroll_entries WHERE payroll_period_id = $1 AND employee_id = $2;
  `, [testPeriodId, syncEmp.id]);
  assert(afterArchiveCheck.rows.length === 0, 'Archived employee is cleanly excluded from open payroll period');

  // Finalized period protection check:
  // Finalize period
  await db.query(`UPDATE payroll_periods SET status = 'Finalized' WHERE id = $1;`, [testPeriodId]);

  // Re-activate syncEmp
  await db.query(`UPDATE employees SET is_active = TRUE, archived_at = NULL WHERE id = $1;`, [syncEmp.id]);

  // Attempt sync on finalized period
  const syncFinalized = await syncPeriodWithActiveEmployees(testPeriodId, adminId);
  assert(syncFinalized.addedCount === 0 && syncFinalized.updatedCount === 0 && syncFinalized.removedCount === 0, 'Finalized payroll periods are strictly protected and NEVER modified by sync');

  // ========================================================
  // TEST GROUP 6: EXCEL / CSV TEMPLATE & PARSING INTEGRITY
  // ========================================================
  console.log('\n--- TEST GROUP 6: Excel / CSV Template & Parsing Integrity ---');
  const workbook = ExcelImporter.generateTemplateWorkbook();
  assert(workbook.worksheets.length >= 1, 'ExcelImporter generates valid Excel template workbook');
  const ws1 = workbook.getWorksheet(1);
  assert(ws1.name === 'Employee Master Template', 'Template has Employee Master Template sheet');

  // Clean up test period and test entries
  await db.query(`DELETE FROM payroll_entries WHERE payroll_period_id = $1;`, [testPeriodId]);
  await db.query(`DELETE FROM payroll_periods WHERE id = $1;`, [testPeriodId]);

  console.log('\n========================================================================');
  console.log(`TEST SUITE COMPLETE: ${passed} PASSED, ${failed} FAILED`);
  console.log('========================================================================\n');

  if (failed > 0) process.exit(1);
}

runArchiveDeleteSyncTests().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
