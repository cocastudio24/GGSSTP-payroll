const { db } = require('../dist/database/db');

async function mergeSodhiContractors() {
  console.log('================================================================');
  console.log('CONSOLIDATING M/S SODHI ERECTORS CONTRACTORS');
  console.log('================================================================');

  await db.init();

  // 1. Inspect existing Sodhi Erectors contractors
  const sodhiRes = await db.query(`SELECT id, name FROM contractors WHERE name ILIKE '%sodhi%erectors%' ORDER BY id ASC;`);
  console.log('Found Sodhi Erectors records:', sodhiRes.rows);

  if (sodhiRes.rows.length === 0) {
    console.log('No Sodhi Erectors contractor found. Creating standard "M/s Sodhi Erectors"...');
    const created = await db.query(`INSERT INTO contractors (name) VALUES ('M/s Sodhi Erectors') RETURNING id, name;`);
    console.log('Created:', created.rows[0]);
    process.exit(0);
  }

  // Choose primary contractor: prefer exact "M/s Sodhi Erectors" or the lowest ID
  const primary = sodhiRes.rows.find(r => r.name.trim().toLowerCase() === 'm/s sodhi erectors') || sodhiRes.rows[0];
  const primaryId = primary.id;
  const duplicateIds = sodhiRes.rows.filter(r => r.id !== primaryId).map(r => r.id);

  console.log(`Primary Contractor designated: ID ${primaryId} (${primary.name})`);
  console.log(`Duplicate Contractor IDs to merge: [${duplicateIds.join(', ')}]`);

  if (duplicateIds.length > 0) {
    // 2. Count employees before migration
    const beforeCountRes = await db.query(
      `SELECT COUNT(*) as count FROM employees WHERE contractor_id = ANY($1::int[]);`,
      [[primaryId, ...duplicateIds]]
    );
    console.log(`Total employees assigned to all Sodhi variants: ${beforeCountRes.rows[0].count}`);

    // 3. Reassign all employees to primaryId
    const updateRes = await db.query(
      `UPDATE employees SET contractor_id = $1 WHERE contractor_id = ANY($2::int[]) RETURNING id;`,
      [primaryId, duplicateIds]
    );
    console.log(`Reassigned ${updateRes.rowCount || updateRes.rows.length} employees to Contractor ID ${primaryId}.`);

    // 4. Delete the duplicate contractor records
    const deleteRes = await db.query(
      `DELETE FROM contractors WHERE id = ANY($1::int[]) RETURNING id, name;`,
      [duplicateIds]
    );
    console.log(`Deleted ${deleteRes.rowCount || deleteRes.rows.length} duplicate contractor records:`, deleteRes.rows);

    // 5. Ensure the primary contractor's name is cleanly set to "M/s Sodhi Erectors"
    await db.query(`UPDATE contractors SET name = 'M/s Sodhi Erectors' WHERE id = $1;`, [primaryId]);

    // 6. Record in Audit Log
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'MERGE_CONTRACTORS', 'CONTRACTOR', $2, $3);
    `, [
      'admin',
      String(primaryId),
      `Merged 4 duplicate Sodhi Erectors contractors into single contractor "M/s Sodhi Erectors" (ID ${primaryId}). Reassigned ${updateRes.rowCount || updateRes.rows.length} employees.`
    ]);
  }

  // 7. Verify final state
  const finalCheck = await db.query(`
    SELECT c.id, c.name, COUNT(e.id) as employee_count
    FROM contractors c
    LEFT JOIN employees e ON e.contractor_id = c.id
    WHERE c.name ILIKE '%sodhi%'
    GROUP BY c.id, c.name;
  `);
  console.log('================================================================');
  console.log('FINAL SODHI ERECTORS STATE IN DATABASE:');
  console.log(finalCheck.rows);

  const allContractors = await db.query(`
    SELECT c.id, c.name, COUNT(e.id) as employee_count
    FROM contractors c
    LEFT JOIN employees e ON e.contractor_id = c.id
    GROUP BY c.id, c.name
    ORDER BY c.id ASC;
  `);
  console.log('================================================================');
  console.log('ALL CONTRACTORS IN DATABASE:');
  console.table(allContractors.rows);
  console.log('================================================================');

  process.exit(0);
}

mergeSodhiContractors().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
