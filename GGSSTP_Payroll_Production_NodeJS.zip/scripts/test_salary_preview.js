const fs = require('fs');
const path = require('path');

async function testSalaryPreview() {
  console.log('Testing Salary Upload Preview Endpoint & Logic...');
  const baseUrl = 'http://127.0.0.1:5000';

  // 1. Health check
  const healthRes = await fetch(`${baseUrl}/api/health`);
  console.log('Health check status:', healthRes.status);
  if (!healthRes.ok) throw new Error('Server not reachable');

  // 2. Login
  const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'admin@ggsstp2026' })
  });
  const loginData = await loginRes.json();
  if (!loginRes.ok) throw new Error(`Login failed: ${loginData.error}`);
  const token = loginData.token;
  console.log('Logged in successfully as:', loginData.user.username);

  // 3. Test /api/employees/salary-upload-preview with reference sheet
  const refPath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
  const fileBytes = fs.readFileSync(refPath);
  const blob = new Blob([fileBytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

  const formData = new FormData();
  formData.append('file', blob, 'SALARY SHEET-for EPF Sepf 2026.xlsx');
  formData.append('sheetName', 'MM-1');

  console.log('Sending POST to /api/employees/salary-upload-preview...');
  const prevRes = await fetch(`${baseUrl}/api/employees/salary-upload-preview`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: formData
  });

  const prevData = await prevRes.json();
  console.log('Response HTTP Status:', prevRes.status);
  console.log('Response payload keys:', Object.keys(prevData));

  if (!prevRes.ok) {
    throw new Error(`Salary preview failed: ${prevData.error}`);
  }

  console.log('Matched rows count:', prevData.matchedCount);
  console.log('Unmatched rows count:', prevData.unmatchedCount);
  if (prevData.matchedRows && prevData.matchedRows.length > 0) {
    console.log('Sample matched employee:', {
      empCode: prevData.matchedRows[0].empCode,
      name: prevData.matchedRows[0].name,
      oldGross: prevData.matchedRows[0].oldGross,
      newGross: prevData.matchedRows[0].newGross,
      oldNetPayable: prevData.matchedRows[0].oldNetPayable,
      newNetPayable: prevData.matchedRows[0].newNetPayable
    });
  }

  // 4. Test /api/employees/salary-upload-commit
  console.log('\nTesting /api/employees/salary-upload-commit...');
  const commitRes = await fetch(`${baseUrl}/api/employees/salary-upload-commit`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ rows: prevData.matchedRows })
  });
  const commitData = await commitRes.json();
  console.log('Commit HTTP Status:', commitRes.status);
  console.log('Commit Message:', commitData.message);
  console.log('Commit Result:', commitData.result);
  if (!commitRes.ok) throw new Error(`Salary commit failed: ${commitData.error}`);

  // 5. Test sheet EMC
  const formDataEmc = new FormData();
  formDataEmc.append('file', blob, 'SALARY SHEET-for EPF Sepf 2026.xlsx');
  formDataEmc.append('sheetName', 'EMC');

  console.log('\nTesting sheet EMC on /api/employees/salary-upload-preview...');
  const prevResEmc = await fetch(`${baseUrl}/api/employees/salary-upload-preview`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: formDataEmc
  });
  const prevDataEmc = await prevResEmc.json();
  console.log('EMC Status:', prevResEmc.status);
  console.log('EMC Matched rows count:', prevDataEmc.matchedCount);
  if (!prevResEmc.ok) throw new Error(`EMC preview failed: ${prevDataEmc.error}`);

  console.log('\n✅ ALL SALARY PREVIEW & COMMIT TESTS PASSED WITH ZERO ERRORS!');
}

testSalaryPreview().catch(err => {
  console.error('\n❌ TEST FAILED:', err);
  process.exit(1);
});
