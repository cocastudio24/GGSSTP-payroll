const { db } = require('../dist/database/db');

async function inspectSchema() {
  await db.init();
  const res = await db.query(`
    SELECT table_name, column_name, data_type 
    FROM information_schema.columns 
    WHERE table_schema = 'public' 
    ORDER BY table_name, ordinal_position;
  `);
  const tables = {};
  res.rows.forEach(r => {
    if (!tables[r.table_name]) tables[r.table_name] = [];
    tables[r.table_name].push(`${r.column_name} (${r.data_type})`);
  });
  console.log(JSON.stringify(tables, null, 2));
  process.exit(0);
}

inspectSchema().catch(e => { console.error(e); process.exit(1); });
