const { db } = require('../dist/database/db');

async function main() {
  await db.init();
  const empCols = await db.query(
    "SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'employees' ORDER BY ordinal_position"
  );
  console.log('Employee columns:\n', empCols.rows.map(r => `${r.column_name} (${r.data_type})`).join(', '));

  const peCols = await db.query(
    "SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'payroll_entries' ORDER BY ordinal_position"
  );
  console.log('\nPayroll entry columns:\n', peCols.rows.map(r => `${r.column_name} (${r.data_type})`).join(', '));

  await db.close();
}

main().catch(console.error);
