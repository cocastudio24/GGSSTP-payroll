const { db } = require('../dist/database/db');

async function testDashboardApi() {
  await db.init();

  // Test Super Admin stats query
  console.log('--- Testing Super Admin Dashboard Stats ---');
  const periodRow = (await db.query(`SELECT * FROM payroll_periods ORDER BY year DESC, month DESC, id DESC LIMIT 1;`)).rows[0];
  console.log('Period:', periodRow ? `${periodRow.month_name} ${periodRow.year} (ID: ${periodRow.id})` : 'None');

  // Employee overview
  const empCounts = (await db.query(`
    SELECT 
      COUNT(*) as total,
      COUNT(CASE WHEN is_active = TRUE THEN 1 END) as active,
      COUNT(CASE WHEN is_active = FALSE THEN 1 END) as inactive,
      COUNT(CASE WHEN bank_account IS NULL OR bank_account = '' THEN 1 END) as missing_bank,
      COUNT(CASE WHEN uan IS NULL OR uan = '' THEN 1 END) as missing_uan,
      COUNT(CASE WHEN esi_number IS NULL OR esi_number = '' THEN 1 END) as missing_esi
    FROM employees
    WHERE archived_at IS NULL;
  `)).rows[0];
  console.log('Employee Overview:', empCounts);

  // Circle workforce
  const allEmployeesRes = await db.query(`
    SELECT 
      e.id, e.name, e.emp_code, e.uan, e.bank_account, e.ifsc, e.esi_number,
      COALESCE(d.alias, 'SW') as designation_alias, 
      COALESCE(d.name, 'Skilled') as designation_name,
      c.id as contractor_id, 
      COALESCE(c.name, 'Direct / Unassigned') as contractor_name,
      cir.id as circle_id, 
      COALESCE(cir.name, 'General Circle') as circle_name,
      COALESCE(pe.present_days, 0) as present_days,
      COALESCE(pe.gross_salary_rate, e.default_gross_rate, dsr.gross_salary_rate, 16530) as gross_salary_rate,
      COALESCE(pe.total_basic, e.default_gross_rate, 0) as total_basic,
      COALESCE(pe.thermal_allowance, 0) as thermal_allowance,
      COALESCE(pe.perf_allowance_days, 0) as perf_allowance_days,
      COALESCE(pe.bonus, 0) as bonus,
      COALESCE(pe.total_earnings_before_bonus, 0) as total_earnings_before_bonus,
      COALESCE(pe.gross_total, 0) as gross_total,
      COALESCE(pe.employee_epf_12, 0) as employee_epf_12,
      COALESCE(pe.employee_esi_075, 0) as employee_esi_075,
      COALESCE(pe.employee_lwf, 0) as employee_lwf,
      COALESCE(pe.total_employee_deductions, 0) as total_employee_deductions,
      COALESCE(pe.net_payable, 0) as net_payable
    FROM employees e
    LEFT JOIN designations d ON e.designation_id = d.id
    LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
    LEFT JOIN contractors c ON e.contractor_id = c.id
    LEFT JOIN circles cir ON e.circle_id = cir.id
    LEFT JOIN payroll_entries pe ON pe.employee_id = e.id AND pe.payroll_period_id = ${Number(periodRow.id)}
    WHERE e.is_active = TRUE AND e.archived_at IS NULL
    ORDER BY e.name ASC;
  `);

  console.log(`Total live employees queried: ${allEmployeesRes.rows.length}`);

  // Test dynamic circle aggregation
  const circleGroups = {};
  for (const emp of allEmployeesRes.rows) {
    const cName = emp.circle_name || 'General Circle';
    if (!circleGroups[cName]) {
      circleGroups[cName] = {
        circleName: cName,
        totalCount: 0,
        totalBasic: 0,
        totalEmployeeDeductions: 0,
        totalEmployeeEpf: 0,
        totalEmployeeEsi: 0,
        totalEmployeeLwf: 0,
        totalNetPayable: 0,
        employees: []
      };
    }
    const g = circleGroups[cName];
    g.totalCount++;
    g.totalBasic += Number(emp.total_basic || 0);
    g.totalEmployeeDeductions += Number(emp.total_employee_deductions || 0);
    g.totalEmployeeEpf += Number(emp.employee_epf_12 || 0);
    g.totalEmployeeEsi += Number(emp.employee_esi_075 || 0);
    g.totalEmployeeLwf += Number(emp.employee_lwf || 0);
    g.totalNetPayable += Number(emp.net_payable || 0);
    g.employees.push(emp);
  }

  console.log('Circles grouped in Dashboard:');
  for (const [cName, g] of Object.entries(circleGroups)) {
    console.log(`  Circle [${cName}]: ${g.totalCount} staff, Net: ₹${g.totalNetPayable.toLocaleString('en-IN')}`);
  }

  // Designation distribution
  const desRes = await db.query(`
    SELECT 
      d.id,
      d.name as designation,
      d.alias,
      COUNT(e.id) as count
    FROM designations d
    LEFT JOIN employees e ON e.designation_id = d.id AND e.is_active = TRUE AND e.archived_at IS NULL
    GROUP BY d.id, d.name, d.alias
    HAVING COUNT(e.id) > 0
    ORDER BY count DESC, d.name ASC;
  `);
  console.log('Designations in Dashboard:', desRes.rows);

  console.log('\nDashboard API logic verification completed successfully!');
  process.exit(0);
}

testDashboardApi().catch(err => {
  console.error('API test failed:', err);
  process.exit(1);
});
