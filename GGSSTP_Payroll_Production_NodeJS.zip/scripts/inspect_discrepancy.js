const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });
const sheet = workbook.Sheets['MM-1'];

[18, 20].forEach(rowNum => {
  console.log(`\n--- ROW ${rowNum} in MM-1 ---`);
  const r = rowNum - 1;
  ['AG', 'AH', 'AI', 'AO', 'AV'].forEach(col => {
    const c = XLSX.utils.decode_col(col);
    const cell = sheet[XLSX.utils.encode_cell({ r, c })];
    console.log(`Col ${col} (${cell ? cell.t : 'empty'}): val = ${cell ? cell.v : 'N/A'}, formula = ${cell ? cell.f : 'N/A'}, formatted = ${cell ? cell.w : 'N/A'}`);
  });
});
