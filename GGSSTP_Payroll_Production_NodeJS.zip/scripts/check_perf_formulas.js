const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });

function checkPerfFormulas(sheetName, colLetter, startRow, endRow) {
  const sheet = workbook.Sheets[sheetName];
  console.log(`Checking sheet ${sheetName} column ${colLetter}:`);
  const c = XLSX.utils.decode_col(colLetter);
  for (let r = startRow; r <= endRow; r++) {
    const cell = sheet[XLSX.utils.encode_cell({ r, c })];
    if (cell) {
      console.log(`Row ${r + 1}: f = ${cell.f}, v = ${cell.v}`);
    }
  }
}

checkPerfFormulas('MM-1', 'AH', 1, 21);
checkPerfFormulas('EMC', 'AK', 2, 46);
