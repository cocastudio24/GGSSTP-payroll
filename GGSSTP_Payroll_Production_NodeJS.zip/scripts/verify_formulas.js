const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });

function calculatePayrollRow(params) {
  const {
    designation,
    totalDays,
    presentDays,
    perfAllowanceMonthly = 0,
    bonus = 0,
    employerLwf = 20,
    employeeLwf = 5
  } = params;

  // Designation rates
  const rates = {
    'USW': { gross: 14408, special: 3314 },
    'SEMI SW': { gross: 15395, special: 3541 },
    'SW': { gross: 16530, special: 3802 },
    'HSW': { gross: 17835, special: 4102 }
  };

  const desRate = rates[designation] || { gross: 0, special: 0 };
  const grossSalary = desRate.gross;
  const specialAllowance = desRate.special;

  // Proportioned salary
  const proportionedSalary = totalDays > 0 ? (grossSalary / totalDays * presentDays) : 0;

  // Total Basic = ROUND((Gross + Special) * Present / Total, 0)
  const totalBasic = totalDays > 0 ? Math.round((grossSalary + specialAllowance) * presentDays / totalDays) : 0;

  // Thermal Allowance = ROUND(1500 * Present / Total, 0)
  const thermalAllowance = totalDays > 0 ? Math.round(1500 * presentDays / totalDays) : 0;

  // Performance Allowance Days wise = Monthly / Total * Present (Excel doesn't round this in MM-1/EMC formula: AG2/Z2*AA2)
  const perfAllowanceDaysWise = totalDays > 0 ? (perfAllowanceMonthly / totalDays * presentDays) : 0;

  // Total (Earnings before bonus) = Total Basic + Thermal + Performance Days wise
  const totalEarningsBeforeBonus = totalBasic + thermalAllowance + perfAllowanceDaysWise;

  // Employer EPF 12% = ROUND(IF(ProportionedSalary < 25000, ProportionedSalary * 0.12, 3000), 0)
  const employerEpf12 = Math.round(proportionedSalary < 25000 ? (proportionedSalary * 0.12) : 3000);

  // Employer EPF 1% = ROUND(IF(ProportionedSalary < 25000, ProportionedSalary * 0.01, 250), 0)
  const employerEpf1 = Math.round(proportionedSalary < 25000 ? (proportionedSalary * 0.01) : 250);

  // Employer ESI 3.25% = ROUND(IF(totalEarningsBeforeBonus < 21000, totalEarningsBeforeBonus * 0.0325, 0), 0)
  const employerEsi325 = Math.round(totalEarningsBeforeBonus < 21000 ? (totalEarningsBeforeBonus * 0.0325) : 0);

  // Gross Total (Source formula = SUM(TOTAL:LWF) = totalEarningsBeforeBonus + bonus + employerEpf12 + employerEpf1 + employerEsi325 + employerLwf)
  const grossTotal = totalEarningsBeforeBonus + bonus + employerEpf12 + employerEpf1 + employerEsi325 + employerLwf;

  // Employee EPF Deduction 12% = Employer EPF 12%
  const employeeEpf12 = employerEpf12;

  // Employee ESI Deduction 0.75% = ROUND(IF(totalEarningsBeforeBonus < 21000, totalEarningsBeforeBonus * 0.0075, 0), 0)
  const employeeEsi075 = Math.round(totalEarningsBeforeBonus < 21000 ? (totalEarningsBeforeBonus * 0.0075) : 0);

  // Total Employee Deductions = Employee EPF + Employee ESI + Employee LWF
  const totalEmployeeDeductions = employeeEpf12 + employeeEsi075 + employeeLwf;

  // Total Employer Contributions (Column AT in MM-1 / AW in EMC) = employerEpf12 + employerEpf1 + employerEsi325 + employerLwf
  const totalEmployerContributions = employerEpf12 + employerEpf1 + employerEsi325 + employerLwf;

  // Combined Deductions in Excel (Column AU in MM-1 / AX in EMC) = totalEmployeeDeductions + totalEmployerContributions
  const combinedDeductions = totalEmployeeDeductions + totalEmployerContributions;

  // Net Payable Salary = Gross Total - Combined Deductions = (totalEarningsBeforeBonus + bonus) - totalEmployeeDeductions
  const netPayable = grossTotal - combinedDeductions;

  return {
    grossSalary,
    specialAllowance,
    proportionedSalary,
    totalBasic,
    thermalAllowance,
    perfAllowanceDaysWise,
    totalEarningsBeforeBonus,
    employerEpf12,
    employerEpf1,
    employerEsi325,
    employerLwf,
    grossTotal,
    employeeEpf12,
    employeeEsi075,
    employeeLwf,
    totalEmployeeDeductions,
    totalEmployerContributions,
    combinedDeductions,
    netPayable
  };
}

function verifySheet(sheetName, config) {
  const sheet = workbook.Sheets[sheetName];
  const range = XLSX.utils.decode_range(sheet['!ref']);
  console.log(`\n======================================================`);
  console.log(`VERIFYING SHEET: ${sheetName}`);

  let totalChecked = 0;
  let discrepancies = [];

  for (let r = config.startRow; r <= range.e.r; r++) {
    const getVal = (col) => {
      const cell = sheet[XLSX.utils.encode_cell({ r, c: col })];
      return cell ? cell.v : null;
    };

    const empCode = getVal(config.empCode);
    const empName = getVal(config.empName);
    if (!empCode && !empName) continue;

    const designation = String(getVal(config.designation) || '').trim();
    const totalDays = Number(getVal(config.totalDays)) || 0;
    const presentDays = Number(getVal(config.presentDays)) || 0;
    const perfAllowanceMonthly = Number(getVal(config.perfMonthly)) || 0;
    const bonus = Number(getVal(config.bonus)) || 0;

    const calc = calculatePayrollRow({
      designation,
      totalDays,
      presentDays,
      perfAllowanceMonthly,
      bonus
    });

    totalChecked++;

    // Compare with sheet values
    const sheetGross = Number(getVal(config.grossSalary));
    const sheetBasic = Number(getVal(config.totalBasic));
    const sheetThermal = Number(getVal(config.thermal));
    const sheetPerfDays = Number(getVal(config.perfDays));
    const sheetTotalEarnings = Number(getVal(config.totalEarnings));
    const sheetEmpEpf = Number(getVal(config.employerEpf));
    const sheetEmpEpf1 = Number(getVal(config.employerEpf1));
    const sheetEmpEsi = Number(getVal(config.employerEsi));
    const sheetGrossTotal = Number(getVal(config.grossTotal));
    const sheetEmployeeDeduction = Number(getVal(config.employeeDeduction));
    const sheetNetPayable = Number(getVal(config.netPayable));

    const diffs = [];
    if (Math.abs(calc.grossSalary - sheetGross) > 0.01) diffs.push(`GrossSalary: calc ${calc.grossSalary} vs sheet ${sheetGross}`);
    if (Math.abs(calc.totalBasic - sheetBasic) > 0.01) diffs.push(`TotalBasic: calc ${calc.totalBasic} vs sheet ${sheetBasic}`);
    if (Math.abs(calc.thermalAllowance - sheetThermal) > 0.01) diffs.push(`Thermal: calc ${calc.thermalAllowance} vs sheet ${sheetThermal}`);
    if (Math.abs(calc.perfAllowanceDaysWise - sheetPerfDays) > 0.01) diffs.push(`PerfDays: calc ${calc.perfAllowanceDaysWise} vs sheet ${sheetPerfDays}`);
    if (Math.abs(calc.totalEarningsBeforeBonus - sheetTotalEarnings) > 0.01) diffs.push(`TotalEarnings: calc ${calc.totalEarningsBeforeBonus} vs sheet ${sheetTotalEarnings}`);
    if (Math.abs(calc.employerEpf12 - sheetEmpEpf) > 0.01) diffs.push(`EmployerEPF12: calc ${calc.employerEpf12} vs sheet ${sheetEmpEpf}`);
    if (Math.abs(calc.employerEpf1 - sheetEmpEpf1) > 0.01) diffs.push(`EmployerEPF1: calc ${calc.employerEpf1} vs sheet ${sheetEmpEpf1}`);
    if (Math.abs(calc.employerEsi325 - sheetEmpEsi) > 0.01) diffs.push(`EmployerESI: calc ${calc.employerEsi325} vs sheet ${sheetEmpEsi}`);
    if (Math.abs(calc.grossTotal - sheetGrossTotal) > 0.01) diffs.push(`GrossTotal: calc ${calc.grossTotal} vs sheet ${sheetGrossTotal}`);
    if (Math.abs(calc.totalEmployeeDeductions - sheetEmployeeDeduction) > 0.01) diffs.push(`EmpDeduction: calc ${calc.totalEmployeeDeductions} vs sheet ${sheetEmployeeDeduction}`);
    if (Math.abs(calc.netPayable - sheetNetPayable) > 0.01) diffs.push(`NetPayable: calc ${calc.netPayable} vs sheet ${sheetNetPayable}`);

    if (diffs.length > 0) {
      discrepancies.push({
        row: r + 1,
        empCode,
        empName,
        designation,
        totalDays,
        presentDays,
        diffs
      });
    }
  }

  console.log(`Total employees checked: ${totalChecked}`);
  console.log(`Employees with discrepancies: ${discrepancies.length}`);
  if (discrepancies.length > 0) {
    console.log(`Sample discrepancies (first 5):`, JSON.stringify(discrepancies.slice(0, 5), null, 2));
  } else {
    console.log(`PERFECT MATCH! 100% of employees match the Excel reference sheet!`);
  }
}

// MM-1 config (0-indexed columns):
// A=0, B=1, E=4 (desig), Z=25 (days), AA=26 (present), AB=27 (gross), AE=30 (total basic), AF=31 (thermal),
// AG=32 (perf monthly), AH=33 (perf days), AI=34 (total), AJ=35 (bonus), AK=36 (emp epf), AL=37 (emp epf 1%),
// AM=38 (emp esi), AN=39 (lwf), AO=40 (gross total), AS=44 (emp ded), AV=47 (net payable)
verifySheet('MM-1', {
  startRow: 1,
  empCode: 0,
  empName: 1,
  designation: 4,
  totalDays: 25,
  presentDays: 26,
  grossSalary: 27,
  totalBasic: 30,
  thermal: 31,
  perfMonthly: 32,
  perfDays: 33,
  totalEarnings: 34,
  bonus: 35,
  employerEpf: 36,
  employerEpf1: 37,
  employerEsi: 38,
  grossTotal: 40,
  employeeDeduction: 44,
  netPayable: 47
});

// EMC config (0-indexed columns):
// A=0 (Sr), B=1 (Sr), C=2 (circle), D=3 (cell), E=4 (name), H=7 (desig), AC=28 (days), AD=29 (present),
// AE=30 (gross), AH=33 (total basic), AI=34 (thermal), AJ=35 (perf monthly), AK=36 (perf days), AL=37 (total),
// AM=38 (bonus), AN=39 (emp epf), AO=40 (emp epf 1%), AP=41 (emp esi), AR=43 (gross total), AV=47 (emp ded),
// AY=50 (net payable)
verifySheet('EMC', {
  startRow: 2,
  empCode: 0,
  empName: 4,
  designation: 7,
  totalDays: 28,
  presentDays: 29,
  grossSalary: 30,
  totalBasic: 33,
  thermal: 34,
  perfMonthly: 35,
  perfDays: 36,
  totalEarnings: 37,
  bonus: 38,
  employerEpf: 39,
  employerEpf1: 40,
  employerEsi: 41,
  grossTotal: 43,
  employeeDeduction: 47,
  netPayable: 50
});
