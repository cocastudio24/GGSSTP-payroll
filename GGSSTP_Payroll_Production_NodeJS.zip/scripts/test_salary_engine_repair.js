const fs = require('fs');
const path = require('path');

async function testSalaryEngineRepair() {
  console.log('=== TESTING SALARY ENGINE REPAIR & PAYROLL ENHANCEMENTS ===');
  const baseUrl = 'http://127.0.0.1:5000';

  // 1. Health check
  const healthRes = await fetch(`${baseUrl}/api/health`);
  if (!healthRes.ok) throw new Error('Health check failed');
  console.log('[PASS] Server healthcheck: 200 OK');

  // 2. Login
  const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'admin@ggsstp2026' })
  });
  const loginData = await loginRes.json();
  if (!loginRes.ok) throw new Error(`Login failed: ${loginData.error}`);
  const token = loginData.token;
  console.log('[PASS] Logged in successfully as admin.');

  // 3. Get periods
  const periodsRes = await fetch(`${baseUrl}/api/payroll/periods`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const periodsData = await periodsRes.json();
  const periods = periodsData.periods;
  console.log(`[PASS] Fetched ${periods.length} payroll periods.`);
  if (periods.length === 0) throw new Error('No payroll periods found');
  const period = periods[0];

  // 4. Get entries for period
  const entriesRes = await fetch(`${baseUrl}/api/payroll/entries?periodId=${period.id}&limit=10`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const entriesData = await entriesRes.json();
  const entries = entriesData.entries;
  console.log(`[PASS] Fetched ${entries.length} entries for period ${period.month_name} ${period.year}.`);
  if (entries.length === 0) throw new Error('No entries found');
  const entry = entries[0];

  // 5. Test Direct Net Payable Edit
  console.log(`Testing Direct Net Payable Edit for entry ${entry.id} (${entry.emp_name})...`);
  const originalNet = entry.net_payable;
  const targetNet = 5555.50;
  const editNetRes = await fetch(`${baseUrl}/api/payroll/entries/${entry.id}/net-payable`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      netPayable: targetNet,
      isOverridden: true,
      reason: 'Automated test direct edit'
    })
  });
  const editNetData = await editNetRes.json();
  if (!editNetRes.ok) throw new Error(`Direct edit failed: ${editNetData.error}`);
  console.log(`[PASS] Direct edit updated Net Payable to: ₹${editNetData.entry.net_payable} (locked: ${editNetData.entry.is_overridden})`);

  // 6. Test Generate Net Payable (mode: formula, round_50_up)
  console.log('Testing Generate Net Payable (formula mode with round_50_up)...');
  const genFormulaRes = await fetch(`${baseUrl}/api/payroll/periods/${period.id}/generate-salaries`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      scope: 'all',
      mode: 'formula',
      roundingMode: 'round_50_up'
    })
  });
  const genFormulaData = await genFormulaRes.json();
  if (!genFormulaRes.ok) throw new Error(`Generate formula failed: ${genFormulaData.error}`);
  console.log(`[PASS] Formula generation completed: updated ${genFormulaData.updatedCount} entries.`);

  // 7. Test Generate Net Payable (mode: adopt_excel)
  console.log('Testing Generate Net Payable (adopt_excel mode)...');
  const genAdoptRes = await fetch(`${baseUrl}/api/payroll/periods/${period.id}/generate-salaries`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      scope: 'all',
      mode: 'adopt_excel'
    })
  });
  const genAdoptData = await genAdoptRes.json();
  if (!genAdoptRes.ok) throw new Error(`Adopt Excel failed: ${genAdoptData.error}`);
  console.log(`[PASS] Adopt Excel completed: updated ${genAdoptData.updatedCount} entries to exact Excel sheets.`);

  // 8. Test Clear Single Salary
  console.log(`Testing Clear Single Salary for entry ${entry.id}...`);
  const clearSingleRes = await fetch(`${baseUrl}/api/payroll/entries/${entry.id}/salary`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const clearSingleData = await clearSingleRes.json();
  if (!clearSingleRes.ok) throw new Error(`Clear salary failed: ${clearSingleData.error}`);
  console.log(`[PASS] Cleared salary for entry ${entry.id}: Net Payable is now ₹${clearSingleData.entry.net_payable}, present days: ${clearSingleData.entry.present_days}`);

  // 9. Test Bulk Delete/Clear Salaries
  console.log('Testing Bulk Delete/Clear Salaries for selected entry...');
  const bulkDeleteRes = await fetch(`${baseUrl}/api/payroll/periods/${period.id}/bulk-delete-salaries`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      entryIds: [entry.id]
    })
  });
  const bulkDeleteData = await bulkDeleteRes.json();
  if (!bulkDeleteRes.ok) throw new Error(`Bulk clear failed: ${bulkDeleteData.error}`);
  console.log(`[PASS] Bulk cleared salaries for ${bulkDeleteData.clearedCount} entries.`);

  // Re-generate formulas so period is restored
  await fetch(`${baseUrl}/api/payroll/periods/${period.id}/generate-salaries`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      scope: 'all',
      mode: 'formula',
      roundingMode: 'round_50_up'
    })
  });

  // 10. Test Reconciliation Reset
  console.log('Testing POST /api/reconciliation/reset...');
  const resetRes = await fetch(`${baseUrl}/api/reconciliation/reset`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      periodId: period.id,
      resetRules: true
    })
  });
  const resetData = await resetRes.json();
  if (!resetRes.ok) throw new Error(`Reconciliation reset failed: ${resetData.error}`);
  console.log(`[PASS] Reconciliation reset: ${resetData.message}`);

  console.log('\n✅ ALL SALARY ENGINE REPAIR & PAYROLL TESTS PASSED WITH 100% SUCCESS!');
}

testSalaryEngineRepair().catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
