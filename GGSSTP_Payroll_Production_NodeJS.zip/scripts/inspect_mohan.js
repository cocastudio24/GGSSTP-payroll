const XLSX = require('xlsx');
const wb = XLSX.readFile('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const sheet = wb.Sheets['EMC'];
const range = XLSX.utils.decode_range(sheet['!ref']);

for (let r = 0; r <= range.e.r; r++) {
  const rowVals = [];
  for (let c = 0; c <= range.e.c; c++) {
    rowVals.push(sheet[XLSX.utils.encode_cell({ r, c })]?.v);
  }
  const rowStr = rowVals.join(' | ');
  if (rowStr.toUpperCase().includes('MOHAN')) {
    console.log(`Row ${r}:`);
    console.log(`  Col 0: ${rowVals[0]}`);
    console.log(`  Col 1: ${rowVals[1]}`);
    console.log(`  Col 2: ${rowVals[2]}`);
    console.log(`  Col 3: ${rowVals[3]}`);
    console.log(`  Col 4: ${rowVals[4]}`);
    console.log(`  Col 5: ${rowVals[5]}`);
    console.log(`  Col 6: ${rowVals[6]}`);
    console.log(`  Col 18 (Bank): ${rowVals[18]}`);
    console.log(`  Col 19 (IFSC): ${rowVals[19]}`);
    console.log(`  Col 20 (ESI): ${rowVals[20]}`);
  }
}
