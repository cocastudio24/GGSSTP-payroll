const http = require('http');
const { spawn } = require('child_process');
const path = require('path');

const BASE_URL = 'http://localhost:5000';

async function request(urlPath, options = {}) {
  const url = `${BASE_URL}${urlPath}`;
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const res = await fetch(url, {
    method: options.method || 'GET',
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, ok: res.ok, data };
}

async function login(username, password) {
  const res = await request('/api/auth/login', {
    method: 'POST',
    body: { username, password }
  });
  if (!res.ok || !res.data.token) {
    throw new Error(`Failed to login as ${username}: ${JSON.stringify(res.data)}`);
  }
  return { token: res.data.token, user: res.data.user };
}

async function isServerRunning() {
  try {
    const res = await fetch(`${BASE_URL}/api/health`).catch(() => null);
    return res && (res.status === 200 || res.status === 404);
  } catch {
    return false;
  }
}

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function main() {
  console.log('================================================================');
  console.log('MULTI-USER CELL1/CELL2/CELL3 & ADMIN DATA INTEGRITY VERIFICATION');
  console.log('================================================================\n');

  let serverProcess = null;
  const running = await isServerRunning();
  if (!running) {
    console.log('[1/7] Starting backend server (dist/server.js)...');
    serverProcess = spawn('node', ['dist/server.js'], {
      cwd: path.resolve(__dirname, '..'),
      stdio: 'inherit'
    });
    // Wait for server to bind
    for (let i = 0; i < 20; i++) {
      await sleep(1000);
      if (await isServerRunning()) {
        console.log(' Backend server bound successfully to port 5000.');
        break;
      }
    }
  } else {
    console.log('[1/7] Backend server is already running.');
  }

  try {
    // 1. Login as ADMIN
    console.log('\n[2/7] Logging in as admin...');
    const adminAuth = await login('admin', 'admin@ggsstp2026');
    console.log(` Admin logged in: ${adminAuth.user.fullName} (${adminAuth.user.role})`);

    // Get periods
    const periodsRes = await request('/api/payroll/periods', {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    if (!periodsRes.ok || !periodsRes.data.periods || periodsRes.data.periods.length === 0) {
      throw new Error(`No payroll periods found: ${JSON.stringify(periodsRes.data)}`);
    }
    const targetPeriod = periodsRes.data.periods[0];
    console.log(` Target Period: ID ${targetPeriod.id} (${targetPeriod.month_name} ${targetPeriod.year}), Total Days: ${targetPeriod.total_days}`);

    // Get existing entries as admin
    const initialEntriesRes = await request(`/api/payroll/entries?periodId=${targetPeriod.id}`, {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    const totalEntriesBefore = initialEntriesRes.data.entries ? initialEntriesRes.data.entries.length : 0;
    console.log(` Initial entry count in Period ${targetPeriod.id}: ${totalEntriesBefore} records.`);
    if (totalEntriesBefore < 3) {
      throw new Error(`Need at least 3 entries to test multi-user isolation. Found: ${totalEntriesBefore}`);
    }

    const entry1 = initialEntriesRes.data.entries[0];
    const entry2 = initialEntriesRes.data.entries[1];
    const entry3 = initialEntriesRes.data.entries[2];

    // 2. Login as CELL1 (Baljit Kaur)
    console.log('\n[3/7] Testing cell1 (Baljit Kaur)...');
    const cell1Auth = await login('cell1', 'cell1@ggsstp2026');
    console.log(` cell1 logged in: ${cell1Auth.user.fullName} (${cell1Auth.user.role})`);

    // Verify cell1 can see all period entries
    const cell1Entries = await request(`/api/payroll/entries?periodId=${targetPeriod.id}`, {
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    console.log(` cell1 entries query returned: ${cell1Entries.data.entries?.length || 0} entries.`);
    if (!cell1Entries.data.entries || cell1Entries.data.entries.length === 0) {
      throw new Error(`cell1 cannot view entries! Returned 0 entries.`);
    }

    // cell1 updates entry1: set present_days to 27
    console.log(` cell1 modifying entry ID ${entry1.id} (${entry1.emp_name}): setting present_days = 27`);
    const update1 = await request(`/api/payroll/entries/${entry1.id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${cell1Auth.token}` },
      body: {
        present_days: 27,
        ot_hours: 4,
        special_allowance: Number(entry1.special_allowance || 0),
        thermal_allowance: Number(entry1.thermal_allowance || 1500),
        perf_allowance: Number(entry1.perf_allowance || 0)
      }
    });
    if (!update1.ok || !update1.data.entry) {
      throw new Error(`cell1 failed to update entry ${entry1.id}: ${JSON.stringify(update1.data)}`);
    }
    console.log(` cell1 update succeeded. Net payable recomputed to: ₹${update1.data.entry?.net_payable}`);

    // 3. Login as CELL2 (Gopika Kashyap)
    console.log('\n[4/7] Testing cell2 (Gopika Kashyap)...');
    const cell2Auth = await login('cell2', 'cell2@ggsstp2026');
    console.log(` cell2 logged in: ${cell2Auth.user.fullName} (${cell2Auth.user.role})`);

    // cell2 modifies entry2 net payable
    const testNetPayable = 28950.00;
    console.log(` cell2 modifying entry ID ${entry2.id} (${entry2.emp_name}): setting net_payable = ₹${testNetPayable}`);
    const update2 = await request(`/api/payroll/entries/${entry2.id}/net-payable`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${cell2Auth.token}` },
      body: {
        netPayable: testNetPayable,
        reason: 'Authorized Cell 2 Special Adjustment for Verification'
      }
    });
    if (!update2.ok || !update2.data.entry) {
      throw new Error(`cell2 failed to update net payable on entry ${entry2.id}: ${JSON.stringify(update2.data)}`);
    }
    console.log(` cell2 net_payable override succeeded. Saved net_payable: ₹${update2.data.entry?.net_payable}`);

    // 4. Login as CELL3 (Harpreet Singh)
    console.log('\n[5/7] Testing cell3 (Harpreet Singh)...');
    const cell3Auth = await login('cell3', 'cell3@ggsstp2026');
    console.log(` cell3 logged in: ${cell3Auth.user.fullName} (${cell3Auth.user.role})`);

    // cell3 modifies entry3 via batch-save-grid
    const testSpecialAllowance = 3850.00;
    const testPerfAllowance = 350.00;
    console.log(` cell3 saving grid changes for entry ID ${entry3.id} (${entry3.emp_name}): special=${testSpecialAllowance}, perf=${testPerfAllowance}`);
    const update3 = await request('/api/payroll/batch-save-grid', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell3Auth.token}` },
      body: {
        periodId: targetPeriod.id,
        rows: [
          {
            id: entry3.id,
            present_days: entry3.present_days,
            ot_hours: entry3.ot_hours,
            gross_salary_rate: entry3.gross_salary_rate,
            special_allowance: testSpecialAllowance,
            thermal_allowance: entry3.thermal_allowance,
            perf_allowance_monthly: testPerfAllowance
          }
        ]
      }
    });
    if (!update3.ok || !update3.data.savedCount) {
      throw new Error(`cell3 failed to batch-save grid: ${JSON.stringify(update3.data)}`);
    }
    console.log(` cell3 batch grid save succeeded. Rows updated: ${update3.data.savedCount}`);

    // 5. Query as ADMIN and verify ALL updates are preserved and visible
    console.log('\n[6/7] Verifying Admin ID reflects ALL cell1, cell2, cell3 updates...');
    const adminCheck = await request(`/api/payroll/entries?periodId=${targetPeriod.id}`, {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    if (!adminCheck.ok || !adminCheck.data.entries) {
      throw new Error(`Admin query failed: ${JSON.stringify(adminCheck.data)}`);
    }

    const adminEntries = adminCheck.data.entries;
    console.log(` Total entries visible to Admin: ${adminEntries.length}`);

    if (adminEntries.length !== totalEntriesBefore) {
      throw new Error(`Entry count changed! Expected ${totalEntriesBefore}, but found ${adminEntries.length}`);
    }

    // Verify Entry 1 (cell1 edit)
    const verifiedEntry1 = adminEntries.find(e => e.id === entry1.id);
    console.log(` Verification 1 [cell1 edit]: present_days = ${verifiedEntry1?.present_days} (expected 27)`);
    if (Number(verifiedEntry1?.present_days) !== 27) {
      throw new Error(`cell1 edit NOT found in admin id! Found: ${verifiedEntry1?.present_days}`);
    }

    // Verify Entry 2 (cell2 edit)
    const verifiedEntry2 = adminEntries.find(e => e.id === entry2.id);
    console.log(` Verification 2 [cell2 edit]: net_payable = ₹${verifiedEntry2?.net_payable} (expected ₹${testNetPayable}), is_overridden = ${verifiedEntry2?.is_overridden}`);
    if (Math.abs(Number(verifiedEntry2?.net_payable) - testNetPayable) > 0.01) {
      throw new Error(`cell2 edit NOT found in admin id! Found: ${verifiedEntry2?.net_payable}`);
    }

    // Verify Entry 3 (cell3 edit)
    const verifiedEntry3 = adminEntries.find(e => e.id === entry3.id);
    console.log(` Verification 3 [cell3 edit]: special_allowance = ₹${verifiedEntry3?.special_allowance} (expected ₹${testSpecialAllowance}), perf_monthly = ₹${verifiedEntry3?.perf_allowance_monthly}`);
    if (Math.abs(Number(verifiedEntry3?.special_allowance) - testSpecialAllowance) > 0.01) {
      throw new Error(`cell3 edit NOT found in admin id! Found special_allowance: ${verifiedEntry3?.special_allowance}`);
    }
    if (Math.abs(Number(verifiedEntry3?.perf_allowance_monthly) - testPerfAllowance) > 0.01) {
      throw new Error(`cell3 edit NOT found in admin id! Found perf_allowance_monthly: ${verifiedEntry3?.perf_allowance_monthly}`);
    }

    // 6. Test Period Employee Sync: Ensure syncPeriodWithActiveEmployees preserves all data
    console.log('\n[7/7] Testing Period Employee Synchronization (non-destructive check)...');
    const syncRes = await request(`/api/payroll/periods/${targetPeriod.id}/sync-employees`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    console.log(` cell1 triggered period sync: ${syncRes.data.message}`);

    const postSyncCheck = await request(`/api/payroll/entries?periodId=${targetPeriod.id}`, {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    console.log(` Post-sync total entries visible to Admin: ${postSyncCheck.data.entries?.length}`);
    if (postSyncCheck.data.entries?.length !== totalEntriesBefore) {
      throw new Error(`Sync deleted rows! Before: ${totalEntriesBefore}, After: ${postSyncCheck.data.entries?.length}`);
    }

    console.log('\n================================================================');
    console.log('✅ ALL MULTI-USER & ADMIN DATA SYNCHRONIZATION TESTS PASSED 100%!');
    console.log('================================================================');

  } finally {
    if (serverProcess) {
      serverProcess.kill();
    }
  }
}

main().catch(err => {
  console.error('\n❌ TEST FAILED:', err);
  process.exit(1);
});
