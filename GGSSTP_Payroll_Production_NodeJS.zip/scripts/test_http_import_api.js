const fs = require('fs');
const path = require('path');

async function testHttpEndpoints() {
  console.log('Testing HTTP Import Endpoints...');
  const baseUrl = 'http://127.0.0.1:5000';

  // 1. Health check
  const healthRes = await fetch(`${baseUrl}/api/health`);
  console.log('Health check status:', healthRes.status);
  if (!healthRes.ok) throw new Error('Health check failed');

  // 2. Login
  const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'admin@ggsstp2026' })
  });
  const loginData = await loginRes.json();
  if (!loginRes.ok) throw new Error(`Login failed: ${loginData.error}`);
  const token = loginData.token;
  console.log('Logged in successfully. User:', loginData.user.username);

  // 3. Test /api/import/inspect
  const refPath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
  const fileBytes = fs.readFileSync(refPath);
  const blob = new Blob([fileBytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

  const formData = new FormData();
  formData.append('file', blob, 'SALARY SHEET-for EPF Sepf 2026.xlsx');
  formData.append('sheetName', 'MM-1');

  const inspectRes = await fetch(`${baseUrl}/api/import/inspect`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: formData
  });
  const inspectData = await inspectRes.json();
  console.log('Inspect HTTP Status:', inspectRes.status);
  console.log('Inspect Sheet:', inspectData.selectedSheet);
  console.log('Inspect Total Columns:', inspectData.totalColumns);
  console.log('Inspect Mapped Count:', inspectData.summary.mappedCount);
  console.log('Inspect Preview Rows:', inspectData.previewRows.length);

  if (inspectData.totalColumns !== 48) {
    throw new Error(`Expected 48 columns from HTTP inspect, got ${inspectData.totalColumns}`);
  }

  // 4. Test /api/employees/import-preview
  const formData2 = new FormData();
  formData2.append('file', blob, 'SALARY SHEET-for EPF Sepf 2026.xlsx');
  formData2.append('sheetName', 'EMC');

  const prevRes = await fetch(`${baseUrl}/api/employees/import-preview`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: formData2
  });
  const prevData = await prevRes.json();
  console.log('Employees Import Preview HTTP Status:', prevRes.status);
  console.log('Employees Import Preview Total Records:', prevData.totalRecords);
  console.log('Employees Import Preview Columns:', prevData.columns?.length);

  if (!prevData.columns || prevData.columns.length !== 54) {
    throw new Error(`Expected 54 columns in preview, got ${prevData.columns?.length}`);
  }

  console.log('\n✅ ALL HTTP IMPORT API ENDPOINTS WORKING FLAWLESSLY!');
}

testHttpEndpoints().catch(err => {
  console.error('\n❌ HTTP API TEST FAILED:', err);
  process.exit(1);
});
