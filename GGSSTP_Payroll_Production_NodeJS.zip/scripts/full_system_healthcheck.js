const http = require('http');
const { spawn } = require('child_process');

async function testHttpUrl(url) {
  return new Promise((resolve) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        resolve({ url, status: res.statusCode, length: data.length });
      });
    }).on('error', (err) => {
      resolve({ url, error: err.message });
    });
  });
}

async function runHealthCheck() {
  console.log('================================================================');
  console.log('STARTING COMPREHENSIVE GGSSTP APPLICATION HEALTH CHECK');
  console.log('================================================================\n');

  // STEP 1: Verify Port Bindings
  console.log('--- 1. TESTING MULTI-PORT BINDINGS ---');
  const ports = ['http://localhost:5000', 'http://localhost', 'http://localhost:3000'];
  for (const p of ports) {
    const res = await testHttpUrl(p);
    console.log(`Port Check [${p}]: Status ${res.status}, Length: ${res.length} bytes`);
    if (res.status !== 200) {
      throw new Error(`Port check failed for ${p}`);
    }
  }
  console.log('✅ All ports (5000, 80, 3000) are responding with HTTP 200 OK.\n');

  // STEP 2: Verify API Authentication & Endpoints
  console.log('--- 2. TESTING BACKEND API ENDPOINTS ---');
  const loginRes = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'admin@ggsstp2026' })
  });
  const loginData = await loginRes.json();
  if (!loginData.token) {
    throw new Error('API Login failed: ' + JSON.stringify(loginData));
  }
  console.log(`✅ API Login successful for user: ${loginData.user.username} (${loginData.user.role})`);
  const token = loginData.token;

  // Test Dashboard Stats API
  const dashRes = await fetch('http://localhost:5000/api/dashboard/stats', {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const dashData = await dashRes.json();
  console.log(`✅ /api/dashboard/stats: Success (Active contractual staff: ${dashData.employeeOverview?.active || 0})`);

  // Test Employees API
  const empRes = await fetch('http://localhost:5000/api/employees', {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const empData = await empRes.json();
  console.log(`✅ /api/employees: Success (Total employees in DB: ${empData.employees?.length || 0})`);

  // Test Payroll Periods API
  const periodRes = await fetch('http://localhost:5000/api/payroll/periods', {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  const periodData = await periodRes.json();
  console.log(`✅ /api/payroll/periods: Success (Periods count: ${periodData.periods?.length || 0})\n`);

  // STEP 3: Browser End-To-End Test (Verify NO White Screen and UI Renders)
  console.log('--- 3. TESTING BROWSER RENDERING VIA DEVTOOLS PROTOCOL ---');
  const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  const debuggingPort = 9230;

  const browserProc = spawn(edgePath, [
    `--remote-debugging-port=${debuggingPort}`,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    'http://localhost:5000'
  ]);

  await new Promise(r => setTimeout(r, 2000));

  try {
    const targetsRes = await fetch(`http://127.0.0.1:${debuggingPort}/json/list`);
    const targets = await targetsRes.json();
    const appTarget = targets.find(t => t.url.includes('5000'));
    if (!appTarget) throw new Error('Could not attach to Edge browser window');

    const ws = new WebSocket(appTarget.webSocketDebuggerUrl);

    let msgId = 1;
    function send(method, params = {}) {
      const id = msgId++;
      ws.send(JSON.stringify({ id, method, params }));
      return id;
    }

    const browserExceptions = [];
    await new Promise((resolve) => {
      ws.onopen = () => {
        send('Runtime.enable');
        send('Page.enable');
        send('Console.enable');
        setTimeout(resolve, 1000);
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.method === 'Runtime.exceptionThrown') {
          browserExceptions.push(msg.params.exceptionDetails);
          console.error('[BROWSER EXCEPTION]:', msg.params.exceptionDetails.text);
        }
      };
    });

    console.log('Simulating User Login on browser UI...');
    const loginScript = `
      (async () => {
        const userInput = document.querySelector('input[type="text"]') || document.querySelector('input');
        const passInput = document.querySelector('input[type="password"]');
        const submitBtn = document.querySelector('button[type="submit"]') || Array.from(document.querySelectorAll('button')).find(b => b.textContent.includes('Sign In') || b.textContent.includes('Login'));

        if (!userInput || !passInput || !submitBtn) return { error: 'Elements not found' };

        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        nativeSetter.call(userInput, 'admin');
        userInput.dispatchEvent(new Event('input', { bubbles: true }));

        nativeSetter.call(passInput, 'admin@ggsstp2026');
        passInput.dispatchEvent(new Event('input', { bubbles: true }));

        await new Promise(r => setTimeout(r, 200));
        submitBtn.click();
        return { success: true };
      })()
    `;

    send('Runtime.evaluate', { expression: loginScript, awaitPromise: true });
    await new Promise(r => setTimeout(r, 3000));

    // Verify Dashboard rendered (NOT blank white screen)
    const checkDashboard = `
      ({
        bodyLength: document.body.innerHTML.length,
        hasAppContainer: !!document.querySelector('.app-container'),
        hasTopBar: !!document.querySelector('.topbar-container') || !!document.querySelector('header'),
        isWhiteScreen: document.body.innerHTML.trim() === '<div id="root"></div>'
      })
    `;
    const dashCheckId = send('Runtime.evaluate', { expression: checkDashboard, returnByValue: true });

    let dashResult = null;
    await new Promise((resolve) => {
      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.id === dashCheckId) {
          dashResult = msg.result.result.value;
          resolve();
        }
      };
      setTimeout(resolve, 2000);
    });

    console.log('Dashboard Render Check:', dashResult);
    if (!dashResult || dashResult.isWhiteScreen || dashResult.bodyLength < 1000) {
      throw new Error('White screen detected after login!');
    }
    console.log(`✅ Dashboard rendered perfectly! DOM size: ${dashResult.bodyLength} bytes (White Screen: NO).`);

    // Test Clicking Employees Tab
    console.log('\nTesting Tab Navigation: Switching to "Employees"...');
    const switchTabScript = `
      (async () => {
        const buttons = Array.from(document.querySelectorAll('button, a, div'));
        const empBtn = buttons.find(b => b.textContent.trim() === 'Employees');
        if (empBtn) {
          empBtn.click();
          await new Promise(r => setTimeout(r, 1200));
          return { clicked: true, bodyLen: document.body.innerHTML.length };
        }
        return { clicked: false };
      })()
    `;
    const tabCheckId = send('Runtime.evaluate', { expression: switchTabScript, awaitPromise: true, returnByValue: true });

    let tabResult = null;
    await new Promise((resolve) => {
      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.id === tabCheckId) {
          tabResult = msg.result.result.value;
          resolve();
        }
      };
      setTimeout(resolve, 2500);
    });

    console.log('Employees Tab Navigation Result:', tabResult);
    console.log(`✅ Employees View rendered cleanly! DOM size: ${tabResult?.bodyLen} bytes.`);

    console.log(`\nBrowser Uncaught Exceptions: ${browserExceptions.length}`);
    if (browserExceptions.length > 0) {
      throw new Error(`Encountered ${browserExceptions.length} browser exceptions!`);
    }

    ws.close();
  } finally {
    browserProc.kill();
  }

  console.log('\n================================================================');
  console.log('🎉 ALL HEALTH CHECKS PASSED: SYSTEM IS 100% OPERATIONAL!');
  console.log('================================================================');
}

runHealthCheck().catch(err => {
  console.error('\n❌ HEALTH CHECK FAILED:', err);
  process.exit(1);
});
