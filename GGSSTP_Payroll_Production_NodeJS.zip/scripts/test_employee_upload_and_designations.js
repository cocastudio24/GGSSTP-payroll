const { db } = require('../dist/database/db');
const { ExcelImporter } = require('../dist/excel/excelImporter');
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

async function run() {
  console.log('--- Step 1: Initializing DB ---');
  await db.init();

  // Check permanent user accounts
  const usersRes = await db.query('SELECT id, username, role FROM users ORDER BY id;');
  console.log('Permanent users in DB:', usersRes.rows);
  const expectedUsers = ['admin', 'cell1', 'cell2', 'cell3'];
  const actualUsers = usersRes.rows.map(u => u.username);
  for (const exp of expectedUsers) {
    if (!actualUsers.includes(exp)) {
      throw new Error(`CRITICAL: Permanent user ${exp} is missing!`);
    }
  }
  console.log('All permanent user accounts verified!');

  // Check periods
  const periodRes = await db.query('SELECT * FROM payroll_periods ORDER BY id DESC LIMIT 1;');
  let periodId = periodRes.rows[0]?.id;
  if (!periodId) {
    const newPeriod = await db.query(`
      INSERT INTO payroll_periods (owner_user_id, year, month, month_name, total_days, status)
      VALUES (1, 2026, 9, 'September 2026', 30, 'Draft') RETURNING id;
    `);
    periodId = newPeriod.rows[0].id;
  }
  console.log('Using payroll period ID:', periodId);

  // Clean any remnants of TEST-% employees
  await db.query("DELETE FROM employees WHERE emp_code LIKE 'TEST-%';");
  await db.query("DELETE FROM designations WHERE alias ~ '^[0-9]+$';");

  // Step 2: Seed / re-import reference file so reference employees have true designations and circles
  console.log('\n--- Step 2: Importing Reference Excel Sheet ---');
  const refBuf = fs.readFileSync('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
  const parsedMap = ExcelImporter.parseWorkbook(refBuf, 'SALARY SHEET-for EPF Sepf 2026.xlsx');
  const allRows = Object.values(parsedMap).flat();
  console.log(`Parsed ${allRows.length} total rows from reference workbook.`);
  const refImportResult = await ExcelImporter.commitImport(
    allRows,
    9,
    2026,
    'admin',
    1
  );
  console.log('Reference import result:', refImportResult);

  // Check designations distribution for reference employees
  const desCountRes = await db.query(`
    SELECT d.alias, d.name, COUNT(e.id) as count
    FROM employees e
    JOIN designations d ON e.designation_id = d.id
    WHERE e.is_active = TRUE AND e.archived_at IS NULL
    GROUP BY d.alias, d.name
    ORDER BY count DESC;
  `);
  console.log('Current Designation breakdown in DB:', desCountRes.rows);

  // Step 3: Test Uploading Employee Master with Varied Designations
  console.log('\n--- Step 3: Testing Custom Employee Excel Import with Varied Designations ---');
  // Create an Excel workbook in memory with multiple designations
  const mockRows = [
    ['Emp Code', 'Employee Name', 'Father Name', 'Designation', 'UAN', 'ESI', 'Circle', 'Cell', 'Bank Name', 'Account No', 'IFSC', 'Gross Rate', 'Special All.'],
    ['TEST-001', 'AMARJIT SINGH', 'JOGINDER SINGH', 'USW', '100111111111', '1201111111', 'EMC CIRCLE', 'EM-1', 'State Bank of India', '111122223333', 'SBIN0001234', 14500, 3200],
    ['TEST-002', 'BALDEV RAJ', 'KISHAN CHAND', 'Semi Skilled', '100222222222', '1202222222', 'EMC CIRCLE', 'EM-2', 'Punjab National Bank', '222233334444', 'PUNB0002345', 15400, 3500],
    ['TEST-003', 'CHANDER MOHAN', 'RAM LAL', 'Skilled', '100333333333', '1203333333', 'MM-1 CIRCLE', 'MM-1 CELL', 'HDFC Bank', '333344445555', 'HDFC0003456', 16530, 3802],
    ['TEST-004', 'DHARAM PAL', 'SOM NATH', 'Highly Skilled', '100444444444', '1204444444', 'MM-1 CIRCLE', 'MM-1 CELL', 'ICICI Bank', '444455556666', 'ICIC0004567', 18200, 4200],
    ['TEST-005', 'EKNOOR SINGH', 'GURMEET SINGH', 'Electrician', '100555555555', '1205555555', 'OPERATION CIRCLE', 'OP-MAIN', 'Bank of Baroda', '555566667777', 'BARB0005678', 17000, 3900],
    ['TEST-006', 'FAKIR CHAND', 'DES RAJ', 'Helper', '100666666666', '1206666666', 'GENERAL CIRCLE', 'CIVIL', 'Canara Bank', '666677778888', 'CNRB0006789', 14000, 3000]
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(mockRows);
  XLSX.utils.book_append_sheet(wb, ws, 'Employees');
  const mockBuf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

  // Preview and import via commitEmployeeMasterImport
  const preview = await ExcelImporter.previewEmployeeMasterImport(mockBuf, 1);
  console.log(`Preview detected ${preview.totalRecords} records across sheets:`, preview.sheetNames);
  const masterImportRes = await ExcelImporter.commitEmployeeMasterImport(
    preview.previewRows,
    'both',
    1,
    'admin'
  );
  console.log('Employee Master Import result:', masterImportRes);

  // Verify TEST-001 through TEST-006 designations in DB
  const testEmpsRes = await db.query(`
    SELECT e.emp_code, e.name, d.alias as des_alias, d.name as des_name, c.name as circle, e.bank_name, e.bank_account, e.cell
    FROM employees e
    JOIN designations d ON e.designation_id = d.id
    LEFT JOIN circles c ON e.circle_id = c.id
    WHERE e.emp_code LIKE 'TEST-%'
    ORDER BY e.emp_code;
  `);
  console.log('Test employees in DB with their resolved designations:');
  console.table(testEmpsRes.rows);

  // Validate designations are correctly assigned
  const desMap = {};
  testEmpsRes.rows.forEach(r => { desMap[r.emp_code] = r.des_alias; });
  if (desMap['TEST-001'] !== 'USW') throw new Error(`TEST-001 expected USW, got ${desMap['TEST-001']}`);
  if (!['SSW', 'SEMI SW'].includes(desMap['TEST-002'])) throw new Error(`TEST-002 expected SSW/SEMI SW, got ${desMap['TEST-002']}`);
  if (desMap['TEST-003'] !== 'SW') throw new Error(`TEST-003 expected SW, got ${desMap['TEST-003']}`);
  if (desMap['TEST-004'] !== 'HSW') throw new Error(`TEST-004 expected HSW, got ${desMap['TEST-004']}`);
  if (!['ELECTRIC', 'ELECTRICIAN'].includes(desMap['TEST-005'])) throw new Error(`TEST-005 expected ELECTRIC/ELECTRICIAN, got ${desMap['TEST-005']}`);
  if (desMap['TEST-006'] !== 'HELPER') throw new Error(`TEST-006 expected HELPER, got ${desMap['TEST-006']}`);
  console.log('SUCCESS: All 6 diverse designations resolved and categorized perfectly!');

  // Step 4: Test Dashboard Stats API query logic
  console.log('\n--- Step 4: Testing Dashboard Stats Aggregation ---');
  // We simulate dashboard logic for Super Admin
  const isSuper = true;
  const targetUserId = null;

  // Active employees overview
  const totalEmployees = (await db.query(`
    SELECT 
      COUNT(*) FILTER (WHERE is_active = TRUE) as active,
      COUNT(*) FILTER (WHERE is_active = FALSE) as inactive,
      COUNT(*) FILTER (WHERE bank_account IS NULL OR bank_account = '') as missing_bank,
      COUNT(*) FILTER (WHERE uan IS NULL OR uan = '') as missing_uan,
      COUNT(*) FILTER (WHERE esi_number IS NULL OR esi_number = '') as missing_esi
    FROM employees 
    WHERE archived_at IS NULL;
  `)).rows[0];
  console.log('Dashboard active employees:', totalEmployees);

  // Circle workforce dynamic grouping
  const circlesList = (await db.query(`
    SELECT DISTINCT c.name as circle_name
    FROM employees e
    JOIN circles c ON e.circle_id = c.id
    WHERE e.is_active = TRUE AND e.archived_at IS NULL;
  `)).rows;
  console.log('Circles present in active workforce:', circlesList.map(c => c.circle_name));

  // Employees by designation
  const desSummary = (await db.query(`
    SELECT 
      d.id,
      d.name as designation,
      d.alias,
      COUNT(e.id) as count
    FROM designations d
    LEFT JOIN employees e ON e.designation_id = d.id AND e.is_active = TRUE AND e.archived_at IS NULL
    GROUP BY d.id, d.name, d.alias
    HAVING COUNT(e.id) > 0
    ORDER BY count DESC, d.name ASC;
  `)).rows;
  console.log('Dashboard Designation breakdown:');
  console.table(desSummary);

  // Clean up mock test employees so DB remains pristine
  console.log('\n--- Step 5: Cleaning up mock test records ---');
  await db.query("DELETE FROM employees WHERE emp_code LIKE 'TEST-%';");
  console.log('Mock records cleaned up.');

  console.log('\nALL VERIFICATIONS PASSED WITH 100% SUCCESS!');
  process.exit(0);
}

run().catch(err => {
  console.error('Fatal error during test:', err);
  process.exit(1);
});
