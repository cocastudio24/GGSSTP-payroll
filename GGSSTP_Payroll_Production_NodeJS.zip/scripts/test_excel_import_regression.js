const fs = require('fs');
const path = require('path');
const { ExcelImporter } = require('../dist/excel/excelImporter');
const { db } = require('../dist/database/db');

async function runRegressionTests() {
  console.log('=== STARTING EXCEL IMPORT & COLUMN MAPPING REGRESSION TESTS ===');

  const refPath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
  if (!fs.existsSync(refPath)) {
    throw new Error(`Reference workbook not found at: ${refPath}`);
  }
  const buffer = fs.readFileSync(refPath);

  // 1. Inspect MM-1
  console.log('\n--- 1. Testing inspectWorkbook on MM-1 ---');
  const mm1Inspect = ExcelImporter.inspectWorkbook(buffer, 'SALARY SHEET-for EPF Sepf 2026.xlsx', 'MM-1');
  console.log(`MM-1 Total Columns: ${mm1Inspect.totalColumns}`);
  console.log(`MM-1 Header Row Index: ${mm1Inspect.headerRowIndex}`);
  console.log(`MM-1 Mapped Columns Count: ${mm1Inspect.summary.mappedCount}`);
  console.log(`MM-1 Excluded Columns Count: ${mm1Inspect.summary.excludedCount}`);
  console.log(`MM-1 Preview Rows Count: ${mm1Inspect.previewRows.length}`);

  if (mm1Inspect.totalColumns !== 48) {
    throw new Error(`Expected 48 columns in MM-1, got ${mm1Inspect.totalColumns}`);
  }

  // Check critical identifiers in MM-1 row 0 (Simranjeet Singh)
  const emp101 = mm1Inspect.previewRows.find(r => r.empCode === 'EMP-101' || r.name.includes('SIMRANJEET'));
  if (!emp101) throw new Error('EMP-101 (Simranjeet Singh) not found in MM-1 preview');

  console.log('Verified EMP-101 Preview Row:');
  console.log(`  Name: ${emp101.name}`);
  console.log(`  UAN: ${emp101.uan}`);
  console.log(`  ESI Number: ${emp101.esiNumber}`);
  console.log(`  Bank Account: ${emp101.bankAccount}`);
  console.log(`  IFSC: ${emp101.ifsc}`);
  console.log(`  Designation: ${emp101.designationAlias}`);
  console.log(`  Total Basic: ₹${emp101.totalBasic}`);
  console.log(`  Thermal Allowance: ₹${emp101.thermalAllowance}`);
  console.log(`  Employee EPF (12%): ₹${emp101.customEmployeeEpf}`);
  console.log(`  Employee ESI (0.75%): ₹${emp101.customEmployeeEsi}`);
  console.log(`  Total Deductions: ₹${emp101.importedTotalEmployeeDeductions}`);
  console.log(`  Net Payable: ₹${emp101.importedNetPayable}`);

  if (emp101.uan !== '100364468209') {
    throw new Error(`Expected UAN '100364468209', got '${emp101.uan}' (Scientific notation check failed!)`);
  }
  if (emp101.bankAccount !== '55150355883') {
    throw new Error(`Expected Bank Account '55150355883', got '${emp101.bankAccount}'`);
  }
  if (emp101.esiNumber !== '2613380444') {
    throw new Error(`Expected ESI Number '2613380444', got '${emp101.esiNumber}'`);
  }
  if (emp101.ifsc !== 'SBIN0050302') {
    throw new Error(`Expected IFSC 'SBIN0050302', got '${emp101.ifsc}'`);
  }
  if (emp101.importedNetPayable !== 4640) {
    throw new Error(`Expected Net Payable 4640 (rounded from 4639.5), got ${emp101.importedNetPayable}`);
  }

  // 2. Inspect EMC
  console.log('\n--- 2. Testing inspectWorkbook on EMC ---');
  const emcInspect = ExcelImporter.inspectWorkbook(buffer, 'SALARY SHEET-for EPF Sepf 2026.xlsx', 'EMC');
  console.log(`EMC Total Columns: ${emcInspect.totalColumns}`);
  console.log(`EMC Header Row Index: ${emcInspect.headerRowIndex}`);
  console.log(`EMC Mapped Columns Count: ${emcInspect.summary.mappedCount}`);
  console.log(`EMC Excluded Columns Count: ${emcInspect.summary.excludedCount}`);
  console.log(`EMC Preview Rows Count: ${emcInspect.previewRows.length}`);

  if (emcInspect.totalColumns !== 54) {
    throw new Error(`Expected 54 columns in EMC, got ${emcInspect.totalColumns}`);
  }

  const emc323 = emcInspect.previewRows.find(r => r.empCode === 'EMC-323' || r.name.includes('MOHAN PARSAD'));
  if (!emc323) throw new Error('EMC-323 (Mohan Parsad) not found in EMC preview');

  console.log('Verified EMC-323 Preview Row:');
  console.log(`  Name: ${emc323.name}`);
  console.log(`  UAN: ${emc323.uan}`);
  console.log(`  ESI Number: ${emc323.esiNumber}`);
  console.log(`  Bank Account: ${emc323.bankAccount}`);
  console.log(`  IFSC: ${emc323.ifsc}`);
  console.log(`  Total Basic: ₹${emc323.totalBasic}`);
  console.log(`  Thermal Allowance: ₹${emc323.thermalAllowance}`);
  console.log(`  Employee EPF (12%): ₹${emc323.customEmployeeEpf}`);
  console.log(`  Employee ESI (0.75%): ₹${emc323.customEmployeeEsi}`);
  console.log(`  Total Deductions: ₹${emc323.importedTotalEmployeeDeductions}`);
  console.log(`  Net Payable: ₹${emc323.importedNetPayable}`);

  if (emc323.uan !== '100229801824') {
    throw new Error(`Expected UAN '100229801824', got '${emc323.uan}'`);
  }
  if (emc323.bankAccount !== '55145808720') {
    throw new Error(`Expected Bank Account '55145808720', got '${emc323.bankAccount}'`);
  }
  if (emc323.esiNumber !== '1209986957') {
    throw new Error(`Expected ESI Number '1209986957', got '${emc323.esiNumber}'`);
  }
  if (emc323.ifsc !== 'SBIN0050082') {
    throw new Error(`Expected IFSC 'SBIN0050082', got '${emc323.ifsc}'`);
  }
  if (emc323.importedNetPayable !== 5699) {
    throw new Error(`Expected Net Payable 5699, got ${emc323.importedNetPayable}`);
  }

  // 3. Execute Mapped Import for MM-1 into Database
  console.log('\n--- 3. Testing executeMappedImport on MM-1 ---');
  // Get admin user
  const adminRes = await db.query("SELECT id FROM users WHERE username = 'admin' LIMIT 1;");
  const adminId = adminRes.rows[0].id;

  const mm1Mapping = {};
  mm1Inspect.columns.forEach(c => {
    mm1Mapping[c.colIndex] = c.proposedField;
  });

  const mm1ExecRes = await ExcelImporter.executeMappedImport(
    buffer,
    'MM-1',
    mm1Mapping,
    mm1Inspect.headerRowIndex,
    'both',
    9,
    2026,
    adminId,
    'admin'
  );

  console.log('MM-1 Import Result:', mm1ExecRes);
  if (mm1ExecRes.createdCount + mm1ExecRes.updatedCount !== 21) {
    throw new Error(`Expected 21 employees imported from MM-1, got ${mm1ExecRes.createdCount + mm1ExecRes.updatedCount}`);
  }

  // 4. Execute Mapped Import for EMC into Database
  console.log('\n--- 4. Testing executeMappedImport on EMC ---');
  const emcMapping = {};
  emcInspect.columns.forEach(c => {
    emcMapping[c.colIndex] = c.proposedField;
  });

  const emcExecRes = await ExcelImporter.executeMappedImport(
    buffer,
    'EMC',
    emcMapping,
    emcInspect.headerRowIndex,
    'both',
    9,
    2026,
    adminId,
    'admin'
  );

  console.log('EMC Import Result:', emcExecRes);
  if (emcExecRes.createdCount + emcExecRes.updatedCount !== 45) {
    throw new Error(`Expected 45 employees imported from EMC, got ${emcExecRes.createdCount + emcExecRes.updatedCount}`);
  }

  // 5. Verify database records
  console.log('\n--- 5. Verifying Database Employees & Payroll Entries ---');
  const dbEmpRes = await db.query("SELECT * FROM employees WHERE emp_code = 'EMP-101' AND owner_user_id = $1;", [adminId]);
  if (dbEmpRes.rows.length === 0) throw new Error('EMP-101 not found in database');
  const dbEmp = dbEmpRes.rows[0];
  console.log('DB EMP-101 Record:', {
    emp_code: dbEmp.emp_code,
    name: dbEmp.name,
    uan: dbEmp.uan,
    esi_number: dbEmp.esi_number,
    bank_account: dbEmp.bank_account,
    ifsc: dbEmp.ifsc,
    is_active: dbEmp.is_active
  });

  if (dbEmp.uan !== '100364468209') throw new Error(`DB UAN mismatch: ${dbEmp.uan}`);
  if (dbEmp.bank_account !== '55150355883') throw new Error(`DB Bank Account mismatch: ${dbEmp.bank_account}`);
  if (dbEmp.esi_number !== '2613380444') throw new Error(`DB ESI mismatch: ${dbEmp.esi_number}`);

  const dbPayRes = await db.query(`
    SELECT pe.* FROM payroll_entries pe
    WHERE pe.employee_id = $1 AND pe.payroll_period_id = $2;
  `, [dbEmp.id, mm1ExecRes.periodId]);

  if (dbPayRes.rows.length === 0) throw new Error('Payroll entry for EMP-101 not found in database');
  const dbPay = dbPayRes.rows[0];
  console.log('DB Payroll Entry for EMP-101:', {
    present_days: dbPay.present_days,
    total_basic: dbPay.total_basic,
    thermal_allowance: dbPay.thermal_allowance,
    employee_epf_12: dbPay.employee_epf_12,
    employee_esi_075: dbPay.employee_esi_075,
    employee_lwf: dbPay.employee_lwf,
    total_employee_deductions: dbPay.total_employee_deductions,
    net_payable: dbPay.net_payable
  });

  if (Number(dbPay.net_payable) !== 4640) {
    throw new Error(`DB Net Payable mismatch: expected 4640 (rounded from 4639.5), got ${dbPay.net_payable}`);
  }
  if (Number(dbPay.employee_epf_12) !== 463) {
    throw new Error(`DB EPF deduction mismatch: expected 463, got ${dbPay.employee_epf_12}`);
  }
  if (Number(dbPay.employee_esi_075) !== 39) {
    throw new Error(`DB ESI deduction mismatch: expected 39, got ${dbPay.employee_esi_075}`);
  }

  // 6. Test Multi-Sheet All Worksheets Reading (__ALL__)
  console.log('\n--- 6. Testing inspectWorkbook with __ALL__ ---');
  const allInspect = ExcelImporter.inspectWorkbook(buffer, 'SALARY SHEET-for EPF Sepf 2026.xlsx', '__ALL__');
  console.log('All Sheets Inspect: selectedSheet =', allInspect.selectedSheet);
  console.log('All Sheets Inspect: sheetsSummary =', allInspect.sheetsSummary?.map(s => `${s.sheetName} (${s.totalRows} rows)`));
  console.log('All Sheets Inspect: totalRows =', allInspect.totalRows);
  console.log('All Sheets Inspect: previewRows =', allInspect.previewRows.length);

  if (allInspect.selectedSheet !== '__ALL__') {
    throw new Error(`Expected selectedSheet '__ALL__', got ${allInspect.selectedSheet}`);
  }
  if (!allInspect.sheetsSummary || allInspect.sheetsSummary.length < 2) {
    throw new Error(`Expected at least 2 sheets in summary, got ${allInspect.sheetsSummary?.length}`);
  }
  if (allInspect.totalRows < 66 || allInspect.previewRows.length !== 46) {
    throw new Error(`Expected at least 66 totalRows and 46 previewRows across MM-1 and EMC, got totalRows ${allInspect.totalRows}, previewRows ${allInspect.previewRows.length}`);
  }

  // 7. Test executeAllSheetsImport
  console.log('\n--- 7. Testing executeAllSheetsImport (__ALL__) ---');
  const allImportRes = await ExcelImporter.executeAllSheetsImport(
    buffer,
    'both',
    9,
    2026,
    adminId,
    'admin'
  );
  console.log('All Sheets Import Result:', {
    totalProcessed: allImportRes.totalProcessed,
    totalSheets: allImportRes.totalSheets,
    sheetResults: allImportRes.sheetResults
  });

  if (allImportRes.totalProcessed !== 66) {
    throw new Error(`Expected 66 employees processed across all sheets, got ${allImportRes.totalProcessed}`);
  }
  if (allImportRes.totalSheets !== 2) {
    throw new Error(`Expected 2 sheets processed, got ${allImportRes.totalSheets}`);
  }

  console.log('\n✅ ALL REGRESSION & MULTI-SHEET TESTS PASSED PERFECTLY!');
  process.exit(0);
}

runRegressionTests().catch(err => {
  console.error('\n❌ REGRESSION TEST FAILED:', err);
  process.exit(1);
});
