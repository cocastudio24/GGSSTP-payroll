const http = require('http');

const BASE_URL = 'http://localhost:5000';

function request(path, options = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const reqOptions = {
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    };

    const req = http.request(url, reqOptions, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(data);
        } catch {
          json = data;
        }
        resolve({ status: res.statusCode, data: json, headers: res.headers });
      });
    });

    req.on('error', reject);

    if (options.body) {
      req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
    }
    req.end();
  });
}

async function runMultiUserSecurityTests() {
  console.log('================================================================');
  console.log('STARTING AUTOMATED MULTI-USER DATA ISOLATION & SECURITY TEST SUITE');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, testName, details = '') {
    if (condition) {
      console.log(`✅ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`❌ [FAIL] ${testName}: ${details}`);
      failed++;
    }
  }

  try {
    // 1. Unauthenticated Access Protection
    console.log('--- TEST GROUP 1: UNAUTHENTICATED ENDPOINT PROTECTION ---');
    const unauthEmp = await request('/api/employees');
    assert(unauthEmp.status === 401, 'Unauthenticated GET /api/employees rejected with 401');

    const unauthPayroll = await request('/api/payroll/periods');
    assert(unauthPayroll.status === 401, 'Unauthenticated GET /api/payroll/periods rejected with 401');

    const unauthExport = await request('/api/export/payroll-xlsx/1');
    assert(unauthExport.status === 401, 'Unauthenticated GET /api/export/payroll-xlsx/:id rejected with 401');

    // 2. User A (Admin) Authentication
    console.log('\n--- TEST GROUP 2: USER A AUTHENTICATION & WORKSPACE ---');
    const loginA = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'admin', password: 'admin@ggsstp2026' }
    });
    assert(loginA.status === 200 && loginA.data.token, 'User A (admin) logged in successfully');
    assert(Boolean(loginA.data.user.uuid), 'User A has a unique UUID: ' + loginA.data.user.uuid);
    const tokenA = loginA.data.token;
    const userA = loginA.data.user;

    // Fetch User A employees (Admin owns the 66 migrated employees)
    const empsA = await request('/api/employees', {
      headers: { Authorization: `Bearer ${tokenA}` }
    });
    assert(empsA.status === 200 && empsA.data.employees.length > 0, `User A sees own employees (Count: ${empsA.data.employees.length})`);
    const empA = empsA.data.employees[0];
    console.log(`   Sample User A Employee: ID=${empA.id}, Code=${empA.emp_code}, Name=${empA.name}`);

    // Fetch User A payroll periods
    const periodsA = await request('/api/payroll/periods', {
      headers: { Authorization: `Bearer ${tokenA}` }
    });
    assert(periodsA.status === 200 && periodsA.data.periods.length > 0, `User A sees own payroll periods (Count: ${periodsA.data.periods.length})`);
    const periodA = periodsA.data.periods[0];

    // 3. Register New User B (Completely isolated account)
    console.log('\n--- TEST GROUP 3: USER B REGISTRATION & DATA ISOLATION ---');
    const uniqueSuffix = Date.now();
    const userBUsername = `contractor_user_${uniqueSuffix}`;
    const registerB = await request('/api/auth/register', {
      method: 'POST',
      body: {
        username: userBUsername,
        password: 'Password@123',
        fullName: 'Independent Contractor User B',
        role: 'Payroll Operator'
      }
    });
    assert(registerB.status === 201 && registerB.data.token, 'User B registered successfully with new workspace');
    assert(Boolean(registerB.data.user.uuid), 'User B has unique UUID: ' + registerB.data.user.uuid);
    assert(registerB.data.user.uuid !== userA.uuid, 'User B UUID is distinct from User A UUID');
    const tokenB = registerB.data.token;
    const userB = registerB.data.user;

    // 4. Verify User B has a clean isolated workspace with 0 employees
    console.log('\n--- TEST GROUP 4: ZERO CROSS-USER DATA LEAKAGE IN WORKSPACE ---');
    const empsB = await request('/api/employees', {
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(empsB.status === 200 && empsB.data.employees.length === 0, 'User B sees 0 employees (User A data completely hidden)');

    const periodsB = await request('/api/payroll/periods', {
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(periodsB.status === 200 && periodsB.data.periods.length === 0, 'User B sees 0 payroll periods (User A periods completely hidden)');

    const statsB = await request('/api/dashboard/stats', {
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(statsB.status === 200 && Number(statsB.data.employeeOverview.total) === 0, 'User B dashboard reports 0 employees in private workspace');

    // 5. Test IDOR Protections (User B attempting to read/modify User A data)
    console.log('\n--- TEST GROUP 5: IDOR PROTECTION AGAINST CROSS-USER ACCESS ---');
    // Read User A's employee
    const idorRead = await request(`/api/employees/${empA.id}`, {
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(idorRead.status === 404, `User B IDOR attempt to view User A Employee ID ${empA.id} returns 404 Not Found`);

    // Update User A's employee
    const idorUpdate = await request(`/api/employees/${empA.id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${tokenB}` },
      body: { name: 'Hacked Employee Name' }
    });
    assert(idorUpdate.status === 404, `User B IDOR attempt to update User A Employee ID ${empA.id} returns 404 Not Found`);

    // Verify employee was NOT modified
    const verifyUnchanged = await request(`/api/employees/${empA.id}`, {
      headers: { Authorization: `Bearer ${tokenA}` }
    });
    assert(verifyUnchanged.data.employee.name === empA.name, 'User A Employee record remains uncompromised');

    // Delete User A's employee
    const idorDelete = await request(`/api/employees/${empA.id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(idorDelete.status === 404, `User B IDOR attempt to delete User A Employee ID ${empA.id} returns 404 Not Found`);

    // User B attempting to read User A payroll entries
    const idorPayrollEntries = await request(`/api/payroll/entries?periodId=${periodA.id}`, {
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(idorPayrollEntries.status === 404 || (idorPayrollEntries.data && idorPayrollEntries.data.entries.length === 0),
      'User B cannot access User A payroll entries for Period ' + periodA.id);

    // User B attempting to download User A Excel export
    const idorExport = await request(`/api/export/payroll-xlsx/${periodA.id}`, {
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(idorExport.status === 404, 'User B IDOR attempt to export User A Payroll Excel returns 404 Not Found');

    // User B attempting to download User A Bank Payment Sheet
    const idorBankExport = await request(`/api/export/bank-payment/${periodA.id}`, {
      headers: { Authorization: `Bearer ${tokenB}` }
    });
    assert(idorBankExport.status === 404, 'User B IDOR attempt to export User A Bank Sheet returns 404 Not Found');

    // 6. Test Spoofing Prevention
    console.log('\n--- TEST GROUP 6: CLIENT-SUPPLIED OWNERSHIP SPOOFING PREVENTION ---');
    // User B tries to insert an employee with spoofed owner_user_id = 1 (User A)
    const spoofEmp = await request('/api/employees', {
      method: 'POST',
      headers: { Authorization: `Bearer ${tokenB}` },
      body: {
        emp_code: `B-EMP-${uniqueSuffix}`,
        name: 'Employee Owned By User B',
        owner_user_id: userA.id // Malicious attempt to inject User A as owner
      }
    });
    assert(spoofEmp.status === 201, 'User B created new employee');
    assert(spoofEmp.data.employee.owner_user_id === userB.id,
      `Server rejected spoofed owner_user_id; strictly assigned authenticated ID (${userB.id})`);

    const userBEmpId = spoofEmp.data.employee.id;

    // 7. Verify User A cannot see User B's new employee
    console.log('\n--- TEST GROUP 7: BIDIRECTIONAL ISOLATION VERIFICATION ---');
    const empsACheck = await request('/api/employees', {
      headers: { Authorization: `Bearer ${tokenA}` }
    });
    const foundBInA = empsACheck.data.employees.find(e => e.id === userBEmpId);
    assert(!foundBInA, 'User A cannot see User B Employee in employee list');

    const idorUserAReadB = await request(`/api/employees/${userBEmpId}`, {
      headers: { Authorization: `Bearer ${tokenA}` }
    });
    assert(idorUserAReadB.status === 404, 'User A querying User B employee directly returns 404 Not Found');

    console.log('\n================================================================');
    console.log(`MULTI-USER SECURITY TESTS COMPLETED: ${passed} PASSED, ${failed} FAILED`);
    console.log('================================================================\n');

    if (failed > 0) {
      process.exit(1);
    }
  } catch (err) {
    console.error('Fatal test execution error:', err);
    process.exit(1);
  }
}

runMultiUserSecurityTests();
