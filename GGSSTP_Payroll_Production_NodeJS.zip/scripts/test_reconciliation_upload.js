const fs = require('fs');
const path = require('path');

async function testReconciliation() {
  console.log('Testing Reconciliation API with Formula Extraction...');

  // 1. Login to get token
  const loginRes = await fetch('http://localhost:5000/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'admin@ggsstp2026' })
  });
  const loginData = await loginRes.json();
  const token = loginData.token;
  console.log('✓ Admin login successful. Token acquired.');

  // 2. Test GET /api/reconciliation/run
  const runRes = await fetch('http://localhost:5000/api/reconciliation/run', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const runData = await runRes.json();
  console.log('✓ Default reconciliation status:', runData.overall.status);
  console.log('✓ Audited records:', runData.overall.totalEmployeesAudited, 'Match Rate:', runData.overall.overallMatchRate);
  console.log('✓ Extracted formulas count:', runData.extractedFormulasSummary?.length);
  const sampleF = runData.extractedFormulasSummary?.[0];
  if (sampleF) {
    console.log('  Sample Formula:', sampleF.col, sampleF.header, '=>', sampleF.formula);
  }

  // 3. Test POST /api/reconciliation/upload-and-reconcile with multipart upload
  const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
  const fileBuffer = fs.readFileSync(filePath);
  const boundary = '----WebKitFormBoundary' + Math.random().toString(36).substring(2);

  const payload = Buffer.concat([
    Buffer.from(
      `--${boundary}\r\n` +
      `Content-Disposition: form-data; name="file"; filename="SALARY SHEET-for EPF Sepf 2026.xlsx"\r\n` +
      `Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n\r\n`
    ),
    fileBuffer,
    Buffer.from(`\r\n--${boundary}--\r\n`)
  ]);

  const uploadRes = await fetch('http://localhost:5000/api/reconciliation/upload-and-reconcile', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': `multipart/form-data; boundary=${boundary}`
    },
    body: payload
  });

  const uploadData = await uploadRes.json();
  console.log('✓ Upload reconciliation response status:', uploadRes.status);
  if (!uploadRes.ok) {
    console.error('Upload Error:', uploadData);
    process.exit(1);
  }

  console.log('✓ Uploaded File Name:', uploadData.referenceFile);
  console.log('✓ Extracted Formulas Count:', uploadData.extractedFormulasSummary?.length);
  for (const f of (uploadData.extractedFormulasSummary || []).slice(0, 4)) {
    console.log(`    Col ${f.col} [${f.header}]: ${f.formula} (Val: ₹${f.sampleVal})`);
  }

  // Check Net Payable Formula
  const mm1Data = uploadData.sheets['MM-1'];
  if (mm1Data) {
    console.log('✓ MM-1 Net Payable Formula:', mm1Data.netPayableFormula);
    console.log('✓ MM-1 Match Rate:', mm1Data.matchRate);
  }

  // 4. Test GET /api/reconciliation/periods
  const pRes = await fetch('http://localhost:5000/api/reconciliation/periods', {
    headers: { Authorization: `Bearer ${token}` }
  });
  const pData = await pRes.json();
  console.log('✓ Available periods for Net Payable sync:', pData.periods?.length);

  // 5. Test Adopt Rules
  if (uploadData.detectedParameters) {
    const adoptRes = await fetch('http://localhost:5000/api/reconciliation/adopt-rules', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: 'Auto-Adopted Test Rules',
        ...uploadData.detectedParameters
      })
    });
    const adoptData = await adoptRes.json();
    console.log('✓ Adopt Rules result:', adoptData.message);
  }

  console.log('================================================================');
  console.log('ALL RECONCILIATION & FORMULA EXTRACTION TESTS PASSED!');
  console.log('================================================================');
}

testReconciliation().catch(err => {
  console.error('Test Failed:', err);
  process.exit(1);
});
