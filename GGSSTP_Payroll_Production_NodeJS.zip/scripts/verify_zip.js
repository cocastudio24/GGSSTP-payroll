const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const zipPath = path.join(__dirname, '..', 'GGSSTP_Payroll_Production_NodeJS.zip');
console.log('Verifying Zip Archive Integrity:', zipPath);

if (!fs.existsSync(zipPath)) {
  console.error('ERROR: Zip file not found!');
  process.exit(1);
}

const stats = fs.statSync(zipPath);
console.log(`Zip File Size: ${(stats.size / 1024).toFixed(2)} KB`);

// Check Magic bytes
const buffer = Buffer.alloc(4);
const fd = fs.openSync(zipPath, 'r');
fs.readSync(fd, buffer, 0, 4, 0);
fs.closeSync(fd);

const isPkZip = buffer[0] === 0x50 && buffer[1] === 0x4b && buffer[2] === 0x03 && buffer[3] === 0x04;
if (!isPkZip) {
  console.error('ERROR: Invalid ZIP magic header!');
  process.exit(1);
}
console.log('✅ ZIP Magic Header Verified (PK\\x03\\x04 standard format)');

// Test unzip into a temporary directory using PowerShell / tar
const testExtractDir = path.join(__dirname, '..', 'temp_verify_extract');
if (fs.existsSync(testExtractDir)) {
  fs.rmSync(testExtractDir, { recursive: true, force: true });
}
fs.mkdirSync(testExtractDir, { recursive: true });

try {
  console.log('Testing extraction into temporary folder...');
  execSync(`tar -xf "${zipPath}" -C "${testExtractDir}"`, { stdio: 'pipe' });
  console.log('✅ Extraction succeeded without warnings or errors!');

  // Check critical files at root
  const requiredRootFiles = [
    'package.json',
    'package-lock.json',
    'index.html',
    'index.js',
    'server.js',
    'vite.config.mts',
    'tsconfig.json',
    'tsconfig.server.json',
    'Dockerfile',
    '.env',
    'HOW_TO_RUN_ON_SERVER.txt'
  ];

  for (const rf of requiredRootFiles) {
    const p = path.join(testExtractDir, rf);
    if (!fs.existsSync(p)) {
      throw new Error(`Missing expected root file: ${rf}`);
    }
    console.log(`  ✓ Root file present: ${rf}`);
  }

  // Check critical directories
  const requiredDirs = [
    'dist',
    'src',
    'server',
    'reference_files',
    'scripts'
  ];

  for (const rd of requiredDirs) {
    const p = path.join(testExtractDir, rd);
    if (!fs.existsSync(p)) {
      throw new Error(`Missing expected directory: ${rd}`);
    }
    console.log(`  ✓ Directory present: ${rd}`);
  }

  // Check critical files
  const requiredFiles = [
    'reference_files/user_prompt_184_employees.csv',
    'scripts/seed_184_employees.js'
  ];
  for (const rf of requiredFiles) {
    const p = path.join(testExtractDir, rf);
    if (!fs.existsSync(p)) {
      throw new Error(`Missing expected file: ${rf}`);
    }
    console.log(`  ✓ Essential file present: ${rf}`);
  }

  // Check dist artifacts
  const distFiles = [
    'dist/index.html',
    'dist/server.js',
    'dist/database/schema.sql'
  ];

  for (const df of distFiles) {
    const p = path.join(testExtractDir, df);
    if (!fs.existsSync(p)) {
      throw new Error(`Missing expected compiled dist artifact: ${df}`);
    }
    console.log(`  ✓ Compiled artifact present: ${df}`);
  }

  // Verify package.json is valid JSON
  const pkgContent = JSON.parse(fs.readFileSync(path.join(testExtractDir, 'package.json'), 'utf-8'));
  console.log(`  ✓ package.json parsed successfully. App Name: "${pkgContent.name}", Scripts: [${Object.keys(pkgContent.scripts).join(', ')}]`);

  // Verify node_modules and blocked files (.ps1) are NOT present anywhere
  function assertNoBlockedFilesOrNodeModules(dir) {
    const list = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of list) {
      const p = path.join(dir, item.name);
      if (item.name === 'node_modules') {
        throw new Error(`Forbidden directory found in archive: ${p}`);
      }
      if (item.name.endsWith('.ps1')) {
        throw new Error(`Blocked file type (.ps1) found in archive: ${p}`);
      }
      if (item.isDirectory()) {
        assertNoBlockedFilesOrNodeModules(p);
      }
    }
  }
  assertNoBlockedFilesOrNodeModules(testExtractDir);
  console.log('  ✓ Verified ZERO node_modules and ZERO .ps1 files exist anywhere in the archive.');

  console.log('================================================================');
  console.log('🎉 ZIP INTEGRITY VERIFICATION PASSED: 100% HEALTHY PRODUCTION ARCHIVE!');
  console.log('================================================================');
} catch (err) {
  console.error('ZIP VERIFICATION FAILED:', err.message);
  process.exit(1);
} finally {
  // Clean up temporary test folder
  if (fs.existsSync(testExtractDir)) {
    fs.rmSync(testExtractDir, { recursive: true, force: true });
    console.log('Cleaned up verification scratch directory.');
  }
}
