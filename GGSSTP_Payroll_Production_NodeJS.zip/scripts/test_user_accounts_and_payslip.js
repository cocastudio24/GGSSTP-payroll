const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const { db } = require('../dist/database/db');
const { numberToWordsIndian, fetchPayslipData } = require('../dist/payslip/payslipUtils');
const { generatePayslipPdf } = require('../dist/payslip/payslipPdfGenerator');
const { generatePayslipExcel } = require('../dist/payslip/payslipExcelGenerator');
const { PROTECTED_USERNAMES } = require('../dist/routes/userRoutes');

async function runVerification() {
  console.log('================================================================');
  console.log('VERIFYING PERMANENT ACCOUNTS, DATA ISOLATION & PAYSLIP SYSTEM');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  }

  try {
    await db.init();

    // 1. Verify 4 permanent accounts in database
    console.log('\n--- CHECK 1: Four Permanent System Accounts ---');
    const usersRes = await db.query(`SELECT id, username, full_name, role, password_hash, is_active FROM users ORDER BY id;`);
    const usersByUsername = {};
    usersRes.rows.forEach(u => { usersByUsername[u.username] = u; });

    // admin
    const adminUser = usersByUsername['admin'];
    assert(adminUser !== undefined, 'Account 1: "admin" exists in database');
    assert(adminUser && adminUser.full_name === 'INDERJIT SINGH', 'Account 1: Name is "INDERJIT SINGH"');
    assert(adminUser && (adminUser.role === 'SUPER_ADMIN' || adminUser.role === 'Super Administrator'), 'Account 1: Role is SUPER_ADMIN');
    assert(adminUser && bcrypt.compareSync('admin@ggsstp2026', adminUser.password_hash), 'Account 1: Password matches "admin@ggsstp2026"');

    // cell1
    const cell1User = usersByUsername['cell1'];
    assert(cell1User !== undefined, 'Account 2: "cell1" exists in database');
    assert(cell1User && cell1User.full_name === 'BALJIT KAUR', 'Account 2: Name is "BALJIT KAUR"');
    assert(cell1User && (cell1User.role === 'PAYROLL_ADMIN' || cell1User.role === 'Payroll Administrator'), 'Account 2: Role is PAYROLL_ADMIN');
    assert(cell1User && bcrypt.compareSync('cell1@ggsstp2026', cell1User.password_hash), 'Account 2: Password matches "cell1@ggsstp2026"');

    // cell2
    const cell2User = usersByUsername['cell2'];
    assert(cell2User !== undefined, 'Account 3: "cell2" exists in database');
    assert(cell2User && cell2User.full_name === 'GOPIKA KASHYAP', 'Account 3: Name is "GOPIKA KASHYAP"');
    assert(cell2User && (cell2User.role === 'PAYROLL_ADMIN' || cell2User.role === 'Payroll Administrator'), 'Account 3: Role is PAYROLL_ADMIN');
    assert(cell2User && bcrypt.compareSync('cell2@ggsstp2026', cell2User.password_hash), 'Account 3: Password matches "cell2@ggsstp2026"');

    // cell3
    const cell3User = usersByUsername['cell3'];
    assert(cell3User !== undefined, 'Account 4: "cell3" exists in database');
    assert(cell3User && cell3User.full_name === 'HARPREET SINGH', 'Account 4: Name is "HARPREET SINGH"');
    assert(cell3User && (cell3User.role === 'PAYROLL_ADMIN' || cell3User.role === 'Payroll Administrator'), 'Account 4: Role is PAYROLL_ADMIN');
    assert(cell3User && bcrypt.compareSync('cell3@ggsstp2026', cell3User.password_hash), 'Account 4: Password matches "cell3@ggsstp2026"');

    // 2. Verify account immutability & protection list
    console.log('\n--- CHECK 2: Account Immutability & Protection Safeguards ---');
    assert(Array.isArray(PROTECTED_USERNAMES) && PROTECTED_USERNAMES.length === 4, 'PROTECTED_USERNAMES contains exactly 4 accounts');
    assert(PROTECTED_USERNAMES.includes('admin') && PROTECTED_USERNAMES.includes('cell1') &&
           PROTECTED_USERNAMES.includes('cell2') && PROTECTED_USERNAMES.includes('cell3'),
           'PROTECTED_USERNAMES covers [admin, cell1, cell2, cell3]');

    // 3. Verify Number to Words Indian Currency
    console.log('\n--- CHECK 3: Indian Currency Number-to-Words Converter ---');
    const words1 = numberToWordsIndian(20068);
    assert(words1 === 'Rupees Twenty Thousand Sixty Eight Only', `20068 -> "${words1}"`);
    const words2 = numberToWordsIndian(125430.50);
    assert(words2.includes('Lakh') && words2.includes('Rupees'), `125430.50 -> "${words2}"`);
    const words3 = numberToWordsIndian(0);
    assert(words3 === 'Rupees Zero Only', `0 -> "${words3}"`);

    // 4. Verify Payslip Data Fetcher
    console.log('\n--- CHECK 4: Payslip Data Fetcher ---');
    const firstEntryRes = await db.query(`SELECT id FROM payroll_entries ORDER BY id LIMIT 1;`);
    if (firstEntryRes.rows.length > 0) {
      const entryId = firstEntryRes.rows[0].id;
      const payslipData = await fetchPayslipData(entryId);
      assert(payslipData !== null, `Successfully fetched payslip data for entry ID ${entryId}`);
      assert(Boolean(payslipData.empName && payslipData.empCode), `Payslip employee: ${payslipData.empName} (${payslipData.empCode})`);
      assert(Boolean(payslipData.monthName && payslipData.year), `Payslip period: ${payslipData.monthName} ${payslipData.year}`);
      assert(payslipData.netPayable !== undefined, `Net payable amount: ₹${payslipData.netPayable}`);
      assert(Boolean(payslipData.netPayableWords), `Net payable in words: "${payslipData.netPayableWords}"`);
      assert(payslipData.employerEpf12 !== undefined, `Employer EPF 12%: ₹${payslipData.employerEpf12}`);
      assert(payslipData.totalEmployerContributions !== undefined, `Total Employer Cost: ₹${payslipData.totalEmployerContributions}`);

      // 5. Verify Payslip PDF Generation
      console.log('\n--- CHECK 5: Payslip PDF Generation ---');
      const pdfBuffer = await generatePayslipPdf(payslipData);
      assert(Buffer.isBuffer(pdfBuffer) && pdfBuffer.length > 1000, `Generated PDF buffer of size ${pdfBuffer.length} bytes`);
      const pdfHeader = pdfBuffer.slice(0, 5).toString('ascii');
      assert(pdfHeader === '%PDF-', `PDF starts with valid header: ${pdfHeader}`);

      // 6. Verify Payslip Excel Generation
      console.log('\n--- CHECK 6: Payslip Excel Generation ---');
      const workbook = generatePayslipExcel(payslipData);
      const xlsxBuffer = await workbook.xlsx.writeBuffer();
      assert(Buffer.isBuffer(xlsxBuffer) && xlsxBuffer.length > 1000, `Generated Excel buffer of size ${xlsxBuffer.length} bytes`);
      const xlsxHeader = xlsxBuffer.slice(0, 2).toString('ascii');
      assert(xlsxHeader === 'PK', `Excel starts with valid ZIP/XLSX signature: ${xlsxHeader}`);
    } else {
      console.log('No payroll entries found to test payslip data fetching.');
    }

    // 7. Verify Data Isolation Logic
    console.log('\n--- CHECK 7: RBAC Data Isolation Query Logic ---');
    // Admin query
    const adminQuery = await db.query(`SELECT COUNT(*) as count FROM employees WHERE 1=1;`);
    const totalEmployees = parseInt(adminQuery.rows[0].count, 10);
    assert(totalEmployees > 0, `Super Admin query accesses all ${totalEmployees} employee records`);

    // Cell1 query
    const cell1Query = await db.query(`SELECT COUNT(*) as count FROM employees WHERE (owner_user_id = $1 OR created_by_user_id = $1);`, [cell1User.id]);
    const cell1Employees = parseInt(cell1Query.rows[0].count, 10);
    assert(typeof cell1Employees === 'number', `Cell1 query successfully isolated to own records (count: ${cell1Employees})`);

    // Verify created_by_user_id column exists
    const colCheck = await db.query(`
      SELECT column_name FROM information_schema.columns 
      WHERE table_name = 'employees' AND column_name IN ('created_by_user_id', 'updated_by_user_id');
    `);
    assert(colCheck.rows.length === 2, 'Employees table has created_by_user_id and updated_by_user_id tracking columns');

    console.log('\n================================================================');
    console.log(`SUMMARY: ${passed} PASSED, ${failed} FAILED`);
    console.log('================================================================\n');

    if (failed > 0) {
      process.exit(1);
    }
  } catch (err) {
    console.error('Test execution failed with error:', err);
    process.exit(1);
  } finally {
    try {
      await db.close();
    } catch {}
  }
}

runVerification();
