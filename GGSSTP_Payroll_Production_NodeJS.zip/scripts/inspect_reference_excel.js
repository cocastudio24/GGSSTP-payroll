const XLSX = require('xlsx');
const path = require('path');
const fs = require('fs');

const file = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
console.log('Reading file:', file);

const wb = XLSX.readFile(file);
console.log('Sheet names:', wb.SheetNames);

for (const name of wb.SheetNames) {
  console.log(`\n================ SHEET: ${name} ================`);
  const ws = wb.Sheets[name];
  const range = XLSX.utils.decode_range(ws['!ref'] || 'A1:A1');
  console.log(`Range: ${ws['!ref']} (Cols: ${range.e.c + 1}, Rows: ${range.e.r + 1})`);

  // Print first 5 rows to see headers
  for (let r = 0; r <= Math.min(5, range.e.r); r++) {
    const rowVals = [];
    for (let c = 0; c <= Math.min(60, range.e.c); c++) {
      const cellAddress = XLSX.utils.encode_cell({ r, c });
      const cell = ws[cellAddress];
      if (cell) {
        rowVals.push(`[${cellAddress}: ${cell.v}${cell.f ? ' (F: ' + cell.f + ')' : ''}]`);
      }
    }
    if (rowVals.length > 0) {
      console.log(`Row ${r + 1}: ${rowVals.slice(0, 15).join(' ')}`);
      if (rowVals.length > 15) {
        console.log(`       ${rowVals.slice(15, 30).join(' ')}`);
      }
      if (rowVals.length > 30) {
        console.log(`       ${rowVals.slice(30).join(' ')}`);
      }
    }
  }
}
