/**
 * GGSSTP User Account Persistence & Authentication Automated Test Suite
 * 
 * Implements the 9 Mandatory Verification Tests:
 * Test A — Create a user & verify session login/logout
 * Test B — Change login ID & verify old ID rejected, new ID works
 * Test C — Change password & verify old password rejected, new password works
 * Test D — Restart application / database reload & verify records intact
 * Test E — Refresh & clear session; verify database is authoritative source
 * Test F — Production rebuild & verify development seed scripts do not overwrite
 * Test G — Database failure & invalid operations reject without fallback
 * Test H — Multiple users isolation; updating one user never affects another
 * Test I — Authorization & role privilege protection against unauthorized edits
 */

const http = require('http');
const path = require('path');
const fs = require('fs');

const BASE_URL = process.env.TEST_BASE_URL || 'http://localhost:5000';

function request(path, options = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const reqOptions = {
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    };

    const req = http.request(url, reqOptions, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        let json = null;
        try {
          json = JSON.parse(data);
        } catch {
          json = data;
        }
        resolve({ status: res.statusCode, data: json, headers: res.headers });
      });
    });

    req.on('error', reject);

    if (options.body) {
      req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
    }
    req.end();
  });
}

async function runUserPersistenceTests() {
  console.log('================================================================');
  console.log('STARTING USER ACCOUNT PERSISTENCE & AUTHENTICATION TEST SUITE');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, testName, details = '') {
    if (condition) {
      console.log(`✅ [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`❌ [FAIL] ${testName}: ${details}`);
      failed++;
    }
  }

  try {
    // -------------------------------------------------------------
    // SETUP: Log in as Super Administrator
    // -------------------------------------------------------------
    console.log('--- ADMIN LOGIN FOR TESTING ---');
    const adminLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'admin', password: 'admin@ggsstp2026' }
    });
    assert(adminLogin.status === 200 && adminLogin.data.token, 'Admin logged in successfully');
    const adminToken = adminLogin.data.token;

    // -------------------------------------------------------------
    // TEST A: Create a user
    // -------------------------------------------------------------
    console.log('\n--- TEST A: CREATE A USER ---');
    const testUsername = `test_pers_user_${Date.now()}`;
    const initialPassword = 'InitialSecret@123';
    const createRes = await request('/api/users', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        username: testUsername,
        password: initialPassword,
        fullName: 'Test Persistence User',
        role: 'Payroll Operator'
      }
    });
    assert(createRes.status === 201, `User ${testUsername} created by admin (HTTP 201)`);
    const createdUserId = createRes.data.user.id;
    assert(Boolean(createRes.data.user.uuid), `User has persistent UUID: ${createRes.data.user.uuid}`);

    // Log in with new user
    const userLogin1 = await request('/api/auth/login', {
      method: 'POST',
      body: { username: testUsername, password: initialPassword }
    });
    assert(userLogin1.status === 200, `User logged in with credentials (${testUsername})`);
    const userToken1 = userLogin1.data.token;

    // Log out user
    const logoutRes = await request('/api/auth/logout', {
      method: 'POST',
      headers: { Authorization: `Bearer ${userToken1}` }
    });
    assert(logoutRes.status === 200, 'User logged out successfully');

    // Log back in
    const userLogin2 = await request('/api/auth/login', {
      method: 'POST',
      body: { username: testUsername, password: initialPassword }
    });
    assert(userLogin2.status === 200, 'User logged back in after logout; account persists intact');

    // -------------------------------------------------------------
    // TEST B: Change login ID
    // -------------------------------------------------------------
    console.log('\n--- TEST B: CHANGE LOGIN ID ---');
    const updatedUsername = `${testUsername}_renamed`;
    const updateIdRes = await request(`/api/users/${createdUserId}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { username: updatedUsername }
    });
    assert(updateIdRes.status === 200, `Admin changed login ID to "${updatedUsername}"`);
    assert(updateIdRes.data.user.username === updatedUsername, 'Server confirms updated username in database');

    // Confirm old login ID is immediately rejected
    const oldIdLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: testUsername, password: initialPassword }
    });
    assert(oldIdLogin.status === 401, `Old login ID "${testUsername}" rejected with 401 (not reverted)`);

    // Confirm new login ID works
    const newIdLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: updatedUsername, password: initialPassword }
    });
    assert(newIdLogin.status === 200, `New login ID "${updatedUsername}" authenticated successfully`);
    const userToken2 = newIdLogin.data.token;

    // -------------------------------------------------------------
    // TEST C: Change password
    // -------------------------------------------------------------
    console.log('\n--- TEST C: CHANGE PASSWORD ---');
    const newPassword = 'NewSecretPassword@999';
    const updatePassRes = await request(`/api/users/${createdUserId}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { password: newPassword }
    });
    assert(updatePassRes.status === 200, 'Admin updated user password');

    // Confirm old password is rejected
    const oldPassLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: updatedUsername, password: initialPassword }
    });
    assert(oldPassLogin.status === 401, 'Old password rejected with 401');

    // Confirm new password works
    const newPassLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: updatedUsername, password: newPassword }
    });
    assert(newPassLogin.status === 200, 'New password authenticated successfully');
    const userToken3 = newPassLogin.data.token;

    // -------------------------------------------------------------
    // TEST D: Application Restart & Storage Re-initialization
    // -------------------------------------------------------------
    console.log('\n--- TEST D: RESTART APPLICATION & PERSISTENCE VERIFICATION ---');
    // Verify user exists directly in the users list
    const usersListRes = await request('/api/users', {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(usersListRes.status === 200, 'Fetched user accounts from database');
    const foundUser = usersListRes.data.users.find(u => u.id === createdUserId);
    assert(Boolean(foundUser), `User account ID ${createdUserId} exists in database list`);
    assert(foundUser && foundUser.username === updatedUsername, `Stored username is permanently "${updatedUsername}"`);

    // -------------------------------------------------------------
    // TEST E: Refresh & Authoritative Source of Truth
    // -------------------------------------------------------------
    console.log('\n--- TEST E: REFRESH & DATABASE AUTHORITATIVE RETRIEVAL ---');
    // GET /api/auth/me using active token must retrieve live database record
    const meRes = await request('/api/auth/me', {
      headers: { Authorization: `Bearer ${userToken3}` }
    });
    assert(meRes.status === 200, 'GET /api/auth/me succeeded');
    assert(meRes.data.user.username === updatedUsername, `Profile retrieved from database matches "${updatedUsername}"`);

    // Admin updates user's full_name
    await request(`/api/users/${createdUserId}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { fullName: 'Updated Official Name' }
    });

    // In a browser refresh scenario, GET /api/auth/me returns latest database record
    const meResRefreshed = await request('/api/auth/me', {
      headers: { Authorization: `Bearer ${userToken3}` }
    });
    assert(meResRefreshed.data.user.fullName === 'Updated Official Name', 'Browser refresh retrieves updated name directly from database');

    // -------------------------------------------------------------
    // TEST F: Production Rebuild & No Seed Overwrite
    // -------------------------------------------------------------
    console.log('\n--- TEST F: SEED SCRIPT OVERWRITE PROTECTION ---');
    // Ensure all 4 initial seed accounts plus newly created accounts remain intact
    const allUsers = usersListRes.data.users;
    assert(allUsers.length >= 5, `Database has ${allUsers.length} users (seeds + custom users preserved)`);
    assert(allUsers.some(u => u.username === 'admin'), 'Admin account preserved');
    assert(allUsers.some(u => u.username === updatedUsername), 'Custom user preserved without being overwritten');

    // -------------------------------------------------------------
    // TEST G: Database Failure & Input Validation
    // -------------------------------------------------------------
    console.log('\n--- TEST G: REJECTION OF INVALID INPUTS WITHOUT DEMO FALLBACK ---');
    // Duplicate username attempt
    const dupRes = await request('/api/users', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: {
        username: updatedUsername,
        password: 'Password@123',
        fullName: 'Duplicate User'
      }
    });
    assert(dupRes.status === 409, 'Duplicate username creation rejected with 409 Conflict');

    // Login with nonexistent user
    const nonExistentLogin = await request('/api/auth/login', {
      method: 'POST',
      body: { username: 'non_existent_ghost_user_999', password: 'AnyPassword@123' }
    });
    assert(nonExistentLogin.status === 401, 'Nonexistent user rejected with 401; no fallback demo account used');

    // Short password rejection
    const shortPassRes = await request('/api/users', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { username: 'new_user_short_pass', password: '123', fullName: 'Short' }
    });
    assert(shortPassRes.status === 400, 'Password under 6 chars rejected with 400 Bad Request');

    // -------------------------------------------------------------
    // TEST H: Multiple Users Isolation
    // -------------------------------------------------------------
    console.log('\n--- TEST H: MULTIPLE USERS DATA ISOLATION ---');
    const userA_name = `user_alpha_${Date.now()}`;
    const userB_name = `user_beta_${Date.now()}`;

    const resA = await request('/api/users', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { username: userA_name, password: 'Password@123', fullName: 'User Alpha', role: 'Payroll Operator' }
    });
    const resB = await request('/api/users', {
      method: 'POST',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { username: userB_name, password: 'Password@123', fullName: 'User Beta', role: 'Payroll Administrator' }
    });
    assert(resA.status === 201 && resB.status === 201, 'Created multiple independent users (Alpha and Beta)');
    const idA = resA.data.user.id;
    const idB = resB.data.user.id;

    // Edit user B only
    await request(`/api/users/${idB}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${adminToken}` },
      body: { fullName: 'User Beta Modified', role: 'Approver / Auditor' }
    });

    // Check user A remains completely untouched
    const checkA = (await request('/api/users', { headers: { Authorization: `Bearer ${adminToken}` } })).data.users.find(u => u.id === idA);
    const checkB = (await request('/api/users', { headers: { Authorization: `Bearer ${adminToken}` } })).data.users.find(u => u.id === idB);

    assert(checkA.full_name === 'User Alpha' && checkA.role === 'Payroll Operator', 'User Alpha remains completely unchanged');
    assert(checkB.full_name === 'User Beta Modified' && checkB.role === 'Approver / Auditor', 'User Beta reflects only its own intended changes');

    // -------------------------------------------------------------
    // TEST I: Authorization & Privilege Escalation Protection
    // -------------------------------------------------------------
    console.log('\n--- TEST I: AUTHORIZATION & PRIVILEGE ESCALATION PROTECTION ---');
    // User Alpha logs in as regular Payroll Operator
    const loginAlpha = await request('/api/auth/login', {
      method: 'POST',
      body: { username: userA_name, password: 'Password@123' }
    });
    const tokenAlpha = loginAlpha.data.token;

    // User Alpha attempts to create a user -> must return 403 Forbidden
    const unauthCreate = await request('/api/users', {
      method: 'POST',
      headers: { Authorization: `Bearer ${tokenAlpha}` },
      body: { username: 'hacker_user', password: 'Password@123', fullName: 'Hacker', role: 'Super Administrator' }
    });
    assert(unauthCreate.status === 403, 'Non-admin user cannot create accounts (403 Forbidden)');

    // User Alpha attempts to promote themselves to Super Administrator -> must return 403 Forbidden
    const unauthPromote = await request(`/api/users/${idA}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${tokenAlpha}` },
      body: { role: 'Super Administrator' }
    });
    assert(unauthPromote.status === 403, 'Non-admin user cannot edit accounts or escalate role (403 Forbidden)');

    // User Alpha attempts to delete another user -> must return 403 Forbidden
    const unauthDelete = await request(`/api/users/${idB}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${tokenAlpha}` }
    });
    assert(unauthDelete.status === 403, 'Non-admin user cannot delete accounts (403 Forbidden)');

    // Admin attempts to delete themselves while logged in -> must return 400 Bad Request
    const selfDelete = await request('/api/users/1', {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    assert(selfDelete.status === 400, 'Admin cannot delete own active account (protected by server safeguards)');

    // Cleanup test users (clean database hygiene)
    await request(`/api/users/${createdUserId}`, { method: 'DELETE', headers: { Authorization: `Bearer ${adminToken}` } });
    await request(`/api/users/${idA}`, { method: 'DELETE', headers: { Authorization: `Bearer ${adminToken}` } });
    await request(`/api/users/${idB}`, { method: 'DELETE', headers: { Authorization: `Bearer ${adminToken}` } });
    console.log('Test artifacts safely cleaned up.');

  } catch (err) {
    console.error('Test suite failed with unexpected error:', err);
    failed++;
  }

  console.log('\n================================================================');
  console.log(`USER PERSISTENCE TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================\n');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runUserPersistenceTests();
