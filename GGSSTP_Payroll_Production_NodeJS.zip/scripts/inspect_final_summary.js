const { db } = require('../dist/database/db');

async function q() {
  await db.init();
  const summary = await db.query(`
    SELECT 
      u.id as user_id, 
      u.username, 
      u.full_name, 
      COUNT(e.id) as employee_count, 
      SUM(pe.net_payable) as total_net_payable
    FROM users u
    LEFT JOIN employees e ON e.owner_user_id = u.id AND e.is_active = TRUE AND e.is_archived = FALSE
    LEFT JOIN payroll_entries pe ON pe.employee_id = e.id AND pe.payroll_period_id = 1
    GROUP BY u.id, u.username, u.full_name
    ORDER BY u.id ASC;
  `);
  console.log('\n--- User Employee & Salary Breakdown ---');
  console.table(summary.rows);

  const circles = await db.query(`
    SELECT 
      cir.name as circle_name, 
      COUNT(e.id) as emp_count, 
      SUM(pe.net_payable) as circle_net_payable
    FROM circles cir
    JOIN employees e ON e.circle_id = cir.id AND e.is_active = TRUE AND e.is_archived = FALSE
    JOIN payroll_entries pe ON pe.employee_id = e.id AND pe.payroll_period_id = 1
    GROUP BY cir.name
    ORDER BY cir.name ASC;
  `);
  console.log('\n--- Circle Employee & Salary Breakdown ---');
  console.table(circles.rows);

  const plantTotal = await db.query(`
    SELECT COUNT(*) as total_employees, SUM(net_payable) as plant_wide_net_payable
    FROM payroll_entries WHERE payroll_period_id = 1;
  `);
  console.log('\n--- Plant-Wide Totals ---');
  console.table(plantTotal.rows);
  await db.close();
}

q().catch(console.error);
