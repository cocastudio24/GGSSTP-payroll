const XLSX = require('xlsx');
const path = require('path');

const filePath = path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });

function analyzeSheet(sheetName, headerRowIdx, sampleRowIdx) {
  const sheet = workbook.Sheets[sheetName];
  if (!sheet || !sheet['!ref']) return;
  const range = XLSX.utils.decode_range(sheet['!ref']);
  console.log(`\n==================================================`);
  console.log(`ANALYSIS OF SHEET: ${sheetName}`);
  console.log(`Range: ${sheet['!ref']} | Total Rows: ${range.e.r + 1} | Total Cols: ${range.e.c + 1}`);

  // Let's get headers
  const cols = [];
  for (let c = range.s.c; c <= range.e.c; c++) {
    const colLetter = XLSX.utils.encode_col(c);
    const headerCell = sheet[XLSX.utils.encode_cell({ r: headerRowIdx, c })];
    const headerVal = headerCell ? (headerCell.v !== undefined ? headerCell.v : '') : '';
    
    // Also check row above header if any
    let titleVal = '';
    if (headerRowIdx > 0) {
      const topCell = sheet[XLSX.utils.encode_cell({ r: headerRowIdx - 1, c })];
      if (topCell && topCell.v !== undefined) titleVal = topCell.v;
    }

    const sampleCell = sheet[XLSX.utils.encode_cell({ r: sampleRowIdx, c })];
    const sampleVal = sampleCell ? sampleCell.v : '';
    const sampleFormula = sampleCell && sampleCell.f ? sampleCell.f : '';

    cols.push({
      col: colLetter,
      cIndex: c,
      header: String(headerVal).trim().replace(/\r?\n/g, ' '),
      title: String(titleVal).trim().replace(/\r?\n/g, ' '),
      sampleVal,
      sampleFormula
    });
  }

  console.log(`Columns count: ${cols.length}`);
  cols.forEach((col, idx) => {
    let desc = `Col ${col.col} (#${idx + 1}): [${col.header}]`;
    if (col.title && col.title !== col.header) desc += ` (Row-1: "${col.title}")`;
    desc += ` => Sample: "${col.sampleVal}"`;
    if (col.sampleFormula) desc += ` | FORMULA: =${col.sampleFormula}`;
    console.log(desc);
  });
}

analyzeSheet('MM-1', 0, 1);
analyzeSheet('EMC', 1, 2);
