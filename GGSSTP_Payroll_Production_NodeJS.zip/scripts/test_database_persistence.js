/**
 * GGSSTP Database Persistence & Zero-Reset Verification Suite
 * 
 * Verifies that data entered by users (cell1, cell2, cell3, admin)
 * permanently survives server restarts, process recycling, and browser re-authentication
 * without reverting to seed/default data or triggering destructive backup overwrites.
 */

const http = require('http');
const { spawn } = require('child_process');
const path = require('path');

const PORT = 5005;
const BASE_URL = `http://127.0.0.1:${PORT}/api`;

function request(method, endpoint, body = null, token = null) {
  return new Promise((resolve, reject) => {
    const url = new URL(endpoint.startsWith('http') ? endpoint : `${BASE_URL}${endpoint}`);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method: method,
      headers: {
        'Content-Type': 'application/json'
      }
    };
    if (token) options.headers['Authorization'] = `Bearer ${token}`;

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = data ? JSON.parse(data) : {};
          resolve({ status: res.statusCode, headers: res.headers, body: parsed });
        } catch {
          resolve({ status: res.statusCode, headers: res.headers, body: data });
        }
      });
    });
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

function startServer() {
  return new Promise((resolve, reject) => {
    const serverProcess = spawn('node', ['dist/server.js'], {
      cwd: path.resolve(__dirname, '..'),
      env: {
        ...process.env,
        PORT: String(PORT),
        NODE_ENV: 'test',
        NO_AUTO_OPEN: 'true'
      },
      stdio: ['ignore', 'pipe', 'pipe']
    });

    let started = false;
    serverProcess.stdout.on('data', d => {
      const msg = d.toString();
      if ((msg.includes('running on port') || msg.includes('API Base URL')) && !started) {
        started = true;
        setTimeout(() => resolve(serverProcess), 500);
      }
    });

    serverProcess.stderr.on('data', d => {
      // console.error('[Server Error]', d.toString());
    });

    serverProcess.on('exit', code => {
      if (!started) reject(new Error(`Server exited with code ${code} before starting`));
    });

    setTimeout(() => {
      if (!started) reject(new Error('Server start timed out after 10s'));
    }, 10000);
  });
}

async function runPersistenceTest() {
  console.log('================================================================');
  console.log('GGSSTP DATABASE PERSISTENCE & ZERO-RESET VERIFICATION SUITE');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, desc) {
    if (condition) {
      console.log(`  [PASS] ${desc}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${desc}`);
      failed++;
    }
  }

  let server1 = null;
  let server2 = null;
  let testEmpId = null;
  const uniqueCode = `PERST-${Date.now().toString().slice(-5)}`;
  const testName = `Persistence Test Employee ${uniqueCode}`;

  try {
    // -------------------------------------------------------------
    // Phase 1: Start Server Instance 1
    // -------------------------------------------------------------
    console.log('[Phase 1] Launching Server Instance 1 (Initial Session)...');
    server1 = await startServer();
    console.log('  Server Instance 1 online on port', PORT);

    // Login as cell1
    const cell1Login = await request('POST', '/auth/login', { username: 'cell1', password: 'cell1@ggsstp2026' });
    assert(cell1Login.status === 200 && cell1Login.body.token, 'Cell1 authenticated on Server 1');
    const cell1Token = cell1Login.body.token;

    // Login as admin
    const adminLogin = await request('POST', '/auth/login', { username: 'admin', password: 'admin@ggsstp2026' });
    assert(adminLogin.status === 200 && adminLogin.body.token, 'Super Admin authenticated on Server 1');
    const adminToken = adminLogin.body.token;

    // Cell1 creates an employee with specific custom allowances
    console.log(`\n[Phase 2] Cell1 creates a new employee: ${testName} (${uniqueCode})...`);
    const createRes = await request('POST', '/employees', {
      name: testName,
      emp_code: uniqueCode,
      uan: `10099${Date.now().toString().slice(-7)}`,
      designation_id: 3,
      cell: 'Cell 1 Main Plant',
      default_gross_rate: 18500,
      default_special_allowance: 4200,
      default_thermal_allowance: 1500,
      default_perf_allowance: 500
    }, cell1Token);

    assert(createRes.status === 201 && createRes.body.employee && createRes.body.employee.id, 'Employee created successfully by Cell1');
    testEmpId = createRes.body?.employee?.id;

    // Verify Admin immediately sees this new employee created by cell1
    const adminCheck1 = await request('GET', `/employees/${testEmpId}`, null, adminToken);
    assert(adminCheck1.status === 200 && adminCheck1.body.employee.emp_code === uniqueCode, 'Super Admin immediately sees Cell1 employee on Server 1');

    // -------------------------------------------------------------
    // Phase 3: Abrupt Process Termination (Simulating GoDaddy restart)
    // -------------------------------------------------------------
    console.log('\n[Phase 3] Simulating Abrupt Server Crash / Process Restart (killing Server 1)...');
    server1.kill('SIGKILL');
    await new Promise(r => setTimeout(r, 1500));
    console.log('  Server 1 terminated.');

    // -------------------------------------------------------------
    // Phase 4: Launch Server Instance 2 (Cold Start)
    // -------------------------------------------------------------
    console.log('\n[Phase 4] Launching Server Instance 2 (Cold Restart from persistent storage)...');
    server2 = await startServer();
    console.log('  Server Instance 2 online on port', PORT);

    // Login again after restart
    const adminLogin2 = await request('POST', '/auth/login', { username: 'admin', password: 'admin@ggsstp2026' });
    assert(adminLogin2.status === 200 && adminLogin2.body.token, 'Super Admin authenticated on Server 2 after cold restart');
    const adminToken2 = adminLogin2.body.token;

    const cell1Login2 = await request('POST', '/auth/login', { username: 'cell1', password: 'cell1@ggsstp2026' });
    assert(cell1Login2.status === 200 && cell1Login2.body.token, 'Cell1 authenticated on Server 2 after cold restart');
    const cell1Token2 = cell1Login2.body.token;

    // -------------------------------------------------------------
    // Phase 5: Verification of Persistence Across Restarts
    // -------------------------------------------------------------
    console.log('\n[Phase 5] Verifying Data Persistence (Zero-Reset Check)...');
    
    // Check if test employee STILL exists after restart
    const empPersistCheck = await request('GET', `/employees/${testEmpId}`, null, adminToken2);
    assert(empPersistCheck.status === 200, `Employee record #${testEmpId} survived server restart without reset (HTTP 200)`);
    assert(empPersistCheck.body?.employee?.name === testName, `Employee name "${testName}" matches exactly`);
    assert(empPersistCheck.body?.employee?.emp_code === uniqueCode, `Employee code "${uniqueCode}" matches exactly`);
    assert(Number(empPersistCheck.body?.employee?.default_gross_rate) === 18500, 'Custom salary rate 18500 persisted correctly');

    // Cell1 can also still see their own employee
    const cell1PersistCheck = await request('GET', `/employees/${testEmpId}`, null, cell1Token2);
    assert(cell1PersistCheck.status === 200, 'Cell1 can access persisted employee after restart');

    // Cell2 cannot access cell1's persisted employee
    const cell2Login = await request('POST', '/auth/login', { username: 'cell2', password: 'cell2@ggsstp2026' });
    const cell2Token = cell2Login.body.token;
    const cell2PersistCheck = await request('GET', `/employees/${testEmpId}`, null, cell2Token);
    assert(cell2PersistCheck.status === 403, 'Data isolation maintained after restart (Cell2 denied access with 403)');

    // -------------------------------------------------------------
    // Phase 6: Clean Up
    // -------------------------------------------------------------
    console.log('\n[Phase 6] Cleaning up test records...');
    const delRes = await request('DELETE', `/employees/${testEmpId}`, null, adminToken2);
    assert(delRes.status === 200, 'Cleaned up test employee');

  } catch (err) {
    console.error('Fatal error during persistence test:', err);
    failed++;
  } finally {
    if (server1 && !server1.killed) server1.kill();
    if (server2 && !server2.killed) server2.kill();
  }

  console.log('\n================================================================');
  console.log(`PERSISTENCE TEST RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================');

  if (failed > 0) process.exit(1);
}

runPersistenceTest();
