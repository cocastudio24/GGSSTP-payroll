const XLSX = require('xlsx');
const path = require('path');
const { autoMapHeader, normalizeHeader, TARGET_FIELDS, formatIdentifierText } = require('../dist/excel/columnDictionary');

function testSheetMapping(filename, sheetName, headerRow) {
  const wb = XLSX.readFile(filename);
  const sheet = wb.Sheets[sheetName];
  const range = XLSX.utils.decode_range(sheet['!ref']);
  
  const allHeaders = [];
  for (let c = 0; c <= range.e.c; c++) {
    const cell = sheet[XLSX.utils.encode_cell({ r: headerRow, c })];
    const val = cell && cell.v !== undefined ? String(cell.v).trim().replace(/\n/g, ' ') : '';
    allHeaders.push({ colIndex: c, rawHeader: val });
  }

  console.log(`\n================================================================`);
  console.log(`TESTING MAPPING FOR: ${filename} -> Sheet: ${sheetName}`);
  console.log(`================================================================`);

  let mappedCount = 0;
  let excludedCount = 0;

  for (let c = 0; c <= range.e.c; c++) {
    const rawHeader = allHeaders[c].rawHeader;
    const sampleCell = sheet[XLSX.utils.encode_cell({ r: headerRow + 1, c })];
    const sampleVal = sampleCell && sampleCell.v !== undefined ? sampleCell.v : '';

    const mapping = autoMapHeader(rawHeader, c, allHeaders, sampleVal);
    const targetField = TARGET_FIELDS.find(f => f.key === mapping.targetFieldKey);

    if (mapping.targetFieldKey === '__EXCLUDE__') {
      excludedCount++;
      console.log(`  [${XLSX.utils.encode_col(c)}] "${rawHeader}" -> ✕ EXCLUDED (${mapping.reason}) [Sample: "${sampleVal}"]`);
    } else {
      mappedCount++;
      console.log(`  [${XLSX.utils.encode_col(c)}] "${rawHeader}" -> ✓ ${targetField.label} (${mapping.targetFieldKey}) [Conf: ${(mapping.confidence * 100).toFixed(0)}%] [Sample: "${sampleVal}"]`);
    }
  }

  console.log(`\nSummary: Total Columns: ${range.e.c + 1} | Mapped: ${mappedCount} | Excluded: ${excludedCount}`);
}

(async () => {
  testSheetMapping('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx', 'MM-1', 0);
  testSheetMapping('reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx', 'EMC', 1);
  testSheetMapping('reference_files/SALARY OP AND c&i.xlsx', 'operation circle', 1);
})();
