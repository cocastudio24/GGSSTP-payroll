const XLSX = require('xlsx');
const path = require('path');

const wb = XLSX.readFile(path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx'), { cellFormula: true });
console.log('Sheet Names:', wb.SheetNames);

for (const sheetName of wb.SheetNames) {
  const ws = wb.Sheets[sheetName];
  console.log('\n================ SHEET:', sheetName, '================');
  const range = XLSX.utils.decode_range(ws['!ref'] || 'A1');
  console.log('Range:', ws['!ref'], 'Rows:', range.e.r + 1, 'Cols:', range.e.c + 1);

  // Look for header row
  let headerRow = 0;
  for (let r = 0; r <= Math.min(5, range.e.r); r++) {
    for (let c = 0; c <= range.e.c; c++) {
      const cell = ws[XLSX.utils.encode_cell({ r, c })];
      if (cell && cell.v && String(cell.v).toLowerCase().includes('net')) {
        headerRow = r;
        break;
      }
    }
  }

  const headers = [];
  for (let c = 0; c <= range.e.c; c++) {
    const cell = ws[XLSX.utils.encode_cell({ r: headerRow, c })];
    headers.push(cell ? String(cell.v).trim().replace(/\r?\n/g, ' ') : '');
  }

  headers.forEach((h, idx) => {
    const hl = h.toLowerCase();
    if (hl.includes('net') || hl.includes('epf') || hl.includes('esi') || hl.includes('lwf') || hl.includes('deduction') || hl.includes('round')) {
      console.log(` Col ${idx} [${XLSX.utils.encode_col(idx)}]: "${h}"`);
    }
  });

  for (let r = headerRow + 1; r <= Math.min(headerRow + 6, range.e.r); r++) {
    const nameCell = ws[XLSX.utils.encode_cell({ r, c: 1 })] || ws[XLSX.utils.encode_cell({ r, c: 2 })];
    console.log(`\nRow ${r+1}: Name = ${nameCell ? nameCell.v : ''}`);
    for (let c = 0; c <= range.e.c; c++) {
      const cell = ws[XLSX.utils.encode_cell({ r, c })];
      const h = headers[c];
      const hl = h.toLowerCase();
      if (cell && (hl.includes('net') || hl.includes('epf') || hl.includes('esi') || hl.includes('lwf') || hl.includes('total deduction') || hl.includes('round'))) {
        console.log(`  Col ${XLSX.utils.encode_col(c)} ("${h}"): val=${cell.v}, formula=${cell.f || 'none'}`);
      }
    }
  }
}
