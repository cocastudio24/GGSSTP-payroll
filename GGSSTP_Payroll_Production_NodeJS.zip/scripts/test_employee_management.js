const path = require('path');
const fs = require('fs');

async function runEmployeeManagementTests() {
  console.log('================================================================');
  console.log('STARTING GGSSTP EMPLOYEE MANAGEMENT MODULE AUTOMATED TEST SUITE');
  console.log('================================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  }

  // Set test data dir
  process.env.PG_DATA_DIR = path.resolve(__dirname, '../data/test_emp_pg');
  const { db } = require('../dist/database/db');
  const { calculatePayroll, INITIAL_RATES } = require('../dist/engine/payrollCalculator');
  const { ExcelImporter } = require('../dist/excel/excelImporter');

  await db.init();
  console.log('Database connected.\n');

  // Find or create test user
  const userRes = await db.query(`SELECT id FROM users WHERE username = 'admin' LIMIT 1;`);
  const adminId = userRes.rows[0]?.id || 1;

  // --- TEST A: Add New Employee with All Master Fields ---
  console.log('--- TEST A: Add New Employee with All Master Fields ---');
  const testEmpCode = `TEST-EMP-${Date.now().toString().slice(-4)}`;
  const desigRes = await db.query(`SELECT id FROM designations WHERE alias = 'SW' LIMIT 1;`);
  const swDesigId = desigRes.rows[0]?.id || 1;

  const insRes = await db.query(`
    INSERT INTO employees (
      owner_user_id, created_by_user_id, emp_code, name, father_name, uan, designation_id,
      dob, age_above_58, date_of_joining, more_than_3_yrs, more_than_5_yrs,
      qualification, experience_years, qualified_status, cell, hazard_duty, above_60,
      bank_name, bank_account, ifsc, account_holder_name, esi_number,
      default_gross_rate, default_special_allowance, default_thermal_allowance,
      default_perf_allowance, default_bonus_percentage,
      epf_applicable, esi_applicable, lwf_applicable, is_active
    ) VALUES (
      $1, $1, $2, 'HARPREET KAUR', 'JAGJIT SINGH', '100999888777', $3,
      '15-08-1992', 'N', '01.04.2018', 'YES', 'YES',
      'Diploma (Electrical)', '8', 'Yes', 'EM-1', 'haz', 'N',
      'State Bank of India', '55150999888', 'SBIN0050302', 'HARPREET KAUR', '1219998887',
      16530, 3802, 1500, 225, 8.33,
      TRUE, TRUE, TRUE, TRUE
    ) RETURNING *;
  `, [adminId, testEmpCode, swDesigId]);

  const newEmp = insRes.rows[0];
  assert(newEmp && newEmp.id > 0, `Employee inserted with ID ${newEmp?.id}`);
  assert(newEmp.emp_code === testEmpCode, `Employee Code saved correctly: ${newEmp.emp_code}`);
  assert(newEmp.cell === 'EM-1', `Cell work location saved: ${newEmp.cell}`);
  assert(newEmp.bank_name === 'State Bank of India', `Bank name saved: ${newEmp.bank_name}`);
  assert(newEmp.epf_applicable === true, `EPF applicability flag is TRUE`);
  assert(Number(newEmp.default_gross_rate) === 16530, `Default gross rate is ₹16,530`);
  assert(Number(newEmp.default_bonus_percentage) === 8.33, `Default bonus percentage is 8.33%`);

  // Calculate live salary for this employee
  const calcA = calculatePayroll({
    designationAlias: 'SW',
    grossSalaryRate: Number(newEmp.default_gross_rate),
    specialAllowanceRate: Number(newEmp.default_special_allowance),
    customThermalAllowance: Number(newEmp.default_thermal_allowance),
    perfAllowanceMonthly: Number(newEmp.default_perf_allowance),
    bonusPercentage: Number(newEmp.default_bonus_percentage),
    totalDays: 30,
    presentDays: 30
  });

  assert(calcA.proportionedSalary === 16530, `Proportioned Salary for 30 days equals gross rate: ₹16,530 (got ${calcA.proportionedSalary})`);
  assert(calcA.totalBasic === 20332, `Total Basic is ₹20,332 (got ${calcA.totalBasic})`);
  assert(calcA.thermalAllowance === 1500, `Thermal Allowance is ₹1,500`);
  assert(calcA.bonus === 1694, `8.33% Bonus is ₹1,694`);
  assert(calcA.netPayable === 21762, `Net Payable Salary with 8.33% Bonus is ₹21,762 (got ${calcA.netPayable})`);
  assert(calcA.auditDiscrepancy === 0, `Zero discrepancy between Excel formula and Cash Payout`);
  assert(calcA.formulas.proportionedSalary.includes('ROUND'), `Proportioned Salary formula string correctly documented in engine: ${calcA.formulas.proportionedSalary}`);

  // Test Prorated Attendance (7 Days like reference Excel sheet MM-1)
  const calcProrated7Days = calculatePayroll({
    designationAlias: 'SW',
    grossSalaryRate: 16530,
    specialAllowanceRate: 3802,
    totalDays: 30,
    presentDays: 7
  });
  const expectedPropSW7 = Math.round((16530 / 30) * 7); // 3857
  assert(Math.round(calcProrated7Days.proportionedSalary) === expectedPropSW7, `Prorated 7-day proportioned salary matches Excel MM-1 Col P: ₹${expectedPropSW7} (got ${Math.round(calcProrated7Days.proportionedSalary)})`);

  // --- TEST B: Designation-based Formula Parity ---
  console.log('\n--- TEST B: Designation-based Formula Parity ---');
  for (const [desAlias, rates] of Object.entries(INITIAL_RATES)) {
    const calc = calculatePayroll({
      designationAlias: desAlias,
      grossSalaryRate: rates.gross,
      specialAllowanceRate: rates.special,
      totalDays: 30,
      presentDays: 30,
      perfAllowanceMonthly: 225,
      bonusPercentage: 8.33
    });
    const expectedBasic = Math.round(rates.gross + rates.special);
    assert(calc.totalBasic === expectedBasic, `${desAlias} Total Basic matches sum: ₹${expectedBasic}`);
    assert(calc.grossSalaryRate === rates.gross, `${desAlias} Gross rate is ₹${rates.gross}`);
    assert(calc.specialAllowance === rates.special, `${desAlias} Special allowance is ₹${rates.special}`);
  }

  // --- TEST C: Statutory Applicability Toggles ---
  console.log('\n--- TEST C: Statutory Applicability Toggles ---');
  // EPF Disabled
  const calcNoEPF = calculatePayroll({
    designationAlias: 'SW',
    grossSalaryRate: 16530,
    specialAllowanceRate: 3802,
    totalDays: 30,
    presentDays: 30,
    perfAllowanceMonthly: 225,
    customEmployeeEpf: 0,
    customEmployerEpf: 0,
    customEmployerEpf1: 0
  });
  assert(calcNoEPF.employeeEpf12 === 0, `EPF deduction is 0 when employee is exempt`);
  assert(calcNoEPF.employerEpf12 === 0, `Employer EPF is 0 when employee is exempt`);

  // ESI Disabled
  const calcNoESI = calculatePayroll({
    designationAlias: 'USW',
    grossSalaryRate: 14408,
    specialAllowanceRate: 3314,
    totalDays: 30,
    presentDays: 30,
    perfAllowanceMonthly: 225,
    customEmployeeEsi: 0,
    customEmployerEsi: 0
  });
  assert(calcNoESI.employeeEsi075 === 0, `ESI deduction is 0 when employee is exempt`);
  assert(calcNoESI.employerEsi325 === 0, `Employer ESI is 0 when employee is exempt`);

  // --- TEST D: Excel Template Generation ---
  console.log('\n--- TEST D: Excel Template Generation ---');
  const templateWb = ExcelImporter.generateTemplateWorkbook();
  assert(templateWb.worksheets.length === 2, `Template workbook contains 2 worksheets`);
  assert(templateWb.getWorksheet('Employee Master Template') !== undefined, `Employee Master Template sheet exists`);
  assert(templateWb.getWorksheet('Salary Rates Update Template') !== undefined, `Salary Rates Update Template sheet exists`);

  // --- TEST E: Excel Import Preview & Commit ---
  console.log('\n--- TEST E: Excel Import Preview & Commit ---');
  const refPath = path.resolve(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
  if (fs.existsSync(refPath)) {
    const buffer = fs.readFileSync(refPath);
    const previewRes = await ExcelImporter.previewEmployeeMasterImport(buffer, adminId, 'MM-1');
    assert(previewRes.sheetNames.length >= 2, `Detected workbook sheets: [${previewRes.sheetNames.join(', ')}]`);
    assert(previewRes.totalRecords === 21, `Parsed 21 employees from MM-1 sheet (got ${previewRes.totalRecords})`);
    assert(previewRes.previewRows.length === 21, `Preview rows count is 21`);
    assert(previewRes.previewRows[0].salaryPreview !== null, `Salary preview generated for row 1`);

    // Commit import
    const commitRes = await ExcelImporter.commitEmployeeMasterImport(previewRes.previewRows.slice(0, 5), 'both', adminId, 'admin');
    assert(commitRes.totalProcessed === 5, `Committed 5 employees successfully`);
    assert(commitRes.createdCount + commitRes.updatedCount === 5, `All rows created or updated`);
  } else {
    console.log('[SKIP] Reference file not found for physical import test');
  }

  // --- TEST F: Edit Existing Employee ---
  console.log('\n--- TEST F: Edit Existing Employee ---');
  await db.query(`
    UPDATE employees SET
      default_gross_rate = 18000,
      default_special_allowance = 4500,
      default_perf_allowance = 500,
      cell = 'EM-2',
      qualification = 'B.Tech Electrical'
    WHERE id = $1;
  `, [newEmp.id]);

  const updatedRes = await db.query(`SELECT * FROM employees WHERE id = $1;`, [newEmp.id]);
  const updatedEmp = updatedRes.rows[0];
  assert(Number(updatedEmp.default_gross_rate) === 18000, `Updated gross rate is ₹18,000`);
  assert(Number(updatedEmp.default_special_allowance) === 4500, `Updated special allowance is ₹4,500`);
  assert(updatedEmp.cell === 'EM-2', `Updated cell is EM-2`);
  assert(updatedEmp.qualification === 'B.Tech Electrical', `Updated qualification saved`);

  // --- TEST G: Safe Delete & Historical Payroll Protection ---
  console.log('\n--- TEST G: Safe Delete & Historical Payroll Protection ---');
  // 1. Create a dummy payroll period and entry for this employee
  const periodRes = await db.query(`
    INSERT INTO payroll_periods (owner_user_id, year, month, month_name, total_days, status)
    VALUES ($1, 2026, 11, 'November', 30, 'Finalized')
    RETURNING id;
  `, [adminId]);
  const testPeriodId = periodRes.rows[0].id;

  await db.query(`
    INSERT INTO payroll_entries (
      owner_user_id, payroll_period_id, employee_id, present_days, gross_salary_rate,
      total_basic, thermal_allowance, perf_allowance_monthly, gross_total,
      total_employee_deductions, total_employer_contributions, combined_deductions, net_payable
    ) VALUES ($1, $2, $3, 30, 18000, 22500, 1500, 500, 24500, 2500, 3000, 5500, 22000);
  `, [adminId, testPeriodId, newEmp.id]);

  // Check history count
  const histRes = await db.query(`SELECT COUNT(*) as count FROM payroll_entries WHERE employee_id = $1;`, [newEmp.id]);
  const historyCount = Number(histRes.rows[0].count);
  assert(historyCount === 1, `Employee has 1 historical payroll record`);

  // Soft archive when history exists
  await db.query(`
    UPDATE employees SET
      is_active = FALSE,
      archived_at = CURRENT_TIMESTAMP,
      archived_reason = 'Archived with historical payroll records'
    WHERE id = $1;
  `, [newEmp.id]);

  const archivedEmp = (await db.query(`SELECT * FROM employees WHERE id = $1;`, [newEmp.id])).rows[0];
  assert(archivedEmp.is_active === false, `Employee is inactive after archive`);
  assert(archivedEmp.archived_at !== null, `Archived timestamp recorded`);

  // Verify historical payroll entry still exists and was NOT cascade-deleted
  const historyStillExists = await db.query(`SELECT id FROM payroll_entries WHERE employee_id = $1;`, [newEmp.id]);
  assert(historyStillExists.rows.length === 1, `Historical payroll entry preserved intact`);

  // Test restore
  await db.query(`
    UPDATE employees SET is_active = TRUE, archived_at = NULL, archived_reason = NULL WHERE id = $1;
  `, [newEmp.id]);
  const restoredEmp = (await db.query(`SELECT * FROM employees WHERE id = $1;`, [newEmp.id])).rows[0];
  assert(restoredEmp.is_active === true, `Employee restored back to active state`);
  assert(restoredEmp.archived_at === null, `Archived timestamp cleared`);

  // --- TEST H: Connection to Monthly Payroll Creation ---
  console.log('\n--- TEST H: Connection to Monthly Payroll Creation ---');
  const monthPeriodRes = await db.query(`
    INSERT INTO payroll_periods (owner_user_id, year, month, month_name, total_days, status)
    VALUES ($1, 2026, 12, 'December', 30, 'Draft')
    RETURNING id;
  `, [adminId]);
  const decPeriodId = monthPeriodRes.rows[0].id;

  // Retrieve active employees
  const activeEmps = await db.query(`
    SELECT e.id, d.alias as designation_alias, e.default_gross_rate, e.default_special_allowance
    FROM employees e
    LEFT JOIN designations d ON e.designation_id = d.id
    WHERE e.id = $1 AND e.is_active = TRUE;
  `, [newEmp.id]);

  assert(activeEmps.rows.length === 1, `Restored employee is available in Monthly Payroll`);
  const activeEmp = activeEmps.rows[0];
  assert(Number(activeEmp.default_gross_rate) === 18000, `Monthly payroll reads custom gross rate ₹18,000`);

  // Clean up test period & employee
  await db.query(`DELETE FROM payroll_entries WHERE employee_id = $1;`, [newEmp.id]);
  await db.query(`DELETE FROM payroll_periods WHERE id IN ($1, $2);`, [testPeriodId, decPeriodId]);
  await db.query(`DELETE FROM employees WHERE id = $1;`, [newEmp.id]);

  console.log('\n================================================================');
  console.log(`EMPLOYEE MANAGEMENT TEST SUMMARY: ${passed} PASSED, ${failed} FAILED`);
  console.log('================================================================\n');

  if (failed > 0) process.exit(1);
}

runEmployeeManagementTests().catch(err => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
