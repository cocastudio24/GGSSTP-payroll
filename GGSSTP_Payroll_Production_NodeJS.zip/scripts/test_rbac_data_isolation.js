const http = require('http');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const BASE_URL = 'http://localhost:5000';

async function request(urlPath, options = {}) {
  const url = `${BASE_URL}${urlPath}`;
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const res = await fetch(url, {
    method: options.method || 'GET',
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined
  });
  let data;
  const contentType = res.headers.get('content-type') || '';
  if (contentType.includes('application/json')) {
    data = await res.json().catch(() => ({}));
  } else {
    data = await res.text().catch(() => '');
  }
  return { status: res.status, ok: res.ok, data, headers: res.headers };
}

async function login(username, password) {
  const res = await request('/api/auth/login', {
    method: 'POST',
    body: { username, password }
  });
  if (!res.ok || !res.data.token) {
    throw new Error(`Failed to login as ${username}: ${JSON.stringify(res.data)}`);
  }
  return { token: res.data.token, user: res.data.user };
}

async function isServerRunning() {
  try {
    const res = await fetch(`${BASE_URL}/api/health`).catch(() => null);
    return res && (res.status === 200 || res.status === 404);
  } catch {
    return false;
  }
}

async function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

async function runTests() {
  console.log('================================================================');
  console.log('GGSSTP RBAC & DATA ISOLATION VERIFICATION SUITE');
  console.log('================================================================\n');

  let serverProcess = null;
  const running = await isServerRunning();
  if (!running) {
    console.log('[*] Starting backend server (dist/server.js)...');
    serverProcess = spawn('node', ['dist/server.js'], {
      cwd: path.resolve(__dirname, '..'),
      stdio: 'inherit'
    });
    for (let i = 0; i < 20; i++) {
      await sleep(1000);
      if (await isServerRunning()) {
        console.log('    Backend server started successfully on port 5000.\n');
        break;
      }
    }
  } else {
    console.log('    Existing server detected on port 5000.\n');
  }

  let passed = 0;
  let failed = 0;

  function assert(condition, testName, details = '') {
    if (condition) {
      console.log(`  [PASS] ${testName}`);
      passed++;
    } else {
      console.error(`  [FAIL] ${testName} - ${details}`);
      failed++;
    }
  }

  try {
    // 1. Authenticate users
    console.log('[Step 1] Authenticating Test Users (admin, cell1, cell2)...');
    const adminAuth = await login('admin', 'admin@ggsstp2026');
    const cell1Auth = await login('cell1', 'cell1@ggsstp2026');
    const cell2Auth = await login('cell2', 'cell2@ggsstp2026');

    assert(adminAuth.user.role === 'SUPER_ADMIN', 'Super Administrator role matches SUPER_ADMIN');
    assert(cell1Auth.user.role === 'PAYROLL_ADMIN', 'Cell1 role matches PAYROLL_ADMIN');
    assert(cell2Auth.user.role === 'PAYROLL_ADMIN', 'Cell2 role matches PAYROLL_ADMIN');

    // 2. Fetch existing employees count for Admin
    const initialAdminEmps = await request('/api/employees', {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    const baselineCount = initialAdminEmps.data.employees.length;
    console.log(`    Plant baseline employees for Super Admin: ${baselineCount}`);

    // 3. Test 1: Employee Isolation
    console.log('\n[Step 2] Test 1: Employee Isolation (Cell1 creates Emp1, Cell2 creates Emp2)...');
    const uniqueSuffix = Date.now().toString().slice(-4);
    const empCode1 = `TEST-C1-${uniqueSuffix}`;
    const empCode2 = `TEST-C2-${uniqueSuffix}`;

    const create1 = await request('/api/employees', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell1Auth.token}` },
      body: {
        emp_code: empCode1,
        empCode: empCode1,
        name: `Ramesh Kumar C1 ${uniqueSuffix}`,
        father_name: 'Late Sh. Satish Kumar',
        uan: `10099988${uniqueSuffix}`,
        dob: '1990-05-15',
        qualification: 'Diploma Mechanical',
        experience_years: '8',
        bank_account: `98765432${uniqueSuffix}`,
        ifsc: 'SBIN0050302',
        esi_number: `2613${uniqueSuffix}99`,
        cell: 'CELL-1',
        default_gross_rate: 16530,
        default_special_allowance: 3802
      }
    });
    assert(create1.status === 201 && create1.data.employee.id, `Cell1 created employee (${empCode1})`);
    const emp1 = create1.data.employee;

    const create2 = await request('/api/employees', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell2Auth.token}` },
      body: {
        emp_code: empCode2,
        empCode: empCode2,
        name: `Suresh Singh C2 ${uniqueSuffix}`,
        father_name: 'Sh. Gurmukh Singh',
        uan: `10088877${uniqueSuffix}`,
        dob: '1992-08-20',
        qualification: 'Matric',
        experience_years: '5',
        bank_account: `87654321${uniqueSuffix}`,
        ifsc: 'SBIN0050302',
        esi_number: `2614${uniqueSuffix}88`,
        cell: 'CELL-2',
        default_gross_rate: 14408,
        default_special_allowance: 3314
      }
    });
    assert(create2.status === 201 && create2.data.employee.id, `Cell2 created employee (${empCode2})`);
    const emp2 = create2.data.employee;

    // Verify cell1 listing
    const cell1List = await request('/api/employees?limit=200', {
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    const cell1EmpCodes = cell1List.data.employees.map(e => e.emp_code);
    assert(cell1EmpCodes.includes(empCode1), 'Cell1 can see its own employee (emp1)');
    assert(!cell1EmpCodes.includes(empCode2), 'Cell1 CANNOT see Cell2 employee (emp2)');

    // Verify cell2 listing
    const cell2List = await request('/api/employees?limit=200', {
      headers: { Authorization: `Bearer ${cell2Auth.token}` }
    });
    const cell2EmpCodes = cell2List.data.employees.map(e => e.emp_code);
    assert(cell2EmpCodes.includes(empCode2), 'Cell2 can see its own employee (emp2)');
    assert(!cell2EmpCodes.includes(empCode1), 'Cell2 CANNOT see Cell1 employee (emp1)');

    // Verify super admin listing
    const adminList = await request('/api/employees?limit=200', {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    const adminEmpCodes = adminList.data.employees.map(e => e.emp_code);
    assert(adminEmpCodes.includes(empCode1) && adminEmpCodes.includes(empCode2), 'Super Admin sees BOTH emp1 and emp2');

    // 4. Test 2: Direct ID / URL Access Security (Strict 403 Forbidden)
    console.log('\n[Step 3] Test 2: Direct ID / URL Access Security (Cross-Tenant Access)...');
    
    // Cell1 attempts GET on Emp2
    const cell1GetEmp2 = await request(`/api/employees/${emp2.id}`, {
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    assert(cell1GetEmp2.status === 403, 'Cell1 GET /api/employees/{emp2.id} returns 403 Forbidden');

    // Cell1 attempts PUT on Emp2
    const cell1PutEmp2 = await request(`/api/employees/${emp2.id}`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${cell1Auth.token}` },
      body: { name: 'Hacked by Cell1' }
    });
    assert(cell1PutEmp2.status === 403, 'Cell1 PUT /api/employees/{emp2.id} returns 403 Forbidden');

    // Cell1 attempts Archive on Emp2
    const cell1ArchiveEmp2 = await request(`/api/employees/${emp2.id}/archive`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell1Auth.token}` },
      body: { reason: 'Unauthorized archive attempt' }
    });
    assert(cell1ArchiveEmp2.status === 403, 'Cell1 POST /api/employees/{emp2.id}/archive returns 403 Forbidden');

    // Cell1 attempts Delete on Emp2
    const cell1DelEmp2 = await request(`/api/employees/${emp2.id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    assert(cell1DelEmp2.status === 403, 'Cell1 DELETE /api/employees/{emp2.id} returns 403 Forbidden');

    // Super Admin GET on Emp2 -> 200 OK
    const adminGetEmp2 = await request(`/api/employees/${emp2.id}`, {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    assert(adminGetEmp2.status === 200, 'Super Admin GET /api/employees/{emp2.id} returns 200 OK');

    // 5. Test 3: Administrative Access Restrictions (403 for Payroll Admin)
    console.log('\n[Step 4] Test 3: Administrative Access Restrictions...');
    const cell1Users = await request('/api/users', {
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    assert(cell1Users.status === 403, 'Cell1 GET /api/users returns 403 Forbidden');

    const adminUsers = await request('/api/users', {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    assert(adminUsers.status === 200 && Array.isArray(adminUsers.data.users), 'Super Admin GET /api/users returns 200 OK');

    const cell1FormulaRules = await request('/api/payroll/rules', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell1Auth.token}` },
      body: { name: 'Unauthorized Rule', epf_wage_cap: 30000 }
    });
    assert(cell1FormulaRules.status === 403, 'Cell1 POST /api/payroll/rules returns 403 Forbidden');

    const cell1AdoptRules = await request('/api/reconciliation/adopt-rules', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell1Auth.token}` },
      body: { name: 'Unauthorized Adopt', epfWageCap: 30000 }
    });
    assert(cell1AdoptRules.status === 403, 'Cell1 POST /api/reconciliation/adopt-rules returns 403 Forbidden');

    // 6. Test 4: Payroll Entry & Period Data Isolation
    console.log('\n[Step 5] Test 4: Payroll Entry & Period Data Isolation...');
    const periodsRes = await request('/api/payroll/periods', {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    let testPeriod = periodsRes.data.periods && periodsRes.data.periods[0];
    assert(Boolean(testPeriod), `Active payroll period exists (${testPeriod?.month_name} ${testPeriod?.year})`);

    // Sync period for cell1 and cell2
    await request(`/api/payroll/periods/${testPeriod.id}/sync-employees`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    await request(`/api/payroll/periods/${testPeriod.id}/sync-employees`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell2Auth.token}` }
    });

    // Query entries for cell1
    const cell1Entries = await request(`/api/payroll/entries?periodId=${testPeriod.id}&limit=200`, {
      headers: { Authorization: `Bearer ${cell1Auth.token}` }
    });
    const cell1EntryCodes = cell1Entries.data.entries.map(e => e.emp_code);
    assert(cell1EntryCodes.includes(empCode1), 'Cell1 sees its own employee in payroll entries');
    assert(!cell1EntryCodes.includes(empCode2), 'Cell1 CANNOT see Cell2 employee in payroll entries');

    // Query entries for cell2
    const cell2Entries = await request(`/api/payroll/entries?periodId=${testPeriod.id}&limit=200`, {
      headers: { Authorization: `Bearer ${cell2Auth.token}` }
    });
    const cell2EntryCodes = cell2Entries.data.entries.map(e => e.emp_code);
    assert(cell2EntryCodes.includes(empCode2), 'Cell2 sees its own employee in payroll entries');
    assert(!cell2EntryCodes.includes(empCode1), 'Cell2 CANNOT see Cell1 employee in payroll entries');

    // Find entry IDs
    const emp2Entry = cell2Entries.data.entries.find(e => e.emp_code === empCode2);
    if (emp2Entry) {
      // Cell1 tries to view payslip of Cell2 employee
      const cell1PayslipEmp2 = await request(`/api/payroll/entries/${emp2Entry.id}/payslip`, {
        headers: { Authorization: `Bearer ${cell1Auth.token}` }
      });
      assert(cell1PayslipEmp2.status === 403, 'Cell1 GET payslip for Cell2 employee returns 403 Forbidden');

      // Cell1 tries to download payslip PDF of Cell2 employee
      const cell1PdfEmp2 = await request(`/api/export/payslip-pdf/${emp2Entry.id}`, {
        headers: { Authorization: `Bearer ${cell1Auth.token}` }
      });
      assert(cell1PdfEmp2.status === 403, 'Cell1 GET payslip-pdf for Cell2 employee returns 403 Forbidden');

      // Cell1 tries to modify Cell2 payroll entry
      const cell1PutEntry2 = await request(`/api/payroll/entries/${emp2Entry.id}`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${cell1Auth.token}` },
        body: { present_days: 15 }
      });
      assert(cell1PutEntry2.status === 403, 'Cell1 PUT payroll entry for Cell2 employee returns 403 Forbidden');

      // Cell1 tries to override net payable for Cell2 employee
      const cell1Override2 = await request(`/api/payroll/entries/${emp2Entry.id}/net-payable`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${cell1Auth.token}` },
        body: { netPayable: 99999 }
      });
      assert(cell1Override2.status === 403, 'Cell1 override net payable for Cell2 employee returns 403 Forbidden');

      // Super Admin can view payslip for Cell2 employee
      const adminPayslipEmp2 = await request(`/api/payroll/entries/${emp2Entry.id}/payslip`, {
        headers: { Authorization: `Bearer ${adminAuth.token}` }
      });
      assert(adminPayslipEmp2.status === 200, 'Super Admin GET payslip for Cell2 employee returns 200 OK');
    }

    // 7. Test 5: Export Isolation
    console.log('\n[Step 6] Test 5: Reports & Excel Export Isolation...');
    const cell1Exp = await request('/api/export/employees-xlsx', {
      method: 'POST',
      headers: { Authorization: `Bearer ${cell1Auth.token}` },
      body: {}
    });
    assert(cell1Exp.status === 200, 'Cell1 export employees-xlsx returns 200 OK');

    // 8. Test 6: Clean up temporary test data
    console.log('\n[Step 7] Test 6: Clean Up Test Records & Verify Baseline...');
    const del1 = await request(`/api/employees/${emp1.id}?force=true`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    assert(del1.status === 200, 'Super Admin cleaned up test employee 1');

    const del2 = await request(`/api/employees/${emp2.id}?force=true`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    assert(del2.status === 200, 'Super Admin cleaned up test employee 2');

    const finalAdminEmps = await request('/api/employees', {
      headers: { Authorization: `Bearer ${adminAuth.token}` }
    });
    assert(
      finalAdminEmps.data.employees.length === baselineCount,
      `Reference employees intact (${finalAdminEmps.data.employees.length} === ${baselineCount})`
    );

    console.log('\n================================================================');
    console.log(`RESULTS: ${passed} PASSED, ${failed} FAILED`);
    console.log('================================================================\n');

  } catch (err) {
    console.error('Test execution error:', err);
    failed++;
  } finally {
    if (serverProcess) {
      console.log('Stopping spawned test server...');
      serverProcess.kill();
    }
  }

  process.exit(failed > 0 ? 1 : 0);
}

runTests();
