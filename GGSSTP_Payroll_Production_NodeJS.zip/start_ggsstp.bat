@echo off
title GGSSTP Payroll Management System
echo ================================================================
echo Starting GGSSTP Payroll System (Guru Gobind Singh ST Plant)
echo ================================================================
echo.

cd /d "%~dp0"

echo Checking Node.js installation...
node -v >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please install Node.js v18 or v20 LTS from https://nodejs.org/
    pause
    exit /b 1
)

echo.
echo Launching GGSSTP Server and database...
echo.
echo Browser URL:       http://localhost:5000 (or simply http://localhost)
echo Network Access:    http://127.0.0.1:5000
echo.
echo Browser will automatically open as soon as the server is ready!
echo.
echo Press Ctrl+C in this window to stop the server.
echo ================================================================
echo.

node dist/server.js
pause
