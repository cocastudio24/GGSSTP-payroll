import ExcelJS from 'exceljs';
import { db } from '../database/db';

export class ExcelExporter {
  static async generatePayrollWorkbook(periodId: number, ownerUserId?: number): Promise<ExcelJS.Workbook> {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'GGSSTP Payroll System';
    workbook.lastModifiedBy = 'GGSSTP Payroll Administrator';
    workbook.created = new Date();
    workbook.modified = new Date();
    workbook.calcProperties.fullCalcOnLoad = true;

    // Fetch period info
    const periodRes = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [periodId]);
    if (periodRes.rows.length === 0) throw new Error('Payroll period not found');
    const period = periodRes.rows[0];

    // Fetch entries with employee details
    const entriesQuery = ownerUserId
      ? `
      SELECT 
        pe.*,
        e.emp_code, e.sr_no, e.name as emp_name, e.father_name, e.uan, e.dob,
        e.date_of_joining, e.qualification, e.experience_years, e.bank_account,
        e.ifsc, e.esi_number,
        d.alias as designation_alias, d.name as designation_name,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      WHERE pe.payroll_period_id = $1 AND (pe.owner_user_id = $2 OR pe.created_by_user_id = $2 OR e.owner_user_id = $2 OR e.created_by_user_id = $2)
      ORDER BY e.emp_code ASC;
    `
      : `
      SELECT 
        pe.*,
        e.emp_code, e.sr_no, e.name as emp_name, e.father_name, e.uan, e.dob,
        e.date_of_joining, e.qualification, e.experience_years, e.bank_account,
        e.ifsc, e.esi_number,
        d.alias as designation_alias, d.name as designation_name,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      WHERE pe.payroll_period_id = $1
      ORDER BY e.emp_code ASC;
    `;
    const entriesParams = ownerUserId ? [periodId, ownerUserId] : [periodId];
    const entriesRes = await db.query(entriesQuery, entriesParams);

    const entries = entriesRes.rows;

    // 1. MAIN PAYROLL SHEET
    const ws = workbook.addWorksheet(`Payroll ${period.month_name} ${period.year}`, {
      views: [{ state: 'frozen', xSplit: 3, ySplit: 2 }]
    });

    // Title Row
    ws.mergeCells('A1:AL1');
    const titleCell = ws.getCell('A1');
    titleCell.value = `GURU GOBIND SINGH SUPER THERMAL PLANT, RUPNAGAR - CONTRACTUAL PAYROLL REGISTER FOR ${period.month_name.toUpperCase()} ${period.year}`;
    titleCell.font = { name: 'Calibri', size: 14, bold: true, color: { argb: 'FFFFFFFF' } };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
    titleCell.fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FF1E3A8A' } // Deep Navy Blue
    };
    ws.getRow(1).height = 32;

    // Headers in Row 2
    const headers = [
      'Emp Code', 'Employee Name', "Father's Name", 'UAN', 'Designation',
      'Circle', 'Department/Cell', 'Contractor', 'Bank A/c', 'IFSC',
      'ESI No', 'DOB', 'Total Days', 'Present Days',
      // Inputs & Calculated
      'Gross Salary Rate', 'Proportioned Salary', 'Special Allowance', 'Total Basic',
      'Thermal Allowance', 'Perf. Allowance (Monthly)', 'Perf. Allowance (Days Wise)',
      'Total Earnings Before Bonus', 'Bonus',
      // Employer Contributions
      'Employer EPF (12%)', 'Employer EPF (1%)', 'Employer ESI (3.25%)', 'Employer LWF',
      'Gross Total (Incl Employer Cost)',
      // Employee Deductions
      'Employee EPF (12%)', 'Employee ESI (0.75%)', 'Employee LWF',
      'Total Employee Deductions', 'Total Employer Cost', 'Combined Deductions',
      'Net Payable Salary',
      // EMC Performance Allowance Circle Comparison
      'Last Drawn Perf. Allowance', 'Circle Perf. Allowance', 'Perf. Allowance Diff'
    ];

    const headerRow = ws.getRow(2);
    headerRow.height = 28;
    headers.forEach((h, idx) => {
      const colNum = idx + 1;
      const cell = headerRow.getCell(colNum);
      cell.value = h;
      cell.font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      
      // Categorized header colors
      let bgColor = 'FF1E40AF'; // Default Blue
      if (idx >= 14 && idx <= 22) bgColor = 'FF065F46'; // Earnings (Green)
      if (idx >= 23 && idx <= 27) bgColor = 'FF92400E'; // Employer costs (Amber)
      if (idx >= 28 && idx <= 33) bgColor = 'FF991B1B'; // Deductions (Red)
      if (idx === 34) bgColor = 'FF1E3A8A'; // Net Payable (Dark Navy)
      if (idx >= 35 && idx <= 37) bgColor = 'FF0E7490'; // Performance Allowance comparison (Teal)

      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgColor } };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'medium' },
        right: { style: 'thin' }
      };
    });

    // Populate Data Rows with LIVE FORMULAS
    entries.forEach((emp, index) => {
      const rowIdx = index + 3; // Data starts at Row 3
      const row = ws.getRow(rowIdx);
      row.height = 22;

      // Excel Column Letters:
      // M = 13 (Total Days), N = 14 (Present Days)
      // O = 15 (Gross Salary Rate), P = 16 (Proportioned Salary), Q = 17 (Special Allowance), R = 18 (Total Basic)
      // S = 19 (Thermal Allowance), T = 20 (Perf Monthly), U = 21 (Perf Days Wise)
      // V = 22 (Total Earnings Before Bonus), W = 23 (Bonus)
      // X = 24 (Employer EPF 12%), Y = 25 (Employer EPF 1%), Z = 26 (Employer ESI 3.25%), AA = 27 (Employer LWF)
      // AB = 28 (Gross Total)
      // AC = 29 (Employee EPF 12%), AD = 30 (Employee ESI 0.75%), AE = 31 (Employee LWF)
      // AF = 32 (Total Employee Deductions), AG = 33 (Total Employer Cost), AH = 34 (Combined Deductions)
      // AI = 35 (Net Payable Salary)

      // Fixed identifiers
      row.getCell(1).value = emp.emp_code;
      row.getCell(2).value = emp.emp_name;
      row.getCell(3).value = emp.father_name || '';
      row.getCell(4).value = emp.uan || '';
      row.getCell(5).value = emp.designation_alias || 'SW';
      row.getCell(6).value = emp.circle_name || 'GGSSTP';
      row.getCell(7).value = emp.department_name || '';
      row.getCell(8).value = emp.contractor_name || '';
      row.getCell(9).value = emp.bank_account || '';
      row.getCell(10).value = emp.ifsc || '';
      row.getCell(11).value = emp.esi_number || '';
      row.getCell(12).value = emp.dob || '';

      // Attendance inputs
      row.getCell(13).value = Number(period.total_days) || 30; // Col M
      row.getCell(14).value = Number(emp.present_days) || 0;    // Col N

      // Salary Rate & Allowance inputs
      row.getCell(15).value = Number(emp.gross_salary_rate);     // Col O
      
      // Col P (Proportioned Salary) = O{row}/M{row}*N{row}
      row.getCell(16).value = {
        formula: `O${rowIdx}/M${rowIdx}*N${rowIdx}`,
        result: Number(emp.proportioned_salary)
      };

      row.getCell(17).value = Number(emp.special_allowance);    // Col Q

      // Col R (Total Basic) = ROUND((O{row}+Q{row})*N{row}/M{row}, 0)
      row.getCell(18).value = {
        formula: `ROUND((O${rowIdx}+Q${rowIdx})*N${rowIdx}/M${rowIdx}, 0)`,
        result: Number(emp.total_basic)
      };

      // Col S (Thermal Allowance) = ROUND(1500*N{row}/M{row}, 0)
      row.getCell(19).value = {
        formula: `ROUND(1500*N${rowIdx}/M${rowIdx}, 0)`,
        result: Number(emp.thermal_allowance)
      };

      // Col T (Perf Monthly)
      row.getCell(20).value = Number(emp.perf_allowance_monthly);

      // Col U (Perf Days Wise) = T{row}/M{row}*N{row}
      row.getCell(21).value = {
        formula: `T${rowIdx}/M${rowIdx}*N${rowIdx}`,
        result: Number(emp.perf_allowance_days)
      };

      // Col V (Total Earnings Before Bonus) = R{row}+S{row}+U{row}
      row.getCell(22).value = {
        formula: `R${rowIdx}+S${rowIdx}+U${rowIdx}`,
        result: Number(emp.total_earnings_before_bonus)
      };

      // Col W (Bonus)
      if (emp.is_overridden) {
        row.getCell(23).value = Number(emp.bonus) || 0;
      } else {
        const bonusPct = Number(emp.bonus_percentage) || 8.33;
        row.getCell(23).value = {
          formula: `ROUND(R${rowIdx}*${bonusPct}/100, 0)`,
          result: Number(emp.bonus) || 0
        };
      }

      // Col X (Employer EPF 12%) = ROUND(IF(P{row}<25000, P{row}*0.12, 3000), 0)
      row.getCell(24).value = {
        formula: `ROUND(IF(P${rowIdx}<25000, P${rowIdx}*0.12, 3000), 0)`,
        result: Number(emp.employer_epf_12)
      };

      // Col Y (Employer EPF 1%) = ROUND(IF(P{row}<25000, P{row}*0.01, 250), 0)
      row.getCell(25).value = {
        formula: `ROUND(IF(P${rowIdx}<25000, P${rowIdx}*0.01, 250), 0)`,
        result: Number(emp.employer_epf_1)
      };

      // Col Z (Employer ESI 3.25%) = ROUND(IF(V{row}<21000, V{row}*0.0325, 0), 0)
      row.getCell(26).value = {
        formula: `ROUND(IF(V${rowIdx}<21000, V${rowIdx}*0.0325, 0), 0)`,
        result: Number(emp.employer_esi_325)
      };

      // Col AA (Employer LWF) = 20
      row.getCell(27).value = Number(emp.employer_lwf) || 20;

      // Col AB (Gross Total) = SUM(V{row}:AA{row})
      row.getCell(28).value = {
        formula: `SUM(V${rowIdx}:AA${rowIdx})`,
        result: Number(emp.gross_total)
      };

      // Col AC (Employee EPF 12%) = X{row}
      row.getCell(29).value = {
        formula: `X${rowIdx}`,
        result: Number(emp.employee_epf_12)
      };

      // Col AD (Employee ESI 0.75%) = ROUND(IF(V{row}<21000, V{row}*0.0075, 0), 0)
      row.getCell(30).value = {
        formula: `ROUND(IF(V${rowIdx}<21000, V${rowIdx}*0.0075, 0), 0)`,
        result: Number(emp.employee_esi_075)
      };

      // Col AE (Employee LWF) = 5
      row.getCell(31).value = Number(emp.employee_lwf) || 5;

      // Col AF (Total Employee Deductions) = AC{row}+AD{row}+AE{row}
      row.getCell(32).value = {
        formula: `AC${rowIdx}+AD${rowIdx}+AE${rowIdx}`,
        result: Number(emp.total_employee_deductions)
      };

      // Col AG (Total Employer Cost) = X{row}+Y{row}+Z{row}+AA{row}
      row.getCell(33).value = {
        formula: `X${rowIdx}+Y${rowIdx}+Z${rowIdx}+AA${rowIdx}`,
        result: Number(emp.total_employer_contributions)
      };

      // Col AH (Combined Deductions) = AF{row}+AG{row}
      row.getCell(34).value = {
        formula: `AF${rowIdx}+AG${rowIdx}`,
        result: Number(emp.combined_deductions)
      };

      // Col AI (Net Payable Salary) = ROUND(AB{row}-AH{row}, 0)
      row.getCell(35).value = {
        formula: `ROUND(AB${rowIdx}-AH${rowIdx}, 0)`,
        result: Math.round(Number(emp.net_payable))
      };

      // EMC Performance Allowance Circle Comparison
      // Col AJ (Last Drawn)
      row.getCell(36).value = Number(emp.perf_last_drawn) || 0;

      // Col AK (Circle Rate)
      row.getCell(37).value = Number(emp.perf_as_per_circle) || 0;

      // Col AL (Difference) = AJ{row}-AK{row}
      row.getCell(38).value = {
        formula: `AJ${rowIdx}-AK${rowIdx}`,
        result: Number(emp.perf_difference) || 0
      };

      // Formatting
      for (let c = 1; c <= 38; c++) {
        const cell = row.getCell(c);
        cell.border = {
          top: { style: 'thin', color: { argb: 'FFE5E7EB' } },
          left: { style: 'thin', color: { argb: 'FFE5E7EB' } },
          bottom: { style: 'thin', color: { argb: 'FFE5E7EB' } },
          right: { style: 'thin', color: { argb: 'FFE5E7EB' } }
        };
        // Number format for currency columns
        if (c >= 15 && c <= 38) {
          cell.numFmt = '#,##0.00';
          cell.alignment = { horizontal: 'right', vertical: 'middle' };
        } else if (c === 13 || c === 14) {
          cell.numFmt = '0';
          cell.alignment = { horizontal: 'center', vertical: 'middle' };
        } else {
          cell.alignment = { horizontal: 'left', vertical: 'middle' };
        }
      }
    });

    // Summary Totals Row at the bottom
    const totalRowIdx = entries.length + 3;
    const totRow = ws.getRow(totalRowIdx);
    totRow.height = 26;
    totRow.getCell(2).value = 'TOTAL';
    totRow.getCell(2).font = { bold: true };
    totRow.getCell(2).alignment = { horizontal: 'center' };

    // Add SUM formulas for numerical columns
    ['O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL'].forEach((colLetter, i) => {
      const colNum = 15 + i;
      const cell = totRow.getCell(colNum);
      cell.value = {
        formula: `SUM(${colLetter}3:${colLetter}${totalRowIdx - 1})`
      };
      cell.font = { bold: true };
      cell.numFmt = '#,##0.00';
      cell.border = {
        top: { style: 'thin' },
        bottom: { style: 'double' }
      };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFF3F4F6' }
      };
    });

    // Auto-fit column widths
    ws.columns.forEach((col, idx) => {
      let maxLen = 12;
      if (idx === 1) maxLen = 22; // Name
      if (idx === 7) maxLen = 25; // Contractor
      if (idx >= 14) maxLen = 16; // Money
      col.width = maxLen;
    });

    // Enable Autofilter
    ws.autoFilter = `A2:AL${entries.length + 2}`;

    // 2. DESIGNATION & RATE CARD SHEET
    const rateSheet = workbook.addWorksheet('Salary Rate Card');
    rateSheet.views = [{ showGridLines: true }];
    rateSheet.mergeCells('A1:E1');
    rateSheet.getCell('A1').value = 'GGSSTP DESIGNATION SALARY RATES & ALLOWANCES';
    rateSheet.getCell('A1').font = { bold: true, size: 12 };
    rateSheet.getRow(2).values = ['Designation Alias', 'Designation Name', 'Gross Salary Rate', 'Special Allowance', 'Thermal Allowance Base'];
    rateSheet.getRow(2).font = { bold: true };
    rateSheet.addRow(['USW', 'Unskilled', 14408, 3314, 1500]);
    rateSheet.addRow(['SEMI SW', 'Semi Skilled', 15395, 3541, 1500]);
    rateSheet.addRow(['SW', 'Skilled', 16530, 3802, 1500]);
    rateSheet.addRow(['HSW', 'Highly Skilled', 17835, 4102, 1500]);
    rateSheet.columns = [{ width: 18 }, { width: 22 }, { width: 18 }, { width: 18 }, { width: 22 }];

    return workbook;
  }
}
