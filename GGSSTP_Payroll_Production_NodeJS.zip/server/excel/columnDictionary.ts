/**
 * Universal Column Dictionary & Auto-Mapping Engine for GGSSTP Payroll Management
 * Guru Gobind Singh Super Thermal Plant, Rupnagar
 */

export interface TargetFieldDef {
  key: string;
  label: string;
  category: 'identification' | 'statutory' | 'bank' | 'hr' | 'attendance' | 'salary' | 'deductions' | 'auxiliary' | 'system';
  dataType: 'string' | 'number' | 'date' | 'boolean';
  description: string;
  isIdentifier?: boolean;
  aliases: string[];
}

export const TARGET_FIELDS: TargetFieldDef[] = [
  // 1. Employee Identification
  {
    key: 'emp_code',
    label: 'Employee Code / ID',
    category: 'identification',
    dataType: 'string',
    description: 'Unique Employee Identification Code (e.g. EMP-101, EMC-323)',
    isIdentifier: true,
    aliases: ['emp code', 'emp_code', 'employee code', 'emp id', 'employee id', 'emp no', 'worker id', 'ref no', 'ref. no', 'reference no']
  },
  {
    key: 'sr_no',
    label: 'Serial Number',
    category: 'identification',
    dataType: 'string',
    description: 'Serial / Register sequence number',
    aliases: ['sr no', 'sr. no', 'sr no.', 's. no', 's no', 's.no', 'sl no', 'sl. no', 'serial no', 'serial number']
  },
  {
    key: 'name',
    label: 'Employee Name',
    category: 'identification',
    dataType: 'string',
    description: 'Full name of the worker / employee',
    aliases: ['employee name', 'name of the worker', 'name of worker', 'worker name', 'name of employee', 'name', 'worker']
  },
  {
    key: 'father_name',
    label: "Father's / Husband's Name",
    category: 'identification',
    dataType: 'string',
    description: "Father's or husband's name",
    aliases: ["father's name", "father name", "husband's name", "husband name", "father / husband name", "father"]
  },
  {
    key: 'designation',
    label: 'Designation / Skill Category',
    category: 'identification',
    dataType: 'string',
    description: 'Job category: USW (Unskilled), SEMI SW, SW (Skilled), HSW (Highly Skilled)',
    aliases: ['designation', 'design', 'category', 'skill category', 'trade', 'post', 'skill']
  },
  {
    key: 'contractor',
    label: 'Contractor / Service Provider',
    category: 'identification',
    dataType: 'string',
    description: 'Name of contractor / outsourced agency (e.g. M/s Sodhi Erectors)',
    aliases: ['name of the service provider', 'name of service provider', 'service provider', 'contractor', 'contractor name', 'agency', 'firm']
  },
  {
    key: 'circle',
    label: 'Circle Name',
    category: 'identification',
    dataType: 'string',
    description: 'Plant Circle: MM-1, EMC, Operation Circle, etc.',
    aliases: ['name of circle', 'circle name', 'circle']
  },
  {
    key: 'cell_department',
    label: 'Cell / Department / Office',
    category: 'identification',
    dataType: 'string',
    description: 'Cell or Department: EM-1, EM-2, EM-3, MM-1 CELL, Addl.S.E./Op',
    aliases: ['cell', 'department', 'dept', 'office', 'nme of office', 'name of office', 'section', 'division']
  },

  // 2. Identity & Statutory Numbers
  {
    key: 'uan',
    label: 'UAN (EPF Universal Account No.)',
    category: 'statutory',
    dataType: 'string',
    description: '12-digit EPF Universal Account Number',
    isIdentifier: true,
    aliases: ['uan no.', 'uan no', 'uan number', 'uan', 'epf no/ uan', 'epf no / uan', 'epf no', 'pf no', 'epf uan', 'universal account number']
  },
  {
    key: 'esi_number',
    label: 'ESI / ESIC Number',
    category: 'statutory',
    dataType: 'string',
    description: '10-digit or 17-digit Employee State Insurance identification number',
    isIdentifier: true,
    aliases: ['esi', 'esi no.', 'esi no', 'esic no', 'esic number', 'esi number', 'ip number', 'esi insurance no']
  },
  {
    key: 'aadhar_number',
    label: 'Aadhaar Card Number',
    category: 'statutory',
    dataType: 'string',
    description: '12-digit Aadhaar UID number',
    isIdentifier: true,
    aliases: ['aadhar no.', 'aadhar no', 'aadhaar no.', 'aadhaar no', 'aadhar number', 'aadhaar number', 'aadhar', 'aadhaar', 'uid']
  },
  {
    key: 'pan_number',
    label: 'PAN Card Number',
    category: 'statutory',
    dataType: 'string',
    description: '10-character Permanent Account Number',
    isIdentifier: true,
    aliases: ['pan card', 'pan no.', 'pan no', 'pan number', 'pan']
  },
  {
    key: 'mobile_number',
    label: 'Mobile Number',
    category: 'statutory',
    dataType: 'string',
    description: 'Primary contact or Aadhaar linked mobile number',
    aliases: ['mobile no. linked with aadhar', 'mobile no', 'mobile number', 'mobile', 'phone', 'contact no']
  },

  // 3. Bank Account & Payment Details
  {
    key: 'bank_account',
    label: 'Bank Account Number',
    category: 'bank',
    dataType: 'string',
    description: 'Worker bank account number for direct wage transfer',
    isIdentifier: true,
    aliases: ['bank a/c no.', 'bank a/c no', 'bank a/c', 'bank account no', 'bank account number', 'account no', 'account no.', 'a/c no', 'a/c no.', 'bank acc', 'bank acc no', 'bank']
  },
  {
    key: 'ifsc',
    label: 'IFSC Code',
    category: 'bank',
    dataType: 'string',
    description: '11-character Indian Financial System Code (e.g. SBIN0050302)',
    aliases: ['ifsc', 'ifsc code', 'bank ifsc', 'ifsc no']
  },
  {
    key: 'bank_name',
    label: 'Bank Name & Branch',
    category: 'bank',
    dataType: 'string',
    description: 'Name of the banking institution (e.g. State Bank of India)',
    aliases: ['name of bank', 'bank name', 'bank branch', 'branch']
  },
  {
    key: 'account_holder_name',
    label: 'Account Holder Name',
    category: 'bank',
    dataType: 'string',
    description: 'Name as registered in bank records',
    aliases: ['account holder name', 'holder name', 'name in bank', 'beneficiary name']
  },

  // 4. HR Attributes & Statutory Eligibility
  {
    key: 'dob',
    label: 'Date of Birth',
    category: 'hr',
    dataType: 'date',
    description: 'Birth date (DD-MM-YYYY or Date)',
    aliases: ['dob dd-mm-yyyy', 'dob', 'date of birth', 'birth date']
  },
  {
    key: 'age_above_58',
    label: 'Age Above 58 Indicator',
    category: 'hr',
    dataType: 'string',
    description: 'Statutory age indicator: Y or N (affects EPF pension contribution)',
    aliases: ['age above 58 yrs', 'age above 58', 'above 58', '58+']
  },
  {
    key: 'above_60',
    label: 'Above 60 Indicator',
    category: 'hr',
    dataType: 'string',
    description: 'Senior worker indicator (above 60 years)',
    aliases: ['above 60', 'age above 60', '60+']
  },
  {
    key: 'date_of_joining',
    label: 'Date of Joining (DOJ)',
    category: 'hr',
    dataType: 'date',
    description: 'Date worker joined plant contractual services',
    aliases: ['date of joining', 'joining date', 'doj']
  },
  {
    key: 'date_of_exit',
    label: 'Date of Exit (DOE)',
    category: 'hr',
    dataType: 'date',
    description: 'Date worker completed or exited contract',
    aliases: ['date of exit', 'exit date', 'doe']
  },
  {
    key: 'more_than_3_yrs',
    label: 'More Than 3 Years in Plant',
    category: 'hr',
    dataType: 'string',
    description: 'Experience criteria: YES or NO',
    aliases: ['more than 3', 'more than 3 yrs', '> 3 years', '>3 yrs']
  },
  {
    key: 'more_than_5_yrs',
    label: 'More Than 5 Years in Plant',
    category: 'hr',
    dataType: 'string',
    description: 'Seniority criteria: YES or NO',
    aliases: ['more than 5', 'more than 5 yrs', '> 5 years', '>5 yrs']
  },
  {
    key: 'qualification',
    label: 'Educational / Technical Qualification',
    category: 'hr',
    dataType: 'string',
    description: 'Qualification: ITI, Diploma, 10th, 12th, etc.',
    aliases: ['qualification', 'qual', 'educational qualification', 'tech qual']
  },
  {
    key: 'experience_years',
    label: 'Total Experience (Years)',
    category: 'hr',
    dataType: 'string',
    description: 'Total experience in years (e.g. 15, 20)',
    aliases: ['total experience in year (in digits only)', 'total experience', 'experience in years', 'experience', 'exp']
  },
  {
    key: 'qualified_status',
    label: 'Whether Qualified (Yes / No)',
    category: 'hr',
    dataType: 'string',
    description: 'Trade qualification verification: Yes or No',
    aliases: ['wether qualified or not (yes / no)', 'whether qualified or not', 'whether qualified', 'qualified']
  },
  {
    key: 'hazard_duty',
    label: 'Hazard Duty Indicator',
    category: 'hr',
    dataType: 'string',
    description: 'Thermal plant hazardous area assignment (haz)',
    aliases: ['haz', 'hazard', 'hazard duty', 'hazardous']
  },
  {
    key: 'check_status',
    label: 'Verification Status',
    category: 'hr',
    dataType: 'string',
    description: 'Cell supervisor audit verification stamp (e.g. Done 1, Done 10)',
    aliases: ['check', 'audit check', 'verified']
  },

  // 5. Attendance & Working Days
  {
    key: 'total_days',
    label: 'Total Days in Month',
    category: 'attendance',
    dataType: 'number',
    description: 'Calendar days in the payroll cycle (normally 30)',
    aliases: ['days', 'total days', 'cycle days', 'month days']
  },
  {
    key: 'present_days',
    label: 'Present / Duty Days',
    category: 'attendance',
    dataType: 'number',
    description: 'Actual verified working days attended in month',
    aliases: ['presnt. days', 'present days', 'duty days', 'working days', 'days worked', 'attendance']
  },

  // 6. Salary Rates & Allowances
  {
    key: 'gross_salary_rate',
    label: 'Gross Salary Rate',
    category: 'salary',
    dataType: 'number',
    description: 'Designation gross monthly wage rate (e.g. ₹16,530 for SW, ₹14,408 for USW)',
    aliases: ['grose salary', 'gross salary', 'gross salary rate', 'wage rate', 'gross wage', 'monthly gross']
  },
  {
    key: 'proportioned_salary',
    label: 'Proportioned Basic Salary',
    category: 'salary',
    dataType: 'number',
    description: 'Proportioned wage for present days: ROUND(Gross / Days * Present)',
    aliases: ['propostioned salary', 'proportioned salary', 'b.p', 'b.p.', 'basic proportioned', 'proportioned basic', 'proportioned']
  },
  {
    key: 'special_allowance',
    label: 'Special Allowance Rate',
    category: 'salary',
    dataType: 'number',
    description: 'Designation special allowance (e.g. ₹3,802 for SW, ₹3,314 for USW)',
    aliases: ['special allownce', 'special allowance', 'spl allowance', 'special allow']
  },
  {
    key: 'total_basic',
    label: 'Total Basic Wages',
    category: 'salary',
    dataType: 'number',
    description: 'Combined basic wages: Proportioned Salary + Proportioned Special Allowance',
    aliases: ['total basic', 'total basic salary', 'basic wages', 'earned basic']
  },
  {
    key: 'thermal_allowance',
    label: 'Thermal Allowance',
    category: 'salary',
    dataType: 'number',
    description: 'Plant allowance: ROUND(₹1,500 / Days * Present)',
    aliases: ['thermal allonce', 'thermal allowance', 'thermal', 'thermal allow']
  },
  {
    key: 'perf_allowance_monthly',
    label: 'Performance Allowance (Monthly)',
    category: 'salary',
    dataType: 'number',
    description: 'Monthly performance allowance base (e.g. ₹225, ₹4,800)',
    aliases: ['performance allon.', 'performance allowance', 'perf allowance', 'perf monthly']
  },
  {
    key: 'perf_allowance_days',
    label: 'Performance Allowance (Days Wise)',
    category: 'salary',
    dataType: 'number',
    description: 'Performance allowance proportioned to present days',
    aliases: ['performance allon. days wise', 'perf allowance days wise', 'earned performance']
  },
  {
    key: 'total_earnings_before_bonus',
    label: 'Total Earnings (Before Bonus)',
    category: 'salary',
    dataType: 'number',
    description: 'Total basic + Thermal + Performance Days Wise',
    aliases: ['total', 'total earnings before bonus', 'earnings before bonus', 'gross earnings']
  },
  {
    key: 'bonus',
    label: 'Bonus Amount',
    category: 'salary',
    dataType: 'number',
    description: 'Bonus payable (default 8.33% of Basic or 0 if omitted)',
    aliases: ['bonunse', 'bonus', 'annual bonus', 'earned bonus']
  },
  {
    key: 'bonus_percentage',
    label: 'Bonus Percentage',
    category: 'salary',
    dataType: 'number',
    description: 'Statutory bonus rate percentage (e.g. 8.33%)',
    aliases: ['bonus %', 'bonus percentage', 'bonus rate']
  },

  // 7. Statutory Contributions & Deductions
  {
    key: 'employer_epf_12',
    label: 'Employer EPF (12%)',
    category: 'deductions',
    dataType: 'number',
    description: 'Employer EPF Share: 12% of Total Basic (Max ₹1,800)',
    aliases: ['epf emplyer share 12%', 'epf employer share 12%', 'employer epf 12%', 'employer epf', 'employer pf']
  },
  {
    key: 'employer_epf_1',
    label: 'Employer EPF Admin & EDLI (1%)',
    category: 'deductions',
    dataType: 'number',
    description: 'Employer EPF Admin / EDLI Share: 1% of Total Basic (Max ₹150)',
    aliases: ['epf 1%', 'epf@1%', 'epf admin 1%', 'employer epf 1%']
  },
  {
    key: 'employer_esi_325',
    label: 'Employer ESI (3.25%)',
    category: 'deductions',
    dataType: 'number',
    description: 'Employer ESI Contribution: 3.25% of Gross Total (for wages <= ₹21,000)',
    aliases: ['esi 3.25%', 'esi@3.25%', 'employer esi 3.25%', 'employer esi']
  },
  {
    key: 'employer_lwf',
    label: 'Employer LWF (₹20)',
    category: 'deductions',
    dataType: 'number',
    description: 'Punjab Labour Welfare Fund Employer Share: ₹20/month',
    aliases: ['lwf', 'employer lwf', 'lwf employer', 'lwf 20']
  },
  {
    key: 'gross_total',
    label: 'Gross Total (Earnings + Employer Contributions)',
    category: 'salary',
    dataType: 'number',
    description: 'Total Earnings + Bonus + Employer Contributions (Used for ESI calculation)',
    aliases: ['grose total', 'gross total', 'total ctc', 'company cost']
  },
  {
    key: 'employee_epf_12',
    label: 'Employee EPF Deduction (12%)',
    category: 'deductions',
    dataType: 'number',
    description: 'Employee EPF Share: 12% of Total Basic (Max ₹1,800)',
    aliases: ['epf deduction 12%', 'employee epf 12%', 'epf ded. 12%', 'employee epf', 'epf deduction', 'pf deduction']
  },
  {
    key: 'employee_esi_075',
    label: 'Employee ESI Deduction (0.75%)',
    category: 'deductions',
    dataType: 'number',
    description: 'Employee ESI Share: 0.75% of Gross Total (for wages <= ₹21,000)',
    aliases: ['esi ded. 0.75%', 'esi@.75%', 'esi 0.75%', 'employee esi 0.75%', 'esi deduction', 'esic deduction']
  },
  {
    key: 'employee_lwf',
    label: 'Employee LWF Deduction (₹5)',
    category: 'deductions',
    dataType: 'number',
    description: 'Punjab Labour Welfare Fund Employee Share: ₹5/month',
    aliases: ['lwf ded.', 'employee lwf', 'lwf employee', 'lwf 5']
  },
  {
    key: 'total_employee_deductions',
    label: 'Total Employee Deductions',
    category: 'deductions',
    dataType: 'number',
    description: 'Sum of employee deductions: EPF (12%) + ESI (0.75%) + LWF (₹5)',
    aliases: ['total employee deductions', 'employee deductions', 'total ded']
  },
  {
    key: 'total_employer_contributions',
    label: 'Total Employer Contributions',
    category: 'deductions',
    dataType: 'number',
    description: 'Sum of employer statutory contributions: EPF (12%) + EPF (1%) + ESI (3.25%) + LWF (₹20)',
    aliases: ['total employer contributions', 'employer contributions', 'employer deductions']
  },
  {
    key: 'combined_deductions',
    label: 'Combined Total Deductions',
    category: 'deductions',
    dataType: 'number',
    description: 'Grand total of employee deductions + employer contributions',
    aliases: ['combined deductions', 'grand total deductions']
  },
  {
    key: 'net_payable',
    label: 'Net Payable Salary (Take-Home)',
    category: 'salary',
    dataType: 'number',
    description: 'Net take-home pay: Total Earnings - Total Employee Deductions',
    aliases: ['net payable', 'net  payable', 'net salary', 'net pay', 'take home', 'net disbursement']
  },

  // 8. Auxiliary Comparison & Verification Fields
  {
    key: 'perf_last_drawn',
    label: 'Last Drawn Performance Allowance',
    category: 'auxiliary',
    dataType: 'number',
    description: 'Historical performance allowance drawn previously (EMC comparison)',
    aliases: ['last drwan performance all.', 'last drawn performance all.', 'last drawn perf']
  },
  {
    key: 'perf_as_per_circle',
    label: 'Performance Allowance As Per Circle',
    category: 'auxiliary',
    dataType: 'number',
    description: 'Performance allowance rate certified by circle office (EMC comparison)',
    aliases: ['as per circle', 'perf as per circle', 'circle perf rate']
  },
  {
    key: 'perf_difference',
    label: 'Performance Allowance Difference',
    category: 'auxiliary',
    dataType: 'number',
    description: 'Variance: Last Drawn - As Per Circle',
    aliases: ['difference', 'perf difference', 'variance']
  },

  // 9. Special Action
  {
    key: '__EXCLUDE__',
    label: '✕ Exclude This Column (Do Not Import)',
    category: 'system',
    dataType: 'string',
    description: 'Skip this column entirely during import',
    aliases: ['exclude', 'skip', 'ignore', 'none']
  }
];

/**
 * Normalizes an arbitrary header text by converting to lowercase, collapsing whitespace,
 * stripping punctuation, and trimming.
 */
export function normalizeHeader(header: string): string {
  if (!header) return '';
  return header
    .toLowerCase()
    .replace(/\r?\n|\r/g, ' ')
    .replace(/[._\-/\\]+/g, ' ')
    .replace(/[()]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Automatically suggests a destination target field for a given raw header.
 * Disambiguates duplicate headings (e.g. multiple "TOTAL DEDUCTION" or "UAN" columns)
 * using column position and neighboring columns.
 */
export function autoMapHeader(
  rawHeader: string,
  colIndex: number,
  allHeadersInRow: { colIndex: number; rawHeader: string }[],
  sampleValue?: any
): { targetFieldKey: string; confidence: number; reason: string } {
  const norm = normalizeHeader(rawHeader);
  if (!norm) {
    return { targetFieldKey: '__EXCLUDE__', confidence: 0.1, reason: 'Empty header' };
  }

  // 1. Disambiguate multiple "TOTAL DEDUCTION" columns
  if (norm.includes('total deduction') || norm === 'total deductions') {
    // Collect all column indices having "total deduction"
    const totalDedCols = allHeadersInRow
      .filter(h => normalizeHeader(h.rawHeader).includes('total deduction') || normalizeHeader(h.rawHeader) === 'total deductions')
      .map(h => h.colIndex);

    const posInGroup = totalDedCols.indexOf(colIndex);
    if (posInGroup === 0) {
      return { targetFieldKey: 'total_employee_deductions', confidence: 0.95, reason: 'First Total Deduction column (Employee Deductions: EPF + ESI + LWF)' };
    } else if (posInGroup === 1) {
      return { targetFieldKey: 'total_employer_contributions', confidence: 0.95, reason: 'Second Total Deduction column (Employer Contributions)' };
    } else {
      return { targetFieldKey: 'combined_deductions', confidence: 0.95, reason: 'Third Total Deduction column (Combined Deductions)' };
    }
  }

  // 2. Disambiguate multiple "UAN" columns
  if (norm === 'uan' || norm === 'uan no' || norm === 'uan no.' || norm.includes('uan')) {
    const uanCols = allHeadersInRow
      .filter(h => {
        const n = normalizeHeader(h.rawHeader);
        return n === 'uan' || n === 'uan no' || n === 'uan no.' || n.includes('uan');
      })
      .map(h => h.colIndex);

    if (uanCols.length > 1 && colIndex === uanCols[0]) {
      return { targetFieldKey: 'uan', confidence: 0.98, reason: 'Primary UAN Column' };
    } else if (uanCols.length > 1) {
      // Second UAN column is a verification column in reference sheet
      return { targetFieldKey: '__EXCLUDE__', confidence: 0.90, reason: 'Duplicate UAN verification column (Excluded)' };
    }
  }

  // 3. Disambiguate "BANK" column (Bank Account Number vs Bank Name)
  if (norm === 'bank' || norm === 'bank a c' || norm === 'bank acc') {
    if (sampleValue && /[a-zA-Z]/.test(String(sampleValue)) && !/^\d+$/.test(String(sampleValue).replace(/[\s-]/g, ''))) {
      return { targetFieldKey: 'bank_name', confidence: 0.90, reason: 'Bank column containing text bank name' };
    }
    return { targetFieldKey: 'bank_account', confidence: 0.95, reason: 'Bank account number column' };
  }

  // 4. Disambiguate "ESI" column (ESI Number vs ESI Contribution)
  if (norm === 'esi' || norm === 'esic') {
    if (colIndex < 25) {
      return { targetFieldKey: 'esi_number', confidence: 0.98, reason: 'Worker statutory ESI identifier' };
    }
  }

  // 5. Check exact and alias matches across all TARGET_FIELDS
  for (const field of TARGET_FIELDS) {
    if (field.key === '__EXCLUDE__') continue;

    for (const alias of field.aliases) {
      const normAlias = normalizeHeader(alias);
      if (norm === normAlias) {
        return { targetFieldKey: field.key, confidence: 1.0, reason: `Exact match with alias "${alias}"` };
      }
    }
  }

  // 6. Substring / fuzzy heuristic matches
  if (/^emp(loyee)?[\s_-]*(code|id|no)$/i.test(norm) || (norm.includes('emp') && (norm.includes('code') || norm.includes('id')))) {
    return { targetFieldKey: 'emp_code', confidence: 0.90, reason: 'Employee ID pattern match' };
  }
  if (/^(name\s+of\s+(the\s+)?(worker|employee)|employee\s*name|worker\s*name)$/i.test(norm)) {
    return { targetFieldKey: 'name', confidence: 0.95, reason: 'Employee name pattern match' };
  }
  if (norm.includes('father') || norm.includes('husband')) {
    return { targetFieldKey: 'father_name', confidence: 0.95, reason: "Father's name pattern match" };
  }
  if (norm.includes('design') || norm.includes('category') || norm.includes('trade') || norm.includes('post')) {
    return { targetFieldKey: 'designation', confidence: 0.92, reason: 'Designation pattern match' };
  }
  if (norm.includes('contractor') || norm.includes('service provider') || norm.includes('agency')) {
    return { targetFieldKey: 'contractor', confidence: 0.95, reason: 'Contractor / service provider match' };
  }
  if (norm.includes('circle')) {
    return { targetFieldKey: 'circle', confidence: 0.95, reason: 'Circle match' };
  }
  if (norm === 'cell' || norm.includes('dept') || norm.includes('office')) {
    return { targetFieldKey: 'cell_department', confidence: 0.92, reason: 'Cell / Department match' };
  }
  if (norm.includes('uan') || norm.includes('pf no')) {
    return { targetFieldKey: 'uan', confidence: 0.95, reason: 'UAN pattern match' };
  }
  if (norm.includes('esi no') || norm.includes('esic no') || norm.includes('esi num')) {
    return { targetFieldKey: 'esi_number', confidence: 0.95, reason: 'ESI identifier pattern match' };
  }
  if (norm.includes('ifsc')) {
    return { targetFieldKey: 'ifsc', confidence: 0.98, reason: 'IFSC pattern match' };
  }
  if (norm.includes('bank') && (norm.includes('acc') || norm.includes('a/c') || norm.includes('no'))) {
    return { targetFieldKey: 'bank_account', confidence: 0.95, reason: 'Bank account number match' };
  }
  if (norm.includes('gross') && (norm.includes('salary') || norm.includes('wage') || norm.includes('rate'))) {
    return { targetFieldKey: 'gross_salary_rate', confidence: 0.95, reason: 'Gross salary rate match' };
  }
  if (norm.includes('proportioned') || norm.includes('b p') || norm === 'bp') {
    return { targetFieldKey: 'proportioned_salary', confidence: 0.95, reason: 'Proportioned salary match' };
  }
  if (norm.includes('special') && norm.includes('allow')) {
    return { targetFieldKey: 'special_allowance', confidence: 0.95, reason: 'Special allowance match' };
  }
  if (norm.includes('thermal')) {
    return { targetFieldKey: 'thermal_allowance', confidence: 0.95, reason: 'Thermal allowance match' };
  }
  if (norm.includes('performance') && norm.includes('day')) {
    return { targetFieldKey: 'perf_allowance_days', confidence: 0.95, reason: 'Performance days wise match' };
  }
  if (norm.includes('performance') || norm.includes('perf allow')) {
    return { targetFieldKey: 'perf_allowance_monthly', confidence: 0.92, reason: 'Performance monthly match' };
  }
  if (norm.includes('bonus') || norm.includes('bonunse')) {
    if (norm.includes('%') || norm.includes('percent')) return { targetFieldKey: 'bonus_percentage', confidence: 0.95, reason: 'Bonus % match' };
    return { targetFieldKey: 'bonus', confidence: 0.92, reason: 'Bonus amount match' };
  }
  if (norm.includes('epf') && norm.includes('ded')) {
    return { targetFieldKey: 'employee_epf_12', confidence: 0.95, reason: 'Employee EPF deduction match' };
  }
  if (norm.includes('epf') && (norm.includes('employer') || norm.includes('emplyer'))) {
    if (norm.includes('1%') || norm.includes('1 %')) return { targetFieldKey: 'employer_epf_1', confidence: 0.95, reason: 'Employer EPF 1% match' };
    return { targetFieldKey: 'employer_epf_12', confidence: 0.95, reason: 'Employer EPF 12% match' };
  }
  if (norm.includes('esi') && norm.includes('0 75')) {
    return { targetFieldKey: 'employee_esi_075', confidence: 0.98, reason: 'Employee ESI 0.75% deduction match' };
  }
  if (norm.includes('esi') && norm.includes('3 25')) {
    return { targetFieldKey: 'employer_esi_325', confidence: 0.98, reason: 'Employer ESI 3.25% match' };
  }
  if (norm.includes('lwf') && (norm.includes('ded') || norm.includes('5'))) {
    return { targetFieldKey: 'employee_lwf', confidence: 0.95, reason: 'Employee LWF (₹5) match' };
  }
  if (norm.includes('lwf')) {
    return { targetFieldKey: 'employer_lwf', confidence: 0.92, reason: 'Employer LWF (₹20) match' };
  }
  if (norm.includes('net') && (norm.includes('pay') || norm.includes('salary'))) {
    return { targetFieldKey: 'net_payable', confidence: 0.98, reason: 'Net payable take-home salary match' };
  }
  if (norm.includes('gross') && norm.includes('total')) {
    return { targetFieldKey: 'gross_total', confidence: 0.95, reason: 'Gross Total match' };
  }

  // Check columns that are verification / empty
  if (norm === 'check' || norm === 'done') {
    return { targetFieldKey: '__EXCLUDE__', confidence: 0.70, reason: 'Verification check column (Excluded by default)' };
  }

  return { targetFieldKey: '__EXCLUDE__', confidence: 0.2, reason: 'Unrecognized header (Excluded by default)' };
}

/**
 * Format string identifier safely (preserves leading zeros, never scientific notation)
 */
export function formatIdentifierText(val: any): string {
  if (val === null || val === undefined) return '';
  if (typeof val === 'number') {
    // If integer, convert cleanly without exponential notation
    if (Number.isInteger(val)) {
      return BigInt(val).toString();
    }
    return Math.floor(val).toString();
  }
  const str = String(val).trim();
  // If scientific notation string e.g. "1.00364E+11"
  if (/^\d+(\.\d+)?[eE]\+\d+$/.test(str)) {
    try {
      const num = Number(str);
      return BigInt(Math.round(num)).toString();
    } catch {
      return str;
    }
  }
  return str;
}

/**
 * Format numeric values cleanly
 */
export function formatNumericValue(val: any): number | null {
  if (val === null || val === undefined) return null;
  if (typeof val === 'number') {
    return isNaN(val) ? null : val;
  }
  const cleanStr = String(val).replace(/[₹,\s]/g, '').trim();
  if (cleanStr === '' || cleanStr === '—' || cleanStr === '-') return null;
  const num = Number(cleanStr);
  return isNaN(num) ? null : num;
}
