import XLSX from 'xlsx';
import ExcelJS from 'exceljs';
import { db } from '../database/db';
import { calculatePayroll, INITIAL_RATES } from '../engine/payrollCalculator';
import { syncEmployeesWithOpenPayrollPeriods } from '../services/payrollSyncService';
import {
  autoMapHeader,
  formatIdentifierText,
  formatNumericValue,
  normalizeHeader,
  TARGET_FIELDS,
  TargetFieldDef
} from './columnDictionary';

export interface ParsedEmployeeRow {
  empCode: string;
  srNo?: string;
  name: string;
  fatherName?: string;
  uan?: string;
  designationAlias: string;
  designationName?: string;
  dob?: string;
  ageAbove58?: string;
  dateOfJoining?: string;
  dateOfExit?: string;
  mobileNumber?: string;
  moreThan3Yrs?: string;
  moreThan5Yrs?: string;
  qualification?: string;
  experienceYears?: string;
  qualifiedStatus?: string;
  contractorName?: string;
  circleName?: string;
  cell?: string;
  departmentName?: string;
  hazardDuty?: string;
  above60?: string;
  checkStatus?: string;
  bankName?: string;
  bankAccount?: string;
  ifsc?: string;
  accountHolderName?: string;
  esiNumber?: string;
  aadharNumber?: string;
  panNumber?: string;
  epfApplicable?: boolean;
  esiApplicable?: boolean;
  lwfApplicable?: boolean;
  defaultGrossRate?: number;
  defaultSpecialAllowance?: number;
  defaultThermalAllowance?: number;
  defaultPerfAllowance?: number;
  defaultBonusPercentage?: number;
  // Explicitly imported statutory deductions & totals from Excel
  customEmployeeEpf?: number;
  customEmployerEpf?: number;
  customEmployerEpf1?: number;
  customEmployeeEsi?: number;
  customEmployerEsi?: number;
  customEmployeeLwf?: number;
  customEmployerLwf?: number;
  specialAllowance?: number;
  employerEpf12?: number;
  employerEpf1?: number;
  employerEsi325?: number;
  employerLwf?: number;
  employeeEpf12?: number;
  employeeEsi075?: number;
  employeeLwf?: number;
  importedGrossTotal?: number;
  importedTotalEmployeeDeductions?: number;
  importedTotalEmployerContributions?: number;
  importedCombinedDeductions?: number;
  importedNetPayable?: number;
  totalDays: number;
  presentDays: number;
  proportionedSalary?: number;
  totalBasic?: number;
  thermalAllowance?: number;
  perfAllowanceMonthly: number;
  perfAllowanceDays?: number;
  totalEarningsBeforeBonus?: number;
  bonus: number;
  bonusPercentage?: number;
  perfLastDrawn?: number;
  perfAsPerCircle?: number;
  perfDifference?: number;
  sourceSheet: string;
  sourceRow: number;
  isPerfRounded?: boolean;
  customData?: Record<string, any>;
}

export interface ImportPreviewResult {
  fileName: string;
  sheetName: string;
  detectedLayout: string;
  totalRecords: number;
  previewRows: ParsedEmployeeRow[];
  duplicates: string[];
  warnings: string[];
}

/**
 * Normalizes any raw designation string into standard alias and title-cased display name.
 */
export function normalizeDesignation(raw?: string): { alias: string; name: string } {
  if (!raw || !raw.trim()) {
    return { alias: 'SW', name: 'Skilled' };
  }
  const clean = raw.trim().toUpperCase().replace(/\s+/g, ' ').replace(/[-_]+/g, ' ');

  // 1. Unskilled
  if (
    clean === 'USW' ||
    clean === 'UNSKILLED' ||
    clean === 'UN SKILLED' ||
    clean === 'UNSKILLED WORKER' ||
    clean === 'UN SKILLED WORKER' ||
    clean === 'U SW' ||
    clean === 'US'
  ) {
    return { alias: 'USW', name: 'Unskilled' };
  }

  // 2. Semi-Skilled
  if (
    clean === 'SEMI SW' ||
    clean === 'SEMISW' ||
    clean === 'SSW' ||
    clean === 'SEMI SKILLED' ||
    clean === 'SEMISKILLED' ||
    clean === 'SEMI SKILLED WORKER' ||
    clean === 'SEMI SW WORKER'
  ) {
    return { alias: 'SEMI SW', name: 'Semi Skilled' };
  }

  // 3. Highly Skilled
  if (
    clean === 'HSW' ||
    clean === 'HIGHLY SKILLED' ||
    clean === 'HIGH SKILLED' ||
    clean === 'HIGHLYSKILLED' ||
    clean === 'HIGHSKILLED' ||
    clean === 'HIGHLY SKILLED WORKER' ||
    clean === 'HIGH SKILLED WORKER' ||
    clean === 'H SW'
  ) {
    return { alias: 'HSW', name: 'Highly Skilled' };
  }

  // 4. Skilled
  if (
    clean === 'SW' ||
    clean === 'SKILLED' ||
    clean === 'SKILLED WORKER' ||
    clean === 'S W'
  ) {
    return { alias: 'SW', name: 'Skilled' };
  }

  // 5. Custom / Specific trade designations (e.g. Electrician, Fitter, Helper, Security Guard)
  const titleName = raw
    .trim()
    .toLowerCase()
    .split(' ')
    .filter(Boolean)
    .map(w => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');

  let alias = clean;
  if (alias.length > 8) {
    const words = clean.split(' ').filter(Boolean);
    if (words.length > 1) {
      alias = words.map(w => w.charAt(0)).join('');
      if (alias.length < 3) alias = clean.slice(0, 6);
    } else {
      alias = clean.slice(0, 8);
    }
  }

  return { alias, name: titleName };
}

/**
 * Resolves a designation ID in the database.
 * If not found, dynamically auto-creates the designation and default rates so no employee is mis-categorized!
 */
export async function resolveDesignationId(
  rawDesignation: string,
  ownerUserId: number,
  fallbackGross?: number,
  fallbackSpecial?: number,
  cacheMap?: Map<string, { id: number; alias: string; name: string }>
): Promise<{ id: number; alias: string; name: string }> {
  const norm = normalizeDesignation(rawDesignation);
  const cacheKey = norm.alias.toUpperCase();

  if (cacheMap && cacheMap.has(cacheKey)) {
    return cacheMap.get(cacheKey)!;
  }

  // 1. Search existing designation by alias or name (case-insensitive)
  let desRes = await db.query(
    `SELECT id, name, alias FROM designations WHERE UPPER(alias) = UPPER($1) OR UPPER(name) = UPPER($2) LIMIT 1;`,
    [norm.alias, norm.name]
  );

  if (desRes.rows.length === 0) {
    desRes = await db.query(
      `SELECT id, name, alias FROM designations WHERE UPPER(alias) = UPPER($1) OR UPPER(name) = UPPER($1) LIMIT 1;`,
      [norm.alias]
    );
  }

  if (desRes.rows.length > 0) {
    const row = desRes.rows[0];
    const resObj = { id: row.id, alias: row.alias, name: row.name };
    if (cacheMap) cacheMap.set(cacheKey, resObj);
    return resObj;
  }

  // 2. Not found in database -> Dynamically create new designation
  const defaultRates = INITIAL_RATES[norm.alias] || INITIAL_RATES['SW'];
  const gross = fallbackGross || defaultRates?.gross || 16530;
  const special = fallbackSpecial || defaultRates?.special || 3802;

  const insDes = await db.query(
    `INSERT INTO designations (owner_user_id, name, alias) VALUES ($1, $2, $3) RETURNING id, name, alias;`,
    [ownerUserId, norm.name, norm.alias]
  );
  const newDesId = insDes.rows[0].id;

  // Insert salary rates for this designation
  await db.query(
    `INSERT INTO designation_salary_rates 
     (designation_id, gross_salary_rate, special_allowance, thermal_allowance, perf_allowance_default)
     VALUES ($1, $2, $3, 1500, 225);`,
    [newDesId, gross, special]
  );

  const newObj = { id: newDesId, alias: norm.alias, name: norm.name };
  if (cacheMap) cacheMap.set(cacheKey, newObj);
  return newObj;
}

export class ExcelImporter {
  /**
   * Inspects an uploaded Excel file, discovers all columns, maps them using the
   * universal column dictionary, and produces a live preview with salary calculations.
   */
  static inspectWorkbook(buffer: Buffer, fileName: string, requestedSheet?: string) {
    const workbook = XLSX.read(buffer, { type: 'buffer', cellFormula: true });
    const sheetNames = workbook.SheetNames;
    if (sheetNames.length === 0) {
      throw new Error('The uploaded file contains no readable worksheets.');
    }

    const cleanStr = (val: any) => (val !== null && val !== undefined ? String(val).trim().replace(/\r?\n+/g, ' ') : '');
    const keyHeaderTerms = [
      'emp', 'code', 'worker', 'name', 'uan', 'esi', 'gross', 'wage', 'rate',
      'salary', 'basic', 'bank', 'ifsc', 'sr', 'father', 'desig', 'category',
      'circle', 'present', 'days', 'total', 'deduction', 'net', 'payable', 'bonus', 'lwf', 'epf'
    ];

    const sheetsSummary = sheetNames.map(sName => {
      const s = workbook.Sheets[sName];
      if (!s || !s['!ref']) {
        return { sheetName: sName, totalRows: 0, totalColumns: 0, isValid: false, headerRowIndex: 0 };
      }
      const r = XLSX.utils.decode_range(s['!ref']);
      let bHeader = 0;
      let mScore = -1;
      for (let row = 0; row <= Math.min(10, r.e.r); row++) {
        let sc = 0;
        for (let col = 0; col <= r.e.c; col++) {
          const v = cleanStr(s[XLSX.utils.encode_cell({ r: row, c: col })]?.v).toLowerCase();
          for (const term of keyHeaderTerms) {
            if (v.includes(term)) { sc++; break; }
          }
        }
        if (sc > mScore) { mScore = sc; bHeader = row; }
      }
      const dataRows = Math.max(0, r.e.r - bHeader);
      return {
        sheetName: sName,
        totalRows: dataRows,
        totalColumns: r.e.c + 1,
        headerRowIndex: bHeader,
        isValid: dataRows > 0 && r.e.c >= 3 && mScore >= 2
      };
    });

    // If user requested all sheets, aggregate inspection across all valid worksheets
    if (requestedSheet === '__ALL__' || requestedSheet === 'ALL') {
      let combinedPreviewRows: any[] = [];
      let totalRowsAll = 0;
      let primaryColumns: any[] = [];
      let headerRowIndex = 0;

      for (const sInfo of sheetsSummary) {
        if (!sInfo.isValid) continue;
        const res = this.inspectWorkbook(buffer, fileName, sInfo.sheetName);
        if (primaryColumns.length === 0) {
          primaryColumns = res.columns;
          headerRowIndex = res.headerRowIndex;
        }
        totalRowsAll += res.totalRows;
        const taggedRows = res.previewRows.map(r => ({ ...r, sheetName: sInfo.sheetName }));
        combinedPreviewRows = combinedPreviewRows.concat(taggedRows);
      }

      const mappedCount = primaryColumns.filter(c => c.proposedField && c.proposedField !== '__EXCLUDE__').length;
      const excludedCount = primaryColumns.filter(c => c.proposedField === '__EXCLUDE__').length;
      const unmappedCount = primaryColumns.length - mappedCount - excludedCount;

      return {
        fileName,
        sheetNames,
        selectedSheet: '__ALL__',
        sheetsSummary,
        headerRowIndex,
        totalRows: totalRowsAll,
        totalColumns: primaryColumns.length,
        columns: primaryColumns,
        targetFields: TARGET_FIELDS.map(t => ({
          key: t.key,
          label: t.label,
          category: t.category,
          dataType: t.dataType,
          description: t.description
        })),
        previewRows: combinedPreviewRows,
        summary: {
          totalColumns: primaryColumns.length,
          mappedCount,
          excludedCount,
          unmappedCount
        }
      };
    }

    const selectedSheet = requestedSheet && sheetNames.includes(requestedSheet)
      ? requestedSheet
      : (sheetNames.find(s => s.toUpperCase().includes('MM') || s.toUpperCase().includes('EMC') || s.toLowerCase().includes('operation')) || sheetNames[0]);

    const sheet = workbook.Sheets[selectedSheet];
    if (!sheet || !sheet['!ref']) {
      return {
        fileName,
        sheetNames,
        selectedSheet,
        sheetsSummary,
        headerRowIndex: 0,
        totalRows: 0,
        totalColumns: 0,
        columns: [],
        targetFields: TARGET_FIELDS.map(t => ({
          key: t.key,
          label: t.label,
          category: t.category,
          dataType: t.dataType,
          description: t.description
        })),
        previewRows: [],
        summary: { totalColumns: 0, mappedCount: 0, excludedCount: 0, unmappedCount: 0 }
      };
    }

    const range = XLSX.utils.decode_range(sheet['!ref']);

    // Heuristic: identify header row by scanning rows 0 to min(10, range.e.r)
    let bestHeaderRow = 0;
    let maxHeaderScore = -1;

    for (let r = 0; r <= Math.min(10, range.e.r); r++) {
      let score = 0;
      for (let c = 0; c <= range.e.c; c++) {
        const cell = sheet[XLSX.utils.encode_cell({ r, c })];
        if (cell && cell.v !== undefined && cell.v !== null) {
          const text = cleanStr(cell.v).toLowerCase();
          for (const term of keyHeaderTerms) {
            if (text.includes(term)) {
              score++;
              break;
            }
          }
        }
      }
      if (score > maxHeaderScore) {
        maxHeaderScore = score;
        bestHeaderRow = r;
      }
    }

    const headerRowIndex = bestHeaderRow;

    // Discover all columns
    const allHeaders: Array<{ colIndex: number; rawHeader: string; sampleValues?: any[] }> = [];
    for (let c = 0; c <= range.e.c; c++) {
      let headerText = cleanStr(sheet[XLSX.utils.encode_cell({ r: headerRowIndex, c })]?.v);
      if (!headerText && headerRowIndex > 0) {
        // Look at previous row for merged headers
        headerText = cleanStr(sheet[XLSX.utils.encode_cell({ r: headerRowIndex - 1, c })]?.v);
      }
      const samples: any[] = [];
      for (let r = headerRowIndex + 1; r <= Math.min(headerRowIndex + 4, range.e.r); r++) {
        const val = sheet[XLSX.utils.encode_cell({ r, c })]?.v;
        if (val !== undefined && val !== null && String(val).trim() !== '') {
          samples.push(val);
        }
      }
      allHeaders.push({ colIndex: c, rawHeader: headerText, sampleValues: samples });
    }

    // Auto-map headers using universal dictionary
    const columns: any[] = [];
    const proposedMapping: Record<number, string> = {};

    for (let c = 0; c <= range.e.c; c++) {
      const colLetter = XLSX.utils.encode_col(c);
      const rawHeader = allHeaders[c].rawHeader;
      const sampleVal = allHeaders[c].sampleValues && allHeaders[c].sampleValues!.length > 0 ? allHeaders[c].sampleValues![0] : '';

      const mapping = autoMapHeader(rawHeader, c, allHeaders);
      proposedMapping[c] = mapping.targetFieldKey;

      const targetDef = TARGET_FIELDS.find(t => t.key === mapping.targetFieldKey);
      let detectedType: 'string' | 'number' | 'date' | 'boolean' = targetDef ? targetDef.dataType : 'string';
      if (!targetDef && sampleVal !== '') {
        detectedType = isNaN(Number(sampleVal)) ? 'string' : 'number';
      }

      let status: 'matched' | 'review' | 'excluded' | 'custom' = 'review';
      if (mapping.targetFieldKey === '__EXCLUDE__') {
        status = 'excluded';
      } else if (mapping.confidence >= 0.8) {
        status = 'matched';
      } else if (mapping.confidence >= 0.4) {
        status = 'review';
      } else {
        status = 'review';
      }

      // Format sample value without scientific notation
      let displaySample = sampleVal;
      if (targetDef?.isIdentifier && sampleVal !== '') {
        displaySample = formatIdentifierText(sampleVal);
      }

      columns.push({
        colIndex: c,
        colLetter,
        rawHeader: rawHeader || `(Column ${colLetter})`,
        sampleValue: displaySample,
        detectedType,
        proposedField: mapping.targetFieldKey,
        confidence: mapping.confidence,
        status,
        reason: mapping.reason
      });
    }

    // Parse preview rows with proposed mapping
    const parsedAll = this.parseSheetWithMapping(sheet, proposedMapping, headerRowIndex, selectedSheet);
    const previewRows = parsedAll.slice(0, 25);

    const mappedCount = columns.filter(c => c.proposedField && c.proposedField !== '__EXCLUDE__').length;
    const excludedCount = columns.filter(c => c.proposedField === '__EXCLUDE__').length;
    const unmappedCount = columns.length - mappedCount - excludedCount;

    return {
      fileName,
      sheetNames,
      selectedSheet,
      sheetsSummary,
      headerRowIndex,
      totalRows: Math.max(0, range.e.r - headerRowIndex),
      totalColumns: range.e.c + 1,
      columns,
      targetFields: TARGET_FIELDS.map(t => ({
        key: t.key,
        label: t.label,
        category: t.category,
        dataType: t.dataType,
        description: t.description
      })),
      previewRows,
      summary: {
        totalColumns: columns.length,
        mappedCount,
        excludedCount,
        unmappedCount
      }
    };
  }

  /**
   * Parses rows from a worksheet according to an explicit column-to-targetField mapping.
   */
  static parseSheetWithMapping(
    sheet: XLSX.WorkSheet,
    mapping: Record<number | string, string>,
    headerRow: number,
    sheetName: string
  ): ParsedEmployeeRow[] {
    const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
    const rows: ParsedEmployeeRow[] = [];

    const getCell = (r: number, c: number) => sheet[XLSX.utils.encode_cell({ r, c })];
    const cleanStr = (val: any) => (val !== null && val !== undefined ? String(val).trim() : '');

    for (let r = headerRow + 1; r <= range.e.r; r++) {
      const rowObj: ParsedEmployeeRow = {
        empCode: '',
        name: '',
        designationAlias: 'SW',
        totalDays: 30,
        presentDays: 30,
        bonus: 0,
        perfAllowanceMonthly: 0,
        sourceSheet: sheetName,
        sourceRow: r + 1,
        customData: {}
      };

      let hasAnyData = false;

      for (let c = 0; c <= range.e.c; c++) {
        const fieldKey = mapping[c];
        if (!fieldKey || fieldKey === '__EXCLUDE__') continue;

        const cell = getCell(r, c);
        if (!cell || cell.v === undefined || cell.v === null || cell.v === '') continue;

        hasAnyData = true;
        const rawVal = cell.v;

        switch (fieldKey) {
          case 'emp_code':
            rowObj.empCode = formatIdentifierText(rawVal);
            break;
          case 'sr_no':
            rowObj.srNo = formatIdentifierText(rawVal);
            break;
          case 'name':
            rowObj.name = cleanStr(rawVal);
            break;
          case 'father_name':
            rowObj.fatherName = cleanStr(rawVal);
            break;
          case 'designation': {
            const desigRaw = cleanStr(rawVal);
            const normalized = normalizeDesignation(desigRaw);
            rowObj.designationAlias = normalized.alias;
            rowObj.designationName = normalized.name;
            break;
          }
          case 'contractor':
            rowObj.contractorName = cleanStr(rawVal);
            break;
          case 'circle':
            rowObj.circleName = cleanStr(rawVal);
            break;
          case 'cell_department':
            rowObj.cell = cleanStr(rawVal);
            rowObj.departmentName = cleanStr(rawVal);
            break;
          case 'uan':
            rowObj.uan = formatIdentifierText(rawVal);
            break;
          case 'esi_number':
            rowObj.esiNumber = formatIdentifierText(rawVal);
            break;
          case 'aadhar_number':
            rowObj.aadharNumber = formatIdentifierText(rawVal);
            break;
          case 'pan_number':
            rowObj.panNumber = cleanStr(rawVal).toUpperCase();
            break;
          case 'mobile_number':
            rowObj.mobileNumber = formatIdentifierText(rawVal);
            break;
          case 'bank_account':
            rowObj.bankAccount = formatIdentifierText(rawVal);
            break;
          case 'ifsc':
            rowObj.ifsc = cleanStr(rawVal).toUpperCase();
            break;
          case 'bank_name':
            rowObj.bankName = cleanStr(rawVal);
            break;
          case 'account_holder_name':
            rowObj.accountHolderName = cleanStr(rawVal);
            break;
          case 'dob':
            rowObj.dob = cleanStr(rawVal);
            break;
          case 'age_above_58':
            rowObj.ageAbove58 = cleanStr(rawVal).toUpperCase().startsWith('Y') ? 'Y' : 'N';
            break;
          case 'above_60':
            rowObj.above60 = cleanStr(rawVal);
            break;
          case 'date_of_joining':
            rowObj.dateOfJoining = cleanStr(rawVal);
            break;
          case 'date_of_exit':
            rowObj.dateOfExit = cleanStr(rawVal);
            break;
          case 'more_than_3_yrs':
            rowObj.moreThan3Yrs = cleanStr(rawVal);
            break;
          case 'more_than_5_yrs':
            rowObj.moreThan5Yrs = cleanStr(rawVal);
            break;
          case 'qualification':
            rowObj.qualification = cleanStr(rawVal);
            break;
          case 'experience_years':
            rowObj.experienceYears = cleanStr(rawVal);
            break;
          case 'qualified_status':
            rowObj.qualifiedStatus = cleanStr(rawVal);
            break;
          case 'hazard_duty':
            rowObj.hazardDuty = cleanStr(rawVal);
            break;
          case 'check_status':
            rowObj.checkStatus = cleanStr(rawVal);
            break;
          case 'total_days':
            rowObj.totalDays = formatNumericValue(rawVal) || 30;
            break;
          case 'present_days':
            rowObj.presentDays = formatNumericValue(rawVal) !== undefined ? formatNumericValue(rawVal)! : 30;
            break;
          case 'gross_salary_rate':
            rowObj.defaultGrossRate = formatNumericValue(rawVal);
            break;
          case 'proportioned_salary':
            rowObj.proportionedSalary = formatNumericValue(rawVal);
            break;
          case 'special_allowance':
            rowObj.defaultSpecialAllowance = formatNumericValue(rawVal);
            break;
          case 'total_basic':
            rowObj.totalBasic = formatNumericValue(rawVal);
            break;
          case 'thermal_allowance':
            rowObj.defaultThermalAllowance = formatNumericValue(rawVal);
            rowObj.thermalAllowance = formatNumericValue(rawVal);
            break;
          case 'perf_allowance_monthly':
            rowObj.defaultPerfAllowance = formatNumericValue(rawVal);
            rowObj.perfAllowanceMonthly = formatNumericValue(rawVal) || 0;
            break;
          case 'perf_allowance_days':
            rowObj.perfAllowanceDays = formatNumericValue(rawVal);
            break;
          case 'total_earnings_before_bonus':
            rowObj.totalEarningsBeforeBonus = formatNumericValue(rawVal);
            break;
          case 'bonus':
            rowObj.bonus = formatNumericValue(rawVal) || 0;
            break;
          case 'bonus_percentage':
            rowObj.defaultBonusPercentage = formatNumericValue(rawVal);
            rowObj.bonusPercentage = formatNumericValue(rawVal);
            break;
          case 'employer_epf_12':
            rowObj.customEmployerEpf = formatNumericValue(rawVal);
            break;
          case 'employer_epf_1':
            rowObj.customEmployerEpf1 = formatNumericValue(rawVal);
            break;
          case 'employer_esi_325':
            rowObj.customEmployerEsi = formatNumericValue(rawVal);
            break;
          case 'employer_lwf':
            rowObj.customEmployerLwf = formatNumericValue(rawVal);
            break;
          case 'gross_total':
            rowObj.importedGrossTotal = formatNumericValue(rawVal);
            break;
          case 'employee_epf_12':
            rowObj.customEmployeeEpf = formatNumericValue(rawVal);
            break;
          case 'employee_esi_075':
            rowObj.customEmployeeEsi = formatNumericValue(rawVal);
            break;
          case 'employee_lwf':
            rowObj.customEmployeeLwf = formatNumericValue(rawVal);
            break;
          case 'total_employee_deductions':
            rowObj.importedTotalEmployeeDeductions = formatNumericValue(rawVal);
            break;
          case 'total_employer_contributions':
            rowObj.importedTotalEmployerContributions = formatNumericValue(rawVal);
            break;
          case 'combined_deductions':
            rowObj.importedCombinedDeductions = formatNumericValue(rawVal);
            break;
          case 'net_payable':
            const rawNetVal = formatNumericValue(rawVal);
            rowObj.importedNetPayable = rawNetVal !== undefined ? Math.round(rawNetVal) : undefined;
            break;
          case 'perf_last_drawn':
            rowObj.perfLastDrawn = formatNumericValue(rawVal);
            break;
          case 'perf_as_per_circle':
            rowObj.perfAsPerCircle = formatNumericValue(rawVal);
            break;
          case 'perf_difference':
            rowObj.perfDifference = formatNumericValue(rawVal);
            break;
          default:
            if (!rowObj.customData) rowObj.customData = {};
            rowObj.customData[fieldKey] = rawVal;
            break;
        }
      }

      if (!hasAnyData || (!rowObj.name && !rowObj.empCode)) continue;
      if (/^(total|grand total|emp code|employee name)$/i.test(rowObj.name || '') || /^(total|grand total)$/i.test(rowObj.empCode || '')) continue;

      if (!rowObj.empCode) {
        rowObj.empCode = rowObj.srNo ? `EMP-${rowObj.srNo}` : `EMP-${sheetName}-${r}`;
      }

      rows.push(rowObj);
    }

    return rows;
  }

  /**
   * Commits an Excel sheet with explicit mapping to database (employees & monthly payroll entries).
   */
  static async executeMappedImport(
    buffer: Buffer,
    sheetName: string,
    mapping: Record<number | string, string>,
    headerRow: number,
    strategy: 'both' | 'add_only' | 'update_only' = 'both',
    month: number = 9,
    year: number = 2026,
    ownerUserId: number,
    userName: string
  ) {
    if (sheetName === '__ALL__' || sheetName === 'ALL') {
      return this.executeAllSheetsImport(buffer, strategy, month, year, ownerUserId, userName);
    }

    const workbook = XLSX.read(buffer, { type: 'buffer', cellFormula: true });
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) {
      throw new Error(`Worksheet "${sheetName}" not found in uploaded workbook.`);
    }

    const rows = this.parseSheetWithMapping(sheet, mapping, headerRow, sheetName);
    if (rows.length === 0) {
      throw new Error(`No employee records could be parsed from sheet "${sheetName}".`);
    }

    // 1. Ensure Payroll Period exists for (month, year, ownerUserId)
    let periodId: number;
    const periodRes = await db.query(
      `SELECT id FROM payroll_periods WHERE owner_user_id = $1 AND month = $2 AND year = $3 LIMIT 1;`,
      [ownerUserId, month, year]
    );

    if (periodRes.rows.length > 0) {
      periodId = periodRes.rows[0].id;
    } else {
      const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const mName = monthNames[month] || `Month ${month}`;
      const newPeriod = await db.query(
        `INSERT INTO payroll_periods (owner_user_id, year, month, month_name, total_days, status, notes)
         VALUES ($1, $2, $3, $4, 30, 'Draft', $5) RETURNING id;`,
        [ownerUserId, year, month, mName, `Auto-created from mapped Excel import (${sheetName})`]
      );
      periodId = newPeriod.rows[0].id;
    }

    const desigCache = new Map<string, { id: number; alias: string; name: string }>();
    const contractorCache = new Map<string, number>();
    const circleCache = new Map<string, number>();
    const deptCache = new Map<string, number>();

    let createdCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;

    for (const r of rows) {
      if (!r.name) {
        skippedCount++;
        continue;
      }

      const codeTrim = (r.empCode || '').trim();
      const uanTrim = (r.uan || '').trim();

      // Check existing employee
      let existingRes = await db.query(
        `SELECT id FROM employees WHERE (emp_code = $1 OR (uan = $2 AND uan != '')) AND owner_user_id = $3 LIMIT 1;`,
        [codeTrim, uanTrim, ownerUserId]
      );
      const isExisting = existingRes.rows.length > 0;

      if (strategy === 'add_only' && isExisting) {
        skippedCount++;
        continue;
      }
      if (strategy === 'update_only' && !isExisting) {
        skippedCount++;
        continue;
      }

      // Contractor
      let contractorId: number | null = null;
      if (r.contractorName) {
        const cKey = r.contractorName.trim().toLowerCase();
        if (contractorCache.has(cKey)) {
          contractorId = contractorCache.get(cKey)!;
        } else {
          let cleanContractor = r.contractorName.trim();
          if (/sodhi\s+erectors/i.test(cleanContractor)) cleanContractor = 'M/s Sodhi Erectors';
          const cRes = await db.query(
            `SELECT id FROM contractors WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`,
            [cleanContractor, ownerUserId]
          );
          if (cRes.rows.length > 0) {
            contractorId = cRes.rows[0].id;
          } else {
            const newC = await db.query(
              `INSERT INTO contractors (owner_user_id, name) VALUES ($1, $2) RETURNING id;`,
              [ownerUserId, cleanContractor]
            );
            contractorId = newC.rows[0].id;
          }
          contractorCache.set(cKey, contractorId);
        }
      }

      // Circle
      let circleId: number | null = null;
      if (r.circleName) {
        const cirKey = r.circleName.trim().toLowerCase();
        if (circleCache.has(cirKey)) {
          circleId = circleCache.get(cirKey)!;
        } else {
          const cirRes = await db.query(
            `SELECT id FROM circles WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`,
            [r.circleName.trim(), ownerUserId]
          );
          if (cirRes.rows.length > 0) {
            circleId = cirRes.rows[0].id;
          } else {
            const newCir = await db.query(
              `INSERT INTO circles (owner_user_id, name) VALUES ($1, $2) RETURNING id;`,
              [ownerUserId, r.circleName.trim()]
            );
            circleId = newCir.rows[0].id;
          }
          circleCache.set(cirKey, circleId);
        }
      }

      // Department
      let deptId: number | null = null;
      if (r.departmentName) {
        const deptKey = r.departmentName.trim().toLowerCase();
        if (deptCache.has(deptKey)) {
          deptId = deptCache.get(deptKey)!;
        } else {
          const dRes = await db.query(
            `SELECT id FROM departments WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`,
            [r.departmentName.trim(), ownerUserId]
          );
          if (dRes.rows.length > 0) {
            deptId = dRes.rows[0].id;
          } else {
            const newD = await db.query(
              `INSERT INTO departments (owner_user_id, name, circle_id) VALUES ($1, $2, $3) RETURNING id;`,
              [ownerUserId, r.departmentName.trim(), circleId]
            );
            deptId = newD.rows[0].id;
          }
          deptCache.set(deptKey, deptId);
        }
      }

      // Designation
      const resolvedDes = await resolveDesignationId(
        r.designationAlias || r.designationName || 'SW',
        ownerUserId,
        r.defaultGrossRate,
        r.defaultSpecialAllowance,
        desigCache
      );
      const desigId = resolvedDes.id;

      let empGross = r.defaultGrossRate;
      let empSpecial = r.defaultSpecialAllowance;
      if (!empGross || !empSpecial) {
        const rateRes = await db.query(
          `SELECT gross_salary_rate, special_allowance FROM designation_salary_rates WHERE designation_id = $1 AND is_active = TRUE LIMIT 1;`,
          [desigId]
        );
        if (rateRes.rows.length > 0) {
          if (!empGross) empGross = Number(rateRes.rows[0].gross_salary_rate);
          if (!empSpecial) empSpecial = Number(rateRes.rows[0].special_allowance);
        }
      }

      let empId: number;

      if (isExisting) {
        empId = existingRes.rows[0].id;
        await db.query(`
          UPDATE employees SET
            emp_code = COALESCE($1, emp_code),
            name = COALESCE($2, name),
            father_name = COALESCE($3, father_name),
            uan = COALESCE($4, uan),
            designation_id = $5,
            dob = COALESCE($6, dob),
            age_above_58 = COALESCE($7, age_above_58),
            date_of_joining = COALESCE($8, date_of_joining),
            date_of_exit = COALESCE($9, date_of_exit),
            mobile_number = COALESCE($10, mobile_number),
            more_than_3_yrs = COALESCE($11, more_than_3_yrs),
            more_than_5_yrs = COALESCE($12, more_than_5_yrs),
            qualification = COALESCE($13, qualification),
            experience_years = COALESCE($14, experience_years),
            qualified_status = COALESCE($15, qualified_status),
            contractor_id = COALESCE($16, contractor_id),
            circle_id = COALESCE($17, circle_id),
            department_id = COALESCE($18, department_id),
            hazard_duty = COALESCE($19, hazard_duty),
            above_60 = COALESCE($20, above_60),
            check_status = COALESCE($21, check_status),
            cell = COALESCE($22, cell),
            bank_name = COALESCE($23, bank_name),
            bank_account = COALESCE($24, bank_account),
            ifsc = COALESCE($25, ifsc),
            account_holder_name = COALESCE($26, account_holder_name),
            esi_number = COALESCE($27, esi_number),
            aadhar_number = COALESCE($28, aadhar_number),
            pan_number = COALESCE($29, pan_number),
            default_gross_rate = COALESCE($30, default_gross_rate),
            default_special_allowance = COALESCE($31, default_special_allowance),
            default_thermal_allowance = COALESCE($32, default_thermal_allowance),
            default_perf_allowance = COALESCE($33, default_perf_allowance),
            default_bonus_percentage = COALESCE($34, default_bonus_percentage),
            custom_employee_epf = COALESCE($35, custom_employee_epf),
            custom_employer_epf = COALESCE($36, custom_employer_epf),
            custom_employer_epf1 = COALESCE($37, custom_employer_epf1),
            custom_employee_esi = COALESCE($38, custom_employee_esi),
            custom_employer_esi = COALESCE($39, custom_employer_esi),
            custom_employee_lwf = COALESCE($40, custom_employee_lwf),
            custom_employer_lwf = COALESCE($41, custom_employer_lwf),
            custom_data = COALESCE($42, custom_data),
            is_active = TRUE,
            is_archived = FALSE,
            archived_at = NULL,
            archived_by_user_id = NULL,
            archived_reason = NULL,
            updated_by_user_id = $43,
            updated_at = CURRENT_TIMESTAMP
          WHERE id = $44 AND owner_user_id = $45;
        `, [
          r.empCode || null, r.name, r.fatherName || null, r.uan || null, desigId,
          r.dob || null, r.ageAbove58 || null, r.dateOfJoining || null, r.dateOfExit || null,
          r.mobileNumber || null, r.moreThan3Yrs || null, r.moreThan5Yrs || null,
          r.qualification || null, r.experienceYears || null, r.qualifiedStatus || null,
          contractorId, circleId, deptId,
          r.hazardDuty || null, r.above60 || null, r.checkStatus || null,
          r.cell || null, r.bankName || null, r.bankAccount || null, r.ifsc || null,
          r.accountHolderName || null, r.esiNumber || null, r.aadharNumber || null,
          r.panNumber || null, empGross || null, empSpecial || null,
          r.defaultThermalAllowance !== undefined && r.defaultThermalAllowance !== null ? Number(r.defaultThermalAllowance) : null,
          r.defaultPerfAllowance !== undefined && r.defaultPerfAllowance !== null ? Number(r.defaultPerfAllowance) : null,
          r.defaultBonusPercentage !== undefined && r.defaultBonusPercentage !== null ? Number(r.defaultBonusPercentage) : null,
          r.customEmployeeEpf !== undefined && r.customEmployeeEpf !== null ? Number(r.customEmployeeEpf) : null,
          r.customEmployerEpf !== undefined && r.customEmployerEpf !== null ? Number(r.customEmployerEpf) : null,
          r.customEmployerEpf1 !== undefined && r.customEmployerEpf1 !== null ? Number(r.customEmployerEpf1) : null,
          r.customEmployeeEsi !== undefined && r.customEmployeeEsi !== null ? Number(r.customEmployeeEsi) : null,
          r.customEmployerEsi !== undefined && r.customEmployerEsi !== null ? Number(r.customEmployerEsi) : null,
          r.customEmployeeLwf !== undefined && r.customEmployeeLwf !== null ? Number(r.customEmployeeLwf) : null,
          r.customEmployerLwf !== undefined && r.customEmployerLwf !== null ? Number(r.customEmployerLwf) : null,
          r.customData && Object.keys(r.customData).length > 0 ? JSON.stringify(r.customData) : null,
          ownerUserId, empId, ownerUserId
        ]);
        updatedCount++;
      } else {
        const insRes = await db.query(`
          INSERT INTO employees (
            owner_user_id, created_by_user_id, emp_code, sr_no, name, father_name, uan, designation_id, dob, age_above_58,
            date_of_joining, date_of_exit, mobile_number, more_than_3_yrs, more_than_5_yrs, qualification, experience_years,
            qualified_status, contractor_id, circle_id, department_id, hazard_duty, above_60,
            check_status, cell, bank_name, bank_account, ifsc, account_holder_name, esi_number, aadhar_number, pan_number,
            default_gross_rate, default_special_allowance, default_thermal_allowance, default_perf_allowance, default_bonus_percentage,
            custom_employee_epf, custom_employer_epf, custom_employer_epf1, custom_employee_esi, custom_employer_esi, custom_employee_lwf, custom_employer_lwf,
            custom_data, epf_applicable, esi_applicable, lwf_applicable, is_active
          ) VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
            $11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
            $21,$22,$23,$24,$25,$26,$27,$28,$29,$30,
            $31,$32,$33,$34,$35,$36,$37,$38,$39,$40,
            $41,$42,$43,$44,$45,$46,$47,$48,TRUE
          ) RETURNING id;
        `, [
          ownerUserId, ownerUserId, codeTrim || `EMP-${Math.floor(100 + Math.random() * 900)}`,
          r.srNo || '', r.name, r.fatherName || '', r.uan || '', desigId,
          r.dob || '', r.ageAbove58 || 'N', r.dateOfJoining || '', r.dateOfExit || '',
          r.mobileNumber || '', r.moreThan3Yrs || 'NO', r.moreThan5Yrs || 'NO',
          r.qualification || '', r.experienceYears || '', r.qualifiedStatus || '',
          contractorId, circleId, deptId, r.hazardDuty || '', r.above60 || '',
          r.checkStatus || '', r.cell || '', r.bankName || '', r.bankAccount || '', r.ifsc || '',
          r.accountHolderName || '', r.esiNumber || '', r.aadharNumber || '', r.panNumber || '',
          empGross || null, empSpecial || null,
          r.defaultThermalAllowance !== undefined && r.defaultThermalAllowance !== null ? Number(r.defaultThermalAllowance) : 1500,
          r.defaultPerfAllowance !== undefined && r.defaultPerfAllowance !== null ? Number(r.defaultPerfAllowance) : 0,
          r.defaultBonusPercentage !== undefined && r.defaultBonusPercentage !== null ? Number(r.defaultBonusPercentage) : 8.33,
          r.customEmployeeEpf !== undefined && r.customEmployeeEpf !== null ? Number(r.customEmployeeEpf) : null,
          r.customEmployerEpf !== undefined && r.customEmployerEpf !== null ? Number(r.customEmployerEpf) : null,
          r.customEmployerEpf1 !== undefined && r.customEmployerEpf1 !== null ? Number(r.customEmployerEpf1) : null,
          r.customEmployeeEsi !== undefined && r.customEmployeeEsi !== null ? Number(r.customEmployeeEsi) : null,
          r.customEmployerEsi !== undefined && r.customEmployerEsi !== null ? Number(r.customEmployerEsi) : null,
          r.customEmployeeLwf !== undefined && r.customEmployeeLwf !== null ? Number(r.customEmployeeLwf) : null,
          r.customEmployerLwf !== undefined && r.customEmployerLwf !== null ? Number(r.customEmployerLwf) : null,
          r.customData && Object.keys(r.customData).length > 0 ? JSON.stringify(r.customData) : '{}',
          r.epfApplicable !== false, r.esiApplicable !== false, r.lwfApplicable !== false
        ]);
        empId = insRes.rows[0].id;
        createdCount++;
      }

      // Calculate Payroll values or use explicit Excel sheet values
      const calc = calculatePayroll({
        designationAlias: resolvedDes.alias,
        totalDays: r.totalDays || 30,
        presentDays: r.presentDays !== undefined && r.presentDays !== null && r.presentDays >= 0 ? r.presentDays : (r.totalDays || 30),
        grossSalaryRate: r.defaultGrossRate || empGross,
        specialAllowanceRate: r.defaultSpecialAllowance || empSpecial,
        customThermalAllowance: r.thermalAllowance !== undefined ? r.thermalAllowance : (r.defaultThermalAllowance !== undefined ? r.defaultThermalAllowance : 1500),
        perfAllowanceMonthly: r.perfAllowanceMonthly !== undefined ? r.perfAllowanceMonthly : 0,
        bonus: r.bonus,
        bonusPercentage: r.bonusPercentage !== undefined ? r.bonusPercentage : (r.defaultBonusPercentage !== undefined ? r.defaultBonusPercentage : 8.33),
        perfLastDrawn: r.perfLastDrawn,
        perfAsPerCircle: r.perfAsPerCircle,
        isPerfRounded: r.isPerfRounded,
        customEmployeeEpf: r.customEmployeeEpf,
        customEmployerEpf: r.customEmployerEpf,
        customEmployerEpf1: r.customEmployerEpf1,
        customEmployeeEsi: r.customEmployeeEsi,
        customEmployerEsi: r.customEmployerEsi,
        customEmployeeLwf: r.customEmployeeLwf,
        customEmployerLwf: r.customEmployerLwf
      });

      const entryProportionedSalary = r.proportionedSalary !== undefined ? r.proportionedSalary : calc.proportionedSalary;
      const entrySpecialAllowance = r.defaultSpecialAllowance !== undefined ? r.defaultSpecialAllowance : (r.specialAllowance !== undefined ? r.specialAllowance : calc.specialAllowance);
      const entryTotalBasic = r.totalBasic !== undefined ? r.totalBasic : calc.totalBasic;
      const entryThermalAllowance = r.thermalAllowance !== undefined ? r.thermalAllowance : calc.thermalAllowance;
      const entryPerfMonthly = r.perfAllowanceMonthly !== undefined ? r.perfAllowanceMonthly : calc.perfAllowanceMonthly;
      const entryPerfDays = r.perfAllowanceDays !== undefined ? r.perfAllowanceDays : calc.perfAllowanceDaysWise;
      const entryEarningsBeforeBonus = r.totalEarningsBeforeBonus !== undefined ? r.totalEarningsBeforeBonus : calc.totalEarningsBeforeBonus;
      const entryBonus = r.bonus !== undefined ? r.bonus : calc.bonus;
      const entryEmployerEpf12 = r.customEmployerEpf !== undefined ? r.customEmployerEpf : (r.employerEpf12 !== undefined ? r.employerEpf12 : calc.employerEpf12);
      const entryEmployerEpf1 = r.customEmployerEpf1 !== undefined ? r.customEmployerEpf1 : (r.employerEpf1 !== undefined ? r.employerEpf1 : calc.employerEpf1);
      const entryEmployerEsi325 = r.customEmployerEsi !== undefined ? r.customEmployerEsi : (r.employerEsi325 !== undefined ? r.employerEsi325 : calc.employerEsi325);
      const entryEmployerLwf = r.customEmployerLwf !== undefined ? r.customEmployerLwf : (r.employerLwf !== undefined ? r.employerLwf : calc.employerLwf);
      const entryGrossTotal = r.importedGrossTotal !== undefined ? r.importedGrossTotal : calc.grossTotal;
      const entryEmployeeEpf12 = r.customEmployeeEpf !== undefined ? r.customEmployeeEpf : (r.employeeEpf12 !== undefined ? r.employeeEpf12 : calc.employeeEpf12);
      const entryEmployeeEsi075 = r.customEmployeeEsi !== undefined ? r.customEmployeeEsi : (r.employeeEsi075 !== undefined ? r.employeeEsi075 : calc.employeeEsi075);
      const entryEmployeeLwf = r.customEmployeeLwf !== undefined ? r.customEmployeeLwf : (r.employeeLwf !== undefined ? r.employeeLwf : calc.employeeLwf);
      const entryTotalEmployeeDeductions = r.importedTotalEmployeeDeductions !== undefined ? r.importedTotalEmployeeDeductions : calc.totalEmployeeDeductions;
      const entryTotalEmployerContributions = r.importedTotalEmployerContributions !== undefined ? r.importedTotalEmployerContributions : calc.totalEmployerContributions;
      const entryCombinedDeductions = r.importedCombinedDeductions !== undefined ? r.importedCombinedDeductions : calc.combinedDeductions;
      const entryNetPayable = Math.round(Number(r.importedNetPayable !== undefined ? r.importedNetPayable : calc.netPayable));
      const entryBonusPct = r.bonusPercentage !== undefined ? r.bonusPercentage : (r.defaultBonusPercentage !== undefined ? r.defaultBonusPercentage : calc.bonusPercentage);

      // Upsert into payroll_entries
      const existingEntry = await db.query(
        `SELECT id FROM payroll_entries WHERE payroll_period_id = $1 AND employee_id = $2 AND owner_user_id = $3;`,
        [periodId, empId, ownerUserId]
      );

      if (existingEntry.rows.length > 0) {
        await db.query(`
          UPDATE payroll_entries SET
            present_days = $1, gross_salary_rate = $2, proportioned_salary = $3,
            special_allowance = $4, total_basic = $5, thermal_allowance = $6,
            perf_allowance_monthly = $7, perf_allowance_days = $8,
            total_earnings_before_bonus = $9, bonus = $10, employer_epf_12 = $11,
            employer_epf_1 = $12, employer_esi_325 = $13, employer_lwf = $14,
            gross_total = $15, employee_epf_12 = $16, employee_esi_075 = $17,
            employee_lwf = $18, total_employee_deductions = $19,
            total_employer_contributions = $20, combined_deductions = $21,
            net_payable = $22, bonus_percentage = $23, perf_last_drawn = $24,
            perf_as_per_circle = $25, perf_difference = $26,
            imported_net_payable = COALESCE($27, imported_net_payable),
            is_overridden = CASE WHEN $27 IS NOT NULL THEN TRUE ELSE is_overridden END,
            calculation_mode = 'Excel-Mapped', updated_at = CURRENT_TIMESTAMP
          WHERE id = $28 AND owner_user_id = $29;
        `, [
          r.presentDays !== undefined && r.presentDays !== null && r.presentDays >= 0 ? r.presentDays : (r.totalDays || 30),
          calc.grossSalaryRate, entryProportionedSalary, entrySpecialAllowance,
          entryTotalBasic, entryThermalAllowance, entryPerfMonthly,
          entryPerfDays, entryEarningsBeforeBonus, entryBonus,
          entryEmployerEpf12, entryEmployerEpf1, entryEmployerEsi325,
          entryEmployerLwf, entryGrossTotal, entryEmployeeEpf12,
          entryEmployeeEsi075, entryEmployeeLwf, entryTotalEmployeeDeductions,
          entryTotalEmployerContributions, entryCombinedDeductions,
          entryNetPayable, entryBonusPct, r.perfLastDrawn || 0,
          r.perfAsPerCircle || 0, r.perfDifference || 0,
          r.importedNetPayable !== undefined ? Number(r.importedNetPayable) : null,
          existingEntry.rows[0].id, ownerUserId
        ]);
      } else {
        await db.query(`
          INSERT INTO payroll_entries (
            owner_user_id, payroll_period_id, employee_id, present_days, gross_salary_rate, proportioned_salary,
            special_allowance, total_basic, thermal_allowance, perf_allowance_monthly, perf_allowance_days,
            total_earnings_before_bonus, bonus, employer_epf_12, employer_epf_1, employer_esi_325,
            employer_lwf, gross_total, employee_epf_12, employee_esi_075, employee_lwf,
            total_employee_deductions, total_employer_contributions, combined_deductions, net_payable,
            imported_net_payable, is_overridden,
            bonus_percentage, perf_last_drawn, perf_as_per_circle, perf_difference,
            calculation_mode
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
            $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
            $21, $22, $23, $24, $25, $26, $27, $28, $29, $30,
            $31, 'Excel-Mapped'
          );
        `, [
          ownerUserId, periodId, empId,
          r.presentDays !== undefined && r.presentDays !== null && r.presentDays >= 0 ? r.presentDays : (r.totalDays || 30),
          calc.grossSalaryRate, entryProportionedSalary, entrySpecialAllowance,
          entryTotalBasic, entryThermalAllowance, entryPerfMonthly,
          entryPerfDays, entryEarningsBeforeBonus, entryBonus,
          entryEmployerEpf12, entryEmployerEpf1, entryEmployerEsi325,
          entryEmployerLwf, entryGrossTotal, entryEmployeeEpf12,
          entryEmployeeEsi075, entryEmployeeLwf, entryTotalEmployeeDeductions,
          entryTotalEmployerContributions, entryCombinedDeductions,
          entryNetPayable,
          r.importedNetPayable !== undefined ? Number(r.importedNetPayable) : null,
          r.importedNetPayable !== undefined,
          entryBonusPct, r.perfLastDrawn || 0,
          r.perfAsPerCircle || 0, r.perfDifference || 0
        ]);
      }
    }

    // Audit log
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'IMPORT_EXCEL_MAPPED', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [userName, String(periodId), `Mapped import of ${rows.length} records from sheet ${sheetName}. Created: ${createdCount}, Updated: ${updatedCount}, Skipped: ${skippedCount}`, ownerUserId]);

    // Automatically synchronize open payroll periods
    let syncRes = null;
    try {
      syncRes = await syncEmployeesWithOpenPayrollPeriods(ownerUserId);
    } catch (e) {
      console.error('Auto-sync payroll periods on mapped import error:', e);
    }

    return {
      periodId,
      createdCount,
      updatedCount,
      skippedCount,
      totalProcessed: rows.length,
      synchronizedPayrollPeriods: syncRes ? syncRes.periodsSynced : 0,
      synchronizedPayrollAdded: syncRes ? syncRes.totalAdded : 0,
      synchronizedPayrollUpdated: syncRes ? syncRes.totalUpdated : 0
    };
  }

  /**
   * Reads inside the uploaded Excel sheet ALL made sheets, auto-discovers each sheet's
   * columns using the universal dictionary, and imports all employees across all worksheets.
   */
  static async executeAllSheetsImport(
    buffer: Buffer,
    strategy: 'both' | 'add_only' | 'update_only' = 'both',
    month: number = 9,
    year: number = 2026,
    ownerUserId: number,
    userName: string
  ) {
    const workbook = XLSX.read(buffer, { type: 'buffer', cellFormula: true });
    let totalCreated = 0;
    let totalUpdated = 0;
    let totalSkipped = 0;
    let totalProcessed = 0;
    const sheetResults: any[] = [];
    let periodId: number = 0;

    for (const sName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sName];
      if (!sheet || !sheet['!ref']) continue;

      const inspectRes = this.inspectWorkbook(buffer, 'all_sheets_upload.xlsx', sName);
      if (!inspectRes || inspectRes.totalRows === 0 || inspectRes.summary.mappedCount === 0) {
        continue;
      }

      const autoMap: Record<number, string> = {};
      inspectRes.columns.forEach(c => {
        autoMap[c.colIndex] = c.proposedField;
      });

      const res = await this.executeMappedImport(
        buffer,
        sName,
        autoMap,
        inspectRes.headerRowIndex,
        strategy,
        month,
        year,
        ownerUserId,
        userName
      );

      periodId = res.periodId;
      totalCreated += res.createdCount;
      totalUpdated += res.updatedCount;
      totalSkipped += res.skippedCount;
      totalProcessed += res.totalProcessed;
      sheetResults.push({
        sheetName: sName,
        createdCount: res.createdCount,
        updatedCount: res.updatedCount,
        skippedCount: res.skippedCount,
        totalProcessed: res.totalProcessed
      });
    }

    const syncRes = await syncEmployeesWithOpenPayrollPeriods(ownerUserId);

    return {
      periodId,
      createdCount: totalCreated,
      updatedCount: totalUpdated,
      skippedCount: totalSkipped,
      totalProcessed,
      totalSheets: sheetResults.length,
      sheetResults,
      synchronizedPayrollPeriods: syncRes ? syncRes.periodsSynced : 0,
      synchronizedPayrollAdded: syncRes ? syncRes.totalAdded : 0,
      synchronizedPayrollUpdated: syncRes ? syncRes.totalUpdated : 0
    };
  }

  static parseWorkbook(buffer: Buffer, fileName: string): Record<string, ParsedEmployeeRow[]> {
    const workbook = XLSX.read(buffer, { type: 'buffer', cellFormula: true });
    const results: Record<string, ParsedEmployeeRow[]> = {};

    for (const sheetName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sheetName];
      if (!sheet || !sheet['!ref']) continue;

      const rows = this.parseSheet(sheet, sheetName);
      if (rows.length > 0) {
        results[sheetName] = rows;
      }
    }

    return results;
  }

  static parseSheet(sheet: XLSX.WorkSheet, sheetName: string): ParsedEmployeeRow[] {
    const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
    const getVal = (r: number, c: number) => {
      const cell = sheet[XLSX.utils.encode_cell({ r, c })];
      return cell ? cell.v : null;
    };

    const cleanStr = (val: any) => (val !== null && val !== undefined ? String(val).trim() : '');
    const cleanNum = (val: any) => {
      if (val === null || val === undefined) return 0;
      const num = Number(val);
      return isNaN(num) ? 0 : num;
    };

    const rows: ParsedEmployeeRow[] = [];

    // Header layout detection
    const row0A = cleanStr(getVal(0, 0)).toLowerCase();
    const row1A = cleanStr(getVal(1, 0)).toLowerCase();

    const isReferenceMM1 = (sheetName.toUpperCase() === 'MM-1' || sheetName.toUpperCase() === 'MM1' || sheetName.toUpperCase().startsWith('MM-1')) && range.e.c >= 25 && row0A.includes('emp code');
    const isReferenceEMC = (sheetName.toUpperCase() === 'EMC' || sheetName.toUpperCase().startsWith('EMC')) && range.e.c >= 25 && (row0A.includes('contractor') || row1A.includes('sr no'));
    const isOpCircle = (sheetName.toLowerCase().includes('operation') || cleanStr(getVal(0, 0)).toLowerCase().includes('operation')) && range.e.c >= 25;

    if (isReferenceMM1) {
      for (let r = 1; r <= range.e.r; r++) {
        const empCode = cleanStr(getVal(r, 0));
        const name = cleanStr(getVal(r, 1));
        if (!empCode && !name) continue;
        if (/^(total|emp\s*code|name|employee\s*name)$/i.test(empCode) || /^(total|emp\s*code|name|employee\s*name)$/i.test(name)) continue;

        const rawDesig = cleanStr(getVal(r, 4));
        const normalizedDes = normalizeDesignation(rawDesig);

        const c5Val = cleanStr(getVal(r, 5));
        let dob = '';
        let ageAbove58 = 'N';
        let dateOfJoining = '';
        let moreThan3Yrs = 'NO';
        let moreThan5Yrs = 'NO';
        let qualification = '';
        let experienceYears = '';
        let qualifiedStatus = '';
        let contractorName = '';
        let hazardDuty = '';

        if (c5Val === 'N' || c5Val === 'Y') {
          // Row where DOB was omitted and fields shifted left by 1 column
          dob = '';
          ageAbove58 = c5Val;
          dateOfJoining = cleanStr(getVal(r, 6));
          moreThan3Yrs = cleanStr(getVal(r, 7));
          moreThan5Yrs = cleanStr(getVal(r, 8));
          qualification = cleanStr(getVal(r, 9));
          experienceYears = cleanStr(getVal(r, 10));
          qualifiedStatus = cleanStr(getVal(r, 11));
          contractorName = cleanStr(getVal(r, 12));
          hazardDuty = cleanStr(getVal(r, 13));
        } else {
          dob = c5Val;
          ageAbove58 = cleanStr(getVal(r, 6)) || 'N';
          dateOfJoining = cleanStr(getVal(r, 7));
          moreThan3Yrs = cleanStr(getVal(r, 8));
          moreThan5Yrs = cleanStr(getVal(r, 9));
          qualification = cleanStr(getVal(r, 10));
          experienceYears = cleanStr(getVal(r, 11));
          qualifiedStatus = cleanStr(getVal(r, 12));
          contractorName = cleanStr(getVal(r, 13));
          hazardDuty = cleanStr(getVal(r, 14));
        }

        const grossSalaryRate = cleanNum(getVal(r, 27));
        const specialAllowance = cleanNum(getVal(r, 29));
        const perfAllowance = cleanNum(getVal(r, 32));
        const bonus = cleanNum(getVal(r, 35));

        rows.push({
          empCode: empCode || `EMP-${100 + r}`,
          name,
          fatherName: cleanStr(getVal(r, 2)),
          uan: cleanStr(getVal(r, 3)),
          designationAlias: normalizedDes.alias,
          designationName: normalizedDes.name,
          dob,
          ageAbove58,
          dateOfJoining,
          moreThan3Yrs,
          moreThan5Yrs,
          qualification,
          experienceYears,
          qualifiedStatus,
          contractorName,
          hazardDuty,
          above60: cleanStr(getVal(r, 15)),
          checkStatus: cleanStr(getVal(r, 17)),
          bankAccount: cleanStr(getVal(r, 18)),
          ifsc: cleanStr(getVal(r, 19)),
          esiNumber: cleanStr(getVal(r, 20)),
          circleName: 'MM-1 CIRCLE',
          cell: 'MM-1',
          departmentName: 'MM-1 CELL',
          totalDays: cleanNum(getVal(r, 25)) || 30,
          presentDays: cleanNum(getVal(r, 26)),
          defaultGrossRate: grossSalaryRate || undefined,
          defaultSpecialAllowance: specialAllowance || undefined,
          defaultThermalAllowance: 1500,
          defaultPerfAllowance: perfAllowance || 0,
          defaultBonusPercentage: 8.33,
          perfAllowanceMonthly: perfAllowance || 0,
          bonus: bonus || 0,
          bonusPercentage: 8.33,
          perfLastDrawn: 0,
          perfAsPerCircle: 0,
          perfDifference: 0,
          sourceSheet: sheetName,
          sourceRow: r + 1,
          isPerfRounded: r >= 16 // rows 17-22 in MM-1 use ROUND
        });
      }
    } else if (isReferenceEMC) {
      for (let r = 2; r <= range.e.r; r++) {
        const srNo = cleanStr(getVal(r, 0));
        const refNo = cleanStr(getVal(r, 1));
        const name = cleanStr(getVal(r, 4));
        if (!name && !srNo) continue;
        if (/^(total|emp\s*code|name|employee\s*name|worker\s*name)$/i.test(name)) continue;

        const rawDesig = cleanStr(getVal(r, 7));
        const normalizedDes = normalizeDesignation(rawDesig);

        const perfLastDrawn = cleanNum(getVal(r, 51));
        const perfAsPerCircle = cleanNum(getVal(r, 52));
        const perfDiff = perfLastDrawn - perfAsPerCircle;

        const grossSalaryRate = cleanNum(getVal(r, 30));
        const specialAllowance = cleanNum(getVal(r, 32));
        const perfAllowance = cleanNum(getVal(r, 35));
        const bonus = cleanNum(getVal(r, 38));
        const cellVal = cleanStr(getVal(r, 3)) || 'EM-3';

        rows.push({
          empCode: `EMC-${refNo || srNo || r}`,
          srNo: srNo || refNo,
          name,
          fatherName: cleanStr(getVal(r, 5)),
          uan: cleanStr(getVal(r, 6)),
          designationAlias: normalizedDes.alias,
          designationName: normalizedDes.name,
          dob: cleanStr(getVal(r, 8)),
          ageAbove58: cleanStr(getVal(r, 9)),
          dateOfJoining: cleanStr(getVal(r, 10)),
          moreThan3Yrs: cleanStr(getVal(r, 11)),
          moreThan5Yrs: cleanStr(getVal(r, 12)),
          qualification: cleanStr(getVal(r, 13)),
          experienceYears: cleanStr(getVal(r, 14)),
          qualifiedStatus: cleanStr(getVal(r, 15)),
          contractorName: cleanStr(getVal(r, 16)),
          hazardDuty: cleanStr(getVal(r, 17)),
          above60: cleanStr(getVal(r, 18)),
          checkStatus: cleanStr(getVal(r, 20)),
          bankAccount: cleanStr(getVal(r, 21)),
          ifsc: cleanStr(getVal(r, 22)),
          esiNumber: cleanStr(getVal(r, 23)),
          circleName: cleanStr(getVal(r, 2)) || 'EMC CIRCLE',
          cell: cellVal,
          departmentName: cellVal,
          totalDays: cleanNum(getVal(r, 28)) || 30,
          presentDays: cleanNum(getVal(r, 29)),
          defaultGrossRate: grossSalaryRate || undefined,
          defaultSpecialAllowance: specialAllowance || undefined,
          defaultThermalAllowance: 1500,
          defaultPerfAllowance: perfAllowance || 0,
          defaultBonusPercentage: 8.33,
          perfAllowanceMonthly: perfAllowance || 0,
          bonus: bonus || 0,
          bonusPercentage: 8.33,
          perfLastDrawn,
          perfAsPerCircle,
          perfDifference: perfDiff,
          sourceSheet: sheetName,
          sourceRow: r + 1,
          isPerfRounded: false
        });
      }
    } else {
      // Dynamic Header Detection for General, Custom, and Template worksheets
      let headerRowIdx = -1;
      const colMap: Record<string, number> = {};

      for (let r = 0; r <= Math.min(5, range.e.r); r++) {
        const tempColMap: Record<string, number> = {};
        let hits = 0;
        for (let c = 0; c <= range.e.c; c++) {
          const raw = cleanStr(getVal(r, c));
          if (!raw) continue;
          const text = raw.toLowerCase().replace(/\s+/g, ' ');

          if (/^(emp(loyee)?[\s_-]*(code|id|no)|ref[\s_-]*no)$/i.test(text) || (text.includes('emp') && (text.includes('code') || text.includes('id')))) {
            tempColMap['empCode'] = c; hits++;
          } else if (/^(s\.?\s*no\.?|sr\.?\s*no\.?|sl\.?\s*no\.?|serial[\s_-]*no)$/i.test(text)) {
            tempColMap['srNo'] = c; hits++;
          } else if (/^(name\s+of\s+(the\s+)?(worker|employee)|employee\s*name|worker\s*name)$/i.test(text) || (text.includes('name') && !text.includes('father') && !text.includes('husband') && !text.includes('bank') && !text.includes('contractor') && !text.includes('service') && !text.includes('circle') && !text.includes('office'))) {
            if (tempColMap['name'] === undefined) { tempColMap['name'] = c; hits++; }
          } else if (/father|husband/i.test(text)) {
            tempColMap['fatherName'] = c; hits++;
          } else if (/designation|design\b|category|post|trade|skill/i.test(text)) {
            tempColMap['designation'] = c; hits++;
          } else if (/uan|epf\s*no|pf\s*no/i.test(text)) {
            tempColMap['uan'] = c; hits++;
          } else if (/esi\b|esic/i.test(text)) {
            tempColMap['esi'] = c; hits++;
          } else if (/aadhar|aadhaar/i.test(text)) {
            tempColMap['aadhar'] = c; hits++;
          } else if (/pan\b|pan\s*card/i.test(text)) {
            tempColMap['pan'] = c; hits++;
          } else if (/name\s+of\s+bank|bank\s+name/i.test(text)) {
            tempColMap['bankName'] = c; hits++;
          } else if (/bank\s*a\/?c|account\s*(no|num)|a\/c\s*no|bank\s*acc|^bank$/i.test(text)) {
            tempColMap['bankAccount'] = c; hits++;
          } else if (/ifsc/i.test(text)) {
            tempColMap['ifsc'] = c; hits++;
          } else if (/contractor|service\s*provider|agency|firm/i.test(text)) {
            tempColMap['contractor'] = c; hits++;
          } else if (/circle/i.test(text)) {
            tempColMap['circle'] = c; hits++;
          } else if (/^cell$|department|dept|office|nme\s*of\s*office/i.test(text)) {
            tempColMap['cell'] = c; hits++;
          } else if (/dob|date\s+of\s+birth/i.test(text)) {
            tempColMap['dob'] = c; hits++;
          } else if (/doj|date\s+of\s+joining|joining\s+date/i.test(text)) {
            tempColMap['doj'] = c; hits++;
          } else if (/gros[se]\s*(salary|rate)|wage\s*rate|^gross$/i.test(text)) {
            tempColMap['grossSalary'] = c; hits++;
          } else if (/proportioned|b\.p/i.test(text)) {
            tempColMap['proportionedSalary'] = c; hits++;
          } else if (/special\s*allow/i.test(text)) {
            tempColMap['specialAllowance'] = c; hits++;
          } else if (/thermal/i.test(text)) {
            tempColMap['thermalAllowance'] = c; hits++;
          } else if (/perf(ormance)?\s*all/i.test(text)) {
            tempColMap['perfAllowance'] = c; hits++;
          } else if (/bonus\s*%/i.test(text)) {
            tempColMap['bonusPercentage'] = c; hits++;
          } else if (/bonu[ns]/i.test(text)) {
            tempColMap['bonus'] = c; hits++;
          } else if (/pres(e)?nt|duty\s*days|working\s*days/i.test(text)) {
            tempColMap['presentDays'] = c; hits++;
          } else if (/^days$|total\s*days/i.test(text)) {
            tempColMap['totalDays'] = c; hits++;
          } else if (/qualification|qual\b/i.test(text)) {
            tempColMap['qualification'] = c; hits++;
          } else if (/experience|exp\b/i.test(text)) {
            tempColMap['experience'] = c; hits++;
          } else if (/hazard|haz\b/i.test(text)) {
            tempColMap['hazardDuty'] = c; hits++;
          } else if (/age\s*above\s*58/i.test(text)) {
            tempColMap['ageAbove58'] = c; hits++;
          } else if (/above\s*60/i.test(text)) {
            tempColMap['above60'] = c; hits++;
          }
        }

        if (hits >= 2 && (tempColMap['name'] !== undefined || tempColMap['empCode'] !== undefined || tempColMap['designation'] !== undefined)) {
          headerRowIdx = r;
          Object.assign(colMap, tempColMap);
          break;
        }
      }

      const startR = headerRowIdx >= 0 ? headerRowIdx + 1 : (isOpCircle ? 2 : 1);

      const hasHeader = headerRowIdx >= 0;

      for (let r = startR; r <= range.e.r; r++) {
        const nameIdx = colMap['name'] !== undefined ? colMap['name'] : (isOpCircle ? 2 : 1);
        const name = cleanStr(getVal(r, nameIdx));
        const srNoIdx = colMap['srNo'] !== undefined ? colMap['srNo'] : (hasHeader ? -1 : 0);
        const srNo = srNoIdx >= 0 ? cleanStr(getVal(r, srNoIdx)) : '';

        const codeIdx = colMap['empCode'] !== undefined ? colMap['empCode'] : (isOpCircle ? 6 : (hasHeader ? -1 : 0));
        let empCode = codeIdx >= 0 ? cleanStr(getVal(r, codeIdx)) : '';
        if (!empCode) {
          empCode = srNo && !isNaN(Number(srNo)) ? `EMP-${srNo}` : `EMP-${sheetName.replace(/\s+/g, '')}-${r}`;
        }

        if (!name && !srNo && !empCode) continue;
        if (/^(total|emp\s*code|name|employee\s*name|worker\s*name|s\.?\s*no|sr\.?\s*no)$/i.test(name)) continue;

        const desigIdx = colMap['designation'] !== undefined ? colMap['designation'] : (hasHeader ? -1 : (isOpCircle ? 4 : 4));
        const rawDesig = desigIdx >= 0 ? cleanStr(getVal(r, desigIdx)) : '';
        const normalizedDes = normalizeDesignation(rawDesig);

        const fatherIdx = colMap['fatherName'] !== undefined ? colMap['fatherName'] : (hasHeader ? -1 : (isOpCircle ? 3 : 2));
        const uanIdx = colMap['uan'] !== undefined ? colMap['uan'] : (hasHeader ? -1 : (isOpCircle ? 6 : 3));
        const dobIdx = colMap['dob'] !== undefined ? colMap['dob'] : (hasHeader ? -1 : (isOpCircle ? 5 : 5));
        const dojIdx = colMap['doj'] !== undefined ? colMap['doj'] : (hasHeader ? -1 : (isOpCircle ? 13 : 7));
        const bankIdx = colMap['bankAccount'] !== undefined ? colMap['bankAccount'] : (hasHeader ? -1 : (isOpCircle ? 11 : 18));
        const bankNameIdx = colMap['bankName'] !== undefined ? colMap['bankName'] : (hasHeader ? -1 : (isOpCircle ? 10 : -1));
        const ifscIdx = colMap['ifsc'] !== undefined ? colMap['ifsc'] : (hasHeader ? -1 : (isOpCircle ? 12 : 19));
        const esiIdx = colMap['esi'] !== undefined ? colMap['esi'] : (hasHeader ? -1 : (isOpCircle ? 7 : 20));
        const aadharIdx = colMap['aadhar'] !== undefined ? colMap['aadhar'] : (hasHeader ? -1 : (isOpCircle ? 8 : 21));
        const panIdx = colMap['pan'] !== undefined ? colMap['pan'] : (hasHeader ? -1 : (isOpCircle ? 9 : 22));
        const contractorIdx = colMap['contractor'] !== undefined ? colMap['contractor'] : (hasHeader ? -1 : (isOpCircle ? -1 : 13));
        const circleIdx = colMap['circle'] !== undefined ? colMap['circle'] : -1;
        const cellIdx = colMap['cell'] !== undefined ? colMap['cell'] : (hasHeader ? -1 : (isOpCircle ? 1 : -1));

        const circleName = circleIdx >= 0 && cleanStr(getVal(r, circleIdx))
          ? cleanStr(getVal(r, circleIdx))
          : (isOpCircle ? 'OPERATION CIRCLE' : `${sheetName.toUpperCase().replace(/\s*TEMPLATE|\s*CIRCLE/gi, '')} CIRCLE`);

        const cellVal = cellIdx >= 0 ? cleanStr(getVal(r, cellIdx)) : '';

        const grossSalary = colMap['grossSalary'] !== undefined ? cleanNum(getVal(r, colMap['grossSalary'])) : (isOpCircle ? 0 : (hasHeader ? 0 : cleanNum(getVal(r, 21))));
        const specialAllowance = colMap['specialAllowance'] !== undefined ? cleanNum(getVal(r, colMap['specialAllowance'])) : (isOpCircle ? 0 : (hasHeader ? 0 : cleanNum(getVal(r, 23))));
        const thermalAllowance = colMap['thermalAllowance'] !== undefined ? cleanNum(getVal(r, colMap['thermalAllowance'])) : 1500;
        const perfAllowance = colMap['perfAllowance'] !== undefined ? cleanNum(getVal(r, colMap['perfAllowance'])) : 0;
        const bonusPct = colMap['bonusPercentage'] !== undefined ? cleanNum(getVal(r, colMap['bonusPercentage'])) : 8.33;
        const totalDays = colMap['totalDays'] !== undefined ? cleanNum(getVal(r, colMap['totalDays'])) : 30;
        const presentDays = colMap['presentDays'] !== undefined ? cleanNum(getVal(r, colMap['presentDays'])) : 0;

        rows.push({
          empCode,
          srNo,
          name,
          fatherName: fatherIdx >= 0 ? cleanStr(getVal(r, fatherIdx)) : '',
          uan: uanIdx >= 0 ? cleanStr(getVal(r, uanIdx)) : '',
          designationAlias: normalizedDes.alias,
          designationName: normalizedDes.name,
          dob: dobIdx >= 0 ? cleanStr(getVal(r, dobIdx)) : '',
          dateOfJoining: dojIdx >= 0 ? cleanStr(getVal(r, dojIdx)) : '',
          bankAccount: bankIdx >= 0 ? cleanStr(getVal(r, bankIdx)) : '',
          bankName: bankNameIdx >= 0 ? cleanStr(getVal(r, bankNameIdx)) : '',
          ifsc: ifscIdx >= 0 ? cleanStr(getVal(r, ifscIdx)) : '',
          esiNumber: esiIdx >= 0 ? cleanStr(getVal(r, esiIdx)) : '',
          aadharNumber: aadharIdx >= 0 ? cleanStr(getVal(r, aadharIdx)) : '',
          panNumber: panIdx >= 0 ? cleanStr(getVal(r, panIdx)) : '',
          contractorName: contractorIdx >= 0 ? cleanStr(getVal(r, contractorIdx)) : (isOpCircle ? 'M/s Sodhi Erectors' : ''),
          circleName,
          cell: cellVal,
          departmentName: cellVal || 'MAIN',
          qualification: colMap['qualification'] !== undefined ? cleanStr(getVal(r, colMap['qualification'])) : '',
          experienceYears: colMap['experience'] !== undefined ? cleanStr(getVal(r, colMap['experience'])) : '',
          hazardDuty: colMap['hazardDuty'] !== undefined ? cleanStr(getVal(r, colMap['hazardDuty'])) : 'haz',
          ageAbove58: colMap['ageAbove58'] !== undefined ? cleanStr(getVal(r, colMap['ageAbove58'])) : 'N',
          above60: colMap['above60'] !== undefined ? cleanStr(getVal(r, colMap['above60'])) : 'N',
          totalDays: totalDays || 30,
          presentDays: presentDays,
          defaultGrossRate: grossSalary || undefined,
          defaultSpecialAllowance: specialAllowance || undefined,
          defaultThermalAllowance: thermalAllowance || 1500,
          defaultPerfAllowance: perfAllowance || 0,
          defaultBonusPercentage: bonusPct || 8.33,
          perfAllowanceMonthly: perfAllowance || 0,
          bonus: colMap['bonus'] !== undefined ? cleanNum(getVal(r, colMap['bonus'])) : 0,
          bonusPercentage: bonusPct || 8.33,
          sourceSheet: sheetName,
          sourceRow: r + 1,
          isPerfRounded: false
        });
      }
    }

    return rows;
  }

  static async commitImport(rows: ParsedEmployeeRow[], payrollMonth: number, payrollYear: number, userName: string, ownerUserId: number = 1) {
    // 1. Get or create payroll period
    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = monthNames[payrollMonth] || 'September';

    let periodRes = await db.query(
      `SELECT id FROM payroll_periods WHERE year = $1 AND month = $2 AND owner_user_id = $3;`,
      [payrollYear, payrollMonth, ownerUserId]
    );

    let periodId: number;
    if (periodRes.rows.length === 0) {
      const newPeriod = await db.query(
        `INSERT INTO payroll_periods (owner_user_id, year, month, month_name, total_days, status) 
         VALUES ($1, $2, $3, $4, 30, 'Draft') RETURNING id;`,
        [ownerUserId, payrollYear, payrollMonth, monthName]
      );
      periodId = newPeriod.rows[0].id;
    } else {
      periodId = periodRes.rows[0].id;
    }

    const desigCache = new Map<string, { id: number; alias: string; name: string }>();
    let createdCount = 0;
    let updatedCount = 0;

    for (const r of rows) {
      if (!r.name) continue;

      // 1. Contractor
      let contractorId: number | null = null;
      if (r.contractorName) {
        let cleanContractor = r.contractorName.trim();
        if (/sodhi\s+erectors/i.test(cleanContractor)) {
          cleanContractor = 'M/s Sodhi Erectors';
        }
        const cRes = await db.query(
          `SELECT id FROM contractors WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`,
          [cleanContractor, ownerUserId]
        );
        if (cRes.rows.length > 0) {
          contractorId = cRes.rows[0].id;
        } else {
          const newC = await db.query(
            `INSERT INTO contractors (owner_user_id, name) VALUES ($1, $2) RETURNING id;`,
            [ownerUserId, cleanContractor]
          );
          contractorId = newC.rows[0].id;
        }
      }

      // 2. Circle
      let circleId: number | null = null;
      if (r.circleName) {
        const cirRes = await db.query(
          `SELECT id FROM circles WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`,
          [r.circleName.trim(), ownerUserId]
        );
        if (cirRes.rows.length > 0) {
          circleId = cirRes.rows[0].id;
        } else {
          const newCir = await db.query(
            `INSERT INTO circles (owner_user_id, name) VALUES ($1, $2) RETURNING id;`,
            [ownerUserId, r.circleName.trim()]
          );
          circleId = newCir.rows[0].id;
        }
      }

      // 3. Department
      let deptId: number | null = null;
      if (r.departmentName) {
        const dRes = await db.query(
          `SELECT id FROM departments WHERE LOWER(name) = LOWER($1) AND circle_id = $2 AND owner_user_id = $3;`,
          [r.departmentName.trim(), circleId, ownerUserId]
        );
        if (dRes.rows.length > 0) {
          deptId = dRes.rows[0].id;
        } else {
          const newDept = await db.query(
            `INSERT INTO departments (owner_user_id, name, circle_id) VALUES ($1, $2, $3) RETURNING id;`,
            [ownerUserId, r.departmentName.trim(), circleId]
          );
          deptId = newDept.rows[0].id;
        }
      }

      // 4. Designation — resolve intelligently without defaulting all to SW!
      const resolvedDes = await resolveDesignationId(
        r.designationAlias,
        ownerUserId,
        r.defaultGrossRate,
        r.defaultSpecialAllowance,
        desigCache
      );
      const desigId = resolvedDes.id;

      // 5. Upsert Employee
      let empId: number;
      const empRes = await db.query(
        `SELECT id FROM employees WHERE (emp_code = $1 OR (uan = $2 AND uan != '')) AND owner_user_id = $3;`,
        [r.empCode.trim(), (r.uan || '').trim(), ownerUserId]
      );
      if (empRes.rows.length > 0) {
        empId = empRes.rows[0].id;
        await db.query(`
          UPDATE employees SET
            sr_no = $1, name = $2, father_name = $3, uan = $4, designation_id = $5,
            dob = $6, age_above_58 = $7, date_of_joining = $8, more_than_3_yrs = $9,
            more_than_5_yrs = $10, qualification = $11, experience_years = $12, qualified_status = $13,
            contractor_id = $14, circle_id = $15, department_id = $16, cell = $17, hazard_duty = $18,
            above_60 = $19, check_status = $20, bank_account = $21, ifsc = $22, esi_number = $23,
            aadhar_number = $24, pan_number = $25, bank_name = $26,
            default_gross_rate = COALESCE($27, default_gross_rate),
            default_special_allowance = COALESCE($28, default_special_allowance),
            default_thermal_allowance = COALESCE($29, default_thermal_allowance),
            default_perf_allowance = COALESCE($30, default_perf_allowance),
            default_bonus_percentage = COALESCE($31, default_bonus_percentage),
            is_active = TRUE, is_archived = FALSE, archived_at = NULL, archived_by_user_id = NULL,
            updated_at = CURRENT_TIMESTAMP
          WHERE id = $32 AND owner_user_id = $33;
        `, [
          r.srNo || '', r.name, r.fatherName || '', r.uan || '', desigId,
          r.dob || '', r.ageAbove58 || 'N', r.dateOfJoining || '', r.moreThan3Yrs || 'NO',
          r.moreThan5Yrs || 'NO', r.qualification || '', r.experienceYears || '', r.qualifiedStatus || '',
          contractorId, circleId, deptId, r.cell || '', r.hazardDuty || '', r.above60 || '', r.checkStatus || '',
          r.bankAccount || '', r.ifsc || '', r.esiNumber || '', r.aadharNumber || '', r.panNumber || '', r.bankName || '',
          r.defaultGrossRate || null, r.defaultSpecialAllowance || null,
          r.defaultThermalAllowance || null, r.defaultPerfAllowance || null,
          r.defaultBonusPercentage || null,
          empId, ownerUserId
        ]);
        updatedCount++;
      } else {
        const newEmp = await db.query(`
          INSERT INTO employees (
            owner_user_id, emp_code, sr_no, name, father_name, uan, designation_id, dob, age_above_58,
            date_of_joining, more_than_3_yrs, more_than_5_yrs, qualification, experience_years,
            qualified_status, contractor_id, circle_id, department_id, cell, hazard_duty, above_60,
            check_status, bank_account, ifsc, esi_number, aadhar_number, pan_number, bank_name,
            default_gross_rate, default_special_allowance, default_thermal_allowance, default_perf_allowance, default_bonus_percentage,
            is_active
          ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,TRUE)
          RETURNING id;
        `, [
          ownerUserId, r.empCode, r.srNo || '', r.name, r.fatherName || '', r.uan || '', desigId,
          r.dob || '', r.ageAbove58 || 'N', r.dateOfJoining || '', r.moreThan3Yrs || 'NO',
          r.moreThan5Yrs || 'NO', r.qualification || '', r.experienceYears || '', r.qualifiedStatus || '',
          contractorId, circleId, deptId, r.cell || '', r.hazardDuty || '', r.above60 || '', r.checkStatus || '',
          r.bankAccount || '', r.ifsc || '', r.esiNumber || '', r.aadharNumber || '', r.panNumber || '', r.bankName || '',
          r.defaultGrossRate || null, r.defaultSpecialAllowance || null,
          r.defaultThermalAllowance || 1500, r.defaultPerfAllowance || 0,
          r.defaultBonusPercentage || 8.33
        ]);
        empId = newEmp.rows[0].id;
        createdCount++;
      }

      // 6. Calculate Payroll for this row using resolved designation
      const calc = calculatePayroll({
        designationAlias: resolvedDes.alias,
        totalDays: r.totalDays || 30,
        presentDays: r.presentDays !== undefined && r.presentDays !== null && r.presentDays > 0 ? r.presentDays : (r.totalDays || 30),
        grossSalaryRate: r.defaultGrossRate,
        specialAllowanceRate: r.defaultSpecialAllowance,
        perfAllowanceMonthly: r.perfAllowanceMonthly,
        bonus: r.bonus,
        bonusPercentage: r.bonusPercentage || 8.33,
        perfLastDrawn: r.perfLastDrawn,
        perfAsPerCircle: r.perfAsPerCircle,
        isPerfRounded: r.isPerfRounded
      });

      // 7. Upsert Payroll Entry
      const existingEntry = await db.query(
        `SELECT id FROM payroll_entries WHERE payroll_period_id = $1 AND employee_id = $2 AND owner_user_id = $3;`,
        [periodId, empId, ownerUserId]
      );

      if (existingEntry.rows.length > 0) {
        await db.query(`
          UPDATE payroll_entries SET
            present_days = $1, gross_salary_rate = $2, proportioned_salary = $3,
            special_allowance = $4, total_basic = $5, thermal_allowance = $6,
            perf_allowance_monthly = $7, perf_allowance_days = $8,
            total_earnings_before_bonus = $9, bonus = $10, employer_epf_12 = $11,
            employer_epf_1 = $12, employer_esi_325 = $13, employer_lwf = $14,
            gross_total = $15, employee_epf_12 = $16, employee_esi_075 = $17,
            employee_lwf = $18, total_employee_deductions = $19,
            total_employer_contributions = $20, combined_deductions = $21,
            net_payable = $22, bonus_percentage = $23, perf_last_drawn = $24,
            perf_as_per_circle = $25, perf_difference = $26, updated_at = CURRENT_TIMESTAMP
          WHERE id = $27 AND owner_user_id = $28;
        `, [
          r.presentDays, calc.grossSalaryRate, calc.proportionedSalary,
          calc.specialAllowance, calc.totalBasic, calc.thermalAllowance,
          calc.perfAllowanceMonthly, calc.perfAllowanceDaysWise,
          calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12,
          calc.employerEpf1, calc.employerEsi325, calc.employerLwf,
          calc.grossTotal, calc.employeeEpf12, calc.employeeEsi075,
          calc.employeeLwf, calc.totalEmployeeDeductions,
          calc.totalEmployerContributions, calc.combinedDeductions,
          calc.netPayable, calc.bonusPercentage, calc.perfLastDrawn,
          calc.perfAsPerCircle, calc.perfDifference,
          existingEntry.rows[0].id, ownerUserId
        ]);
      } else {
        await db.query(`
          INSERT INTO payroll_entries (
            owner_user_id, payroll_period_id, employee_id, present_days, gross_salary_rate, proportioned_salary,
            special_allowance, total_basic, thermal_allowance, perf_allowance_monthly, perf_allowance_days,
            total_earnings_before_bonus, bonus, employer_epf_12, employer_epf_1, employer_esi_325,
            employer_lwf, gross_total, employee_epf_12, employee_esi_075, employee_lwf,
            total_employee_deductions, total_employer_contributions, combined_deductions, net_payable,
            bonus_percentage, perf_last_drawn, perf_as_per_circle, perf_difference,
            calculation_mode
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
            $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
            $21, $22, $23, $24, $25, $26, $27, $28, $29,
            'Reference-Compatible'
          );
        `, [
          ownerUserId, periodId, empId, r.presentDays, calc.grossSalaryRate, calc.proportionedSalary,
          calc.specialAllowance, calc.totalBasic, calc.thermalAllowance, calc.perfAllowanceMonthly,
          calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12,
          calc.employerEpf1, calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
          calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions, calc.totalEmployerContributions,
          calc.combinedDeductions, calc.netPayable, calc.bonusPercentage, calc.perfLastDrawn,
          calc.perfAsPerCircle, calc.perfDifference
        ]);
      }
    }

    // 8. Audit log
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'IMPORT_EXCEL', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [userName, String(periodId), `Imported ${rows.length} records. Created: ${createdCount}, Updated: ${updatedCount}`, ownerUserId]);

    return { periodId, createdCount, updatedCount, totalRecords: rows.length };
  }

  // ==================== EMPLOYEE MASTER IMPORT & SALARY UPDATE ====================

  static async previewEmployeeMasterImport(buffer: Buffer, ownerUserId: number, requestedSheet?: string) {
    const inspectRes = this.inspectWorkbook(buffer, 'employee_master.xlsx', requestedSheet);

    // Fetch existing employees in user's workspace
    const existingRes = await db.query(
      `SELECT id, emp_code, uan, name FROM employees WHERE owner_user_id = $1;`,
      [ownerUserId]
    );
    const existingByCode = new Map<string, any>();
    const existingByUan = new Map<string, any>();
    for (const emp of existingRes.rows) {
      if (emp.emp_code) existingByCode.set(emp.emp_code.trim().toUpperCase(), emp);
      if (emp.uan) existingByUan.set(emp.uan.trim(), emp);
    }

    const previewRows: any[] = [];
    let newCount = 0;
    let existingCount = 0;
    let invalidCount = 0;
    const seenCodesInFile = new Set<string>();

    for (const r of inspectRes.previewRows) {
      const codeUpper = (r.empCode || '').trim().toUpperCase();
      const uanClean = (r.uan || '').trim();
      const existing = existingByCode.get(codeUpper) || (uanClean ? existingByUan.get(uanClean) : null);

      const isDuplicateInFile = codeUpper ? seenCodesInFile.has(codeUpper) : false;
      if (codeUpper) seenCodesInFile.add(codeUpper);

      const validationErrors: string[] = [];
      if (!r.name) validationErrors.push('Missing employee name');
      if (isDuplicateInFile) validationErrors.push('Duplicate employee code in this file');

      const isExisting = Boolean(existing);
      if (isExisting) existingCount++;
      else if (validationErrors.length === 0) newCount++;
      if (validationErrors.length > 0) invalidCount++;

      // Compute salary preview using normalized designation
      let salaryPreview: any = null;
      try {
        const dAlias = r.designationAlias || 'SW';
        salaryPreview = calculatePayroll({
          designationAlias: dAlias,
          grossSalaryRate: r.defaultGrossRate,
          specialAllowanceRate: r.defaultSpecialAllowance,
          totalDays: r.totalDays || 30,
          presentDays: r.presentDays !== undefined && r.presentDays !== null && r.presentDays > 0 ? r.presentDays : (r.totalDays || 30),
          perfAllowanceMonthly: r.perfAllowanceMonthly || 0,
          bonus: r.bonus,
          bonusPercentage: r.defaultBonusPercentage || r.bonusPercentage || 8.33,
          customEmployeeEpf: r.customEmployeeEpf,
          customEmployerEpf: r.customEmployerEpf,
          customEmployerEpf1: r.customEmployerEpf1,
          customEmployeeEsi: r.customEmployeeEsi,
          customEmployerEsi: r.customEmployerEsi,
          customEmployeeLwf: r.customEmployeeLwf,
          customEmployerLwf: r.customEmployerLwf
        });
      } catch (err: any) {
        // Fallback
      }

      previewRows.push({
        ...r,
        isExisting,
        existingId: existing ? existing.id : null,
        existingName: existing ? existing.name : null,
        isDuplicateInFile,
        validationErrors,
        salaryPreview: salaryPreview ? {
          grossSalaryRate: salaryPreview.grossSalaryRate,
          proportionedSalary: salaryPreview.proportionedSalary,
          specialAllowance: salaryPreview.specialAllowance,
          totalBasic: salaryPreview.totalBasic,
          thermalAllowance: salaryPreview.thermalAllowance,
          perfAllowanceMonthly: salaryPreview.perfAllowanceMonthly,
          bonus: salaryPreview.bonus,
          employerEpf12: salaryPreview.employerEpf12,
          employerEpf1: salaryPreview.employerEpf1,
          employerEsi325: salaryPreview.employerEsi325,
          employerLwf: salaryPreview.employerLwf,
          grossTotal: salaryPreview.grossTotal,
          employeeEpf12: salaryPreview.employeeEpf12,
          employeeEsi075: salaryPreview.employeeEsi075,
          employeeLwf: salaryPreview.employeeLwf,
          totalEmployeeDeductions: salaryPreview.totalEmployeeDeductions,
          totalEmployerContributions: salaryPreview.totalEmployerContributions,
          combinedDeductions: salaryPreview.combinedDeductions,
          netPayable: Math.round(Number(r.importedNetPayable !== undefined ? r.importedNetPayable : salaryPreview.netPayable))
        } : null
      });
    }

    return {
      fileName: inspectRes.fileName,
      sheetNames: inspectRes.sheetNames,
      selectedSheet: inspectRes.selectedSheet,
      sheetsSummary: inspectRes.sheetsSummary,
      headerRowIndex: inspectRes.headerRowIndex,
      totalRecords: inspectRes.totalRows,
      columns: inspectRes.columns,
      targetFields: inspectRes.targetFields,
      summary: inspectRes.summary,
      newCount,
      existingCount,
      invalidCount,
      previewRows
    };
  }

  static async commitEmployeeMasterImport(
    rows: any[],
    strategy: 'add_only' | 'update_only' | 'both',
    ownerUserId: number,
    userName: string
  ) {
    const desigCache = new Map<string, { id: number; alias: string; name: string }>();

    let createdCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;

    for (const r of rows) {
      if (!r.name) {
        skippedCount++;
        continue;
      }

      const codeTrim = (r.empCode || '').trim();
      const uanTrim = (r.uan || '').trim();
      let existingRes = await db.query(
        `SELECT id FROM employees WHERE (emp_code = $1 OR (uan = $2 AND uan != '')) AND owner_user_id = $3 LIMIT 1;`,
        [codeTrim, uanTrim, ownerUserId]
      );
      const isExisting = existingRes.rows.length > 0;

      if (strategy === 'add_only' && isExisting) {
        skippedCount++;
        continue;
      }
      if (strategy === 'update_only' && !isExisting) {
        skippedCount++;
        continue;
      }

      // Contractor
      let contractorId: number | null = null;
      if (r.contractorName) {
        let cleanContractor = r.contractorName.trim();
        if (/sodhi\s+erectors/i.test(cleanContractor)) cleanContractor = 'M/s Sodhi Erectors';
        const cRes = await db.query(`SELECT id FROM contractors WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`, [cleanContractor, ownerUserId]);
        if (cRes.rows.length > 0) contractorId = cRes.rows[0].id;
        else {
          const newC = await db.query(`INSERT INTO contractors (owner_user_id, name) VALUES ($1, $2) RETURNING id;`, [ownerUserId, cleanContractor]);
          contractorId = newC.rows[0].id;
        }
      }

      // Circle
      let circleId: number | null = null;
      if (r.circleName) {
        const cirRes = await db.query(`SELECT id FROM circles WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`, [r.circleName.trim(), ownerUserId]);
        if (cirRes.rows.length > 0) circleId = cirRes.rows[0].id;
        else {
          const newCir = await db.query(`INSERT INTO circles (owner_user_id, name) VALUES ($1, $2) RETURNING id;`, [ownerUserId, r.circleName.trim()]);
          circleId = newCir.rows[0].id;
        }
      }

      // Department
      let deptId: number | null = null;
      if (r.departmentName) {
        const dRes = await db.query(`SELECT id FROM departments WHERE LOWER(name) = LOWER($1) AND owner_user_id = $2;`, [r.departmentName.trim(), ownerUserId]);
        if (dRes.rows.length > 0) deptId = dRes.rows[0].id;
        else {
          const newD = await db.query(`INSERT INTO departments (owner_user_id, name, circle_id) VALUES ($1, $2, $3) RETURNING id;`, [ownerUserId, r.departmentName.trim(), circleId]);
          deptId = newD.rows[0].id;
        }
      }

      // Designation — Resolve accurately per Excel sheet without defaulting all to SW!
      const resolvedDes = await resolveDesignationId(
        r.designationAlias || r.designationName || 'SW',
        ownerUserId,
        r.defaultGrossRate,
        r.defaultSpecialAllowance,
        desigCache
      );
      const desigId = resolvedDes.id;

      // Determine standard rates if not explicitly set in the row
      let empGross = r.defaultGrossRate;
      let empSpecial = r.defaultSpecialAllowance;
      if (!empGross || !empSpecial) {
        const rateRes = await db.query(
          `SELECT gross_salary_rate, special_allowance FROM designation_salary_rates WHERE designation_id = $1 AND is_active = TRUE LIMIT 1;`,
          [desigId]
        );
        if (rateRes.rows.length > 0) {
          if (!empGross) empGross = Number(rateRes.rows[0].gross_salary_rate);
          if (!empSpecial) empSpecial = Number(rateRes.rows[0].special_allowance);
        }
      }

      if (isExisting) {
        const empId = existingRes.rows[0].id;
        await db.query(`
          UPDATE employees SET
            emp_code = COALESCE($1, emp_code),
            name = COALESCE($2, name),
            father_name = COALESCE($3, father_name),
            uan = COALESCE($4, uan),
            designation_id = $5,
            dob = COALESCE($6, dob),
            age_above_58 = COALESCE($7, age_above_58),
            date_of_joining = COALESCE($8, date_of_joining),
            date_of_exit = COALESCE($9, date_of_exit),
            mobile_number = COALESCE($10, mobile_number),
            more_than_3_yrs = COALESCE($11, more_than_3_yrs),
            more_than_5_yrs = COALESCE($12, more_than_5_yrs),
            qualification = COALESCE($13, qualification),
            experience_years = COALESCE($14, experience_years),
            qualified_status = COALESCE($15, qualified_status),
            contractor_id = COALESCE($16, contractor_id),
            circle_id = COALESCE($17, circle_id),
            department_id = COALESCE($18, department_id),
            hazard_duty = COALESCE($19, hazard_duty),
            above_60 = COALESCE($20, above_60),
            check_status = COALESCE($21, check_status),
            cell = COALESCE($22, cell),
            bank_name = COALESCE($23, bank_name),
            bank_account = COALESCE($24, bank_account),
            ifsc = COALESCE($25, ifsc),
            account_holder_name = COALESCE($26, account_holder_name),
            esi_number = COALESCE($27, esi_number),
            aadhar_number = COALESCE($28, aadhar_number),
            pan_number = COALESCE($29, pan_number),
            default_gross_rate = COALESCE($30, default_gross_rate),
            default_special_allowance = COALESCE($31, default_special_allowance),
            default_thermal_allowance = COALESCE($32, default_thermal_allowance),
            default_perf_allowance = COALESCE($33, default_perf_allowance),
            default_bonus_percentage = COALESCE($34, default_bonus_percentage),
            custom_employee_epf = COALESCE($35, custom_employee_epf),
            custom_employer_epf = COALESCE($36, custom_employer_epf),
            custom_employer_epf1 = COALESCE($37, custom_employer_epf1),
            custom_employee_esi = COALESCE($38, custom_employee_esi),
            custom_employer_esi = COALESCE($39, custom_employer_esi),
            custom_employee_lwf = COALESCE($40, custom_employee_lwf),
            custom_employer_lwf = COALESCE($41, custom_employer_lwf),
            custom_data = COALESCE($42, custom_data),
            epf_applicable = COALESCE($43, epf_applicable),
            esi_applicable = COALESCE($44, esi_applicable),
            lwf_applicable = COALESCE($45, lwf_applicable),
            is_active = TRUE,
            is_archived = FALSE,
            archived_at = NULL,
            archived_by_user_id = NULL,
            archived_reason = NULL,
            updated_by_user_id = $46,
            updated_at = CURRENT_TIMESTAMP
          WHERE id = $47 AND owner_user_id = $48;
        `, [
          r.empCode || null, r.name, r.fatherName || null, r.uan || null, desigId,
          r.dob || null, r.ageAbove58 || null, r.dateOfJoining || null, r.dateOfExit || null,
          r.mobileNumber || null, r.moreThan3Yrs || null, r.moreThan5Yrs || null,
          r.qualification || null, r.experienceYears || null, r.qualifiedStatus || null,
          contractorId, circleId, deptId,
          r.hazardDuty || null, r.above60 || null, r.checkStatus || null,
          r.cell || null, r.bankName || null, r.bankAccount || null, r.ifsc || null,
          r.accountHolderName || null, r.esiNumber || null, r.aadharNumber || null,
          r.panNumber || null, empGross || null, empSpecial || null,
          r.defaultThermalAllowance !== undefined && r.defaultThermalAllowance !== null ? Number(r.defaultThermalAllowance) : null,
          r.defaultPerfAllowance !== undefined && r.defaultPerfAllowance !== null ? Number(r.defaultPerfAllowance) : null,
          r.defaultBonusPercentage !== undefined && r.defaultBonusPercentage !== null ? Number(r.defaultBonusPercentage) : null,
          r.customEmployeeEpf !== undefined && r.customEmployeeEpf !== null ? Number(r.customEmployeeEpf) : null,
          r.customEmployerEpf !== undefined && r.customEmployerEpf !== null ? Number(r.customEmployerEpf) : null,
          r.customEmployerEpf1 !== undefined && r.customEmployerEpf1 !== null ? Number(r.customEmployerEpf1) : null,
          r.customEmployeeEsi !== undefined && r.customEmployeeEsi !== null ? Number(r.customEmployeeEsi) : null,
          r.customEmployerEsi !== undefined && r.customEmployerEsi !== null ? Number(r.customEmployerEsi) : null,
          r.customEmployeeLwf !== undefined && r.customEmployeeLwf !== null ? Number(r.customEmployeeLwf) : null,
          r.customEmployerLwf !== undefined && r.customEmployerLwf !== null ? Number(r.customEmployerLwf) : null,
          r.customData && Object.keys(r.customData).length > 0 ? JSON.stringify(r.customData) : null,
          r.epfApplicable !== undefined ? Boolean(r.epfApplicable) : null,
          r.esiApplicable !== undefined ? Boolean(r.esiApplicable) : null,
          r.lwfApplicable !== undefined ? Boolean(r.lwfApplicable) : null,
          ownerUserId, empId, ownerUserId
        ]);
        updatedCount++;
      } else {
        await db.query(`
          INSERT INTO employees (
            owner_user_id, created_by_user_id, emp_code, sr_no, name, father_name, uan, designation_id, dob, age_above_58,
            date_of_joining, date_of_exit, mobile_number, more_than_3_yrs, more_than_5_yrs, qualification, experience_years,
            qualified_status, contractor_id, circle_id, department_id, hazard_duty, above_60,
            check_status, cell, bank_name, bank_account, ifsc, account_holder_name, esi_number, aadhar_number, pan_number,
            default_gross_rate, default_special_allowance, default_thermal_allowance, default_perf_allowance, default_bonus_percentage,
            custom_employee_epf, custom_employer_epf, custom_employer_epf1, custom_employee_esi, custom_employer_esi, custom_employee_lwf, custom_employer_lwf,
            custom_data, epf_applicable, esi_applicable, lwf_applicable, is_active
          ) VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
            $11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
            $21,$22,$23,$24,$25,$26,$27,$28,$29,$30,
            $31,$32,$33,$34,$35,$36,$37,$38,$39,$40,
            $41,$42,$43,$44,$45,$46,$47,$48,TRUE
          );
        `, [
          ownerUserId, ownerUserId, codeTrim || `EMP-${Math.floor(100 + Math.random() * 900)}`,
          r.srNo || '', r.name, r.fatherName || '', r.uan || '', desigId,
          r.dob || '', r.ageAbove58 || 'N', r.dateOfJoining || '', r.dateOfExit || '',
          r.mobileNumber || '', r.moreThan3Yrs || 'NO', r.moreThan5Yrs || 'NO',
          r.qualification || '', r.experienceYears || '', r.qualifiedStatus || '',
          contractorId, circleId, deptId, r.hazardDuty || '', r.above60 || '',
          r.checkStatus || '', r.cell || '', r.bankName || '', r.bankAccount || '', r.ifsc || '',
          r.accountHolderName || '', r.esiNumber || '', r.aadharNumber || '', r.panNumber || '',
          empGross || null, empSpecial || null,
          r.defaultThermalAllowance !== undefined && r.defaultThermalAllowance !== null ? Number(r.defaultThermalAllowance) : 1500,
          r.defaultPerfAllowance !== undefined && r.defaultPerfAllowance !== null ? Number(r.defaultPerfAllowance) : 0,
          r.defaultBonusPercentage !== undefined && r.defaultBonusPercentage !== null ? Number(r.defaultBonusPercentage) : 8.33,
          r.customEmployeeEpf !== undefined && r.customEmployeeEpf !== null ? Number(r.customEmployeeEpf) : null,
          r.customEmployerEpf !== undefined && r.customEmployerEpf !== null ? Number(r.customEmployerEpf) : null,
          r.customEmployerEpf1 !== undefined && r.customEmployerEpf1 !== null ? Number(r.customEmployerEpf1) : null,
          r.customEmployeeEsi !== undefined && r.customEmployeeEsi !== null ? Number(r.customEmployeeEsi) : null,
          r.customEmployerEsi !== undefined && r.customEmployerEsi !== null ? Number(r.customEmployerEsi) : null,
          r.customEmployeeLwf !== undefined && r.customEmployeeLwf !== null ? Number(r.customEmployeeLwf) : null,
          r.customEmployerLwf !== undefined && r.customEmployerLwf !== null ? Number(r.customEmployerLwf) : null,
          r.customData && Object.keys(r.customData).length > 0 ? JSON.stringify(r.customData) : '{}',
          r.epfApplicable !== false, r.esiApplicable !== false, r.lwfApplicable !== false
        ]);
        createdCount++;
      }
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'IMPORT_EMPLOYEE_MASTER', 'EMPLOYEE', 'BATCH', $2, $3);
    `, [userName, `Imported employee master. Created: ${createdCount}, Updated: ${updatedCount}, Skipped: ${skippedCount}`, ownerUserId]);

    // Automatically synchronize open payroll periods with newly imported employees
    let syncRes = null;
    try {
      syncRes = await syncEmployeesWithOpenPayrollPeriods(ownerUserId);
    } catch (e) {
      console.error('Auto-sync payroll periods on employee import error:', e);
    }

    return {
      createdCount,
      updatedCount,
      skippedCount,
      totalProcessed: rows.length,
      synchronizedPayrollPeriods: syncRes ? syncRes.periodsSynced : 0,
      synchronizedPayrollAdded: syncRes ? syncRes.totalAdded : 0,
      synchronizedPayrollUpdated: syncRes ? syncRes.totalUpdated : 0
    };
  }

  static async previewSalaryUpdateImport(buffer: Buffer, ownerUserId: number, requestedSheet?: string) {
    const workbook = XLSX.read(buffer, { type: 'buffer', cellFormula: true });
    const sheetNames = workbook.SheetNames;
    const selectedSheet = requestedSheet && sheetNames.includes(requestedSheet)
      ? requestedSheet
      : (sheetNames.find(s => s.toLowerCase().includes('salary')) || sheetNames[0]);
    const sheet = workbook.Sheets[selectedSheet];
    if (!sheet || !sheet['!ref']) throw new Error('Sheet is empty or has no data range');

    const range = XLSX.utils.decode_range(sheet['!ref']);
    const getVal = (r: number, c: number) => {
      const cell = sheet[XLSX.utils.encode_cell({ r, c })];
      return cell ? cell.v : null;
    };
    const cleanStr = (val: any) => (val !== null && val !== undefined ? String(val).trim() : '');
    const cleanNum = (val: any) => {
      if (val === null || val === undefined) return null;
      const num = Number(val);
      return isNaN(num) ? null : num;
    };

    let headerRow = 0;
    const colMap: Record<string, number> = {};
    for (let r = 0; r <= Math.min(5, range.e.r); r++) {
      for (let c = 0; c <= range.e.c; c++) {
        const text = cleanStr(getVal(r, c)).toLowerCase();
        if (text.includes('emp code') || text === 'code') colMap['empCode'] = c;
        if (text.includes('uan')) colMap['uan'] = c;
        if (text.includes('gross') || text.includes('wage rate')) colMap['grossRate'] = c;
        if (text.includes('special')) colMap['specialAllowance'] = c;
        if (text.includes('thermal')) colMap['thermalAllowance'] = c;
        if (text.includes('performance') || text.includes('perf')) colMap['perfAllowance'] = c;
        if (text.includes('bonus')) colMap['bonusPercentage'] = c;
      }
      if (colMap['empCode'] !== undefined || colMap['uan'] !== undefined) {
        headerRow = r;
        break;
      }
    }

    const userRoleRes = await db.query(`SELECT role FROM users WHERE id = $1`, [ownerUserId]);
    const isSuper = userRoleRes.rows[0]?.role === 'SUPER_ADMIN';

    let empSql = `
      SELECT e.*, d.alias as designation_alias, dsr.gross_salary_rate, dsr.special_allowance
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE e.is_active = TRUE AND e.archived_at IS NULL AND COALESCE(e.is_archived, FALSE) = FALSE
    `;
    const empParams: any[] = [];
    if (!isSuper) {
      empSql += ` AND (e.owner_user_id = $1 OR e.created_by_user_id = $1)`;
      empParams.push(ownerUserId);
    }
    empSql += `;`;

    const empRes = await db.query(empSql, empParams);

    const empByCode = new Map<string, any>();
    const empByUan = new Map<string, any>();
    for (const emp of empRes.rows) {
      if (emp.emp_code) empByCode.set(emp.emp_code.trim().toUpperCase(), emp);
      if (emp.uan) empByUan.set(emp.uan.trim(), emp);
    }

    const matchedRows: any[] = [];
    const unmatchedRows: any[] = [];

    for (let r = headerRow + 1; r <= range.e.r; r++) {
      const code = colMap['empCode'] !== undefined ? cleanStr(getVal(r, colMap['empCode'])) : '';
      const uan = colMap['uan'] !== undefined ? cleanStr(getVal(r, colMap['uan'])) : '';
      if (!code && !uan) continue;

      const emp = empByCode.get(code.toUpperCase()) || (uan ? empByUan.get(uan) : null);
      if (!emp) {
        unmatchedRows.push({ row: r + 1, empCode: code, uan, error: 'Employee not found in workspace' });
        continue;
      }

      const newGross = colMap['grossRate'] !== undefined ? cleanNum(getVal(r, colMap['grossRate'])) : null;
      const newSpecial = colMap['specialAllowance'] !== undefined ? cleanNum(getVal(r, colMap['specialAllowance'])) : null;
      const newThermal = colMap['thermalAllowance'] !== undefined ? cleanNum(getVal(r, colMap['thermalAllowance'])) : null;
      const newPerf = colMap['perfAllowance'] !== undefined ? cleanNum(getVal(r, colMap['perfAllowance'])) : null;
      const newBonus = colMap['bonusPercentage'] !== undefined ? cleanNum(getVal(r, colMap['bonusPercentage'])) : null;

      const currentGross = Number(emp.default_gross_rate || emp.gross_salary_rate || 16530);
      const currentSpecial = Number(emp.default_special_allowance || emp.special_allowance || 3802);
      const currentThermal = Number(emp.default_thermal_allowance || 1500);
      const currentPerf = Number(emp.default_perf_allowance || 0);
      const currentBonusPct = Number(emp.default_bonus_percentage || 8.33);

      const oldCalc = calculatePayroll({
        designationAlias: emp.designation_alias || 'SW',
        grossSalaryRate: currentGross,
        specialAllowanceRate: currentSpecial,
        customThermalAllowance: currentThermal,
        perfAllowanceMonthly: currentPerf,
        bonusPercentage: currentBonusPct,
        totalDays: 30,
        presentDays: 30
      });

      const updatedGross = newGross !== null ? newGross : currentGross;
      const updatedSpecial = newSpecial !== null ? newSpecial : currentSpecial;
      const updatedThermal = newThermal !== null ? newThermal : currentThermal;
      const updatedPerf = newPerf !== null ? newPerf : currentPerf;
      const updatedBonusPct = newBonus !== null ? newBonus : currentBonusPct;

      const newCalc = calculatePayroll({
        designationAlias: emp.designation_alias || 'SW',
        grossSalaryRate: updatedGross,
        specialAllowanceRate: updatedSpecial,
        customThermalAllowance: updatedThermal,
        perfAllowanceMonthly: updatedPerf,
        bonusPercentage: updatedBonusPct,
        totalDays: 30,
        presentDays: 30
      });

      matchedRows.push({
        employeeId: emp.id,
        empCode: emp.emp_code,
        name: emp.name,
        designationAlias: emp.designation_alias || 'SW',
        oldGross: currentGross,
        newGross: updatedGross,
        oldSpecial: currentSpecial,
        newSpecial: updatedSpecial,
        oldThermal: currentThermal,
        newThermal: updatedThermal,
        oldPerf: currentPerf,
        newPerf: updatedPerf,
        oldBonusPercentage: currentBonusPct,
        newBonusPercentage: updatedBonusPct,
        oldNetPayable: Math.round(oldCalc.netPayable),
        newNetPayable: Math.round(newCalc.netPayable),
        netDifference: Math.round(newCalc.netPayable) - Math.round(oldCalc.netPayable)
      });
    }

    return {
      sheetNames,
      selectedSheet,
      totalRows: matchedRows.length + unmatchedRows.length,
      matchedCount: matchedRows.length,
      unmatchedCount: unmatchedRows.length,
      matchedRows,
      unmatchedRows
    };
  }

  static async commitSalaryUpdateImport(rows: any[], ownerUserId: number, userName: string) {
    const userRoleRes = await db.query(`SELECT role FROM users WHERE id = $1`, [ownerUserId]);
    const isSuper = userRoleRes.rows[0]?.role === 'SUPER_ADMIN';

    let updatedCount = 0;
    for (const r of rows) {
      if (!r.employeeId) continue;
      let updateSql = `
        UPDATE employees SET
          default_gross_rate = COALESCE($1, default_gross_rate),
          default_special_allowance = COALESCE($2, default_special_allowance),
          default_thermal_allowance = COALESCE($3, default_thermal_allowance),
          default_perf_allowance = COALESCE($4, default_perf_allowance),
          default_bonus_percentage = COALESCE($5, default_bonus_percentage),
          updated_by_user_id = $6,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $7
      `;
      const params: any[] = [
        r.newGross !== undefined ? Number(r.newGross) : null,
        r.newSpecial !== undefined ? Number(r.newSpecial) : null,
        r.newThermal !== undefined ? Number(r.newThermal) : null,
        r.newPerf !== undefined ? Number(r.newPerf) : null,
        r.newBonusPercentage !== undefined ? Number(r.newBonusPercentage) : null,
        ownerUserId, Number(r.employeeId)
      ];
      if (!isSuper) {
        updateSql += ` AND (owner_user_id = $8 OR created_by_user_id = $8);`;
        params.push(ownerUserId);
      } else {
        updateSql += `;`;
      }
      await db.query(updateSql, params);
      updatedCount++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BULK_SALARY_EXCEL_UPDATE', 'EMPLOYEE_SALARY', 'BATCH', $2, $3);
    `, [userName, `Updated default salary rates for ${updatedCount} employees via Excel`, ownerUserId]);

    // Automatically synchronize open payroll periods with updated salary rates
    let syncRes = null;
    try {
      syncRes = await syncEmployeesWithOpenPayrollPeriods(ownerUserId);
    } catch (e) {
      console.error('Auto-sync payroll periods on salary import error:', e);
    }

    return {
      updatedCount,
      totalProcessed: rows.length,
      synchronizedPayrollPeriods: syncRes ? syncRes.periodsSynced : 0,
      synchronizedPayrollUpdated: syncRes ? syncRes.totalUpdated : 0
    };
  }

  static generateTemplateWorkbook(): ExcelJS.Workbook {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'GGSSTP Payroll System';
    workbook.created = new Date();

    // SHEET 1: Employee Master Import Template
    const ws1 = workbook.addWorksheet('Employee Master Template');
    ws1.views = [{ showGridLines: true }];

    ws1.mergeCells('A1:AB1');
    ws1.getCell('A1').value = 'GURU GOBIND SINGH SUPER THERMAL PLANT, RUPNAGAR — EMPLOYEE MASTER IMPORT TEMPLATE';
    ws1.getCell('A1').font = { bold: true, size: 12, color: { argb: 'FFFFFFFF' } };
    ws1.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A8A' } };
    ws1.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
    ws1.getRow(1).height = 28;

    const headers1 = [
      'Emp Code', 'Employee Name', "Father's Name", 'UAN NO.', 'Designation',
      'DOB DD-MM-YYYY', 'Age above 58 yrs', 'Date of Joining', 'more than 3', 'more than 5',
      'Qualification', 'Total Experience in Year', 'Wether Qualified or not (Yes / No)', 'Name of the service provider',
      'Circle', 'CELL', 'haz', 'above 60', 'BANK', 'IFSC', 'ESI', 'Gross Salary Rate', 'Proportioned Salary', 'Special Allowance',
      'Thermal Allowance', 'Monthly Perf Allowance', 'Bonus %', 'Status'
    ];
    ws1.getRow(2).values = headers1;
    ws1.getRow(2).height = 25;
    ws1.getRow(2).eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1D4ED8' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
    });

    // Sample Row 1 (Skilled Worker)
    ws1.addRow([
      'EMP-101', 'SIMRANJEET SINGH', 'RANJIT SINGH', '100364468209', 'SW',
      '14-11-1989', 'N', '01.03.2011', 'YES', 'YES',
      '10th, Diploma (Elect.)', '15', 'Yes', 'M/s Sodhi Erectors',
      'EMC CIRCLE', 'EM-1', 'haz', 'N', '55150355883', 'SBIN0050302', '2613380444', 16530,
      { formula: 'ROUND((V3/30)*30, 0)', result: 16530 }, 3802,
      1500, 225, 8.33, 'Active'
    ]);

    // Sample Row 2 (Unskilled Worker)
    ws1.addRow([
      'EMP-110', 'BALJEET SINGH', 'HARVINDER SINGH', '101686027701', 'USW',
      '14-12-2002', 'N', '01.10.2022', 'YES', 'YES',
      '10TH', '4', 'Yes', 'M/s Sodhi Erectors',
      'EMC CIRCLE', 'EM-1', 'haz', 'N', '65080391631', 'SBIN0050302', '1215857173', 14408,
      { formula: 'ROUND((V4/30)*30, 0)', result: 14408 }, 3314,
      1500, 0, 8.33, 'Active'
    ]);

    ws1.columns = [
      { width: 14 }, { width: 24 }, { width: 22 }, { width: 18 }, { width: 14 },
      { width: 16 }, { width: 16 }, { width: 16 }, { width: 14 }, { width: 14 },
      { width: 22 }, { width: 22 }, { width: 28 }, { width: 26 },
      { width: 18 }, { width: 12 }, { width: 10 }, { width: 12 }, { width: 20 }, { width: 15 }, { width: 16 },
      { width: 18 }, { width: 20 }, { width: 18 }, { width: 18 }, { width: 22 }, { width: 12 }, { width: 12 }
    ];

    // SHEET 2: Salary Rates Update Template
    const ws2 = workbook.addWorksheet('Salary Rates Template');
    ws2.views = [{ showGridLines: true }];

    ws2.mergeCells('A1:G1');
    ws2.getCell('A1').value = 'GURU GOBIND SINGH SUPER THERMAL PLANT, RUPNAGAR — SALARY RATES UPDATE TEMPLATE';
    ws2.getCell('A1').font = { bold: true, size: 12, color: { argb: 'FFFFFFFF' } };
    ws2.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF059669' } };
    ws2.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
    ws2.getRow(1).height = 28;

    const headers2 = ['Emp Code', 'UAN', 'Employee Name', 'Gross Salary Rate', 'Special Allowance', 'Thermal Allowance', 'Monthly Perf Allowance', 'Bonus %'];
    ws2.getRow(2).values = headers2;
    ws2.getRow(2).height = 25;
    ws2.getRow(2).eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF047857' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
    });

    ws2.addRow(['EMP-101', '100364468209', 'SIMRANJEET SINGH', 16530, 3802, 1500, 225, 8.33]);
    ws2.addRow(['EMP-110', '101686027701', 'BALJEET SINGH', 14408, 3314, 1500, 0, 8.33]);

    ws2.columns = [
      { width: 14 }, { width: 18 }, { width: 24 }, { width: 18 }, { width: 18 }, { width: 18 }, { width: 22 }, { width: 12 }
    ];

    return workbook;
  }
}
