import { AuthenticatedUser } from './authMiddleware';

/**
 * Checks if user has Super Administrator role.
 * Handles role variants: 'SUPER_ADMIN', 'Super Administrator', etc.
 */
export function isSuperAdmin(user?: AuthenticatedUser | { role?: string } | null): boolean {
  if (!user || !user.role) return false;
  const r = user.role.trim().toUpperCase().replace(/\s+/g, '_');
  return r === 'SUPER_ADMIN' || r === 'SUPER_ADMINISTRATOR';
}

/**
 * Checks if user has Payroll Administrator role.
 * Handles role variants: 'PAYROLL_ADMIN', 'Payroll Administrator', etc.
 */
export function isPayrollAdmin(user?: AuthenticatedUser | { role?: string } | null): boolean {
  if (!user || !user.role) return false;
  const r = user.role.trim().toUpperCase().replace(/\s+/g, '_');
  return r === 'PAYROLL_ADMIN' || r === 'PAYROLL_ADMINISTRATOR';
}
