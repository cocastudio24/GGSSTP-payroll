export interface CalculationInput {
  designationAlias: string;
  grossSalaryRate?: number;
  specialAllowanceRate?: number;
  totalDays: number;
  presentDays: number;
  perfAllowanceMonthly?: number;
  bonus?: number | null | string;
  bonusPercentage?: number | null | string; // Default 8.33% of basic
  customBonus?: number | null | string;     // Explicit manual override
  perfLastDrawn?: number;   // Last Drawn Performance Allowance (for EMC comparison)
  perfAsPerCircle?: number; // Performance Allowance as per Circle (for EMC comparison)
  isPerfRounded?: boolean; // For MM-1 rows 17-22 compatibility
  mode?: 'Reference-Compatible' | 'Configurable';
  ruleSet?: {
    epfWageCap?: number;
    epfEmployerRate?: number;
    epfMaxCap?: number;
    epfAdminRate?: number;
    epfAdminMaxCap?: number;
    epfEmployeeRate?: number;
    esiThreshold?: number;
    esiEmployerRate?: number;
    esiEmployeeRate?: number;
    employerLwf?: number;
    employeeLwf?: number;
    thermalAllowanceBase?: number;
    bonusPercentage?: number;
  };
  customThermalAllowance?: number;
  customEmployeeEpf?: number | null | string;
  customEmployeeEsi?: number | null | string;
  customEmployeeLwf?: number | null | string;
  customEmployerEpf?: number | null | string;
  customEmployerEpf1?: number | null | string;
  customEmployerEsi?: number | null | string;
  customEmployerLwf?: number | null | string;
  roundNetPayable?: boolean; // Default true: round to nearest whole rupee with 50+ paise rounded up
  roundingMode?: 'round_50_up' | 'exact' | 'floor' | 'ceil'; // Configurable rounding rule
}

export interface CalculationResult {
  grossSalaryRate: number;
  proportionedSalary: number;
  specialAllowance: number;
  totalBasic: number;
  thermalAllowance: number;
  perfAllowanceMonthly: number;
  perfAllowanceDaysWise: number;
  totalEarningsBeforeBonus: number;
  bonus: number;
  bonusPercentage: number;
  employerEpf12: number;
  employerEpf1: number;
  employerEsi325: number;
  employerLwf: number;
  grossTotal: number;
  employeeEpf12: number;
  employeeEsi075: number;
  employeeLwf: number;
  totalEmployeeDeductions: number;
  totalEmployerContributions: number;
  combinedDeductions: number;
  netPayable: number;
  unroundedNetPayable?: number;
  roundingMode?: 'round_50_up' | 'exact' | 'floor' | 'ceil';
  totalEmployerCost: number;
  // Performance allowance comparison
  perfLastDrawn: number;
  perfAsPerCircle: number;
  perfDifference: number;
  // Audit metrics
  employeeCashEarnings: number;
  employeeOnlyDeductions: number;
  statutoryNetPayable: number;
  auditDiscrepancy: number;
  warnings?: string[];
  formulas: {
    proportionedSalary: string;
    totalBasic: string;
    thermalAllowance: string;
    perfAllowanceDaysWise: string;
    totalEarningsBeforeBonus: string;
    bonus: string;
    employerEpf12: string;
    employerEpf1: string;
    employerEsi325: string;
    grossTotal: string;
    employeeEpf12: string;
    employeeEsi075: string;
    totalEmployeeDeductions: string;
    combinedDeductions: string;
    netPayable: string;
    perfDifference: string;
  };
}

export const INITIAL_RATES: Record<string, { gross: number; special: number }> = {
  'USW': { gross: 14408, special: 3314 },
  'SEMI SW': { gross: 15395, special: 3541 },
  'SW': { gross: 16530, special: 3802 },
  'HSW': { gross: 17835, special: 4102 }
};

export function calculatePayroll(input: CalculationInput): CalculationResult {
  const mode = input.mode || 'Reference-Compatible';
  const totalDays = Number(input.totalDays) || 0;
  const presentDays = Number(input.presentDays) || 0;

  // Safe check
  if (totalDays <= 0 || presentDays < 0) {
    throw new Error('Total calendar/payroll days must be greater than zero, and present days cannot be negative.');
  }

  // Designation wage rates
  const aliasNorm = (input.designationAlias || '').trim().toUpperCase();
  const defaultRate = INITIAL_RATES[aliasNorm] || { gross: 0, special: 0 };
  const warnings: string[] = [];

  if (!INITIAL_RATES[aliasNorm] && (input.grossSalaryRate === undefined || input.grossSalaryRate === null)) {
    warnings.push(`Designation rate not found for "${input.designationAlias}". Using 0 gross rate.`);
  }

  const grossSalaryRate = input.grossSalaryRate !== undefined && input.grossSalaryRate !== null
    ? Number(input.grossSalaryRate)
    : defaultRate.gross;

  const specialAllowance = input.specialAllowanceRate !== undefined && input.specialAllowanceRate !== null
    ? Number(input.specialAllowanceRate)
    : defaultRate.special;

  const thermalBase = input.ruleSet?.thermalAllowanceBase ?? 1500;
  const perfMonthly = Number(input.perfAllowanceMonthly) || 0;

  // 1. Proportioned Basic Pay = Gross Salary Rate / Total Days * Present Days
  // Equivalent to Excel: =AE3/AC3*AD3 (or =AB2/Z2*AA2)
  const proportionedSalary = (grossSalaryRate / totalDays) * presentDays;

  // 2. Total Basic = ROUND((Gross Salary + Special Allowance) * Present Days / Total Days, 0)
  // Equivalent to Excel: =ROUND((AE3+AG3)*AD3/AC3, 0) (or =ROUND((AB2+AD2)*AA2/Z2, 0))
  const totalBasic = Math.round(((grossSalaryRate + specialAllowance) * presentDays) / totalDays);

  // 3. Thermal Allowance = ROUND(ThermalBase * Present Days / Total Days, 0)
  // Equivalent to Excel: =ROUND(1500*AD3/AC3, 0) (or =ROUND(1500*AA2/Z2, 0))
  const thermalAllowance = input.customThermalAllowance !== undefined && input.customThermalAllowance !== null
    ? Number(input.customThermalAllowance)
    : Math.round((thermalBase * presentDays) / totalDays);

  // 4. Performance Allowance Days wise = Monthly / Total Days * Present Days
  // Equivalent to Excel: =AJ3/AC3*AD3 (or =$AG2/Z2*AA2)
  let perfAllowanceDaysWise = (perfMonthly / totalDays) * presentDays;
  if (input.isPerfRounded) {
    perfAllowanceDaysWise = Math.round(perfAllowanceDaysWise);
  }

  // 5. Total (Earnings before bonus) = Total Basic + Thermal + Performance Days wise
  // Equivalent to Excel: =AH3+AI3+AK3 (or =AE2+AF2+AH2)
  const totalEarningsBeforeBonus = totalBasic + thermalAllowance + perfAllowanceDaysWise;

  // 6. Bonus calculation: Default 8.33% of Basic Salary
  // Formula: Bonus = ROUND(Basic Salary * Bonus Percentage / 100, 0)
  const bonusPercentage = input.bonusPercentage !== undefined
    ? (input.bonusPercentage === null || input.bonusPercentage === '' ? 0 : Number(input.bonusPercentage))
    : (input.ruleSet?.bonusPercentage ?? 8.33);

  let bonus: number;
  if (input.customBonus !== undefined && input.customBonus !== null && input.customBonus !== '') {
    bonus = Number(input.customBonus);
  } else if (input.bonus !== undefined && input.bonus !== null && input.bonus !== '') {
    bonus = Number(input.bonus);
  } else {
    bonus = Math.round((totalBasic * bonusPercentage) / 100);
  }

  // Rules
  const epfWageCap = input.ruleSet?.epfWageCap ?? 25000;
  const epfEmployerRate = input.ruleSet?.epfEmployerRate ?? 0.12;
  const epfMaxCap = input.ruleSet?.epfMaxCap ?? 3000;
  const epfAdminRate = input.ruleSet?.epfAdminRate ?? 0.01;
  const epfAdminMaxCap = input.ruleSet?.epfAdminMaxCap ?? 250;
  const epfEmployeeRate = input.ruleSet?.epfEmployeeRate ?? epfEmployerRate;

  const esiThreshold = input.ruleSet?.esiThreshold ?? 21000;
  const esiEmployerRate = input.ruleSet?.esiEmployerRate ?? 0.0325;
  const esiEmployeeRate = input.ruleSet?.esiEmployeeRate ?? 0.0075;

  const defaultEmployerLwf = input.ruleSet?.employerLwf ?? 20;
  const defaultEmployeeLwf = input.ruleSet?.employeeLwf ?? 5;

  // 7. Employer EPF 12% = ROUND(IF(ProportionedSalary < 25000, ProportionedSalary * 0.12, 3000), 0)
  // Equivalent to Excel: =ROUND(IF(AF3<25000, (AF3*0.12), (3000)), 0)
  const employerEpf12 = input.customEmployerEpf !== undefined
    ? (input.customEmployerEpf === null || input.customEmployerEpf === '' ? 0 : Number(input.customEmployerEpf))
    : Math.round(proportionedSalary < epfWageCap ? proportionedSalary * epfEmployerRate : epfMaxCap);

  // 8. Employer EPF 1% = ROUND(IF(ProportionedSalary < 25000, ProportionedSalary * 0.01, 250), 0)
  // Equivalent to Excel: =ROUND(IF(AF3<25000, (AF3*0.01), (250)), 0)
  const employerEpf1 = input.customEmployerEpf1 !== undefined
    ? (input.customEmployerEpf1 === null || input.customEmployerEpf1 === '' ? 0 : Number(input.customEmployerEpf1))
    : Math.round(proportionedSalary < epfWageCap ? proportionedSalary * epfAdminRate : epfAdminMaxCap);

  // 9. Employer ESI 3.25% = ROUND(IF(TotalEarnings < 21000, TotalEarnings * 0.0325, 0), 0)
  // Equivalent to Excel: =ROUND(IF(AL3<21000, (AL3*0.0325), (0)), 0)
  const employerEsi325 = input.customEmployerEsi !== undefined
    ? (input.customEmployerEsi === null || input.customEmployerEsi === '' ? 0 : Number(input.customEmployerEsi))
    : Math.round(totalEarningsBeforeBonus < esiThreshold ? totalEarningsBeforeBonus * esiEmployerRate : 0);

  // 10. Employer LWF
  const employerLwf = input.customEmployerLwf !== undefined
    ? (input.customEmployerLwf === null || input.customEmployerLwf === '' ? 0 : Number(input.customEmployerLwf))
    : defaultEmployerLwf;

  // 11. Gross Total (Source formula = SUM(EarningsBeforeBonus + Bonus + all 4 Employer Contributions))
  // Equivalent to Excel: =SUM(AL3:AQ3) (or =SUM(AI2:AN2))
  const grossTotal = totalEarningsBeforeBonus + bonus + employerEpf12 + employerEpf1 + employerEsi325 + employerLwf;

  // 12. Employee EPF 12% = Employer EPF Share
  // Equivalent to Excel: =AN3 (or =AK2)
  const employeeEpf12 = input.customEmployeeEpf !== undefined
    ? (input.customEmployeeEpf === null || input.customEmployeeEpf === '' ? 0 : Number(input.customEmployeeEpf))
    : (input.ruleSet?.epfEmployeeRate
        ? Math.round(proportionedSalary < epfWageCap ? proportionedSalary * epfEmployeeRate : epfMaxCap)
        : employerEpf12);

  // 13. Employee ESI 0.75% = ROUND(IF(TotalEarnings < 21000, TotalEarnings * 0.0075, 0), 0)
  // Equivalent to Excel: =ROUND(IF(AL3<21000, (AL3*0.0075), (0)), 0)
  const employeeEsi075 = input.customEmployeeEsi !== undefined
    ? (input.customEmployeeEsi === null || input.customEmployeeEsi === '' ? 0 : Number(input.customEmployeeEsi))
    : Math.round(totalEarningsBeforeBonus < esiThreshold ? totalEarningsBeforeBonus * esiEmployeeRate : 0);

  // 14. Employee LWF (₹5)
  const employeeLwf = input.customEmployeeLwf !== undefined
    ? (input.customEmployeeLwf === null || input.customEmployeeLwf === '' ? 0 : Number(input.customEmployeeLwf))
    : defaultEmployeeLwf;

  // 15. Employee Total Deductions = Employee EPF + Employee ESI + Employee LWF
  // Equivalent to Excel: =AS3+AT3+AU3 (or =AP2+AQ2+AR2)
  const totalEmployeeDeductions = employeeEpf12 + employeeEsi075 + employeeLwf;

  // 16. Employer Contributions Subtotal = Employer EPF 12% + EPF 1% + ESI 3.25% + Employer LWF
  // Equivalent to Excel: =AN3+AO3+AP3+AQ3 (or =AK2+AL2+AM2+AN2)
  const totalEmployerContributions = employerEpf12 + employerEpf1 + employerEsi325 + employerLwf;

  // 17. Combined Deductions (Col AU/AX in Excel) = Employee Deductions + Employer Contributions
  // Equivalent to Excel: =AV3+AW3 (or =AS2+AT2)
  const combinedDeductions = totalEmployeeDeductions + totalEmployerContributions;

  // 18. FINAL NET PAYABLE SALARY = Gross Total - Combined Deductions
  // Equivalent to Excel: =ROUND(AR3-AX3, 0) (or =ROUND(AO2-AU2, 0))
  // Configurable rounding mode:
  // - 'round_50_up': standard rounded off to nearest whole rupee, with 50 paise (.50) or above rounding up
  // - 'exact': preserves exact decimal paise as calculated in Excel (e.g. ₹4,639.50)
  // - 'floor': rounds down to whole rupee
  // - 'ceil': rounds up to whole rupee
  const unroundedNetPayable = grossTotal - combinedDeductions;
  const activeRoundingMode: 'round_50_up' | 'exact' | 'floor' | 'ceil' = 
    input.roundingMode || (input.roundNetPayable === false ? 'exact' : 'round_50_up');

  let netPayable: number;
  if (activeRoundingMode === 'exact') {
    netPayable = Number(unroundedNetPayable.toFixed(2));
  } else if (activeRoundingMode === 'floor') {
    netPayable = Math.floor(unroundedNetPayable);
  } else if (activeRoundingMode === 'ceil') {
    netPayable = Math.ceil(unroundedNetPayable);
  } else {
    netPayable = Math.round(unroundedNetPayable);
  }

  // Performance Allowance Comparison (EMC audit columns)
  // Formula: Difference = Last Drawn Performance Allowance - Performance Allowance as per Circle (=AZ3-BA3)
  const perfLastDrawn = Number(input.perfLastDrawn) || 0;
  const perfAsPerCircle = Number(input.perfAsPerCircle) || 0;
  const perfDifference = perfLastDrawn - perfAsPerCircle;

  // Audit Metrics (Separating employee cash earnings and deductions for validation)
  const employeeCashEarnings = totalEarningsBeforeBonus + bonus;
  const employeeOnlyDeductions = totalEmployeeDeductions;
  let statutoryNetPayable: number;
  const unroundedStatutory = employeeCashEarnings - employeeOnlyDeductions;
  if (activeRoundingMode === 'exact') {
    statutoryNetPayable = Number(unroundedStatutory.toFixed(2));
  } else if (activeRoundingMode === 'floor') {
    statutoryNetPayable = Math.floor(unroundedStatutory);
  } else if (activeRoundingMode === 'ceil') {
    statutoryNetPayable = Math.ceil(unroundedStatutory);
  } else {
    statutoryNetPayable = Math.round(unroundedStatutory);
  }
  const auditDiscrepancy = Math.abs(netPayable - statutoryNetPayable) < 0.0001 ? 0 : Number((netPayable - statutoryNetPayable).toFixed(2));

  // Total Employer Cost to Company (CTC) = Total Employee Earnings + Bonus + Employer Contributions
  const totalEmployerCost = totalEarningsBeforeBonus + bonus + totalEmployerContributions;

  return {
    grossSalaryRate,
    proportionedSalary,
    specialAllowance,
    totalBasic,
    thermalAllowance,
    perfAllowanceMonthly: perfMonthly,
    perfAllowanceDaysWise,
    totalEarningsBeforeBonus,
    bonus,
    bonusPercentage,
    employerEpf12,
    employerEpf1,
    employerEsi325,
    employerLwf,
    grossTotal,
    employeeEpf12,
    employeeEsi075,
    employeeLwf,
    totalEmployeeDeductions,
    totalEmployerContributions,
    combinedDeductions,
    netPayable,
    unroundedNetPayable,
    roundingMode: activeRoundingMode,
    totalEmployerCost,
    perfLastDrawn,
    perfAsPerCircle,
    perfDifference,
    employeeCashEarnings,
    employeeOnlyDeductions,
    statutoryNetPayable,
    auditDiscrepancy,
    warnings: warnings.length > 0 ? warnings : undefined,
    formulas: {
      proportionedSalary: `ROUND((GrossSalaryRate / TotalDays) * PresentDays, 0) [Excel MM-1 Col P: =(O3/M3)*N3, EMC Col AD: =AB3/Z3*AA3]`,
      totalBasic: `ROUND((GrossSalaryRate + SpecialAllowance) * PresentDays / TotalDays, 0)`,
      thermalAllowance: `ROUND(${thermalBase} * PresentDays / TotalDays, 0)`,
      perfAllowanceDaysWise: `PerfMonthly / TotalDays * PresentDays`,
      totalEarningsBeforeBonus: `TotalBasic + ThermalAllowance + ProratedPerfAllowance`,
      bonus: `ROUND(TotalBasic * ${bonusPercentage} / 100, 0)`,
      employerEpf12: `ROUND(IF(ProportionedSalary < ${epfWageCap}, ProportionedSalary * ${epfEmployerRate}, ${epfMaxCap}), 0)`,
      employerEpf1: `ROUND(IF(ProportionedSalary < ${epfWageCap}, ProportionedSalary * ${epfAdminRate}, ${epfAdminMaxCap}), 0)`,
      employerEsi325: `ROUND(IF(TotalEarnings < ${esiThreshold}, TotalEarnings * ${esiEmployerRate}, 0), 0)`,
      grossTotal: `TotalEarnings + Bonus + EmployerEPF12 + EmployerEPF1 + EmployerESI + EmployerLWF`,
      employeeEpf12: `EmployerEPF12`,
      employeeEsi075: `ROUND(IF(TotalEarnings < ${esiThreshold}, TotalEarnings * ${esiEmployeeRate}, 0), 0)`,
      totalEmployeeDeductions: `EmployeeEPF12 + EmployeeESI + EmployeeLWF`,
      combinedDeductions: `TotalEmployeeDeductions + TotalEmployerContributions`,
      netPayable: `ROUND(GrossTotal - CombinedDeductions, 0) = ROUND((TotalEarnings + Bonus) - TotalEmployeeDeductions, 0)`,
      perfDifference: `PerfLastDrawn - PerfAsPerCircle`
    }
  };
}
