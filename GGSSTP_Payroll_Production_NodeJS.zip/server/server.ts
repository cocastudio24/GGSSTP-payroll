import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { db } from './database/db';
import { ExcelImporter } from './excel/excelImporter';

import authRoutes from './routes/authRoutes';
import dashboardRoutes from './routes/dashboardRoutes';
import employeeRoutes from './routes/employeeRoutes';
import designationRoutes from './routes/designationRoutes';
import organizationRoutes from './routes/organizationRoutes';
import payrollRoutes from './routes/payrollRoutes';
import importRoutes from './routes/importRoutes';
import exportRoutes from './routes/exportRoutes';
import reconciliationRoutes from './routes/reconciliationRoutes';
import userRoutes from './routes/userRoutes';
import auditRoutes from './routes/auditRoutes';
import backupRoutes from './routes/backupRoutes';
import chatRoutes from './routes/chatRoutes';

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/designations', designationRoutes);
app.use('/api/org', organizationRoutes);
app.use('/api/payroll', payrollRoutes);
app.use('/api/import', importRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/reconciliation', reconciliationRoutes);
app.use('/api/users', userRoutes);
app.use('/api/audit-logs', auditRoutes);
app.use('/api/backup', backupRoutes);
app.use('/api/chat', chatRoutes);

app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    system: 'GGSSTP Contractual Employee Payroll Management System',
    location: 'Guru Gobind Singh Super Thermal Plant, Rupnagar, Punjab',
    version: '2.0.0',
    timestamp: new Date().toISOString()
  });
});

// Serve frontend static build if available
const possibleDistPaths = [
  path.join(__dirname, '.'),
  path.join(__dirname, '../dist'),
  path.join(__dirname, '../client/dist'),
  path.join(__dirname, '../../dist')
];

const clientDist = possibleDistPaths.find(p => fs.existsSync(path.join(p, 'index.html')));
if (clientDist) {
  console.log(`Serving static frontend bundle from: ${clientDist}`);
  app.use(express.static(clientDist));
  app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api')) {
      res.sendFile(path.join(clientDist, 'index.html'));
    } else {
      next();
    }
  });
}

async function startServer() {
  try {
    await db.init();

    // Check if initial reference workbook should be auto-loaded (only if explicitly enabled via AUTO_SEED env)
    const empCount = await db.query(`SELECT COUNT(*) as count FROM employees;`);
    if (parseInt(empCount.rows[0].count, 10) === 0 && process.env.AUTO_SEED === 'true') {
      const possibleRefFiles = [
        path.join(__dirname, '../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx'),
        path.join(__dirname, '../../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx'),
        path.join(process.cwd(), 'reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx')
      ];
      const refFile = possibleRefFiles.find(p => fs.existsSync(p));
      if (refFile) {
        console.log('Auto-populating reference dataset from Excel workbook...');
        const buffer = fs.readFileSync(refFile);
        const parsed = ExcelImporter.parseWorkbook(buffer, 'SALARY SHEET-for EPF Sepf 2026.xlsx');
        const allRows = [
          ...(parsed['MM-1'] || []),
          ...(parsed['EMC'] || [])
        ];
        if (allRows.length > 0) {
          await ExcelImporter.commitImport(allRows, 9, 2026, 'system_bootstrap');
          console.log(`Auto-seeded ${allRows.length} reference employee records for September 2026.`);
        }
      }
    }

    const rawPort = process.env.PORT || '5000';
    const isSocket = isNaN(Number(rawPort));

    // Support both TCP port and Phusion Passenger socket paths
    const server = isSocket
      ? app.listen(rawPort, () => {
          console.log(`================================================================`);
          console.log(`GGSSTP Payroll Server running on Passenger socket: ${rawPort}`);
          console.log(`================================================================`);
        })
      : app.listen(Number(rawPort), '0.0.0.0', () => {
          console.log(`================================================================`);
          console.log(`GGSSTP Payroll Management System Server running on port ${rawPort}`);
          console.log(`Network / Local: http://localhost:${rawPort} / http://127.0.0.1:${rawPort}`);
          console.log(`API Base URL:    http://localhost:${rawPort}/api`);
          console.log(`================================================================`);
        });

    // In local Windows development only, optional convenience ports; never on production Linux / cPanel
    const isProduction = process.env.NODE_ENV === 'production' || Boolean(process.env.PASSENGER_APP_ENV);
    const extraServers: any[] = [];
    if (!isProduction && process.platform === 'win32' && !isSocket) {
      const extraPorts = [3000, 20010, 8080].filter(p => p !== Number(rawPort));
      for (const ep of extraPorts) {
        try {
          const s = app.listen(ep, '0.0.0.0', () => {
            console.log(`Also listening on port ${ep}: http://localhost:${ep}`);
          });
          s.on('error', () => {});
          extraServers.push(s);
        } catch {}
      }
    }

    // Automatically open user's default browser on Windows unless disabled
    if (process.platform === 'win32' && process.env.NODE_ENV !== 'test' && !process.env.NO_AUTO_OPEN) {
      try {
        const { exec } = require('child_process');
        setTimeout(() => {
          console.log(`Auto-launching browser at http://localhost:${rawPort}...`);
          exec(`start http://localhost:${rawPort}`, () => {});
        }, 600);
      } catch {}
    }

    const shutdown = async (signal: string) => {
      console.log(`Received ${signal}. Gracefully closing GGSSTP server & persistent database...`);
      server.close();
      for (const s of extraServers) {
        try { s.close(); } catch {}
      }
      try {
        await db.close();
        console.log('Database connection closed cleanly.');
      } catch {}
      process.exit(0);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
  } catch (err) {
    console.error('Failed to start GGSSTP server:', err);
    process.exit(1);
  }
}

startServer();
