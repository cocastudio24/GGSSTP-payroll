import ExcelJS from 'exceljs';
import { PayslipData } from './payslipUtils';

export function generatePayslipExcel(data: PayslipData): ExcelJS.Workbook {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'GGSSTP Payroll System (PSPCL)';
  workbook.lastModifiedBy = data.creatorUsername || 'admin';
  workbook.created = new Date();
  workbook.modified = new Date();

  const ws = workbook.addWorksheet(`Payslip_${data.empCode}`, {
    pageSetup: {
      paperSize: 9, // A4
      orientation: 'portrait',
      fitToPage: true,
      fitToWidth: 1,
      fitToHeight: 1
    }
  });

  // Set column widths
  ws.columns = [
    { width: 22 }, // A
    { width: 18 }, // B
    { width: 18 }, // C
    { width: 22 }, // D
    { width: 18 }, // E
    { width: 18 }  // F
  ];

  const navyDark = { type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb: 'FF1E3A8A' } };
  const navyMedium = { type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb: 'FF1E40AF' } };
  const redHeader = { type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb: 'FF991B1B' } };
  const greenHeader = { type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb: 'FF047857' } };
  const lightGray = { type: 'pattern' as const, pattern: 'solid' as const, fgColor: { argb: 'FFF8FAFC' } };
  const borderThin: Partial<ExcelJS.Borders> = {
    top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
    bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
    left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
    right: { style: 'thin', color: { argb: 'FFCBD5E1' } }
  };

  // 1. Header
  ws.mergeCells('A1:F1');
  const c1 = ws.getCell('A1');
  c1.value = 'PUNJAB STATE POWER CORPORATION LIMITED';
  c1.font = { name: 'Calibri', size: 14, bold: true, color: { argb: 'FFFFFFFF' } };
  c1.alignment = { horizontal: 'center', vertical: 'middle' };
  c1.fill = navyDark;
  ws.getRow(1).height = 28;

  ws.mergeCells('A2:F2');
  const c2 = ws.getCell('A2');
  c2.value = 'Guru Gobind Singh Super Thermal Plant (GGSSTP), Rupnagar (Ropar), Punjab - 140126';
  c2.font = { name: 'Calibri', size: 10, bold: false, color: { argb: 'FFFFFFFF' } };
  c2.alignment = { horizontal: 'center', vertical: 'middle' };
  c2.fill = navyMedium;
  ws.getRow(2).height = 20;

  ws.mergeCells('A3:F3');
  const c3 = ws.getCell('A3');
  c3.value = `SALARY PAYSLIP — ${data.monthName.toUpperCase()} ${data.year}`;
  c3.font = { name: 'Calibri', size: 11, bold: true, color: { argb: 'FF1E3A8A' } };
  c3.alignment = { horizontal: 'center', vertical: 'middle' };
  c3.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEFF6FF' } };
  ws.getRow(3).height = 22;

  // 2. Employee Details
  const details = [
    [
      'Employee Code:', data.empCode,
      'Employee Name:', data.empName,
      'Designation:', `${data.designationAlias} (${data.designationName})`
    ],
    [
      "Father's Name:", data.fatherName || 'N/A',
      'Contractor:', data.contractorName,
      'Circle / Dept:', `${data.circleName}${data.departmentName ? ` - ${data.departmentName}` : ''}`
    ],
    [
      'UAN / PF No.:', data.uan || 'N/A',
      'ESI Number:', data.esiNumber || 'N/A',
      'Attendance:', `${data.presentDays} / ${data.totalDays} Days`
    ],
    [
      'Bank Account:', data.bankAccount || 'N/A',
      'IFSC Code:', data.ifsc || 'N/A',
      'Payment Mode:', 'Direct Bank Transfer'
    ]
  ];

  details.forEach((rowVals, idx) => {
    const rowNum = 5 + idx;
    const r = ws.getRow(rowNum);
    r.values = rowVals;
    r.height = 19;
    [1, 3, 5].forEach(colIdx => {
      const cell = r.getCell(colIdx);
      cell.font = { name: 'Calibri', size: 9.5, bold: true, color: { argb: 'FF475569' } };
      cell.fill = lightGray;
      cell.border = borderThin;
    });
    [2, 4, 6].forEach(colIdx => {
      const cell = r.getCell(colIdx);
      cell.font = { name: 'Calibri', size: 9.5, bold: true, color: { argb: 'FF0F172A' } };
      cell.border = borderThin;
    });
  });

  // 3. Earnings & Deductions Tables Header
  ws.mergeCells('A10:B10');
  ws.getCell('A10').value = 'EARNINGS';
  ws.getCell('A10').font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('A10').fill = navyDark;
  ws.getCell('A10').alignment = { horizontal: 'left', vertical: 'middle' };

  ws.getCell('C10').value = 'AMOUNT (₹)';
  ws.getCell('C10').font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('C10').fill = navyDark;
  ws.getCell('C10').alignment = { horizontal: 'right', vertical: 'middle' };

  ws.mergeCells('D10:E10');
  ws.getCell('D10').value = 'DEDUCTIONS';
  ws.getCell('D10').font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('D10').fill = redHeader;
  ws.getCell('D10').alignment = { horizontal: 'left', vertical: 'middle' };

  ws.getCell('F10').value = 'AMOUNT (₹)';
  ws.getCell('F10').font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('F10').fill = redHeader;
  ws.getCell('F10').alignment = { horizontal: 'right', vertical: 'middle' };
  ws.getRow(10).height = 22;

  // Rows 11-17
  const earningsList = [
    { label: 'Gross Salary Rate', val: data.grossSalaryRate },
    { label: 'Basic Proportioned Salary', val: data.proportionedSalary },
    { label: 'Special Allowance', val: data.specialAllowance },
    { label: 'Total Basic', val: data.totalBasic },
    { label: 'Thermal Allowance', val: data.thermalAllowance },
    { label: 'Performance Allowance', val: data.perfAllowanceDays },
    { label: 'Bonus / Arrears', val: data.bonus }
  ];

  const deductionsList = [
    { label: 'Employee EPF (12%)', val: data.employeeEpf12 },
    { label: 'Employee ESI (0.75%)', val: data.employeeEsi075 },
    { label: 'Labour Welfare Fund (LWF)', val: data.employeeLwf },
    { label: '', val: null },
    { label: '', val: null },
    { label: '', val: null },
    { label: '', val: null }
  ];

  for (let i = 0; i < earningsList.length; i++) {
    const rowNum = 11 + i;
    ws.mergeCells(`A${rowNum}:B${rowNum}`);
    const eLbl = ws.getCell(`A${rowNum}`);
    eLbl.value = earningsList[i].label;
    eLbl.font = { name: 'Calibri', size: 9.5 };
    eLbl.border = borderThin;

    const eVal = ws.getCell(`C${rowNum}`);
    eVal.value = earningsList[i].val;
    eVal.numFmt = '#,##0.00';
    eVal.font = { name: 'Calibri', size: 9.5 };
    eVal.alignment = { horizontal: 'right' };
    eVal.border = borderThin;

    ws.mergeCells(`D${rowNum}:E${rowNum}`);
    const dLbl = ws.getCell(`D${rowNum}`);
    dLbl.value = deductionsList[i].label;
    dLbl.font = { name: 'Calibri', size: 9.5 };
    dLbl.border = borderThin;

    const dVal = ws.getCell(`F${rowNum}`);
    if (deductionsList[i].val !== null) {
      dVal.value = deductionsList[i].val;
      dVal.numFmt = '#,##0.00';
      dVal.font = { name: 'Calibri', size: 9.5, color: { argb: 'FF991B1B' } };
      dVal.alignment = { horizontal: 'right' };
    } else {
      dVal.value = '';
    }
    dVal.border = borderThin;
    ws.getRow(rowNum).height = 19;
  }

  // Row 18: Totals
  const totRow = 18;
  ws.mergeCells(`A${totRow}:B${totRow}`);
  const totEarnLbl = ws.getCell(`A${totRow}`);
  totEarnLbl.value = 'TOTAL GROSS EARNINGS';
  totEarnLbl.font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FF1E3A8A' } };
  totEarnLbl.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E7FF' } };
  totEarnLbl.border = borderThin;

  const totEarnVal = ws.getCell(`C${totRow}`);
  totEarnVal.value = data.grossEarnings;
  totEarnVal.numFmt = '#,##0.00';
  totEarnVal.font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FF1E3A8A' } };
  totEarnVal.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E7FF' } };
  totEarnVal.alignment = { horizontal: 'right' };
  totEarnVal.border = borderThin;

  ws.mergeCells(`D${totRow}:E${totRow}`);
  const totDedLbl = ws.getCell(`D${totRow}`);
  totDedLbl.value = 'TOTAL DEDUCTIONS';
  totDedLbl.font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FF991B1B' } };
  totDedLbl.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
  totDedLbl.border = borderThin;

  const totDedVal = ws.getCell(`F${totRow}`);
  totDedVal.value = data.totalEmployeeDeductions;
  totDedVal.numFmt = '#,##0.00';
  totDedVal.font = { name: 'Calibri', size: 10, bold: true, color: { argb: 'FF991B1B' } };
  totDedVal.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFEE2E2' } };
  totDedVal.alignment = { horizontal: 'right' };
  totDedVal.border = borderThin;
  ws.getRow(totRow).height = 22;

  // Row 20: Net Payable
  ws.mergeCells('A20:D20');
  const netLbl = ws.getCell('A20');
  netLbl.value = 'NET SALARY PAYABLE (₹):';
  netLbl.font = { name: 'Calibri', size: 12, bold: true, color: { argb: 'FF065F46' } };
  netLbl.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD1FAE5' } };
  netLbl.alignment = { horizontal: 'right', vertical: 'middle' };
  netLbl.border = borderThin;

  ws.mergeCells('E20:F20');
  const netVal = ws.getCell('E20');
  netVal.value = data.netPayable;
  netVal.numFmt = '₹#,##0.00';
  netVal.font = { name: 'Calibri', size: 13, bold: true, color: { argb: 'FFFFFFFF' } };
  netVal.fill = greenHeader;
  netVal.alignment = { horizontal: 'center', vertical: 'middle' };
  netVal.border = borderThin;
  ws.getRow(20).height = 26;

  // Row 21: Amount in words
  ws.mergeCells('A21:F21');
  const wordsCell = ws.getCell('A21');
  wordsCell.value = `Amount in Words: ${data.netPayableWords}`;
  wordsCell.font = { name: 'Calibri', size: 9.5, bold: true, italic: true, color: { argb: 'FF065F46' } };
  wordsCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFECFDF5' } };
  wordsCell.border = borderThin;
  ws.getRow(21).height = 20;

  // Row 23: Employer Contributions
  ws.mergeCells('A23:F23');
  const empHeader = ws.getCell('A23');
  empHeader.value = 'STATUTORY EMPLOYER CONTRIBUTIONS (Separate Establishment Cost - Not Deducted from Salary)';
  empHeader.font = { name: 'Calibri', size: 9, bold: true, color: { argb: 'FF1E3A8A' } };
  empHeader.fill = lightGray;
  empHeader.border = borderThin;

  const r24 = ws.getRow(24);
  r24.values = [
    'Employer EPF (12%):', data.employerEpf12,
    'EPF Admin (1%):', data.employerEpf1,
    'Employer ESI (3.25%):', data.employerEsi325
  ];
  r24.height = 19;
  [1, 3, 5].forEach(i => {
    r24.getCell(i).font = { name: 'Calibri', size: 8.5, bold: true, color: { argb: 'FF475569' } };
    r24.getCell(i).border = borderThin;
  });
  [2, 4, 6].forEach(i => {
    r24.getCell(i).numFmt = '₹#,##0.00';
    r24.getCell(i).font = { name: 'Calibri', size: 8.5 };
    r24.getCell(i).border = borderThin;
  });

  const r25 = ws.getRow(25);
  r25.values = [
    'Employer LWF:', data.employerLwf,
    'Total Employer Contribution:', '',
    '', data.totalEmployerContributions
  ];
  ws.mergeCells('C25:E25');
  ws.getCell('C25').value = 'Total Statutory Employer Cost:';
  ws.getCell('C25').font = { name: 'Calibri', size: 9, bold: true, color: { argb: 'FF1E3A8A' } };
  ws.getCell('C25').alignment = { horizontal: 'right' };
  ws.getCell('C25').border = borderThin;

  ws.getCell('F25').value = data.totalEmployerContributions;
  ws.getCell('F25').numFmt = '₹#,##0.00';
  ws.getCell('F25').font = { name: 'Calibri', size: 9, bold: true, color: { argb: 'FF1E3A8A' } };
  ws.getCell('F25').border = borderThin;
  r25.getCell(1).font = { name: 'Calibri', size: 8.5, bold: true, color: { argb: 'FF475569' } };
  r25.getCell(1).border = borderThin;
  r25.getCell(2).numFmt = '₹#,##0.00';
  r25.getCell(2).border = borderThin;
  r25.height = 19;

  // Row 27: Footer Note
  ws.mergeCells('A27:F27');
  const footerCell = ws.getCell('A27');
  footerCell.value = `This is a computer-generated salary slip. Valid without signature. | © 2026 Punjab State Power Corporation Limited PSEB Head Office, The MALL, Patiala`;
  footerCell.font = { name: 'Calibri', size: 8, italic: true, color: { argb: 'FF64748B' } };
  footerCell.alignment = { horizontal: 'center', vertical: 'middle' };

  return workbook;
}
