import PDFDocument from 'pdfkit';
import path from 'path';
import fs from 'fs';
import { PayslipData } from './payslipUtils';

export function generatePayslipPdf(data: PayslipData, stream?: NodeJS.WritableStream): Promise<Buffer | void> {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margins: { top: 30, bottom: 30, left: 35, right: 35 },
        info: {
          Title: `Payslip_${data.empCode}_${data.monthName}_${data.year}`,
          Author: 'PSPCL - GGSSTP Rupnagar Payroll System',
          Subject: `Salary Slip for ${data.empName} (${data.monthName} ${data.year})`
        }
      });

      if (stream) {
        doc.pipe(stream);
      } else {
        const buffers: Buffer[] = [];
        doc.on('data', (chunk) => buffers.push(chunk));
        doc.on('end', () => resolve(Buffer.concat(buffers)));
        doc.on('error', (err) => reject(err));
      }

      const pageWidth = 595.28;
      const leftMargin = 35;
      const rightMargin = pageWidth - 35;
      const contentWidth = rightMargin - leftMargin; // 525.28

      // 1. HEADER SECTION
      let currentY = 30;

      // Try loading logo
      const logoPath = path.resolve(process.cwd(), 'public/pspcl_logo.png');
      if (fs.existsSync(logoPath)) {
        try {
          doc.image(logoPath, leftMargin, currentY, { width: 44, height: 44 });
        } catch {
          // Continue if image format issue
        }
      }

      // Title text
      doc.font('Helvetica-Bold').fontSize(14).fillColor('#1e3a8a')
        .text('PUNJAB STATE POWER CORPORATION LIMITED', leftMargin + 50, currentY, {
          width: contentWidth - 50,
          align: 'center'
        });

      currentY += 18;
      doc.font('Helvetica').fontSize(9.5).fillColor('#334155')
        .text('Guru Gobind Singh Super Thermal Plant (GGSSTP), Rupnagar (Ropar), Punjab - 140126', leftMargin + 50, currentY, {
          width: contentWidth - 50,
          align: 'center'
        });

      currentY += 15;
      doc.font('Helvetica-Bold').fontSize(11).fillColor('#0f172a')
        .text(`SALARY PAYSLIP — ${data.monthName.toUpperCase()} ${data.year}`, leftMargin + 50, currentY, {
          width: contentWidth - 50,
          align: 'center'
        });

      currentY += 22;

      // Decorative divider
      doc.rect(leftMargin, currentY, contentWidth, 2).fill('#1e3a8a');
      currentY += 8;

      // 2. EMPLOYEE DETAILS GRID
      const detailsBoxY = currentY;
      const detailsBoxHeight = 84;
      doc.rect(leftMargin, detailsBoxY, contentWidth, detailsBoxHeight)
        .fillAndStroke('#f8fafc', '#cbd5e1');

      doc.fillColor('#0f172a');
      const col1X = leftMargin + 10;
      const col2X = leftMargin + 185;
      const col3X = leftMargin + 355;

      const drawRow = (y: number, items: Array<{ label: string; val: string; x: number }>) => {
        items.forEach(it => {
          doc.font('Helvetica-Bold').fontSize(8).fillColor('#64748b').text(it.label, it.x, y, { continued: false });
          doc.font('Helvetica-Bold').fontSize(8.5).fillColor('#0f172a').text(it.val, it.x, y + 9, { continued: false });
        });
      };

      drawRow(detailsBoxY + 6, [
        { label: 'EMPLOYEE CODE', val: data.empCode, x: col1X },
        { label: 'EMPLOYEE NAME', val: data.empName, x: col2X },
        { label: 'DESIGNATION', val: `${data.designationAlias} (${data.designationName})`, x: col3X }
      ]);

      drawRow(detailsBoxY + 32, [
        { label: "FATHER'S NAME", val: data.fatherName || 'N/A', x: col1X },
        { label: 'CONTRACTOR / AGENCY', val: data.contractorName, x: col2X },
        { label: 'CIRCLE / CELL', val: data.circleName + (data.departmentName ? ` - ${data.departmentName}` : ''), x: col3X }
      ]);

      drawRow(detailsBoxY + 58, [
        { label: 'UAN / PF NO.', val: data.uan || 'N/A', x: col1X },
        { label: 'ESI NUMBER', val: data.esiNumber || 'N/A', x: col2X },
        { label: 'ATTENDANCE (DAYS)', val: `${data.presentDays} / ${data.totalDays} Days`, x: col3X }
      ]);

      currentY = detailsBoxY + detailsBoxHeight + 8;

      // 2B. BANK ACCOUNT STRIP
      doc.rect(leftMargin, currentY, contentWidth, 20).fillAndStroke('#f1f5f9', '#cbd5e1');
      doc.font('Helvetica-Bold').fontSize(8).fillColor('#475569')
        .text(`Bank A/c: ${data.bankAccount || 'N/A'}    |    IFSC: ${data.ifsc || 'N/A'}    |    Payment Mode: Direct Bank Transfer (NEFT/RTGS)`, leftMargin + 10, currentY + 5);

      currentY += 28;

      // 3. EARNINGS & DEDUCTIONS TABLES (SIDE BY SIDE)
      const tableWidth = (contentWidth - 10) / 2; // ~257.6
      const tableHeight = 185;

      // Left Box: Earnings
      const earnX = leftMargin;
      doc.rect(earnX, currentY, tableWidth, 22).fill('#1e3a8a');
      doc.font('Helvetica-Bold').fontSize(9).fillColor('#ffffff').text('EARNINGS', earnX + 8, currentY + 6);
      doc.text('AMOUNT (₹)', earnX + tableWidth - 75, currentY + 6, { width: 65, align: 'right' });

      // Earnings Table Border
      doc.rect(earnX, currentY + 22, tableWidth, tableHeight - 22).fillAndStroke('#ffffff', '#cbd5e1');

      const earningsItems = [
        { label: 'Gross Salary Rate', val: data.grossSalaryRate },
        { label: 'Basic Proportioned Salary', val: data.proportionedSalary },
        { label: 'Special Allowance', val: data.specialAllowance },
        { label: 'Total Basic', val: data.totalBasic },
        { label: 'Thermal Allowance', val: data.thermalAllowance },
        { label: 'Performance Allowance', val: data.perfAllowanceDays },
        { label: 'Bonus / Arrears', val: data.bonus }
      ];

      let eY = currentY + 26;
      earningsItems.forEach((item, index) => {
        if (index % 2 === 1) {
          doc.rect(earnX + 1, eY - 2, tableWidth - 2, 18).fill('#f8fafc');
        }
        doc.font('Helvetica').fontSize(8.5).fillColor('#334155').text(item.label, earnX + 8, eY);
        doc.font('Helvetica').fontSize(8.5).fillColor('#0f172a')
          .text(item.val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }), earnX + tableWidth - 85, eY, { width: 75, align: 'right' });
        eY += 19;
      });

      // Total Gross Row
      doc.rect(earnX, currentY + tableHeight - 22, tableWidth, 22).fill('#e0e7ff');
      doc.font('Helvetica-Bold').fontSize(9).fillColor('#1e3a8a').text('TOTAL GROSS EARNINGS', earnX + 8, currentY + tableHeight - 16);
      doc.text(`₹ ${data.grossEarnings.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, earnX + tableWidth - 95, currentY + tableHeight - 16, { width: 85, align: 'right' });

      // Right Box: Deductions
      const dedX = leftMargin + tableWidth + 10;
      doc.rect(dedX, currentY, tableWidth, 22).fill('#991b1b');
      doc.font('Helvetica-Bold').fontSize(9).fillColor('#ffffff').text('DEDUCTIONS', dedX + 8, currentY + 6);
      doc.text('AMOUNT (₹)', dedX + tableWidth - 75, currentY + 6, { width: 65, align: 'right' });

      // Deductions Table Border
      doc.rect(dedX, currentY + 22, tableWidth, tableHeight - 22).fillAndStroke('#ffffff', '#cbd5e1');

      const deductionsItems = [
        { label: 'Employee EPF (12%)', val: data.employeeEpf12 },
        { label: 'Employee ESI (0.75%)', val: data.employeeEsi075 },
        { label: 'Labour Welfare Fund (LWF)', val: data.employeeLwf }
      ];

      let dY = currentY + 26;
      deductionsItems.forEach((item, index) => {
        if (index % 2 === 1) {
          doc.rect(dedX + 1, dY - 2, tableWidth - 2, 18).fill('#fff1f2');
        }
        doc.font('Helvetica').fontSize(8.5).fillColor('#334155').text(item.label, dedX + 8, dY);
        doc.font('Helvetica').fontSize(8.5).fillColor('#991b1b')
          .text(item.val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }), dedX + tableWidth - 85, dY, { width: 75, align: 'right' });
        dY += 19;
      });

      // Note inside deductions
      doc.font('Helvetica-Oblique').fontSize(7.5).fillColor('#64748b')
        .text('Statutory employee contributions as per EPF & ESI Acts.', dedX + 8, dY + 12, { width: tableWidth - 16 });

      // Total Deductions Row
      doc.rect(dedX, currentY + tableHeight - 22, tableWidth, 22).fill('#fee2e2');
      doc.font('Helvetica-Bold').fontSize(9).fillColor('#991b1b').text('TOTAL DEDUCTIONS', dedX + 8, currentY + tableHeight - 16);
      doc.text(`₹ ${data.totalEmployeeDeductions.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, dedX + tableWidth - 95, currentY + tableHeight - 16, { width: 85, align: 'right' });

      currentY += tableHeight + 10;

      // 4. NET PAYABLE HIGHLIGHT BANNER
      const netBannerHeight = 44;
      doc.rect(leftMargin, currentY, contentWidth, netBannerHeight).fillAndStroke('#ecfdf5', '#10b981');

      doc.font('Helvetica-Bold').fontSize(11).fillColor('#065f46')
        .text('NET SALARY PAYABLE:', leftMargin + 12, currentY + 8);

      doc.font('Helvetica-Bold').fontSize(15).fillColor('#047857')
        .text(`₹ ${data.netPayable.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, leftMargin + contentWidth - 160, currentY + 6, { width: 148, align: 'right' });

      doc.font('Helvetica-BoldOblique').fontSize(8.5).fillColor('#065f46')
        .text(`Amount in Words: ${data.netPayableWords}`, leftMargin + 12, currentY + 26, { width: contentWidth - 24 });

      currentY += netBannerHeight + 10;

      // 5. STATUTORY EMPLOYER CONTRIBUTIONS (SEPARATE DISCLOSURE)
      const empCostHeight = 52;
      doc.rect(leftMargin, currentY, contentWidth, empCostHeight).fillAndStroke('#f8fafc', '#cbd5e1');

      doc.font('Helvetica-Bold').fontSize(8).fillColor('#1e3a8a')
        .text('STATUTORY EMPLOYER CONTRIBUTIONS (Not deducted from employee salary):', leftMargin + 10, currentY + 6);

      const eCol1 = leftMargin + 10;
      const eCol2 = leftMargin + 140;
      const eCol3 = leftMargin + 270;
      const eCol4 = leftMargin + 380;

      doc.font('Helvetica').fontSize(8).fillColor('#475569')
        .text(`EPF 12%: ₹${data.employerEpf12.toFixed(2)}`, eCol1, currentY + 20)
        .text(`EPF Admin 1%: ₹${data.employerEpf1.toFixed(2)}`, eCol2, currentY + 20)
        .text(`ESI 3.25%: ₹${data.employerEsi325.toFixed(2)}`, eCol3, currentY + 20)
        .text(`LWF: ₹${data.employerLwf.toFixed(2)}`, eCol4, currentY + 20);

      doc.font('Helvetica-Bold').fontSize(8.5).fillColor('#1e293b')
        .text(`Total Employer Contribution: ₹${data.totalEmployerContributions.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, eCol1, currentY + 36);

      currentY += empCostHeight + 14;

      // 6. SIGNATURE & DISCLAIMER SECTION
      const sigY = currentY;
      doc.font('Helvetica').fontSize(7.5).fillColor('#64748b')
        .text('This is a system-generated salary slip and does not require a physical signature.', leftMargin, sigY);

      doc.text(`Generated On: ${data.generatedAt} | Authorized System User: ${data.creatorUsername || 'admin'}`, leftMargin, sigY + 11);

      // Signatory block
      doc.font('Helvetica-Bold').fontSize(8).fillColor('#334155')
        .text('For Guru Gobind Singh Super Thermal Plant (PSPCL)', leftMargin + contentWidth - 240, sigY, { width: 230, align: 'right' });
      doc.font('Helvetica').fontSize(7.5).fillColor('#64748b')
        .text('Authorised Signatory / Accounts Cell', leftMargin + contentWidth - 240, sigY + 24, { width: 230, align: 'right' });

      // 7. FOOTER BAR
      doc.rect(leftMargin, 792, contentWidth, 1).fill('#cbd5e1');
      doc.font('Helvetica').fontSize(7).fillColor('#64748b')
        .text('© 2026 Punjab State Power Corporation Limited PSEB Head Office, The MALL, Patiala | GGSSTP Rupnagar Contractual Labour Cell', leftMargin, 798, { width: contentWidth, align: 'center' });

      doc.end();
      if (stream) {
        resolve();
      }
    } catch (err) {
      reject(err);
    }
  });
}
