import { db } from '../database/db';

export function numberToWordsIndian(amount: number): string {
  const rounded = Math.round(Math.abs(amount));
  if (rounded === 0) return 'Rupees Zero Only';

  const units = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'
  ];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  function convertTwoDigits(n: number): string {
    if (n < 20) return units[n];
    const unit = n % 10;
    return tens[Math.floor(n / 10)] + (unit ? ' ' + units[unit] : '');
  }

  function convertThreeDigits(n: number): string {
    const hundred = Math.floor(n / 100);
    const rest = n % 100;
    let res = '';
    if (hundred > 0) {
      res += units[hundred] + ' Hundred';
      if (rest > 0) res += ' ';
    }
    if (rest > 0) {
      res += convertTwoDigits(rest);
    }
    return res.trim();
  }

  let crore = Math.floor(rounded / 10000000);
  let remainder = rounded % 10000000;
  let lakh = Math.floor(remainder / 100000);
  remainder = remainder % 100000;
  let thousand = Math.floor(remainder / 1000);
  let hundred = remainder % 1000;

  const parts: string[] = [];
  if (crore > 0) parts.push(convertTwoDigits(crore) + ' Crore');
  if (lakh > 0) parts.push(convertTwoDigits(lakh) + ' Lakh');
  if (thousand > 0) parts.push(convertTwoDigits(thousand) + ' Thousand');
  if (hundred > 0) parts.push(convertThreeDigits(hundred));

  return `Rupees ${parts.join(' ')} Only`;
}

export interface PayslipData {
  entryId: number;
  periodId: number;
  monthName: string;
  year: number;
  totalDays: number;
  periodStatus: string;
  ownerUserId: number;
  empOwnerUserId?: number;
  creatorUsername?: string;
  creatorFullName?: string;

  // Employee Information
  employeeId: number;
  empCode: string;
  srNo?: string;
  empName: string;
  fatherName?: string;
  uan?: string;
  designationName: string;
  designationAlias: string;
  contractorName: string;
  circleName: string;
  departmentName?: string;
  bankAccount?: string;
  ifsc?: string;
  esiNumber?: string;
  dob?: string;
  dateOfJoining?: string;

  // Attendance
  presentDays: number;

  // Earnings
  grossSalaryRate: number;
  proportionedSalary: number;
  specialAllowance: number;
  totalBasic: number;
  thermalAllowance: number;
  perfAllowanceMonthly: number;
  perfAllowanceDays: number;
  bonus: number;
  bonusPercentage: number;
  totalEarningsBeforeBonus: number;
  grossEarnings: number;
  employeeCashEarnings: number;

  // Performance Allowance Circle Comparison (EMC)
  perfLastDrawn?: number;
  perfAsPerCircle?: number;
  perfDifference?: number;

  // Deductions
  employeeEpf12: number;
  employeeEsi075: number;
  employeeLwf: number;
  totalEmployeeDeductions: number;
  employeeOnlyDeductions: number;

  // Net Payable
  netPayable: number;
  netPayableWords: string;

  // Employer Contributions
  employerEpf12: number;
  employerEpf1: number;
  employerEsi325: number;
  employerLwf: number;
  totalEmployerContributions: number;

  // Comprehensive Reference Totals
  grossTotal: number;
  combinedDeductions: number;

  // Organization Metadata
  companyName: string;
  plantName: string;
  location: string;
  generatedAt: string;
}

export async function fetchPayslipData(entryId: number): Promise<PayslipData | null> {
  const query = `
    SELECT 
      pe.*,
      p.year as period_year, p.month as period_month, p.month_name as period_month_name,
      p.total_days as period_total_days, p.status as period_status,
      e.id as emp_id, e.owner_user_id as emp_owner_user_id, e.emp_code, e.sr_no, e.name as emp_name, e.father_name, e.uan,
      e.dob, e.date_of_joining, e.bank_account, e.ifsc, e.esi_number,
      COALESCE(d.name, 'Skilled') as designation_name,
      COALESCE(d.alias, 'SW') as designation_alias,
      COALESCE(c.name, 'Direct / Unassigned') as contractor_name,
      COALESCE(cir.name, 'General Circle') as circle_name,
      COALESCE(dep.name, '') as department_name,
      u.username as creator_username,
      u.full_name as creator_full_name
    FROM payroll_entries pe
    JOIN payroll_periods p ON pe.payroll_period_id = p.id
    JOIN employees e ON pe.employee_id = e.id
    LEFT JOIN designations d ON e.designation_id = d.id
    LEFT JOIN contractors c ON e.contractor_id = c.id
    LEFT JOIN circles cir ON e.circle_id = cir.id
    LEFT JOIN departments dep ON e.department_id = dep.id
    LEFT JOIN users u ON COALESCE(pe.owner_user_id, e.owner_user_id) = u.id
    WHERE pe.id = $1;
  `;

  const res = await db.query(query, [entryId]);
  if (res.rows.length === 0) return null;

  const r = res.rows[0];
  const grossEarnings = Number(r.total_earnings_before_bonus || 0) + Number(r.bonus || 0);
  const netPayable = Number(r.net_payable || 0);

  return {
    entryId: r.id,
    periodId: r.payroll_period_id,
    monthName: r.period_month_name,
    year: r.period_year,
    totalDays: Number(r.period_total_days) || 30,
    periodStatus: r.period_status,
    ownerUserId: r.owner_user_id || r.emp_owner_user_id,
    empOwnerUserId: r.emp_owner_user_id,
    creatorUsername: r.creator_username,
    creatorFullName: r.creator_full_name,

    employeeId: r.emp_id,
    empCode: r.emp_code,
    srNo: r.sr_no,
    empName: r.emp_name,
    fatherName: r.father_name,
    uan: r.uan,
    designationName: r.designation_name,
    designationAlias: r.designation_alias,
    contractorName: r.contractor_name,
    circleName: r.circle_name,
    departmentName: r.department_name,
    bankAccount: r.bank_account,
    ifsc: r.ifsc,
    esiNumber: r.esi_number,
    dob: r.dob,
    dateOfJoining: r.date_of_joining,

    presentDays: Number(r.present_days) || 0,

    grossSalaryRate: Number(r.gross_salary_rate) || 0,
    proportionedSalary: Number(r.proportioned_salary) || 0,
    specialAllowance: Number(r.special_allowance) || 0,
    totalBasic: Number(r.total_basic) || 0,
    thermalAllowance: Number(r.thermal_allowance) || 0,
    perfAllowanceMonthly: Number(r.perf_allowance_monthly) || 0,
    perfAllowanceDays: Number(r.perf_allowance_days) || 0,
    bonus: Number(r.bonus) || 0,
    bonusPercentage: Number(r.bonus_percentage !== null && r.bonus_percentage !== undefined ? r.bonus_percentage : 8.33),
    totalEarningsBeforeBonus: Number(r.total_earnings_before_bonus) || 0,
    grossEarnings,
    employeeCashEarnings: grossEarnings,

    perfLastDrawn: Number(r.perf_last_drawn || 0),
    perfAsPerCircle: Number(r.perf_as_per_circle || 0),
    perfDifference: Number(r.perf_difference || 0),

    employeeEpf12: Number(r.employee_epf_12) || 0,
    employeeEsi075: Number(r.employee_esi_075) || 0,
    employeeLwf: Number(r.employee_lwf) || 0,
    totalEmployeeDeductions: Number(r.total_employee_deductions) || 0,
    employeeOnlyDeductions: Number(r.total_employee_deductions) || 0,

    netPayable,
    netPayableWords: numberToWordsIndian(netPayable),

    employerEpf12: Number(r.employer_epf_12) || 0,
    employerEpf1: Number(r.employer_epf_1) || 0,
    employerEsi325: Number(r.employer_esi_325) || 0,
    employerLwf: Number(r.employer_lwf) || 0,
    totalEmployerContributions: Number(r.total_employer_contributions) || 0,

    grossTotal: Number(r.gross_total || 0),
    combinedDeductions: Number(r.combined_deductions || 0),

    companyName: 'PUNJAB STATE POWER CORPORATION LIMITED (PSPCL)',
    plantName: 'Guru Gobind Singh Super Thermal Plant (GGSSTP)',
    location: 'Rupnagar (Ropar), Punjab - 140126',
    generatedAt: new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })
  };
}
