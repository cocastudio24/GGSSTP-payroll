import { db } from '../database/db';
import { calculatePayroll } from '../engine/payrollCalculator';

export interface SyncResult {
  periodId: number;
  periodName: string;
  addedCount: number;
  updatedCount: number;
  removedCount: number;
}

export interface BulkSyncResult {
  periodsSynced: number;
  results: SyncResult[];
  totalAdded: number;
  totalUpdated: number;
  totalRemoved: number;
}

/**
 * Synchronizes a single payroll period with the active employee register.
 * Finalized periods are NEVER modified.
 */
export async function syncPeriodWithActiveEmployees(periodId: number, ownerUserId?: number): Promise<SyncResult | null> {
  // Check if period exists and is not finalized
  const periodRes = await db.query(
    `SELECT * FROM payroll_periods WHERE id = $1;`,
    [Number(periodId)]
  );
  if (periodRes.rows.length === 0) return null;

  const period = periodRes.rows[0];
  if (period.status && period.status.toLowerCase() === 'finalized') {
    // Finalized periods are locked and must NEVER be modified
    return {
      periodId: period.id,
      periodName: `${period.month_name} ${period.year}`,
      addedCount: 0,
      updatedCount: 0,
      removedCount: 0
    };
  }

  // Fetch plant active rule set
  let ruleRes = await db.query(
    'SELECT * FROM payroll_rule_sets WHERE is_active = TRUE ORDER BY id ASC LIMIT 1;'
  );
  const activeRule = ruleRes.rows[0];

  const ruleSetObj = activeRule ? {
    epfWageCap: Number(activeRule.epf_wage_cap),
    epfEmployerRate: Number(activeRule.epf_employer_rate),
    epfMaxCap: Number(activeRule.epf_max_cap),
    epfAdminRate: Number(activeRule.epf_admin_rate),
    epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
    epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
    esiThreshold: Number(activeRule.esi_threshold),
    esiEmployerRate: Number(activeRule.esi_employer_rate),
    esiEmployeeRate: Number(activeRule.esi_employee_rate),
    employerLwf: Number(activeRule.employer_lwf),
    employeeLwf: Number(activeRule.employee_lwf),
    thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
  } : undefined;

  // 1. Fetch active, non-archived employees (scoped if ownerUserId provided)
  let empQuery = `
    SELECT 
      e.id, e.owner_user_id, e.created_by_user_id, d.alias as designation_alias, 
      dsr.gross_salary_rate, dsr.special_allowance, dsr.perf_allowance_default,
      e.default_gross_rate, e.default_special_allowance, e.default_thermal_allowance,
      e.default_perf_allowance, e.default_bonus_percentage,
      e.custom_employee_epf, e.custom_employer_epf, e.custom_employer_epf1,
      e.custom_employee_esi, e.custom_employer_esi, e.custom_employee_lwf, e.custom_employer_lwf,
      e.epf_applicable, e.esi_applicable, e.lwf_applicable
    FROM employees e
    LEFT JOIN designations d ON e.designation_id = d.id
    LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
    WHERE e.is_active = TRUE AND e.archived_at IS NULL
  `;
  const empParams: any[] = [];
  if (ownerUserId) {
    empQuery += ` AND (e.owner_user_id = $1 OR e.created_by_user_id = $1);`;
    empParams.push(ownerUserId);
  } else {
    empQuery += `;`;
  }
  const activeEmps = await db.query(empQuery, empParams);

  const activeEmpMap = new Map<number, any>();
  for (const emp of activeEmps.rows) {
    activeEmpMap.set(emp.id, emp);
  }

  // 2. Fetch current payroll entries for this period (scoped if ownerUserId provided)
  let entriesQuery = `SELECT id, employee_id, present_days, is_overridden, calculation_mode, owner_user_id, created_by_user_id FROM payroll_entries WHERE payroll_period_id = $1`;
  const entriesParams: any[] = [Number(periodId)];
  if (ownerUserId) {
    entriesQuery += ` AND (owner_user_id = $2 OR created_by_user_id = $2)`;
    entriesParams.push(ownerUserId);
  }
  const entriesRes = await db.query(entriesQuery, entriesParams);

  const existingEntryEmpIds = new Set<number>();
  let removedCount = 0;

  for (const entry of entriesRes.rows) {
    if (!activeEmpMap.has(entry.employee_id)) {
      // Only remove if employee is genuinely inactive or archived in DB
      const chk = await db.query(`SELECT id FROM employees WHERE id = $1 AND (is_active = FALSE OR archived_at IS NOT NULL);`, [entry.employee_id]);
      if (chk.rows.length > 0) {
        await db.query(`DELETE FROM payroll_entries WHERE id = $1;`, [entry.id]);
        removedCount++;
      } else {
        existingEntryEmpIds.add(entry.employee_id);
      }
    } else {
      existingEntryEmpIds.add(entry.employee_id);
    }
  }

  let addedCount = 0;
  let updatedCount = 0;
  const totalDays = Number(period.total_days) || 30;

  for (const [empId, emp] of activeEmpMap.entries()) {
    const effectiveOwner = emp.owner_user_id || emp.created_by_user_id || ownerUserId || period.owner_user_id || 1;
    const grossRate = emp.default_gross_rate ? Number(emp.default_gross_rate) : emp.gross_salary_rate;
    const specialAllowance = emp.default_special_allowance ? Number(emp.default_special_allowance) : emp.special_allowance;
    const thermalAllowance = emp.default_thermal_allowance !== null && emp.default_thermal_allowance !== undefined
      ? Number(emp.default_thermal_allowance)
      : (activeRule ? Number(activeRule.thermal_allowance_base) : 1500);
    const perfMonthly = emp.default_perf_allowance !== null && emp.default_perf_allowance !== undefined
      ? Number(emp.default_perf_allowance)
      : (Number(emp.perf_allowance_default) || 225);
    const bonusPct = emp.default_bonus_percentage !== null && emp.default_bonus_percentage !== undefined && emp.default_bonus_percentage !== ''
      ? Number(emp.default_bonus_percentage)
      : (emp.default_bonus_percentage === null || emp.default_bonus_percentage === '' ? 0 : 8.33);

    if (!existingEntryEmpIds.has(empId)) {
      // Missing from open period -> Insert new entry
      const calc = calculatePayroll({
        designationAlias: emp.designation_alias || 'SW',
        grossSalaryRate: grossRate,
        specialAllowanceRate: specialAllowance,
        customThermalAllowance: thermalAllowance,
        totalDays: totalDays,
        presentDays: totalDays,
        perfAllowanceMonthly: perfMonthly,
        bonusPercentage: bonusPct,
        customEmployeeEpf: emp.custom_employee_epf !== null && emp.custom_employee_epf !== undefined && emp.custom_employee_epf !== ''
          ? Number(emp.custom_employee_epf)
          : (emp.epf_applicable === false ? 0 : undefined),
        customEmployerEpf: emp.custom_employer_epf !== null && emp.custom_employer_epf !== undefined && emp.custom_employer_epf !== ''
          ? Number(emp.custom_employer_epf)
          : (emp.epf_applicable === false ? 0 : undefined),
        customEmployerEpf1: emp.custom_employer_epf1 !== null && emp.custom_employer_epf1 !== undefined && emp.custom_employer_epf1 !== ''
          ? Number(emp.custom_employer_epf1)
          : (emp.epf_applicable === false ? 0 : undefined),
        customEmployeeEsi: emp.custom_employee_esi !== null && emp.custom_employee_esi !== undefined && emp.custom_employee_esi !== ''
          ? Number(emp.custom_employee_esi)
          : (emp.esi_applicable === false ? 0 : undefined),
        customEmployerEsi: emp.custom_employer_esi !== null && emp.custom_employer_esi !== undefined && emp.custom_employer_esi !== ''
          ? Number(emp.custom_employer_esi)
          : (emp.esi_applicable === false ? 0 : undefined),
        customEmployeeLwf: emp.custom_employee_lwf !== null && emp.custom_employee_lwf !== undefined && emp.custom_employee_lwf !== ''
          ? Number(emp.custom_employee_lwf)
          : (emp.lwf_applicable === false ? 0 : undefined),
        customEmployerLwf: emp.custom_employer_lwf !== null && emp.custom_employer_lwf !== undefined && emp.custom_employer_lwf !== ''
          ? Number(emp.custom_employer_lwf)
          : (emp.lwf_applicable === false ? 0 : undefined),
        ruleSet: ruleSetObj
      });

      await db.query(`
        INSERT INTO payroll_entries (
          owner_user_id, payroll_period_id, employee_id, present_days, gross_salary_rate, proportioned_salary,
          special_allowance, total_basic, thermal_allowance, perf_allowance_monthly, perf_allowance_days,
          total_earnings_before_bonus, bonus, employer_epf_12, employer_epf_1, employer_esi_325,
          employer_lwf, gross_total, employee_epf_12, employee_esi_075, employee_lwf,
          total_employee_deductions, total_employer_contributions, combined_deductions, net_payable,
          bonus_percentage, perf_last_drawn, perf_as_per_circle, perf_difference,
          calculation_mode
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
          $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
          $21, $22, $23, $24, $25, $26, $27, $28, $29, 'Reference-Compatible'
        );
      `, [
        effectiveOwner, Number(periodId), empId, totalDays, calc.grossSalaryRate, calc.proportionedSalary,
        calc.specialAllowance, calc.totalBasic, calc.thermalAllowance, calc.perfAllowanceMonthly,
        calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12,
        calc.employerEpf1, calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions, calc.totalEmployerContributions,
        calc.combinedDeductions, calc.netPayable, calc.bonusPercentage, calc.perfLastDrawn,
        calc.perfAsPerCircle, calc.perfDifference
      ]);
      addedCount++;
    } else {
      // Entry exists: check if not locked/overridden, then update latest rates while preserving present_days
      const existingEntry = entriesRes.rows.find(r => r.employee_id === empId);
      if (existingEntry && !existingEntry.is_overridden && existingEntry.calculation_mode !== 'Excel-Mapped') {
        const presentDays = Number(existingEntry.present_days) || totalDays;
        const calc = calculatePayroll({
          designationAlias: emp.designation_alias || 'SW',
          grossSalaryRate: grossRate,
          specialAllowanceRate: specialAllowance,
          customThermalAllowance: thermalAllowance,
          totalDays: totalDays,
          presentDays: presentDays,
          perfAllowanceMonthly: perfMonthly,
          bonusPercentage: bonusPct,
          customEmployeeEpf: emp.custom_employee_epf !== null && emp.custom_employee_epf !== undefined && emp.custom_employee_epf !== ''
            ? Number(emp.custom_employee_epf)
            : (emp.epf_applicable === false ? 0 : undefined),
          customEmployerEpf: emp.custom_employer_epf !== null && emp.custom_employer_epf !== undefined && emp.custom_employer_epf !== ''
            ? Number(emp.custom_employer_epf)
            : (emp.epf_applicable === false ? 0 : undefined),
          customEmployerEpf1: emp.custom_employer_epf1 !== null && emp.custom_employer_epf1 !== undefined && emp.custom_employer_epf1 !== ''
            ? Number(emp.custom_employer_epf1)
            : (emp.epf_applicable === false ? 0 : undefined),
          customEmployeeEsi: emp.custom_employee_esi !== null && emp.custom_employee_esi !== undefined && emp.custom_employee_esi !== ''
            ? Number(emp.custom_employee_esi)
            : (emp.esi_applicable === false ? 0 : undefined),
          customEmployerEsi: emp.custom_employer_esi !== null && emp.custom_employer_esi !== undefined && emp.custom_employer_esi !== ''
            ? Number(emp.custom_employer_esi)
            : (emp.esi_applicable === false ? 0 : undefined),
          customEmployeeLwf: emp.custom_employee_lwf !== null && emp.custom_employee_lwf !== undefined && emp.custom_employee_lwf !== ''
            ? Number(emp.custom_employee_lwf)
            : (emp.lwf_applicable === false ? 0 : undefined),
          customEmployerLwf: emp.custom_employer_lwf !== null && emp.custom_employer_lwf !== undefined && emp.custom_employer_lwf !== ''
            ? Number(emp.custom_employer_lwf)
            : (emp.lwf_applicable === false ? 0 : undefined),
          ruleSet: ruleSetObj
        });

        await db.query(`
          UPDATE payroll_entries SET
            gross_salary_rate = $1,
            proportioned_salary = $2,
            special_allowance = $3,
            total_basic = $4,
            thermal_allowance = $5,
            perf_allowance_monthly = $6,
            perf_allowance_days = $7,
            total_earnings_before_bonus = $8,
            bonus = $9,
            employer_epf_12 = $10,
            employer_epf_1 = $11,
            employer_esi_325 = $12,
            employer_lwf = $13,
            gross_total = $14,
            employee_epf_12 = $15,
            employee_esi_075 = $16,
            employee_lwf = $17,
            total_employee_deductions = $18,
            total_employer_contributions = $19,
            combined_deductions = $20,
            net_payable = $21,
            bonus_percentage = $22,
            updated_at = CURRENT_TIMESTAMP
          WHERE id = $23;
        `, [
          calc.grossSalaryRate, calc.proportionedSalary, calc.specialAllowance, calc.totalBasic,
          calc.thermalAllowance, calc.perfAllowanceMonthly, calc.perfAllowanceDaysWise,
          calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12, calc.employerEpf1,
          calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
          calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
          calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
          calc.bonusPercentage, existingEntry.id
        ]);
        updatedCount++;
      }
    }
  }

  return {
    periodId: period.id,
    periodName: `${period.month_name} ${period.year}`,
    addedCount,
    updatedCount,
    removedCount
  };
}

/**
 * Synchronizes all open / unfinalized payroll periods plant-wide.
 * Finalized periods are strictly protected and never touched.
 */
export async function syncEmployeesWithOpenPayrollPeriods(ownerUserId?: number): Promise<BulkSyncResult> {
  const periodsRes = await db.query(`
    SELECT id, month_name, year, status FROM payroll_periods
    WHERE LOWER(status) != 'finalized'
    ORDER BY year DESC, month DESC;
  `);

  const results: SyncResult[] = [];
  let totalAdded = 0;
  let totalUpdated = 0;
  let totalRemoved = 0;

  for (const p of periodsRes.rows) {
    const res = await syncPeriodWithActiveEmployees(p.id, ownerUserId);
    if (res) {
      results.push(res);
      totalAdded += res.addedCount;
      totalUpdated += res.updatedCount;
      totalRemoved += res.removedCount;
    }
  }

  return {
    periodsSynced: results.length,
    results,
    totalAdded,
    totalUpdated,
    totalRemoved
  };
}
