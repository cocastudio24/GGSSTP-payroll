import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { isSuperAdmin } from '../middleware/rbac';

const router = Router();

router.get('/stats', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const creatorId = req.query.creatorId ? Number(req.query.creatorId) : null;
    const targetUserId = isSuper ? (creatorId || null) : userId;
    const periodIdQuery = req.query.periodId ? Number(req.query.periodId) : null;

    // 1. Employee overview counts (excludes archived)
    let empWhere = 'WHERE archived_at IS NULL';
    const empParams: any[] = [];
    if (targetUserId) {
      empWhere += ' AND (owner_user_id = $1 OR created_by_user_id = $1)';
      empParams.push(targetUserId);
    }

    const empCountsRes = await db.query(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN is_active = TRUE THEN 1 END) as active,
        COUNT(CASE WHEN is_active = FALSE THEN 1 END) as inactive,
        COUNT(CASE WHEN bank_account IS NULL OR bank_account = '' THEN 1 END) as missing_bank,
        COUNT(CASE WHEN uan IS NULL OR uan = '' THEN 1 END) as missing_uan,
        COUNT(CASE WHEN esi_number IS NULL OR esi_number = '' THEN 1 END) as missing_esi
      FROM employees
      ${empWhere};
    `, empParams);

    // 2. Active or selected payroll period
    let periodRow: any = null;
    if (periodIdQuery) {
      const pRes = await db.query(
        `SELECT * FROM payroll_periods WHERE id = $1;`,
        [periodIdQuery]
      );
      if (pRes.rows.length > 0) periodRow = pRes.rows[0];
    } else {
      let pQuery = `SELECT * FROM payroll_periods`;
      const pParams: any[] = [];
      if (targetUserId) {
        pQuery += ` WHERE (owner_user_id = $1 OR created_by_user_id = $1)`;
        pParams.push(targetUserId);
      }
      pQuery += ` ORDER BY year DESC, month DESC, id DESC LIMIT 1;`;
      const pRes = await db.query(pQuery, pParams);
      if (pRes.rows.length > 0) {
        periodRow = pRes.rows[0];
      } else {
        // Fallback to any latest period in the plant so telemetry is never empty
        const anyPeriodRes = await db.query(`SELECT * FROM payroll_periods ORDER BY year DESC, month DESC, id DESC LIMIT 1;`);
        if (anyPeriodRes.rows.length > 0) periodRow = anyPeriodRes.rows[0];
      }
    }

    // 3. Query employees with live payroll entries
    let empJoinWhere = 'WHERE e.is_active = TRUE AND e.archived_at IS NULL';
    const empJoinParams: any[] = [];
    let peFilter = '';
    if (periodRow) {
      peFilter += ` AND pe.payroll_period_id = ${Number(periodRow.id)}`;
    }
    if (targetUserId) {
      empJoinWhere += ` AND (e.owner_user_id = $1 OR e.created_by_user_id = $1)`;
      empJoinParams.push(targetUserId);
      peFilter += ` AND (pe.owner_user_id = $1 OR pe.created_by_user_id = $1)`;
    }

    const allEmployeesRes = await db.query(`
      SELECT 
        e.id, e.name, e.emp_code, e.uan, e.bank_account, e.ifsc, e.esi_number,
        COALESCE(d.alias, 'SW') as designation_alias, 
        COALESCE(d.name, 'Skilled') as designation_name,
        c.id as contractor_id, 
        COALESCE(c.name, 'Direct / Unassigned') as contractor_name,
        cir.id as circle_id, 
        COALESCE(cir.name, 'General Circle') as circle_name,
        COALESCE(pe.present_days, 0) as present_days,
        COALESCE(pe.gross_salary_rate, e.default_gross_rate, dsr.gross_salary_rate, 16530) as gross_salary_rate,
        COALESCE(pe.total_basic, e.default_gross_rate, 0) as total_basic,
        COALESCE(pe.thermal_allowance, 0) as thermal_allowance,
        COALESCE(pe.perf_allowance_days, 0) as perf_allowance_days,
        COALESCE(pe.bonus, 0) as bonus,
        COALESCE(pe.total_earnings_before_bonus, 0) as total_earnings_before_bonus,
        COALESCE(pe.employee_epf_12, 0) as employee_epf_12,
        COALESCE(pe.employee_esi_075, 0) as employee_esi_075,
        COALESCE(pe.employee_lwf, 0) as employee_lwf,
        COALESCE(pe.total_employee_deductions, 0) as total_employee_deductions,
        COALESCE(pe.net_payable, 0) as net_payable
      FROM employees e
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN payroll_entries pe ON pe.employee_id = e.id ${peFilter}
      ${empJoinWhere}
      ORDER BY e.name ASC;
    `, empJoinParams);

    const allEmployees = allEmployeesRes.rows;

    // 4. Circle breakdowns with individualized statutory deductions
    // Dynamic grouping for ALL circles found in active employees
    const circlesMap: Record<string, any> = {};
    for (const emp of allEmployees) {
      const cName = emp.circle_name || 'General Circle';
      if (!circlesMap[cName]) {
        circlesMap[cName] = {
          circleName: cName,
          totalCount: 0,
          totalNetPayable: 0,
          totalBasic: 0,
          totalGross: 0,
          totalEmployeeDeductions: 0,
          totalEmployeeEpf: 0,
          totalEmployeeEsi: 0,
          totalEmployeeLwf: 0,
          employees: []
        };
      }
      circlesMap[cName].totalCount++;
      circlesMap[cName].totalNetPayable += Number(emp.net_payable || 0);
      circlesMap[cName].totalBasic += Number(emp.total_basic || 0);
      circlesMap[cName].totalGross += (Number(emp.total_earnings_before_bonus || 0) + Number(emp.bonus || 0));
      circlesMap[cName].totalEmployeeDeductions += Number(emp.total_employee_deductions || 0);
      circlesMap[cName].totalEmployeeEpf += Number(emp.employee_epf_12 || 0);
      circlesMap[cName].totalEmployeeEsi += Number(emp.employee_esi_075 || 0);
      circlesMap[cName].totalEmployeeLwf += Number(emp.employee_lwf || 0);
      circlesMap[cName].employees.push(emp);
    }

    const emcEmployees = allEmployees.filter(e => e.circle_name && /emc/i.test(e.circle_name));
    const mm1Employees = allEmployees.filter(e => e.circle_name && /mm/i.test(e.circle_name));

    const circleWorkforce = {
      emc: {
        circleName: 'EMC Circle',
        totalCount: emcEmployees.length,
        totalNetPayable: emcEmployees.reduce((acc, curr) => acc + Number(curr.net_payable || 0), 0),
        totalBasic: emcEmployees.reduce((acc, curr) => acc + Number(curr.total_basic || 0), 0),
        totalGross: emcEmployees.reduce((acc, curr) => acc + (Number(curr.total_earnings_before_bonus || 0) + Number(curr.bonus || 0)), 0),
        totalEmployeeDeductions: emcEmployees.reduce((acc, curr) => acc + Number(curr.total_employee_deductions || 0), 0),
        totalEmployeeEpf: emcEmployees.reduce((acc, curr) => acc + Number(curr.employee_epf_12 || 0), 0),
        totalEmployeeEsi: emcEmployees.reduce((acc, curr) => acc + Number(curr.employee_esi_075 || 0), 0),
        totalEmployeeLwf: emcEmployees.reduce((acc, curr) => acc + Number(curr.employee_lwf || 0), 0),
        employees: emcEmployees
      },
      mm1: {
        circleName: 'MM-1 Circle',
        totalCount: mm1Employees.length,
        totalNetPayable: mm1Employees.reduce((acc, curr) => acc + Number(curr.net_payable || 0), 0),
        totalBasic: mm1Employees.reduce((acc, curr) => acc + Number(curr.total_basic || 0), 0),
        totalGross: mm1Employees.reduce((acc, curr) => acc + (Number(curr.total_earnings_before_bonus || 0) + Number(curr.bonus || 0)), 0),
        totalEmployeeDeductions: mm1Employees.reduce((acc, curr) => acc + Number(curr.total_employee_deductions || 0), 0),
        totalEmployeeEpf: mm1Employees.reduce((acc, curr) => acc + Number(curr.employee_epf_12 || 0), 0),
        totalEmployeeEsi: mm1Employees.reduce((acc, curr) => acc + Number(curr.employee_esi_075 || 0), 0),
        totalEmployeeLwf: mm1Employees.reduce((acc, curr) => acc + Number(curr.employee_lwf || 0), 0),
        employees: mm1Employees
      },
      allCircles: Object.values(circlesMap)
    };

    // 5. Employees by Designation with individualized statutory deductions
    const designationMap: {
      [key: string]: {
        designation: string;
        alias: string;
        count: number;
        totalNetPayable: number;
        totalEmployeeDeductions: number;
        totalEmployeeEpf: number;
        totalEmployeeEsi: number;
        totalEmployeeLwf: number;
        employees: any[];
      };
    } = {};
    for (const emp of allEmployees) {
      const desName = emp.designation_name || 'Unassigned';
      if (!designationMap[desName]) {
        designationMap[desName] = {
          designation: desName,
          alias: emp.designation_alias || 'SW',
          count: 0,
          totalNetPayable: 0,
          totalEmployeeDeductions: 0,
          totalEmployeeEpf: 0,
          totalEmployeeEsi: 0,
          totalEmployeeLwf: 0,
          employees: []
        };
      }
      designationMap[desName].count++;
      designationMap[desName].totalNetPayable += Number(emp.net_payable || 0);
      designationMap[desName].totalEmployeeDeductions += Number(emp.total_employee_deductions || 0);
      designationMap[desName].totalEmployeeEpf += Number(emp.employee_epf_12 || 0);
      designationMap[desName].totalEmployeeEsi += Number(emp.employee_esi_075 || 0);
      designationMap[desName].totalEmployeeLwf += Number(emp.employee_lwf || 0);
      designationMap[desName].employees.push(emp);
    }
    const employeesByDesignation = Object.values(designationMap).sort((a, b) => b.count - a.count);

    // 6. Employees by Contractor with individualized statutory deductions
    const contractorMap: {
      [key: string]: {
        id: number;
        contractor: string;
        count: number;
        totalNetPayable: number;
        totalEmployeeDeductions: number;
        totalEmployeeEpf: number;
        totalEmployeeEsi: number;
        totalEmployeeLwf: number;
        employees: any[];
      };
    } = {};
    for (const emp of allEmployees) {
      const cName = emp.contractor_name || 'Direct / Others';
      if (!contractorMap[cName]) {
        contractorMap[cName] = {
          id: emp.contractor_id || 0,
          contractor: cName,
          count: 0,
          totalNetPayable: 0,
          totalEmployeeDeductions: 0,
          totalEmployeeEpf: 0,
          totalEmployeeEsi: 0,
          totalEmployeeLwf: 0,
          employees: []
        };
      }
      contractorMap[cName].count++;
      contractorMap[cName].totalNetPayable += Number(emp.net_payable || 0);
      contractorMap[cName].totalEmployeeDeductions += Number(emp.total_employee_deductions || 0);
      contractorMap[cName].totalEmployeeEpf += Number(emp.employee_epf_12 || 0);
      contractorMap[cName].totalEmployeeEsi += Number(emp.employee_esi_075 || 0);
      contractorMap[cName].totalEmployeeLwf += Number(emp.employee_lwf || 0);
      contractorMap[cName].employees.push(emp);
    }
    const employeesByContractor = Object.values(contractorMap).sort((a, b) => b.count - a.count);

    // 7. Circles summary list
    let circleWhere = 'WHERE e.is_active = TRUE AND e.archived_at IS NULL';
    const circleParams: any[] = [];
    if (targetUserId) {
      circleWhere += ' AND (e.owner_user_id = $1 OR e.created_by_user_id = $1)';
      circleParams.push(targetUserId);
    }
    const circleRes = await db.query(`
      SELECT COALESCE(cir.name, 'General Circle') as circle, COUNT(e.id) as count
      FROM employees e
      LEFT JOIN circles cir ON e.circle_id = cir.id
      ${circleWhere}
      GROUP BY cir.name
      ORDER BY count DESC;
    `, circleParams);

    // 8. Overall Payroll Stats with individual EPF, ESI, LWF totals
    let payrollStats = {
      periodId: periodRow ? periodRow.id : null,
      periodName: periodRow ? `${periodRow.month_name} ${periodRow.year}` : 'No Period',
      status: periodRow ? periodRow.status : 'None',
      totalEmployeesPaid: 0,
      totalGrossEarnings: 0,
      totalEmployerEpf12: 0,
      totalEmployerEpf1: 0,
      totalEmployerEsi325: 0,
      totalEmployerLwf: 0,
      totalEmployeeEpf: 0,
      totalEmployeeEsi: 0,
      totalEmployeeLwf: 0,
      totalEmployeeDeductions: 0,
      totalCombinedDeductions: 0,
      totalNetPayable: 0,
      totalEmployerCost: 0
    };

    if (periodRow) {
      let pWhere = 'WHERE payroll_period_id = $1';
      const pParams: any[] = [periodRow.id];
      if (targetUserId) {
        pWhere += ' AND (owner_user_id = $2 OR created_by_user_id = $2)';
        pParams.push(targetUserId);
      }
      const pStatsRes = await db.query(`
        SELECT 
          COUNT(*) as total_entries,
          COALESCE(SUM(total_earnings_before_bonus + bonus), 0) as gross_earnings,
          COALESCE(SUM(employer_epf_12), 0) as emp_epf12,
          COALESCE(SUM(employer_epf_1), 0) as emp_epf1,
          COALESCE(SUM(employer_esi_325), 0) as emp_esi325,
          COALESCE(SUM(employer_lwf), 0) as emp_lwf,
          COALESCE(SUM(employee_epf_12), 0) as ded_epf12,
          COALESCE(SUM(employee_esi_075), 0) as ded_esi075,
          COALESCE(SUM(employee_lwf), 0) as ded_lwf,
          COALESCE(SUM(total_employee_deductions), 0) as employee_deductions,
          COALESCE(SUM(total_employer_contributions), 0) as employer_contributions,
          COALESCE(SUM(combined_deductions), 0) as combined_deductions,
          COALESCE(SUM(net_payable), 0) as net_payable
        FROM payroll_entries
        ${pWhere};
      `, pParams);

      const ps = pStatsRes.rows[0];
      payrollStats.totalEmployeesPaid = Number(ps.total_entries) || 0;
      payrollStats.totalGrossEarnings = Number(ps.gross_earnings) || 0;
      payrollStats.totalEmployerEpf12 = Number(ps.emp_epf12) || 0;
      payrollStats.totalEmployerEpf1 = Number(ps.emp_epf1) || 0;
      payrollStats.totalEmployerEsi325 = Number(ps.emp_esi325) || 0;
      payrollStats.totalEmployerLwf = Number(ps.emp_lwf) || 0;
      payrollStats.totalEmployeeEpf = Number(ps.ded_epf12) || 0;
      payrollStats.totalEmployeeEsi = Number(ps.ded_esi075) || 0;
      payrollStats.totalEmployeeLwf = Number(ps.ded_lwf) || 0;
      payrollStats.totalEmployeeDeductions = Number(ps.employee_deductions) || 0;
      payrollStats.totalCombinedDeductions = Number(ps.combined_deductions) || 0;
      payrollStats.totalNetPayable = Number(ps.net_payable) || 0;
      payrollStats.totalEmployerCost = payrollStats.totalGrossEarnings + Number(ps.employer_contributions);
    }

    // 9. Recent audit activity
    let auditWhere = 'WHERE 1=1';
    const auditParams: any[] = [];
    if (targetUserId) {
      auditWhere += ' AND (owner_user_id = $1 OR user_name IN (SELECT username FROM users WHERE id = $1))';
      auditParams.push(targetUserId);
    }
    const auditRes = await db.query(`
      SELECT user_name, action, entity_type, details, created_at
      FROM audit_logs
      ${auditWhere}
      ORDER BY created_at DESC
      LIMIT 8;
    `, auditParams);

    res.json({
      employeeOverview: empCountsRes.rows[0],
      employeesByDesignation,
      employeesByContractor,
      employeesByCircle: circleRes.rows,
      circleWorkforce,
      payrollStats,
      recentActivity: auditRes.rows
    });
  } catch (err: any) {
    console.error('Dashboard error:', err);
    res.status(500).json({ error: err.message || 'Failed to fetch dashboard stats' });
  }
});

export default router;
