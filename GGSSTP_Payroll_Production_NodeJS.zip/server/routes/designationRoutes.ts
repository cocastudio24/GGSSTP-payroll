import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();

// GET /api/designations (Plant-wide designations and active rates)
router.get('/', authMiddleware, async (_req: AuthRequest, res) => {
  try {
    const desRes = await db.query(`
      SELECT 
        d.id, d.name, d.alias, d.is_active, d.created_at,
        dsr.id as rate_id, dsr.gross_salary_rate, dsr.special_allowance,
        dsr.thermal_allowance, dsr.perf_allowance_default, dsr.effective_from,
        (SELECT COUNT(*) FROM employees e WHERE e.designation_id = d.id AND e.is_active = TRUE) as employee_count
      FROM designations d
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE d.is_active = TRUE
      ORDER BY d.id ASC;
    `);

    res.json({ designations: desRes.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/designations
router.post('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const { name, alias, grossSalaryRate, specialAllowance, thermalAllowance, perfAllowanceDefault } = req.body;
    if (!name || !alias) {
      return res.status(400).json({ error: 'Designation Name and Alias are required' });
    }

    const insDes = await db.query(`
      INSERT INTO designations (owner_user_id, name, alias) VALUES ($1, $2, $3) RETURNING *;
    `, [userId, name.trim(), alias.trim().toUpperCase()]);

    const desId = insDes.rows[0].id;

    await db.query(`
      INSERT INTO designation_salary_rates 
      (owner_user_id, designation_id, gross_salary_rate, special_allowance, thermal_allowance, perf_allowance_default)
      VALUES ($1, $2, $3, $4, $5, $6);
    `, [
      userId,
      desId,
      Number(grossSalaryRate) || 0,
      Number(specialAllowance) || 0,
      Number(thermalAllowance) || 1500,
      Number(perfAllowanceDefault) || 225
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'CREATE_DESIGNATION', 'DESIGNATION', $2, $3, $4);
    `, [req.user?.username || 'admin', String(desId), `Created designation ${name} (${alias})`, userId]);

    res.status(201).json({ message: 'Designation created successfully', designation: insDes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/designations/:id/rates
router.put('/:id/rates', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const { grossSalaryRate, specialAllowance, thermalAllowance, perfAllowanceDefault, effectiveFrom } = req.body;

    // Verify designation exists
    const desCheck = await db.query(
      `SELECT id FROM designations WHERE id = $1;`,
      [Number(id)]
    );
    if (desCheck.rows.length === 0) return res.status(404).json({ error: 'Designation not found' });

    // Deactivate previous rate
    await db.query(`
      UPDATE designation_salary_rates SET is_active = FALSE, effective_to = CURRENT_DATE
      WHERE designation_id = $1 AND is_active = TRUE;
    `, [Number(id)]);

    // Insert new rate record with effective date
    const newRate = await db.query(`
      INSERT INTO designation_salary_rates (
        owner_user_id, designation_id, gross_salary_rate, special_allowance, thermal_allowance,
        perf_allowance_default, effective_from, is_active
      ) VALUES (1, $1, $2, $3, $4, $5, COALESCE($6, CURRENT_DATE), TRUE)
      RETURNING *;
    `, [
      Number(id),
      Number(grossSalaryRate),
      Number(specialAllowance),
      Number(thermalAllowance) || 1500,
      Number(perfAllowanceDefault) || 225,
      effectiveFrom || null
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'UPDATE_DESIGNATION_RATES', 'DESIGNATION', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Updated rates: Gross ₹${grossSalaryRate}, Spl ₹${specialAllowance}`, userId]);

    res.json({ message: 'Rates updated successfully', rate: newRate.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
