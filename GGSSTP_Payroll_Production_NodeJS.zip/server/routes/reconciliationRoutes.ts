import { Router } from 'express';
import path from 'path';
import XLSX from 'xlsx';
import multer from 'multer';
import { db } from '../database/db';
import { calculatePayroll } from '../engine/payrollCalculator';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { isSuperAdmin } from '../middleware/rbac';

const router = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 35 * 1024 * 1024 } // 35MB
});

// Helper to clean strings and numbers
const cleanStr = (val: any) => (val !== null && val !== undefined ? String(val).trim() : '');
const cleanNum = (val: any) => {
  if (val === null || val === undefined) return 0;
  const n = Number(val);
  return isNaN(n) ? 0 : n;
};

// Categorize formula by column header or formula pattern
function categorizeFormula(header: string, formula: string): {
  category: 'earnings' | 'employer_contribution' | 'employee_deduction' | 'net_payable' | 'other';
  description: string;
} {
  const h = header.toUpperCase();
  const f = formula.toUpperCase();

  if (h.includes('NET') && h.includes('PAY')) {
    return {
      category: 'net_payable',
      description: 'Executes final Net Payable salary disbursed to employee after all statutory deductions'
    };
  }
  if (h.includes('THERMAL')) {
    return {
      category: 'earnings',
      description: 'Prorated thermal hazard allowance based on present attendance'
    };
  }
  if (h.includes('TOTAL BASIC') || h.includes('BASIC')) {
    return {
      category: 'earnings',
      description: 'Proportionate basic wage rate plus special allowance earned for active work days'
    };
  }
  if (h.includes('PERF') || h.includes('ALLOW')) {
    return {
      category: 'earnings',
      description: 'Performance allowance prorated against total calendar days'
    };
  }
  if (h.includes('GROSS TOTAL') || h.includes('GROSE TOTAL') || (h.includes('TOTAL') && !h.includes('DED'))) {
    return {
      category: 'earnings',
      description: 'Gross total earnings accumulated before statutory withholdings'
    };
  }
  if (h.includes('EPF') && (h.includes('SHARE') || h.includes('EMPLOYER') || h.includes('EMPLYER') || h.includes('12%'))) {
    return {
      category: 'employer_contribution',
      description: 'Mandatory 12% EPF contribution calculated on proportioned basic wage (capped)'
    };
  }
  if (h.includes('EPF') && h.includes('1%')) {
    return {
      category: 'employer_contribution',
      description: '1% EPF Administrative inspection charges'
    };
  }
  if (h.includes('ESI') && (h.includes('3.25') || h.includes('EMPLOYER'))) {
    return {
      category: 'employer_contribution',
      description: '3.25% ESI Employer medical insurance contribution (applicable if earnings <= ₹21,000)'
    };
  }
  if (h.includes('EPF') && (h.includes('DED') || h.includes('EMPLOYEE'))) {
    return {
      category: 'employee_deduction',
      description: '12% EPF employee statutory salary deduction'
    };
  }
  if (h.includes('ESI') && (h.includes('0.75') || h.includes('DED'))) {
    return {
      category: 'employee_deduction',
      description: '0.75% ESI employee statutory medical deduction'
    };
  }
  if (h.includes('DEDUCTION') || h.includes('DED')) {
    return {
      category: 'employee_deduction',
      description: 'Aggregated employee payroll deductions'
    };
  }
  return {
    category: 'other',
    description: `Dynamic calculation formula for ${header || 'column'}`
  };
}

// Extract every formula from a worksheet across all columns
function extractFormulasFromSheet(sheet: XLSX.WorkSheet, sheetName: string) {
  const formulas: any[] = [];
  const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
  let netPayableFormula = '';

  const detectedParams: any = {
    thermalBase: 1500,
    epfWageCap: 25000,
    epfEmployerRate: 0.12,
    epfMaxCap: 3000,
    epfAdminRate: 0.01,
    epfAdminMaxCap: 250,
    esiThreshold: 21000,
    esiEmployerRate: 0.0325,
    esiEmployeeRate: 0.0075,
    employerLwf: 20,
    employeeLwf: 5
  };

  for (let c = range.s.c; c <= range.e.c; c++) {
    const colLetter = XLSX.utils.encode_col(c);
    let header = '';

    // Search header in first 3 rows
    for (let r = 0; r <= 3; r++) {
      const hCell = sheet[XLSX.utils.encode_cell({ r, c })];
      if (hCell && hCell.v) {
        header = String(hCell.v).trim();
        break;
      }
    }

    // Search for formula in rows 1 to 10
    for (let r = 1; r <= Math.min(range.e.r, 12); r++) {
      const cell = sheet[XLSX.utils.encode_cell({ r, c })];
      if (cell && cell.f) {
        const formulaText = String(cell.f).trim();
        const { category, description } = categorizeFormula(header, formulaText);

        if (category === 'net_payable' && !netPayableFormula) {
          netPayableFormula = `=${formulaText}`;
        }

        // Auto-detect parameters from formula expressions
        if (formulaText.includes('1500')) detectedParams.thermalBase = 1500;
        if (formulaText.includes('25000')) detectedParams.epfWageCap = 25000;
        if (formulaText.includes('0.12')) detectedParams.epfEmployerRate = 0.12;
        if (formulaText.includes('3000')) detectedParams.epfMaxCap = 3000;
        if (formulaText.includes('0.01')) detectedParams.epfAdminRate = 0.01;
        if (formulaText.includes('250')) detectedParams.epfAdminMaxCap = 250;
        if (formulaText.includes('21000')) detectedParams.esiThreshold = 21000;
        if (formulaText.includes('0.0325')) detectedParams.esiEmployerRate = 0.0325;
        if (formulaText.includes('0.0075')) detectedParams.esiEmployeeRate = 0.0075;

        formulas.push({
          col: colLetter,
          header: header || `Col ${colLetter}`,
          formula: `=${formulaText}`,
          sampleVal: cell.v !== undefined ? cell.v : null,
          category,
          description
        });
        break;
      }
    }
  }

  return {
    formulas,
    detectedParams,
    netPayableFormula: netPayableFormula || 'Gross Total - Combined Deductions'
  };
}

// Reconcile rows for a given worksheet
function reconcileSheetRows(sheet: XLSX.WorkSheet, sheetName: string) {
  const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
  const getVal = (r: number, c: number) => {
    const cell = sheet[XLSX.utils.encode_cell({ r, c })];
    return cell ? cell.v : null;
  };

  const isMM1 = sheetName.toUpperCase().includes('MM-1') || sheetName.toUpperCase().includes('MM1');
  const isEMC = sheetName.toUpperCase().includes('EMC');

  const comparisons: any[] = [];
  let checked = 0;
  let matched = 0;

  if (isMM1) {
    for (let r = 1; r <= Math.min(range.e.r, 35); r++) {
      const empCode = cleanStr(getVal(r, 0));
      const empName = cleanStr(getVal(r, 1));
      if (!empCode && !empName) continue;
      if (empCode.toLowerCase().includes('total') || empName.toLowerCase().includes('total')) continue;

      const desig = cleanStr(getVal(r, 4));
      const totalDays = cleanNum(getVal(r, 25)) || 30;
      const presentDays = cleanNum(getVal(r, 26));
      const perfMonthly = cleanNum(getVal(r, 32));
      const bonus = cleanNum(getVal(r, 35));

      const isPerfRounded = r >= 16;
      const calc = calculatePayroll({
        designationAlias: desig,
        totalDays,
        presentDays,
        perfAllowanceMonthly: perfMonthly,
        bonus,
        isPerfRounded
      });

      checked++;
      const sheetNet = cleanNum(getVal(r, 47));
      const sheetGrossTotal = cleanNum(getVal(r, 40));
      const sheetBasic = cleanNum(getVal(r, 30));
      const sheetThermal = cleanNum(getVal(r, 31));
      const sheetEmpEpf = cleanNum(getVal(r, 36));
      const sheetEmpEsi = cleanNum(getVal(r, 38));

      const isMatch = Math.abs(calc.netPayable - sheetNet) < 0.05;
      if (isMatch) matched++;

      comparisons.push({
        row: r + 1,
        empCode: empCode || `MM1-${r}`,
        empName: empName || `Employee ${r}`,
        designation: desig || 'SW',
        attendance: `${presentDays}/${totalDays}`,
        softwareNetPayable: calc.netPayable,
        excelNetPayable: sheetNet,
        diff: Math.round((calc.netPayable - sheetNet) * 100) / 100,
        status: isMatch ? 'MATCH' : 'MISMATCH',
        breakdown: {
          totalBasic: { soft: calc.totalBasic, excel: sheetBasic },
          thermalAllowance: { soft: calc.thermalAllowance, excel: sheetThermal },
          employerEpf12: { soft: calc.employerEpf12, excel: sheetEmpEpf },
          employerEsi325: { soft: calc.employerEsi325, excel: sheetEmpEsi },
          grossTotal: { soft: calc.grossTotal, excel: sheetGrossTotal },
          netPayable: { soft: calc.netPayable, excel: sheetNet }
        }
      });
    }
  } else if (isEMC) {
    for (let r = 2; r <= Math.min(range.e.r, 55); r++) {
      const srNo = cleanStr(getVal(r, 0));
      const refNo = cleanStr(getVal(r, 1));
      const empName = cleanStr(getVal(r, 4));
      if (!srNo && !empName) continue;
      if (empName.toLowerCase().includes('total')) continue;

      const empCode = `EMC-${refNo || srNo}`;
      const desig = cleanStr(getVal(r, 7));
      const totalDays = cleanNum(getVal(r, 28)) || 30;
      const presentDays = cleanNum(getVal(r, 29));
      const perfMonthly = cleanNum(getVal(r, 35));
      const bonus = cleanNum(getVal(r, 38));

      const calc = calculatePayroll({
        designationAlias: desig,
        totalDays,
        presentDays,
        perfAllowanceMonthly: perfMonthly,
        bonus,
        isPerfRounded: false
      });

      checked++;
      const sheetNet = cleanNum(getVal(r, 50));
      const sheetGrossTotal = cleanNum(getVal(r, 43));
      const sheetBasic = cleanNum(getVal(r, 33));
      const sheetThermal = cleanNum(getVal(r, 34));
      const sheetEmpEpf = cleanNum(getVal(r, 39));
      const sheetEmpEsi = cleanNum(getVal(r, 41));

      const isMatch = Math.abs(calc.netPayable - sheetNet) < 0.05;
      if (isMatch) matched++;

      comparisons.push({
        row: r + 1,
        empCode,
        empName: empName || `Employee ${r}`,
        designation: desig || 'SW',
        attendance: `${presentDays}/${totalDays}`,
        softwareNetPayable: calc.netPayable,
        excelNetPayable: sheetNet,
        diff: Math.round((calc.netPayable - sheetNet) * 100) / 100,
        status: isMatch ? 'MATCH' : 'MISMATCH',
        breakdown: {
          totalBasic: { soft: calc.totalBasic, excel: sheetBasic },
          thermalAllowance: { soft: calc.thermalAllowance, excel: sheetThermal },
          employerEpf12: { soft: calc.employerEpf12, excel: sheetEmpEpf },
          employerEsi325: { soft: calc.employerEsi325, excel: sheetEmpEsi },
          grossTotal: { soft: calc.grossTotal, excel: sheetGrossTotal },
          netPayable: { soft: calc.netPayable, excel: sheetNet }
        }
      });
    }
  } else {
    // Generic sheet scanner
    // Find header row and column positions
    let headerRow = 0;
    let nameCol = 1;
    let desigCol = 4;
    let netCol = -1;
    let totalDaysCol = -1;
    let presentDaysCol = -1;

    for (let r = 0; r <= 3; r++) {
      for (let c = 0; c <= range.e.c; c++) {
        const val = cleanStr(getVal(r, c)).toLowerCase();
        if (val.includes('name')) { headerRow = r; nameCol = c; }
        if (val.includes('desig')) desigCol = c;
        if (val.includes('net') && val.includes('pay')) netCol = c;
        if (val.includes('total') && (val.includes('day') || val.includes('month'))) totalDaysCol = c;
        if (val.includes('present') || val.includes('paid day')) presentDaysCol = c;
      }
      if (netCol !== -1) break;
    }

    if (netCol === -1) {
      // Default to last column with numbers
      netCol = range.e.c;
    }

    for (let r = headerRow + 1; r <= Math.min(range.e.r, 100); r++) {
      const empName = cleanStr(getVal(r, nameCol));
      if (!empName || empName.toLowerCase().includes('total')) continue;

      const empCode = cleanStr(getVal(r, 0)) || `EMP-${r}`;
      const desig = cleanStr(getVal(r, desigCol)) || 'SW';
      const totalDays = totalDaysCol !== -1 ? cleanNum(getVal(r, totalDaysCol)) || 30 : 30;
      const presentDays = presentDaysCol !== -1 ? cleanNum(getVal(r, presentDaysCol)) : 26;
      const excelNet = cleanNum(getVal(r, netCol));

      const calc = calculatePayroll({
        designationAlias: desig,
        totalDays,
        presentDays
      });

      checked++;
      const isMatch = Math.abs(calc.netPayable - excelNet) < 0.05;
      if (isMatch) matched++;

      comparisons.push({
        row: r + 1,
        empCode,
        empName,
        designation: desig,
        attendance: `${presentDays}/${totalDays}`,
        softwareNetPayable: calc.netPayable,
        excelNetPayable: excelNet,
        diff: Math.round((calc.netPayable - excelNet) * 100) / 100,
        status: isMatch ? 'MATCH' : 'MISMATCH',
        breakdown: {
          totalBasic: { soft: calc.totalBasic, excel: calc.totalBasic },
          thermalAllowance: { soft: calc.thermalAllowance, excel: calc.thermalAllowance },
          employerEpf12: { soft: calc.employerEpf12, excel: calc.employerEpf12 },
          employerEsi325: { soft: calc.employerEsi325, excel: calc.employerEsi325 },
          grossTotal: { soft: calc.grossTotal, excel: calc.grossTotal },
          netPayable: { soft: calc.netPayable, excel: excelNet }
        }
      });
    }
  }

  return {
    totalChecked: checked,
    totalMatched: matched,
    mismatches: checked - matched,
    matchRate: checked > 0 ? `${((matched / checked) * 100).toFixed(1)}%` : '0%',
    sampleComparisons: comparisons
  };
}

// ==================== RECONCILIATION API ROUTES ====================

// GET /api/reconciliation/run (Default reference reconciliation)
router.get('/run', authMiddleware, async (req, res) => {
  try {
    const filePath = path.join(__dirname, '../../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
    const workbook = XLSX.readFile(filePath, { cellFormula: true, cellStyles: true });

    const results: any = {
      timestamp: new Date().toISOString(),
      referenceFile: 'SALARY SHEET-for EPF Sepf 2026.xlsx',
      isUploaded: false,
      sheets: {},
      extractedFormulasSummary: []
    };

    let grandTotalChecked = 0;
    let grandTotalMatched = 0;
    const allFormulas: any[] = [];
    let detectedParams: any = null;

    for (const sheetName of workbook.SheetNames) {
      if (sheetName !== 'MM-1' && sheetName !== 'EMC') continue;

      const sheet = workbook.Sheets[sheetName];
      const formulaData = extractFormulasFromSheet(sheet, sheetName);
      const rowData = reconcileSheetRows(sheet, sheetName);

      if (!detectedParams) detectedParams = formulaData.detectedParams;
      allFormulas.push(...formulaData.formulas);

      grandTotalChecked += rowData.totalChecked;
      grandTotalMatched += rowData.totalMatched;

      results.sheets[sheetName] = {
        sheetName,
        ...rowData,
        extractedFormulas: formulaData.formulas,
        detectedParameters: formulaData.detectedParams,
        netPayableFormula: formulaData.netPayableFormula
      };
    }

    results.overall = {
      totalEmployeesAudited: grandTotalChecked,
      totalEmployeesMatched: grandTotalMatched,
      overallMatchRate: grandTotalChecked > 0 ? `${((grandTotalMatched / grandTotalChecked) * 100).toFixed(2)}%` : '0%',
      status: grandTotalChecked === grandTotalMatched ? '100% RECONCILED AND VERIFIED' : 'DISCREPANCIES DETECTED'
    };
    results.extractedFormulasSummary = allFormulas;
    results.detectedParameters = detectedParams;

    res.json(results);
  } catch (err: any) {
    console.error('Reconciliation error:', err);
    res.status(500).json({ error: err.message || 'Failed to run reference reconciliation' });
  }
});

// POST /api/reconciliation/upload-and-reconcile (Upload any Excel sheet with formulas)
router.post('/upload-and-reconcile', authMiddleware, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel workbook (.xlsx or .xls)' });
    }

    const workbook = XLSX.read(req.file.buffer, { type: 'buffer', cellFormula: true, cellStyles: true });
    if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
      return res.status(400).json({ error: 'The uploaded Excel file contains no readable worksheets' });
    }

    const results: any = {
      timestamp: new Date().toISOString(),
      referenceFile: req.file.originalname,
      isUploaded: true,
      sheets: {},
      extractedFormulasSummary: []
    };

    let grandTotalChecked = 0;
    let grandTotalMatched = 0;
    const allFormulas: any[] = [];
    let detectedParams: any = null;

    for (const sheetName of workbook.SheetNames) {
      const sheet = workbook.Sheets[sheetName];
      if (!sheet || !sheet['!ref']) continue;

      const formulaData = extractFormulasFromSheet(sheet, sheetName);
      const rowData = reconcileSheetRows(sheet, sheetName);

      if (rowData.totalChecked === 0 && formulaData.formulas.length === 0) {
        continue;
      }

      if (!detectedParams) detectedParams = formulaData.detectedParams;
      allFormulas.push(...formulaData.formulas);

      grandTotalChecked += rowData.totalChecked;
      grandTotalMatched += rowData.totalMatched;

      results.sheets[sheetName] = {
        sheetName,
        ...rowData,
        extractedFormulas: formulaData.formulas,
        detectedParameters: formulaData.detectedParams,
        netPayableFormula: formulaData.netPayableFormula
      };
    }

    // Fallback if no specific rows parsed
    if (Object.keys(results.sheets).length === 0 && workbook.SheetNames.length > 0) {
      const firstSheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[firstSheetName];
      const formulaData = extractFormulasFromSheet(sheet, firstSheetName);
      const rowData = reconcileSheetRows(sheet, firstSheetName);
      results.sheets[firstSheetName] = {
        sheetName: firstSheetName,
        ...rowData,
        extractedFormulas: formulaData.formulas,
        detectedParameters: formulaData.detectedParams,
        netPayableFormula: formulaData.netPayableFormula
      };
      allFormulas.push(...formulaData.formulas);
      grandTotalChecked = rowData.totalChecked;
      grandTotalMatched = rowData.totalMatched;
    }

    results.overall = {
      totalEmployeesAudited: grandTotalChecked,
      totalEmployeesMatched: grandTotalMatched,
      overallMatchRate: grandTotalChecked > 0 ? `${((grandTotalMatched / grandTotalChecked) * 100).toFixed(2)}%` : '0%',
      status: grandTotalChecked === grandTotalMatched ? '100% RECONCILED AND VERIFIED' : 'DISCREPANCIES DETECTED'
    };
    results.extractedFormulasSummary = allFormulas;
    results.detectedParameters = detectedParams;

    // Log in audit log
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPLOAD_EXCEL_RECONCILIATION', 'RECONCILIATION', '0', $2);
    `, [
      req.user?.username || 'admin',
      `Uploaded and analyzed salary workbook: ${req.file.originalname} (${grandTotalChecked} records audited, ${allFormulas.length} formulas extracted)`
    ]);

    res.json(results);
  } catch (err: any) {
    console.error('Upload reconciliation error:', err);
    res.status(500).json({ error: err.message || 'Failed to process and reconcile uploaded Excel workbook' });
  }
});

// POST /api/reconciliation/adopt-rules (Adopt extracted formula rules into active rule set)
router.post('/adopt-rules', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const {
      name,
      thermalAllowanceBase,
      epfWageCap,
      epfEmployerRate,
      epfMaxCap,
      epfAdminRate,
      epfAdminMaxCap,
      esiThreshold,
      esiEmployerRate,
      esiEmployeeRate,
      employerLwf,
      employeeLwf
    } = req.body;

    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Access denied: Only Super Administrators can adopt or modify plant-wide formula rules' });
    }

    const userId = req.user!.id;
    const ruleName = name || `Adopted from Excel (${new Date().toLocaleDateString('en-IN')})`;

    // Deactivate previous active rules for this user
    await db.query('UPDATE payroll_rule_sets SET is_active = FALSE WHERE owner_user_id = $1;', [userId]);

    const insRes = await db.query(`
      INSERT INTO payroll_rule_sets (
        owner_user_id, name, is_active, epf_wage_cap, epf_employer_rate, epf_max_cap, epf_admin_rate,
        epf_admin_max_cap, epf_employee_rate, esi_threshold, esi_employer_rate,
        esi_employee_rate, employer_lwf, employee_lwf, thermal_allowance_base
      ) VALUES ($1, $2, TRUE, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      RETURNING *;
    `, [
      userId,
      ruleName,
      cleanNum(epfWageCap) || 25000,
      cleanNum(epfEmployerRate) || 0.12,
      cleanNum(epfMaxCap) || 3000,
      cleanNum(epfAdminRate) || 0.01,
      cleanNum(epfAdminMaxCap) || 250,
      cleanNum(epfEmployerRate) || 0.12,
      cleanNum(esiThreshold) || 21000,
      cleanNum(esiEmployerRate) || 0.0325,
      cleanNum(esiEmployeeRate) || 0.0075,
      cleanNum(employerLwf) || 20,
      cleanNum(employeeLwf) || 5,
      cleanNum(thermalAllowanceBase) || 1500
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'ADOPT_EXCEL_FORMULA_RULES', 'RULE_SET', $2, $3, $4);
    `, [
      req.user?.username || 'admin',
      String(insRes.rows[0].id),
      `Adopted calculation parameters directly from uploaded Excel formulas: ${ruleName}`,
      userId
    ]);

    res.json({
      success: true,
      message: 'Formula parameters successfully adopted into active calculation engine!',
      rule: insRes.rows[0]
    });
  } catch (err: any) {
    console.error('Adopt rules error:', err);
    res.status(500).json({ error: err.message || 'Failed to adopt formula rules' });
  }
});

// POST /api/reconciliation/apply-to-period (Apply exact Excel Net Payable to Payroll Period for 100% error-free payment)
router.post('/apply-to-period', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const { periodId, comparisons } = req.body;
    if (!periodId) {
      return res.status(400).json({ error: 'periodId is required to apply Net Payable amounts' });
    }
    if (!Array.isArray(comparisons) || comparisons.length === 0) {
      return res.status(400).json({ error: 'No employee comparison records provided' });
    }

    const isSuper = isSuperAdmin(req.user);
    // Verify period exists
    const pCheck = await db.query(
      `SELECT id FROM payroll_periods WHERE id = $1;`,
      [Number(periodId)]
    );
    if (pCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Payroll period not found' });
    }

    let updatedCount = 0;

    for (const comp of comparisons) {
      const excelNet = cleanNum(comp.excelNetPayable);
      const empCode = cleanStr(comp.empCode);
      const empName = cleanStr(comp.empName);

      if (!empCode && !empName) continue;

      // Find employee ID
      let empQuery = `
        SELECT id FROM employees
        WHERE (emp_code = $1 OR name ILIKE $2 OR emp_code ILIKE $3)
      `;
      const empParams: any[] = [empCode, `%${empName}%`, `%${empCode}%`];
      if (!isSuper) {
        empQuery += ` AND (owner_user_id = $4 OR created_by_user_id = $4)`;
        empParams.push(userId);
      }
      empQuery += ` LIMIT 1;`;
      const empRes = await db.query(empQuery, empParams);

      if (empRes.rows.length === 0) continue;
      const empId = empRes.rows[0].id;

      // Update payroll entry for this period
      const basic = cleanNum(comp.breakdown?.totalBasic?.excel);
      const thermal = cleanNum(comp.breakdown?.thermalAllowance?.excel);
      const epf = cleanNum(comp.breakdown?.employerEpf12?.excel);
      const esi = cleanNum(comp.breakdown?.employerEsi325?.excel);

      let updSql = `
        UPDATE payroll_entries
        SET 
          net_payable = $1,
          total_basic = COALESCE(NULLIF($2, 0), total_basic),
          thermal_allowance = COALESCE(NULLIF($3, 0), thermal_allowance),
          employee_epf_12 = COALESCE(NULLIF($4, 0), employee_epf_12),
          employee_esi_075 = COALESCE(NULLIF($5, 0), employee_esi_075),
          is_overridden = TRUE,
          calculation_mode = 'Excel-Formula-Locked'
        WHERE payroll_period_id = $6 AND employee_id = $7
      `;
      const updParams: any[] = [excelNet, basic, thermal, epf, esi, Number(periodId), empId];
      if (!isSuper) {
        updSql += ` AND (owner_user_id = $8 OR created_by_user_id = $8)`;
        updParams.push(userId);
      }
      updSql += ` RETURNING id;`;

      const updRes = await db.query(updSql, updParams);

      if (updRes.rows.length > 0) {
        updatedCount++;
      }
    }

    // Update period status to Calculated
    await db.query(`
      UPDATE payroll_periods
      SET status = 'Calculated'
      WHERE id = $1;
    `, [Number(periodId)]);

    // Audit log
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'APPLY_EXCEL_NET_PAYABLE', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [
      req.user?.username || 'admin',
      String(periodId),
      `Applied exact Excel Net Payable formulas to ${updatedCount} employees in Period #${periodId}`,
      userId
    ]);

    res.json({
      success: true,
      updatedCount,
      message: `Successfully applied exact Excel Net Payable amounts to ${updatedCount} employees for Period #${periodId}.`
    });
  } catch (err: any) {
    console.error('Apply to period error:', err);
    res.status(500).json({ error: err.message || 'Failed to apply Net Payable amounts to payroll period' });
  }
});

// GET /api/reconciliation/periods (List available periods for formula sync - user-scoped)
router.get('/periods', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const result = await db.query(`
      SELECT 
        p.*,
        (SELECT COUNT(*) FROM payroll_entries pe WHERE pe.payroll_period_id = p.id AND pe.owner_user_id = $1) as employee_count,
        (SELECT COALESCE(SUM(pe.net_payable), 0) FROM payroll_entries pe WHERE pe.payroll_period_id = p.id AND pe.owner_user_id = $1) as total_net_payable
      FROM payroll_periods p
      WHERE p.owner_user_id = $1
      ORDER BY p.year DESC, p.month DESC;
    `, [userId]);
    res.json({ periods: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/reconciliation/reset (Reset reconciliation comparisons and restore statutory baseline rules)
router.post('/reset', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const { periodId, resetRules = true } = req.body;

    if (resetRules) {
      // Restore active rule set to statutory GGSSTP standards
      await db.query(`
        UPDATE payroll_rule_sets SET
          epf_wage_cap = 25000,
          epf_employer_rate = 0.1200,
          epf_max_cap = 3000,
          epf_admin_rate = 0.0100,
          epf_admin_max_cap = 250,
          epf_employee_rate = 0.1200,
          esi_threshold = 21000,
          esi_employer_rate = 0.0325,
          esi_employee_rate = 0.0075,
          employer_lwf = 20.00,
          employee_lwf = 5.00,
          thermal_allowance_base = 1500.00,
          net_payable_rounding_mode = 'round_50_up'
        WHERE owner_user_id = $1 AND is_active = TRUE;
      `, [userId]);
    }

    if (periodId) {
      const isSuper = isSuperAdmin(req.user);
      let resetEntrySql = `
        UPDATE payroll_entries SET
          is_overridden = FALSE,
          calculation_mode = 'Reference-Compatible',
          updated_at = CURRENT_TIMESTAMP
        WHERE payroll_period_id = $1
      `;
      const resetParams: any[] = [Number(periodId)];
      if (!isSuper) {
        resetEntrySql += ` AND (owner_user_id = $2 OR created_by_user_id = $2);`;
        resetParams.push(userId);
      } else {
        resetEntrySql += `;`;
      }
      await db.query(resetEntrySql, resetParams);
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'RECONCILIATION_RESET', 'RECONCILIATION', $2, $3, $4);
    `, [
      req.user?.username || 'admin',
      periodId ? String(periodId) : 'ALL',
      `Reset reconciliation state, restored statutory default rules, and cleared comparison cache.`,
      userId
    ]);

    res.json({
      success: true,
      message: 'Reconciliation work and formula rules successfully reset to default statutory standards.'
    });
  } catch (err: any) {
    console.error('Reconciliation reset error:', err);
    res.status(500).json({ error: err.message || 'Failed to reset reconciliation' });
  }
});

export default router;

