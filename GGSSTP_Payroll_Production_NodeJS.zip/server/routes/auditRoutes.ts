import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { isSuperAdmin } from '../middleware/rbac';

const router = Router();

// GET /api/audit-logs (Scoped to user workspace, Super Admin can see all)
router.get('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const { action, entityType, limit = 100 } = req.query;

    const isSuper = isSuperAdmin(req.user);
    let query = isSuper 
      ? `SELECT * FROM audit_logs WHERE 1=1` 
      : `SELECT * FROM audit_logs WHERE owner_user_id = $1`;

    const params: any[] = isSuper ? [] : [userId];
    let idx = params.length + 1;

    if (action) {
      query += ` AND action = $${idx++}`;
      params.push(String(action));
    }
    if (entityType) {
      query += ` AND entity_type = $${idx++}`;
      params.push(String(entityType));
    }

    query += ` ORDER BY created_at DESC LIMIT $${idx++};`;
    params.push(Math.min(500, Number(limit) || 100));

    const result = await db.query(query, params);
    res.json({ logs: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
