import { Router } from 'express';
import multer from 'multer';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { isSuperAdmin } from '../middleware/rbac';
import { ExcelImporter } from '../excel/excelImporter';
import { calculatePayroll, INITIAL_RATES } from '../engine/payrollCalculator';
import { syncEmployeesWithOpenPayrollPeriods } from '../services/payrollSyncService';

const router = Router();
const upload = multer({ limits: { fileSize: 25 * 1024 * 1024 } }); // 25MB

// Helper to compute live salary for an employee record
function computeEmployeeSalary(emp: any) {
  try {
    const gross = Number(emp.default_gross_rate || emp.gross_salary_rate || INITIAL_RATES[emp.designation_alias]?.gross || 16530);
    const special = Number(emp.default_special_allowance || emp.special_allowance || INITIAL_RATES[emp.designation_alias]?.special || 3802);
    const thermal = emp.default_thermal_allowance !== null && emp.default_thermal_allowance !== undefined ? Number(emp.default_thermal_allowance) : 1500;
    const perf = Number(emp.default_perf_allowance || 0);
    const bonusPct = emp.default_bonus_percentage !== null && emp.default_bonus_percentage !== undefined && emp.default_bonus_percentage !== ''
      ? Number(emp.default_bonus_percentage)
      : (emp.default_bonus_percentage === null || emp.default_bonus_percentage === '' ? 0 : 8.33);

    const calc = calculatePayroll({
      designationAlias: emp.designation_alias || 'SW',
      grossSalaryRate: gross,
      specialAllowanceRate: special,
      customThermalAllowance: thermal,
      perfAllowanceMonthly: perf,
      bonusPercentage: bonusPct,
      customEmployeeEpf: emp.custom_employee_epf !== null && emp.custom_employee_epf !== undefined && emp.custom_employee_epf !== ''
        ? Number(emp.custom_employee_epf)
        : (emp.epf_applicable === false ? 0 : undefined),
      customEmployerEpf: emp.custom_employer_epf !== null && emp.custom_employer_epf !== undefined && emp.custom_employer_epf !== ''
        ? Number(emp.custom_employer_epf)
        : (emp.epf_applicable === false ? 0 : undefined),
      customEmployerEpf1: emp.custom_employer_epf1 !== null && emp.custom_employer_epf1 !== undefined && emp.custom_employer_epf1 !== ''
        ? Number(emp.custom_employer_epf1)
        : (emp.epf_applicable === false ? 0 : undefined),
      customEmployeeEsi: emp.custom_employee_esi !== null && emp.custom_employee_esi !== undefined && emp.custom_employee_esi !== ''
        ? Number(emp.custom_employee_esi)
        : (emp.esi_applicable === false ? 0 : undefined),
      customEmployerEsi: emp.custom_employer_esi !== null && emp.custom_employer_esi !== undefined && emp.custom_employer_esi !== ''
        ? Number(emp.custom_employer_esi)
        : (emp.esi_applicable === false ? 0 : undefined),
      customEmployeeLwf: emp.custom_employee_lwf !== null && emp.custom_employee_lwf !== undefined && emp.custom_employee_lwf !== ''
        ? Number(emp.custom_employee_lwf)
        : (emp.lwf_applicable === false ? 0 : undefined),
      customEmployerLwf: emp.custom_employer_lwf !== null && emp.custom_employer_lwf !== undefined && emp.custom_employer_lwf !== ''
        ? Number(emp.custom_employer_lwf)
        : (emp.lwf_applicable === false ? 0 : undefined),
      totalDays: 30,
      presentDays: 30
    });

    return {
      grossSalaryRate: calc.grossSalaryRate,
      proportionedSalary: calc.proportionedSalary,
      specialAllowance: calc.specialAllowance,
      totalBasic: calc.totalBasic,
      thermalAllowance: calc.thermalAllowance,
      perfAllowanceMonthly: calc.perfAllowanceMonthly,
      perfAllowanceDaysWise: calc.perfAllowanceDaysWise,
      totalEarningsBeforeBonus: calc.totalEarningsBeforeBonus,
      bonus: calc.bonus,
      bonusPercentage: calc.bonusPercentage,
      employerEpf12: calc.employerEpf12,
      employerEpf1: calc.employerEpf1,
      employerEsi325: calc.employerEsi325,
      employerLwf: calc.employerLwf,
      grossTotal: calc.grossTotal,
      employeeEpf12: calc.employeeEpf12,
      employeeEsi075: calc.employeeEsi075,
      employeeLwf: calc.employeeLwf,
      totalEmployeeDeductions: calc.totalEmployeeDeductions,
      totalEmployerContributions: calc.totalEmployerContributions,
      combinedDeductions: calc.combinedDeductions,
      netPayable: calc.netPayable,
      formulas: calc.formulas
    };
  } catch (err) {
    return null;
  }
}

// ==================== EXCEL TEMPLATE & IMPORT ENDPOINTS ====================

// GET /api/employees/template (Download official Excel template)
router.get('/template', authMiddleware, async (_req: AuthRequest, res) => {
  try {
    const workbook = ExcelImporter.generateTemplateWorkbook();
    const filename = `GGSSTP_Employee_And_Salary_Template_${new Date().toISOString().slice(0, 10)}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    await workbook.xlsx.write(res);
    res.end();
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to generate Excel template' });
  }
});

// POST /api/employees/import-preview (Preview Excel upload for employee master)
router.post('/import-preview', authMiddleware, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel file (.xlsx, .xls)' });
    }
    const requestedSheet = req.body.sheetName;
    const preview = await ExcelImporter.previewEmployeeMasterImport(req.file.buffer, req.user!.id, requestedSheet);
    res.json(preview);
  } catch (err: any) {
    console.error('Employee import preview error:', err);
    res.status(500).json({ error: err.message || 'Failed to parse Excel file for preview' });
  }
});

// POST /api/employees/import-commit (Commit imported employee master records)
router.post('/import-commit', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { rows, strategy = 'both' } = req.body;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'No employee rows provided to import' });
    }
    const result = await ExcelImporter.commitEmployeeMasterImport(
      rows,
      strategy,
      req.user!.id,
      req.user?.username || 'admin'
    );
    res.json({
      message: `Successfully processed ${result.totalProcessed} employees. Created: ${result.createdCount}, Updated: ${result.updatedCount}, Skipped: ${result.skippedCount}`,
      result
    });
  } catch (err: any) {
    console.error('Employee import commit error:', err);
    res.status(500).json({ error: err.message || 'Failed to commit employee import' });
  }
});

// POST /api/employees/salary-upload-preview (Preview Excel upload for salary rates)
router.post('/salary-upload-preview', authMiddleware, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel file (.xlsx, .xls)' });
    }
    const requestedSheet = req.body.sheetName;
    const preview = await ExcelImporter.previewSalaryUpdateImport(req.file.buffer, req.user!.id, requestedSheet);
    res.json(preview);
  } catch (err: any) {
    console.error('Salary upload preview error:', err);
    res.status(500).json({ error: err.message || 'Failed to parse salary Excel file' });
  }
});

// POST /api/employees/salary-upload-commit (Commit salary rates update)
router.post('/salary-upload-commit', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { rows } = req.body;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'No salary rows provided to update' });
    }
    const result = await ExcelImporter.commitSalaryUpdateImport(
      rows,
      req.user!.id,
      req.user?.username || 'admin'
    );
    res.json({
      message: `Successfully updated salary structures for ${result.updatedCount} employees`,
      result
    });
  } catch (err: any) {
    console.error('Salary upload commit error:', err);
    res.status(500).json({ error: err.message || 'Failed to commit salary updates' });
  }
});

// POST /api/employees/calculate-preview (Live salary calculator for employee form)
router.post('/calculate-preview', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const {
      designationAlias = 'SW',
      grossSalaryRate,
      specialAllowanceRate,
      thermalAllowance,
      perfAllowanceMonthly,
      bonusPercentage,
      customBonus,
      customEmployeeEpf,
      customEmployerEpf,
      customEmployerEpf1,
      customEmployeeEsi,
      customEmployerEsi,
      customEmployeeLwf,
      customEmployerLwf,
      totalDays = 30,
      presentDays = 30,
      epfApplicable = true,
      esiApplicable = true,
      lwfApplicable = true
    } = req.body;

    const calc = calculatePayroll({
      designationAlias,
      grossSalaryRate: grossSalaryRate !== undefined && grossSalaryRate !== null && grossSalaryRate !== '' ? Number(grossSalaryRate) : undefined,
      specialAllowanceRate: specialAllowanceRate !== undefined && specialAllowanceRate !== null && specialAllowanceRate !== '' ? Number(specialAllowanceRate) : undefined,
      customThermalAllowance: thermalAllowance !== undefined && thermalAllowance !== null && thermalAllowance !== '' ? Number(thermalAllowance) : undefined,
      perfAllowanceMonthly: perfAllowanceMonthly ? Number(perfAllowanceMonthly) : 0,
      bonusPercentage: bonusPercentage !== undefined && bonusPercentage !== null && bonusPercentage !== ''
        ? Number(bonusPercentage)
        : (bonusPercentage === '' || bonusPercentage === null ? 0 : 8.33),
      customBonus: customBonus !== undefined && customBonus !== null && customBonus !== '' ? Number(customBonus) : undefined,
      customEmployeeEpf: customEmployeeEpf !== undefined && customEmployeeEpf !== null && customEmployeeEpf !== ''
        ? Number(customEmployeeEpf)
        : (customEmployeeEpf === '' || customEmployeeEpf === 0 ? 0 : (epfApplicable === false ? 0 : undefined)),
      customEmployerEpf: customEmployerEpf !== undefined && customEmployerEpf !== null && customEmployerEpf !== ''
        ? Number(customEmployerEpf)
        : (customEmployerEpf === '' || customEmployerEpf === 0 ? 0 : (epfApplicable === false ? 0 : undefined)),
      customEmployerEpf1: customEmployerEpf1 !== undefined && customEmployerEpf1 !== null && customEmployerEpf1 !== ''
        ? Number(customEmployerEpf1)
        : (customEmployerEpf1 === '' || customEmployerEpf1 === 0 ? 0 : (epfApplicable === false ? 0 : undefined)),
      customEmployeeEsi: customEmployeeEsi !== undefined && customEmployeeEsi !== null && customEmployeeEsi !== ''
        ? Number(customEmployeeEsi)
        : (customEmployeeEsi === '' || customEmployeeEsi === 0 ? 0 : (esiApplicable === false ? 0 : undefined)),
      customEmployerEsi: customEmployerEsi !== undefined && customEmployerEsi !== null && customEmployerEsi !== ''
        ? Number(customEmployerEsi)
        : (customEmployerEsi === '' || customEmployerEsi === 0 ? 0 : (esiApplicable === false ? 0 : undefined)),
      customEmployeeLwf: customEmployeeLwf !== undefined && customEmployeeLwf !== null && customEmployeeLwf !== ''
        ? Number(customEmployeeLwf)
        : (customEmployeeLwf === '' || customEmployeeLwf === 0 ? 0 : (lwfApplicable === false ? 0 : undefined)),
      customEmployerLwf: customEmployerLwf !== undefined && customEmployerLwf !== null && customEmployerLwf !== ''
        ? Number(customEmployerLwf)
        : (customEmployerLwf === '' || customEmployerLwf === 0 ? 0 : (lwfApplicable === false ? 0 : undefined)),
      totalDays: Number(totalDays) || 30,
      presentDays: Number(presentDays) !== undefined ? Number(presentDays) : 30
    } as any);

    res.json({ calculation: calc });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// ==================== CRUD & LISTING ENDPOINTS ====================

// GET /api/employees (Search, Filter, Sort, Paginate with Live Salary)
router.get('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const creatorId = req.query.creatorId ? Number(req.query.creatorId) : null;
    const {
      search, designationId, contractorId, circleId, cell, status,
      epfApplicable, esiApplicable, lwfApplicable,
      sortBy = 'name', sortOrder = 'ASC',
      page = 1, limit = 50
    } = req.query;

    let query = `
      SELECT 
        e.*,
        d.name as designation_name, d.alias as designation_alias,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name,
        dsr.gross_salary_rate, dsr.special_allowance,
        u.username as creator_username,
        u.full_name as creator_name
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      LEFT JOIN users u ON e.owner_user_id = u.id
      WHERE 1=1
    `;
    const params: any[] = [];
    let pIdx = 1;

    if (!isSuper) {
      query += ` AND (e.owner_user_id = $${pIdx} OR e.created_by_user_id = $${pIdx})`;
      params.push(userId);
      pIdx++;
    } else if (creatorId) {
      query += ` AND (e.owner_user_id = $${pIdx} OR e.created_by_user_id = $${pIdx})`;
      params.push(creatorId);
      pIdx++;
    }

    if (search) {
      query += ` AND (e.name ILIKE $${pIdx} OR e.emp_code ILIKE $${pIdx} OR e.uan ILIKE $${pIdx} OR e.bank_account ILIKE $${pIdx})`;
      params.push(`%${String(search).trim()}%`);
      pIdx++;
    }

    if (designationId) {
      query += ` AND e.designation_id = $${pIdx++}`;
      params.push(Number(designationId));
    }

    if (contractorId) {
      query += ` AND e.contractor_id = $${pIdx++}`;
      params.push(Number(contractorId));
    }

    if (circleId) {
      query += ` AND e.circle_id = $${pIdx++}`;
      params.push(Number(circleId));
    }

    if (cell) {
      query += ` AND e.cell ILIKE $${pIdx++}`;
      params.push(`%${String(cell).trim()}%`);
    }

    if (status === 'active') {
      query += ` AND e.is_active = TRUE`;
    } else if (status === 'inactive') {
      query += ` AND e.is_active = FALSE AND e.archived_at IS NULL`;
    } else if (status === 'archived') {
      query += ` AND e.archived_at IS NOT NULL`;
    }

    if (epfApplicable === 'true') query += ` AND e.epf_applicable = TRUE`;
    if (epfApplicable === 'false') query += ` AND e.epf_applicable = FALSE`;

    if (esiApplicable === 'true') query += ` AND e.esi_applicable = TRUE`;
    if (esiApplicable === 'false') query += ` AND e.esi_applicable = FALSE`;

    if (lwfApplicable === 'true') query += ` AND e.lwf_applicable = TRUE`;
    if (lwfApplicable === 'false') query += ` AND e.lwf_applicable = FALSE`;

    // Dynamic sorting
    const validSortCols: Record<string, string> = {
      name: 'e.name',
      emp_code: 'e.emp_code',
      designation: 'd.alias',
      id: 'e.id',
      created_at: 'e.created_at'
    };
    const sortCol = validSortCols[String(sortBy).toLowerCase()] || 'e.id';
    const sortDir = String(sortOrder).toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
    query += ` ORDER BY ${sortCol} ${sortDir}`;

    // Pagination
    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.max(1, Number(limit) || 50);
    const offset = (pageNum - 1) * limitNum;

    // Count
    const countRes = await db.query(`SELECT COUNT(*) as total FROM (${query}) sub;`, params);
    const total = Number(countRes.rows[0].total) || 0;

    query += ` LIMIT $${pIdx} OFFSET $${pIdx + 1}`;
    params.push(limitNum, offset);

    const result = await db.query(query, params);

    // Enrich with computed salary breakdown
    const enriched = result.rows.map(emp => ({
      ...emp,
      calculated_salary: computeEmployeeSalary(emp)
    }));

    res.json({
      employees: enriched,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum)
      }
    });
  } catch (err: any) {
    console.error('Error fetching employees:', err);
    res.status(500).json({ error: err.message || 'Failed to fetch employees' });
  }
});

// GET /api/employees/:id (View Employee Dossier with Live Calculations and History Check)
router.get('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);

    let query = `
      SELECT 
        e.*,
        d.name as designation_name, d.alias as designation_alias,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name,
        dsr.gross_salary_rate, dsr.special_allowance,
        u.username as creator_username,
        u.full_name as creator_name
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      LEFT JOIN users u ON e.owner_user_id = u.id
      WHERE e.id = $1
    `;
    const params: any[] = [Number(id)];

    const result = await db.query(query, params);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    const emp = result.rows[0];

    // Data Privacy: Payroll Administrators cannot view another user's employee details
    if (!isSuper && emp.owner_user_id !== userId && emp.created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to view this employee dossier.' });
    }

    // Check payroll history
    const historyRes = await db.query(
      `SELECT COUNT(*) as history_count FROM payroll_entries WHERE employee_id = $1;`,
      [Number(id)]
    );
    const historyCount = Number(historyRes.rows[0]?.history_count || 0);

    res.json({
      employee: {
        ...emp,
        calculated_salary: computeEmployeeSalary(emp),
        has_payroll_history: historyCount > 0,
        payroll_history_count: historyCount
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees (Add New Employee with auto-code option and full master fields)
router.post('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const data = req.body;
    if (!data.name || !data.name.trim()) {
      return res.status(400).json({ error: 'Employee Name is required' });
    }

    // Auto-generate code if empty or 'AUTO'
    let code = (data.emp_code || data.empCode || '').trim();
    if (!code || code.toUpperCase() === 'AUTO') {
      const codeSeqRes = await db.query(`SELECT COALESCE(MAX(id), 0) + 101 as next_code FROM employees;`);
      code = `EMP-${codeSeqRes.rows[0]?.next_code || Math.floor(100 + Math.random() * 900)}`;
    }

    // Check duplicate code within workspace
    const dupCheck = await db.query(
      `SELECT id FROM employees WHERE LOWER(emp_code) = LOWER($1) AND owner_user_id = $2;`,
      [code, userId]
    );
    if (dupCheck.rows.length > 0) {
      return res.status(409).json({ error: `Employee Code "${code}" already exists in your workspace.` });
    }

    const insRes = await db.query(`
      INSERT INTO employees (
        owner_user_id, created_by_user_id, emp_code, sr_no, name, father_name, uan, designation_id, dob, age_above_58,
        date_of_joining, more_than_3_yrs, more_than_5_yrs, qualification, experience_years,
        qualified_status, contractor_id, circle_id, department_id, hazard_duty, above_60,
        check_status, cell, bank_name, bank_account, ifsc, account_holder_name, esi_number, aadhar_number, pan_number,
        default_gross_rate, default_special_allowance, default_thermal_allowance, default_perf_allowance, default_bonus_percentage,
        custom_employee_epf, custom_employer_epf, custom_employer_epf1, custom_employee_esi, custom_employer_esi, custom_employee_lwf, custom_employer_lwf,
        other_allowances, other_deductions,
        epf_applicable, esi_applicable, lwf_applicable, epf_statutory_doj, is_active
      ) VALUES (
        $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
        $11,$12,$13,$14,$15,$16,$17,$18,$19,$20,
        $21,$22,$23,$24,$25,$26,$27,$28,$29,$30,
        $31,$32,$33,$34,$35,
        $36,$37,$38,$39,$40,$41,$42,
        $43,$44,$45,$46,$47,$48,$49
      )
      RETURNING *;
    `, [
      userId, userId,
      code, data.sr_no || '', data.name.trim(), data.father_name || '', data.uan || '',
      data.designation_id || null, data.dob || '', data.age_above_58 || 'N', data.date_of_joining || '',
      data.more_than_3_yrs || 'NO', data.more_than_5_yrs || 'NO', data.qualification || '',
      data.experience_years || '', data.qualified_status || '', data.contractor_id || null,
      data.circle_id || null, data.department_id || null, data.hazard_duty || '', data.above_60 || '',
      data.check_status || '', data.cell || '', data.bank_name || '', data.bank_account || '', data.ifsc || '',
      data.account_holder_name || '', data.esi_number || '', data.aadhar_number || '', data.pan_number || '',
      data.default_gross_rate ? Number(data.default_gross_rate) : null,
      data.default_special_allowance ? Number(data.default_special_allowance) : null,
      data.default_thermal_allowance !== undefined && data.default_thermal_allowance !== null && data.default_thermal_allowance !== '' ? Number(data.default_thermal_allowance) : 1500,
      data.default_perf_allowance ? Number(data.default_perf_allowance) : 0,
      data.default_bonus_percentage !== undefined && data.default_bonus_percentage !== null && data.default_bonus_percentage !== '' && data.default_bonus_percentage !== '__NULL__' ? Number(data.default_bonus_percentage) : null,
      data.custom_employee_epf !== undefined && data.custom_employee_epf !== null && data.custom_employee_epf !== '' && data.custom_employee_epf !== 'auto' && data.custom_employee_epf !== '__NULL__' ? Number(data.custom_employee_epf) : (data.custom_employee_epf === '' || data.custom_employee_epf === 0 || data.custom_employee_epf === '0' ? 0 : null),
      data.custom_employer_epf !== undefined && data.custom_employer_epf !== null && data.custom_employer_epf !== '' && data.custom_employer_epf !== 'auto' && data.custom_employer_epf !== '__NULL__' ? Number(data.custom_employer_epf) : (data.custom_employer_epf === '' || data.custom_employer_epf === 0 || data.custom_employer_epf === '0' ? 0 : null),
      data.custom_employer_epf1 !== undefined && data.custom_employer_epf1 !== null && data.custom_employer_epf1 !== '' && data.custom_employer_epf1 !== 'auto' && data.custom_employer_epf1 !== '__NULL__' ? Number(data.custom_employer_epf1) : (data.custom_employer_epf1 === '' || data.custom_employer_epf1 === 0 || data.custom_employer_epf1 === '0' ? 0 : null),
      data.custom_employee_esi !== undefined && data.custom_employee_esi !== null && data.custom_employee_esi !== '' && data.custom_employee_esi !== 'auto' && data.custom_employee_esi !== '__NULL__' ? Number(data.custom_employee_esi) : (data.custom_employee_esi === '' || data.custom_employee_esi === 0 || data.custom_employee_esi === '0' ? 0 : null),
      data.custom_employer_esi !== undefined && data.custom_employer_esi !== null && data.custom_employer_esi !== '' && data.custom_employer_esi !== 'auto' && data.custom_employer_esi !== '__NULL__' ? Number(data.custom_employer_esi) : (data.custom_employer_esi === '' || data.custom_employer_esi === 0 || data.custom_employer_esi === '0' ? 0 : null),
      data.custom_employee_lwf !== undefined && data.custom_employee_lwf !== null && data.custom_employee_lwf !== '' && data.custom_employee_lwf !== 'auto' && data.custom_employee_lwf !== '__NULL__' ? Number(data.custom_employee_lwf) : (data.custom_employee_lwf === '' || data.custom_employee_lwf === 0 || data.custom_employee_lwf === '0' ? 0 : null),
      data.custom_employer_lwf !== undefined && data.custom_employer_lwf !== null && data.custom_employer_lwf !== '' && data.custom_employer_lwf !== 'auto' && data.custom_employer_lwf !== '__NULL__' ? Number(data.custom_employer_lwf) : (data.custom_employer_lwf === '' || data.custom_employer_lwf === 0 || data.custom_employer_lwf === '0' ? 0 : null),
      data.other_allowances ? Number(data.other_allowances) : 0,
      data.other_deductions ? Number(data.other_deductions) : 0,
      data.epf_applicable !== false, data.esi_applicable !== false, data.lwf_applicable !== false,
      data.epf_statutory_doj || '', data.is_active !== false
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'CREATE_EMPLOYEE', 'EMPLOYEE', $2, $3, $4);
    `, [req.user?.username || 'admin', String(insRes.rows[0].id), `Created employee ${data.name} (${code})`, userId]);

    // Automatically synchronize open payroll periods with newly registered employee
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync payroll periods on create failed:', e));

    res.status(201).json({
      employee: {
        ...insRes.rows[0],
        calculated_salary: computeEmployeeSalary(insRes.rows[0])
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/employees/:id (Edit Existing Employee)
router.put('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const data = req.body;

    // Verify existence and authorization
    const checkEmp = await db.query(`SELECT id, name, owner_user_id, created_by_user_id FROM employees WHERE id = $1;`, [Number(id)]);
    if (checkEmp.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });
    if (!isSuper && checkEmp.rows[0].owner_user_id !== userId && checkEmp.rows[0].created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to modify another user\'s employee record.' });
    }

    // Check duplicate code if emp_code changed
    if (data.emp_code) {
      const dupQuery = `SELECT id FROM employees WHERE LOWER(emp_code) = LOWER($1) AND id != $2;`;
      const dupParams = [data.emp_code.trim(), Number(id)];
      const dupCheck = await db.query(dupQuery, dupParams);
      if (dupCheck.rows.length > 0) {
        return res.status(409).json({ error: `Employee Code "${data.emp_code}" is already used by another employee.` });
      }
    }

    let updateSql = `
      UPDATE employees SET
        emp_code = COALESCE($1, emp_code),
        sr_no = COALESCE($2, sr_no),
        name = COALESCE($3, name),
        father_name = COALESCE($4, father_name),
        uan = COALESCE($5, uan),
        designation_id = $6,
        dob = COALESCE($7, dob),
        age_above_58 = COALESCE($8, age_above_58),
        date_of_joining = COALESCE($9, date_of_joining),
        more_than_3_yrs = COALESCE($10, more_than_3_yrs),
        more_than_5_yrs = COALESCE($11, more_than_5_yrs),
        qualification = COALESCE($12, qualification),
        experience_years = COALESCE($13, experience_years),
        qualified_status = COALESCE($14, qualified_status),
        contractor_id = $15,
        circle_id = $16,
        department_id = $17,
        hazard_duty = COALESCE($18, hazard_duty),
        above_60 = COALESCE($19, above_60),
        check_status = COALESCE($20, check_status),
        cell = COALESCE($21, cell),
        bank_name = COALESCE($22, bank_name),
        bank_account = COALESCE($23, bank_account),
        ifsc = COALESCE($24, ifsc),
        account_holder_name = COALESCE($25, account_holder_name),
        esi_number = COALESCE($26, esi_number),
        aadhar_number = COALESCE($27, aadhar_number),
        pan_number = COALESCE($28, pan_number),
        default_gross_rate = $29,
        default_special_allowance = $30,
        default_thermal_allowance = COALESCE($31, default_thermal_allowance),
        default_perf_allowance = COALESCE($32, default_perf_allowance),
        default_bonus_percentage = CASE WHEN $33 = '__NULL__' THEN NULL WHEN $33 IS NOT NULL THEN CAST($33 AS NUMERIC) ELSE default_bonus_percentage END,
        custom_employee_epf = CASE WHEN $44 = '__NULL__' THEN NULL WHEN $44 IS NOT NULL THEN CAST($44 AS NUMERIC) ELSE custom_employee_epf END,
        custom_employer_epf = CASE WHEN $45 = '__NULL__' THEN NULL WHEN $45 IS NOT NULL THEN CAST($45 AS NUMERIC) ELSE custom_employer_epf END,
        custom_employer_epf1 = CASE WHEN $46 = '__NULL__' THEN NULL WHEN $46 IS NOT NULL THEN CAST($46 AS NUMERIC) ELSE custom_employer_epf1 END,
        custom_employee_esi = CASE WHEN $47 = '__NULL__' THEN NULL WHEN $47 IS NOT NULL THEN CAST($47 AS NUMERIC) ELSE custom_employee_esi END,
        custom_employer_esi = CASE WHEN $48 = '__NULL__' THEN NULL WHEN $48 IS NOT NULL THEN CAST($48 AS NUMERIC) ELSE custom_employer_esi END,
        custom_employee_lwf = CASE WHEN $49 = '__NULL__' THEN NULL WHEN $49 IS NOT NULL THEN CAST($49 AS NUMERIC) ELSE custom_employee_lwf END,
        custom_employer_lwf = CASE WHEN $50 = '__NULL__' THEN NULL WHEN $50 IS NOT NULL THEN CAST($50 AS NUMERIC) ELSE custom_employer_lwf END,
        other_allowances = COALESCE($34, other_allowances),
        other_deductions = COALESCE($35, other_deductions),
        epf_applicable = COALESCE($36, epf_applicable),
        esi_applicable = COALESCE($37, esi_applicable),
        lwf_applicable = COALESCE($38, lwf_applicable),
        epf_statutory_doj = COALESCE($39, epf_statutory_doj),
        is_active = COALESCE($40, is_active),
        updated_by_user_id = $41,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $42
    `;
    const params: any[] = [
      data.emp_code ? data.emp_code.trim() : null, data.sr_no, data.name ? data.name.trim() : null, data.father_name, data.uan,
      data.designation_id, data.dob, data.age_above_58, data.date_of_joining,
      data.more_than_3_yrs, data.more_than_5_yrs, data.qualification, data.experience_years,
      data.qualified_status, data.contractor_id, data.circle_id, data.department_id,
      data.hazard_duty, data.above_60, data.check_status,
      data.cell, data.bank_name, data.bank_account, data.ifsc, data.account_holder_name,
      data.esi_number, data.aadhar_number, data.pan_number,
      data.default_gross_rate ? Number(data.default_gross_rate) : null,
      data.default_special_allowance ? Number(data.default_special_allowance) : null,
      data.default_thermal_allowance !== undefined && data.default_thermal_allowance !== null && data.default_thermal_allowance !== '' ? Number(data.default_thermal_allowance) : null,
      data.default_perf_allowance !== undefined && data.default_perf_allowance !== null && data.default_perf_allowance !== '' ? Number(data.default_perf_allowance) : null,
      data.default_bonus_percentage !== undefined ? (data.default_bonus_percentage === null || data.default_bonus_percentage === '' ? '__NULL__' : String(Number(data.default_bonus_percentage))) : null,
      data.other_allowances !== undefined && data.other_allowances !== null && data.other_allowances !== '' ? Number(data.other_allowances) : null,
      data.other_deductions !== undefined && data.other_deductions !== null && data.other_deductions !== '' ? Number(data.other_deductions) : null,
      data.epf_applicable !== undefined ? Boolean(data.epf_applicable) : null,
      data.esi_applicable !== undefined ? Boolean(data.esi_applicable) : null,
      data.lwf_applicable !== undefined ? Boolean(data.lwf_applicable) : null,
      data.epf_statutory_doj,
      data.is_active !== undefined ? Boolean(data.is_active) : null,
      userId, Number(id),
      // $44 - $50
      data.custom_employee_epf !== undefined ? (data.custom_employee_epf === 'auto' || data.custom_employee_epf === 'AUTO' || data.custom_employee_epf === '__NULL__' ? '__NULL__' : (data.custom_employee_epf === null || data.custom_employee_epf === '' || data.custom_employee_epf === 0 ? '0' : String(Number(data.custom_employee_epf)))) : null,
      data.custom_employer_epf !== undefined ? (data.custom_employer_epf === 'auto' || data.custom_employer_epf === 'AUTO' || data.custom_employer_epf === '__NULL__' ? '__NULL__' : (data.custom_employer_epf === null || data.custom_employer_epf === '' || data.custom_employer_epf === 0 ? '0' : String(Number(data.custom_employer_epf)))) : null,
      data.custom_employer_epf1 !== undefined ? (data.custom_employer_epf1 === 'auto' || data.custom_employer_epf1 === 'AUTO' || data.custom_employer_epf1 === '__NULL__' ? '__NULL__' : (data.custom_employer_epf1 === null || data.custom_employer_epf1 === '' || data.custom_employer_epf1 === 0 ? '0' : String(Number(data.custom_employer_epf1)))) : null,
      data.custom_employee_esi !== undefined ? (data.custom_employee_esi === 'auto' || data.custom_employee_esi === 'AUTO' || data.custom_employee_esi === '__NULL__' ? '__NULL__' : (data.custom_employee_esi === null || data.custom_employee_esi === '' || data.custom_employee_esi === 0 ? '0' : String(Number(data.custom_employee_esi)))) : null,
      data.custom_employer_esi !== undefined ? (data.custom_employer_esi === 'auto' || data.custom_employer_esi === 'AUTO' || data.custom_employer_esi === '__NULL__' ? '__NULL__' : (data.custom_employer_esi === null || data.custom_employer_esi === '' || data.custom_employer_esi === 0 ? '0' : String(Number(data.custom_employer_esi)))) : null,
      data.custom_employee_lwf !== undefined ? (data.custom_employee_lwf === 'auto' || data.custom_employee_lwf === 'AUTO' || data.custom_employee_lwf === '__NULL__' ? '__NULL__' : (data.custom_employee_lwf === null || data.custom_employee_lwf === '' || data.custom_employee_lwf === 0 ? '0' : String(Number(data.custom_employee_lwf)))) : null,
      data.custom_employer_lwf !== undefined ? (data.custom_employer_lwf === 'auto' || data.custom_employer_lwf === 'AUTO' || data.custom_employer_lwf === '__NULL__' ? '__NULL__' : (data.custom_employer_lwf === null || data.custom_employer_lwf === '' || data.custom_employer_lwf === 0 ? '0' : String(Number(data.custom_employer_lwf)))) : null
    ];

    updateSql += ` RETURNING *;`;

    const updRes = await db.query(updateSql, params);
    if (updRes.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'UPDATE_EMPLOYEE', 'EMPLOYEE', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Updated employee ${updRes.rows[0].name}`, userId]);

    // Automatically synchronize open payroll periods with updated employee rates
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync payroll periods on update failed:', e));

    res.json({
      employee: {
        ...updRes.rows[0],
        calculated_salary: computeEmployeeSalary(updRes.rows[0])
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/check-delete-eligibility (Check history before deleting single or bulk employees)
router.post('/check-delete-eligibility', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Employee ids array is required' });
    }
    const isSuper = isSuperAdmin(req.user);
    const userId = req.user!.id;

    let query = `
      SELECT e.id, e.emp_code, e.name, COUNT(pe.id) as history_count
      FROM employees e
      LEFT JOIN payroll_entries pe ON e.id = pe.employee_id
      WHERE e.id = ANY($1)
    `;
    const params: any[] = [ids.map(Number)];
    if (!isSuper) {
      query += ` AND (e.owner_user_id = $2 OR e.created_by_user_id = $2)`;
      params.push(userId);
    }
    query += ` GROUP BY e.id, e.emp_code, e.name;`;

    const result = await db.query(query, params);
    const eligible: any[] = [];
    const blocked: any[] = [];

    for (const r of result.rows) {
      const count = Number(r.history_count || 0);
      if (count > 0) {
        blocked.push({ id: r.id, emp_code: r.emp_code, name: r.name, historyCount: count });
      } else {
        eligible.push({ id: r.id, emp_code: r.emp_code, name: r.name });
      }
    }

    res.json({
      totalChecked: result.rows.length,
      eligibleCount: eligible.length,
      blockedCount: blocked.length,
      eligibleEmployees: eligible,
      blockedEmployees: blocked
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/:id/archive (Safely archive individual employee)
router.post('/:id/archive', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { reason = 'Archived by user' } = req.body || {};

    const checkEmp = await db.query(`SELECT id, name, owner_user_id, created_by_user_id FROM employees WHERE id = $1;`, [Number(id)]);
    if (checkEmp.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });
    if (!isSuper && checkEmp.rows[0].owner_user_id !== userId && checkEmp.rows[0].created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to archive another user\'s employee record.' });
    }

    let archiveSql = `
      UPDATE employees SET
        is_active = FALSE,
        is_archived = TRUE,
        archived_at = CURRENT_TIMESTAMP,
        archived_by_user_id = $1,
        archived_reason = $2,
        updated_by_user_id = $1,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
      RETURNING *;
    `;
    const params: any[] = [userId, reason, Number(id)];

    const updRes = await db.query(archiveSql, params);
    if (updRes.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'ARCHIVE_EMPLOYEE', 'EMPLOYEE', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Archived employee ${updRes.rows[0].name} (${updRes.rows[0].emp_code})`, userId]);

    // Automatically synchronize open payroll periods
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync on archive failed:', e));

    res.json({
      message: `Employee "${updRes.rows[0].name}" successfully archived and excluded from future payroll runs.`,
      archived: true,
      employee: updRes.rows[0]
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/employees/:id (Permanent Delete OR Safe Archival with strict safeguards)
router.delete('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { reason, hardDelete } = req.body || {};

    // Fetch employee details
    const empRes = await db.query(`SELECT id, emp_code, name, owner_user_id, created_by_user_id FROM employees WHERE id = $1;`, [Number(id)]);
    if (empRes.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });
    const emp = empRes.rows[0];

    if (!isSuper && emp.owner_user_id !== userId && emp.created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to delete another user\'s employee record.' });
    }

    // Check historical payroll entries count
    const historyRes = await db.query(
      `SELECT COUNT(*) as count FROM payroll_entries WHERE employee_id = $1;`,
      [Number(id)]
    );
    const historyCount = Number(historyRes.rows[0]?.count || 0);

    // If permanent hard delete requested
    if (hardDelete) {
      if (!isSuper) {
        return res.status(403).json({ error: 'Only Administrators have permission to permanently delete employee records.' });
      }

      // Safeguard: If payroll history exists, BLOCK permanent deletion!
      if (historyCount > 0) {
        return res.status(409).json({
          error: `Permanent deletion blocked: Employee "${emp.name}" (${emp.emp_code}) has ${historyCount} historical payroll record(s). Legal payroll retention regulations strictly forbid permanently deleting employees with payroll history. Please use the "Archive" feature instead.`,
          blocked: true,
          hasPayrollHistory: true,
          payrollHistoryCount: historyCount,
          canArchive: true
        });
      }

      // No payroll history exists -> proceed with hard delete
      await db.query(`DELETE FROM employees WHERE id = $1;`, [Number(id)]);

      await db.query(`
        INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
        VALUES ($1, 'HARD_DELETE_EMPLOYEE', 'EMPLOYEE', $2, $3, $4);
      `, [req.user?.username || 'admin', String(id), `Permanently deleted employee ${emp.name} (${emp.emp_code}) with 0 payroll history`, userId]);

      return res.json({
        message: `Employee "${emp.name}" (${emp.emp_code}) has been permanently deleted from the database.`,
        deleted: true,
        employee: emp
      });
    }

    // Otherwise, perform safe archival
    let archiveSql = `
      UPDATE employees SET
        is_active = FALSE,
        is_archived = TRUE,
        archived_at = CURRENT_TIMESTAMP,
        archived_by_user_id = $1,
        archived_reason = $2,
        updated_by_user_id = $1,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $3
      RETURNING *;
    `;
    const updRes = await db.query(archiveSql, [
      userId,
      reason || (historyCount > 0 ? `Archived (${historyCount} payroll records preserved)` : 'Archived by user'),
      Number(id)
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'ARCHIVE_EMPLOYEE', 'EMPLOYEE', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Archived employee ${emp.name} (${historyCount} historical records preserved)`, userId]);

    // Automatically synchronize open payroll periods
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync on archive failed:', e));

    res.json({
      message: historyCount > 0
        ? `Employee "${emp.name}" has ${historyCount} historical payroll records. They have been safely archived and excluded from future payroll runs without affecting historical records.`
        : `Employee "${emp.name}" archived successfully.`,
      archived: true,
      hasPayrollHistory: historyCount > 0,
      payrollHistoryCount: historyCount,
      employee: updRes.rows[0]
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/:id/restore (Reactivate / unarchive employee)
router.post('/:id/restore', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);

    const checkEmp = await db.query(`SELECT id, name, owner_user_id, created_by_user_id FROM employees WHERE id = $1;`, [Number(id)]);
    if (checkEmp.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });
    if (!isSuper && checkEmp.rows[0].owner_user_id !== userId && checkEmp.rows[0].created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to restore another user\'s employee record.' });
    }

    let restoreSql = `
      UPDATE employees SET
        is_active = TRUE,
        is_archived = FALSE,
        archived_at = NULL,
        archived_by_user_id = NULL,
        archived_reason = NULL,
        updated_by_user_id = $1,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $2
      RETURNING *;
    `;
    const params: any[] = [userId, Number(id)];

    const updRes = await db.query(restoreSql, params);
    if (updRes.rows.length === 0) return res.status(404).json({ error: 'Employee not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'RESTORE_EMPLOYEE', 'EMPLOYEE', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Restored employee ${updRes.rows[0].name}`, userId]);

    // Automatically synchronize open payroll periods with restored employee
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync on restore failed:', e));

    res.json({
      message: `Employee "${updRes.rows[0].name}" restored successfully and reactivated for payroll.`,
      employee: updRes.rows[0]
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/bulk-archive (Bulk Archive selected employees)
router.post('/bulk-archive', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { ids, reason = 'Archived by administrator' } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Employee ids array is required' });
    }

    let archiveSql = `
      UPDATE employees SET
        is_active = FALSE,
        is_archived = TRUE,
        archived_at = CURRENT_TIMESTAMP,
        archived_by_user_id = $1,
        archived_reason = $2,
        updated_by_user_id = $1,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ANY($3)
    `;
    const params: any[] = [userId, reason, ids.map(Number)];
    if (!isSuper) {
      archiveSql += ` AND (owner_user_id = $4 OR created_by_user_id = $4)`;
      params.push(userId);
    }
    archiveSql += ` RETURNING id, emp_code, name;`;

    const result = await db.query(archiveSql, params);
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BULK_ARCHIVE_EMPLOYEES', 'EMPLOYEE', 'BULK', $2, $3);
    `, [req.user?.username || 'admin', `Archived ${result.rowCount} employees`, userId]);

    // Automatically synchronize open payroll periods
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync on bulk archive failed:', e));

    res.json({
      message: `Successfully archived ${result.rowCount} employee(s). They will be excluded from future payroll runs.`,
      archivedCount: result.rowCount,
      archivedEmployees: result.rows
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/bulk-restore (Bulk Restore selected archived employees)
router.post('/bulk-restore', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Employee ids array is required' });
    }

    let restoreSql = `
      UPDATE employees SET
        is_active = TRUE,
        is_archived = FALSE,
        archived_at = NULL,
        archived_by_user_id = NULL,
        archived_reason = NULL,
        updated_by_user_id = $1,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ANY($2)
    `;
    const params: any[] = [userId, ids.map(Number)];
    if (!isSuper) {
      restoreSql += ` AND (owner_user_id = $3 OR created_by_user_id = $3)`;
      params.push(userId);
    }
    restoreSql += ` RETURNING id, emp_code, name;`;

    const result = await db.query(restoreSql, params);
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BULK_RESTORE_EMPLOYEES', 'EMPLOYEE', 'BULK', $2, $3);
    `, [req.user?.username || 'admin', `Restored ${result.rowCount} archived employees`, userId]);

    // Automatically synchronize open payroll periods with restored employees
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync on bulk restore failed:', e));

    res.json({
      message: `Successfully restored ${result.rowCount} employee(s).`,
      restoredCount: result.rowCount,
      restoredEmployees: result.rows
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/bulk-delete (Permanent Delete for selected employees - Super Admin only)
router.post('/bulk-delete', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Only Administrators have permission to permanently delete employee records.' });
    }
    const { ids, forceEligibleOnly = false } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Employee ids array is required' });
    }

    // Check history for each id
    const historyRes = await db.query(`
      SELECT e.id, e.emp_code, e.name, COUNT(pe.id) as history_count
      FROM employees e
      LEFT JOIN payroll_entries pe ON e.id = pe.employee_id
      WHERE e.id = ANY($1)
      GROUP BY e.id, e.emp_code, e.name;
    `, [ids.map(Number)]);

    const blocked: any[] = [];
    const eligibleIds: number[] = [];
    for (const r of historyRes.rows) {
      const count = Number(r.history_count || 0);
      if (count > 0) {
        blocked.push({ id: r.id, emp_code: r.emp_code, name: r.name, historyCount: count });
      } else {
        eligibleIds.push(r.id);
      }
    }

    if (blocked.length > 0 && !forceEligibleOnly) {
      return res.status(409).json({
        error: `Permanent deletion blocked: ${blocked.length} employee(s) have historical payroll records and cannot be permanently deleted. Use Archive instead, or confirm deleting only eligible employees without payroll history.`,
        blocked: true,
        blockedEmployees: blocked,
        eligibleCount: eligibleIds.length,
        blockedCount: blocked.length
      });
    }

    if (eligibleIds.length === 0) {
      return res.status(400).json({
        error: 'None of the selected employees are eligible for permanent deletion because all have historical payroll records.',
        blocked: true,
        blockedEmployees: blocked
      });
    }

    const delRes = await db.query(`DELETE FROM employees WHERE id = ANY($1) RETURNING id, emp_code, name;`, [eligibleIds]);
    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BULK_HARD_DELETE_EMPLOYEES', 'EMPLOYEE', 'BULK', $2, $3);
    `, [req.user?.username || 'admin', `Permanently deleted ${delRes.rowCount} employees with 0 payroll history`, userId]);

    res.json({
      message: `Permanently deleted ${delRes.rowCount} employee(s) from database.`,
      deletedCount: delRes.rowCount,
      deletedEmployees: delRes.rows,
      blockedCount: blocked.length,
      blockedEmployees: blocked
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/employees/bulk-update (Bulk Status / Assignment updates)
router.post('/bulk-update', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const { ids, designation_id, contractor_id, is_active } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Employee ids array is required' });
    }

    let updates: string[] = [];
    let params: any[] = [];
    let idx = 1;

    if (designation_id !== undefined) {
      updates.push(`designation_id = $${idx++}`);
      params.push(Number(designation_id));
    }
    if (contractor_id !== undefined) {
      updates.push(`contractor_id = $${idx++}`);
      params.push(Number(contractor_id));
    }
    if (is_active !== undefined) {
      updates.push(`is_active = $${idx++}`);
      params.push(Boolean(is_active));
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update provided' });
    }

    updates.push(`updated_at = CURRENT_TIMESTAMP`);
    const idPlaceholders = ids.map(() => `$${idx++}`).join(',');
    params.push(...ids.map(Number));

    params.push(userId);
    const query = `UPDATE employees SET ${updates.join(', ')} WHERE id IN (${idPlaceholders}) AND owner_user_id = $${idx};`;
    const result = await db.query(query, params);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BULK_UPDATE_EMPLOYEES', 'EMPLOYEE', 'BULK', $2, $3);
    `, [req.user?.username || 'admin', `Bulk updated ${ids.length} employees`, userId]);

    // Automatically synchronize open payroll periods
    syncEmployeesWithOpenPayrollPeriods(userId).catch(e => console.error('Auto-sync on bulk update failed:', e));

    res.json({ message: `Successfully updated ${ids.length} employees`, updatedCount: result.rowCount });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
