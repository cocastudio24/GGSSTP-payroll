import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { ExcelImporter } from '../excel/excelImporter';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();
const upload = multer({ limits: { fileSize: 25 * 1024 * 1024 } }); // 25MB

// POST /api/import/inspect (Inspect workbook, discover columns and auto-map with universal dictionary)
router.post('/inspect', authMiddleware, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel file (.xlsx, .xls, .csv)' });
    }
    const requestedSheet = req.body.sheetName;
    const inspectResult = ExcelImporter.inspectWorkbook(req.file.buffer, req.file.originalname, requestedSheet);
    res.json(inspectResult);
  } catch (err: any) {
    console.error('Import inspect error:', err);
    res.status(500).json({ error: err.message || 'Failed to inspect Excel workbook' });
  }
});

// POST /api/import/execute (Commit mapped Excel sheet to database and synchronize monthly payroll)
router.post('/execute', authMiddleware, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel file' });
    }
    const sheetName = req.body.sheetName;
    if (!sheetName) {
      return res.status(400).json({ error: 'Worksheet name is required' });
    }
    let mapping: Record<string, string> = {};
    if (typeof req.body.mapping === 'string') {
      try {
        mapping = JSON.parse(req.body.mapping);
      } catch (e) {
        return res.status(400).json({ error: 'Invalid column mapping format' });
      }
    } else if (req.body.mapping && typeof req.body.mapping === 'object') {
      mapping = req.body.mapping;
    }

    const headerRow = Number(req.body.headerRow) || 0;
    const strategy = req.body.strategy || 'both';
    const month = Number(req.body.month) || 9;
    const year = Number(req.body.year) || 2026;
    const userName = req.user?.username || 'admin';

    const result = await ExcelImporter.executeMappedImport(
      req.file.buffer,
      sheetName,
      mapping,
      headerRow,
      strategy,
      month,
      year,
      req.user!.id,
      userName
    );

    const message = sheetName === '__ALL__' || sheetName === 'ALL'
      ? `Successfully imported ${result.totalProcessed} records across ${(result as any).totalSheets || 'all'} worksheets! Created: ${result.createdCount}, Updated: ${result.updatedCount}, Skipped: ${result.skippedCount}`
      : `Successfully imported ${result.totalProcessed} records from "${sheetName}". Created: ${result.createdCount}, Updated: ${result.updatedCount}, Skipped: ${result.skippedCount}`;

    res.json({
      message,
      result
    });
  } catch (err: any) {
    console.error('Import execute error:', err);
    res.status(500).json({ error: err.message || 'Failed to execute mapped import' });
  }
});

// POST /api/import/upload
router.post('/upload', authMiddleware, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Please upload an Excel (.xlsx, .xls) file' });
    }

    const parsedSheets = ExcelImporter.parseWorkbook(req.file.buffer, req.file.originalname);
    const summary: any[] = [];

    for (const [sheetName, rows] of Object.entries(parsedSheets)) {
      summary.push({
        sheetName,
        totalRows: rows.length,
        samplePreview: rows.slice(0, 5),
        sampleEmployeeCodes: rows.slice(0, 5).map(r => r.empCode)
      });
    }

    res.json({
      fileName: req.file.originalname,
      sheetCount: Object.keys(parsedSheets).length,
      sheets: summary,
      parsedData: parsedSheets
    });
  } catch (err: any) {
    console.error('Import upload error:', err);
    res.status(500).json({ error: err.message || 'Failed to parse Excel file' });
  }
});

// POST /api/import/commit
router.post('/commit', authMiddleware, async (req: AuthRequest, res) => {
  try {
    let { rows, month, year, periodId } = req.body;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'No rows provided to commit' });
    }

    if (periodId && (!month || !year)) {
      const pRes = await db.query('SELECT month, year FROM payroll_periods WHERE id = $1;', [Number(periodId)]);
      if (pRes.rows.length > 0) {
        month = pRes.rows[0].month;
        year = pRes.rows[0].year;
      }
    }

    month = Number(month) || 9;
    year = Number(year) || 2026;

    const userName = req.user?.username || 'admin';
    const commitResult = await ExcelImporter.commitImport(rows, Number(month), Number(year), userName, req.user!.id);

    res.json({
      message: `Successfully imported ${commitResult.totalRecords} records`,
      result: commitResult,
      periodId: commitResult.periodId
    });
  } catch (err: any) {
    console.error('Import commit error:', err);
    res.status(500).json({ error: err.message || 'Failed to commit import records' });
  }
});

// POST /api/import/seed-reference (One-click button to load the reference workbook)
router.post('/seed-reference', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const refPath = path.join(__dirname, '../../reference_files/SALARY SHEET-for EPF Sepf 2026.xlsx');
    if (!fs.existsSync(refPath)) {
      return res.status(404).json({ error: 'Reference workbook file not found on server' });
    }

    const buffer = fs.readFileSync(refPath);
    const parsedSheets = ExcelImporter.parseWorkbook(buffer, 'SALARY SHEET-for EPF Sepf 2026.xlsx');

    const allRows = [
      ...(parsedSheets['MM-1'] || []),
      ...(parsedSheets['EMC'] || [])
    ];

    const userName = req.user?.username || 'admin';
    const commitResult = await ExcelImporter.commitImport(allRows, 9, 2026, userName, req.user!.id);

    res.json({
      message: `Successfully seeded reference data from MM-1 and EMC worksheets (September 2026)!`,
      totalImported: allRows.length,
      mm1Count: (parsedSheets['MM-1'] || []).length,
      emcCount: (parsedSheets['EMC'] || []).length,
      periodId: commitResult.periodId
    });
  } catch (err: any) {
    console.error('Seed reference error:', err);
    res.status(500).json({ error: err.message || 'Failed to seed reference workbook' });
  }
});

export default router;
