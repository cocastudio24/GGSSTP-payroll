import { Router } from 'express';
import { ExcelExporter } from '../excel/excelExporter';
import { db } from '../database/db';
import ExcelJS from 'exceljs';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { isSuperAdmin } from '../middleware/rbac';
import { fetchPayslipData } from '../payslip/payslipUtils';
import { generatePayslipPdf } from '../payslip/payslipPdfGenerator';
import { generatePayslipExcel } from '../payslip/payslipExcelGenerator';

const router = Router();

// GET /api/export/payslip-pdf/:id (Download A4 PDF Payslip)
router.get('/payslip-pdf/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const entryId = Number(req.params.id);
    const data = await fetchPayslipData(entryId);
    if (!data) return res.status(404).json({ error: 'Payroll entry not found' });

    if (!isSuperAdmin(req.user) && data.ownerUserId !== req.user!.id) {
      return res.status(403).json({ error: 'You are not authorized to download this employee payslip.' });
    }

    const filename = `Payslip_${data.empCode}_${data.monthName}_${data.year}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    await generatePayslipPdf(data, res);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'PAYSLIP_DOWNLOAD_PDF', 'PAYSLIP', $2, $3, $4);
    `, [req.user?.username || 'admin', String(entryId), `Downloaded PDF payslip for ${data.empName} (${data.empCode})`, req.user!.id]);
  } catch (err: any) {
    console.error('Payslip PDF error:', err);
    if (!res.headersSent) {
      res.status(500).json({ error: err.message || 'Failed to generate PDF payslip' });
    }
  }
});

// GET /api/export/payslip-xlsx/:id (Download Excel .xlsx Payslip)
router.get('/payslip-xlsx/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const entryId = Number(req.params.id);
    const data = await fetchPayslipData(entryId);
    if (!data) return res.status(404).json({ error: 'Payroll entry not found' });

    if (!isSuperAdmin(req.user) && data.ownerUserId !== req.user!.id) {
      return res.status(403).json({ error: 'You are not authorized to download this employee payslip.' });
    }

    const filename = `Payslip_${data.empCode}_${data.monthName}_${data.year}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    const workbook = generatePayslipExcel(data);
    await workbook.xlsx.write(res);
    res.end();

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'PAYSLIP_DOWNLOAD_EXCEL', 'PAYSLIP', $2, $3, $4);
    `, [req.user?.username || 'admin', String(entryId), `Downloaded Excel payslip for ${data.empName} (${data.empCode})`, req.user!.id]);
  } catch (err: any) {
    console.error('Payslip Excel error:', err);
    if (!res.headersSent) {
      res.status(500).json({ error: err.message || 'Failed to generate Excel payslip' });
    }
  }
});

// GET /api/export/payroll-xlsx/:periodId (Formula-preserving Excel register)
router.get('/payroll-xlsx/:periodId', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const periodId = Number(req.params.periodId);
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const creatorId = req.query.creatorId ? Number(req.query.creatorId) : null;
    const exportUserId = isSuper ? (creatorId || undefined) : userId;

    const pRes = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [periodId]);
    if (pRes.rows.length === 0) return res.status(404).json({ error: 'Payroll period not found' });
    const period = pRes.rows[0];

    const workbook = await ExcelExporter.generatePayrollWorkbook(periodId, exportUserId);

    const filename = `GGSSTP_Payroll_Register_${period.month_name}_${period.year}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    await workbook.xlsx.write(res);
    res.end();
  } catch (err: any) {
    console.error('Export Excel error:', err);
    res.status(500).json({ error: err.message || 'Failed to export Excel workbook' });
  }
});

// GET /api/export/bank-payment/:periodId (Bank Payment Sheet)
router.get('/bank-payment/:periodId', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const periodId = Number(req.params.periodId);
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const creatorId = req.query.creatorId ? Number(req.query.creatorId) : null;

    const pRes = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [periodId]);
    if (pRes.rows.length === 0) return res.status(404).json({ error: 'Payroll period not found' });
    const period = pRes.rows[0];

    let entriesQuery = `
      SELECT 
        e.emp_code, e.name as emp_name, e.bank_account, e.ifsc, pe.net_payable,
        c.name as contractor_name
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      WHERE pe.payroll_period_id = $1
    `;
    const entriesParams: any[] = [periodId];

    if (!isSuper) {
      entriesQuery += ` AND (pe.owner_user_id = $2 OR pe.created_by_user_id = $2 OR e.owner_user_id = $2 OR e.created_by_user_id = $2)`;
      entriesParams.push(userId);
    } else if (creatorId) {
      entriesQuery += ` AND (pe.owner_user_id = $2 OR pe.created_by_user_id = $2 OR e.owner_user_id = $2 OR e.created_by_user_id = $2)`;
      entriesParams.push(creatorId);
    }
    entriesQuery += ` ORDER BY e.emp_code ASC;`;

    const entriesRes = await db.query(entriesQuery, entriesParams);

    const workbook = new ExcelJS.Workbook();
    const ws = workbook.addWorksheet('Bank Payment Sheet');

    ws.mergeCells('A1:F1');
    ws.getCell('A1').value = `GGSSTP RUPNAGAR - BANK SALARY DISBURSEMENT SHEET (${period.month_name.toUpperCase()} ${period.year})`;
    ws.getCell('A1').font = { bold: true, size: 12 };
    ws.getCell('A1').alignment = { horizontal: 'center' };

    ws.getRow(2).values = ['Sr No', 'Emp Code', 'Employee Name', 'Bank Account No', 'IFSC Code', 'Net Payable Amount (₹)'];
    ws.getRow(2).font = { bold: true };
    ws.getRow(2).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E40AF' } };
    ws.getRow(2).eachCell(cell => { cell.font = { bold: true, color: { argb: 'FFFFFFFF' } }; });

    entriesRes.rows.forEach((r, idx) => {
      const row = ws.addRow([idx + 1, r.emp_code, r.emp_name, r.bank_account || 'N/A', r.ifsc || 'N/A', Number(r.net_payable)]);
      row.getCell(6).numFmt = '#,##0.00';
    });

    const totRow = ws.addRow(['', '', 'TOTAL', '', '', { formula: `SUM(F3:F${entriesRes.rows.length + 2})` }]);
    totRow.font = { bold: true };
    totRow.getCell(6).numFmt = '#,##0.00';

    ws.columns = [{ width: 8 }, { width: 15 }, { width: 25 }, { width: 22 }, { width: 16 }, { width: 24 }];

    const filename = `GGSSTP_Bank_Payment_${period.month_name}_${period.year}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    await workbook.xlsx.write(res);
    res.end();
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/export/employees-xlsx (Export user's employees to Excel)
router.post('/employees-xlsx', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { ids, search, designationId, contractorId, creatorId } = req.body;

    let query = `
      SELECT 
        e.*,
        d.alias as designation_alias, d.name as designation_name,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      WHERE 1=1
    `;
    const params: any[] = [];
    let idx = 1;

    if (!isSuper) {
      query += ` AND (e.owner_user_id = $${idx} OR e.created_by_user_id = $${idx})`;
      params.push(userId);
      idx++;
    } else if (creatorId) {
      query += ` AND (e.owner_user_id = $${idx} OR e.created_by_user_id = $${idx})`;
      params.push(Number(creatorId));
      idx++;
    }

    if (Array.isArray(ids) && ids.length > 0) {
      query += ` AND e.id = ANY($${idx++})`;
      params.push(ids.map(Number));
    } else {
      if (search) {
        query += ` AND (e.name ILIKE $${idx} OR e.emp_code ILIKE $${idx} OR e.uan ILIKE $${idx} OR e.bank_account ILIKE $${idx})`;
        params.push(`%${String(search).trim()}%`);
        idx++;
      }
      if (designationId) {
        query += ` AND e.designation_id = $${idx++}`;
        params.push(Number(designationId));
      }
      if (contractorId) {
        query += ` AND e.contractor_id = $${idx++}`;
        params.push(Number(contractorId));
      }
    }

    query += ` ORDER BY e.name ASC;`;

    const empRes = await db.query(query, params);
    const rows = empRes.rows;

    const workbook = new ExcelJS.Workbook();
    const ws = workbook.addWorksheet('Employee Master');

    // Title Header
    ws.mergeCells('A1:S1');
    ws.getCell('A1').value = 'GURU GOBIND SINGH SUPER THERMAL PLANT, RUPNAGAR';
    ws.getCell('A1').font = { bold: true, size: 13, color: { argb: 'FFFFFFFF' } };
    ws.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
    ws.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A8A' } };
    ws.getRow(1).height = 28;

    ws.mergeCells('A2:S2');
    ws.getCell('A2').value = `CONTRACTUAL EMPLOYEE MASTER REGISTER (${rows.length} EMPLOYEES EXPORTED - ${new Date().toLocaleDateString('en-IN')})`;
    ws.getCell('A2').font = { bold: true, size: 11, color: { argb: 'FF1E3A8A' } };
    ws.getCell('A2').alignment = { horizontal: 'center', vertical: 'middle' };
    ws.getCell('A2').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEFF6FF' } };
    ws.getRow(2).height = 22;

    // Table Column Headers
    const headers = [
      'Sr No', 'Emp Code', 'Employee Name', "Father's Name", 'Designation',
      'Contractor / Service Provider', 'Circle Division', 'UAN Number',
      'Bank Account Number', 'IFSC Code', 'ESI Number', 'Date of Joining',
      'Date of Birth', 'Age > 58', 'Experience', 'Qualification', 'Status',
      'Gross Salary Rate (₹)', 'Proportioned Salary (₹)'
    ];

    ws.getRow(3).values = headers;
    ws.getRow(3).height = 24;
    ws.getRow(3).eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E40AF' } };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    rows.forEach((r, idx) => {
      const grossRate = Number(r.default_gross_rate || r.gross_salary_rate || 16530);
      const rowIdx = idx + 4;
      const row = ws.addRow([
        idx + 1,
        r.emp_code,
        r.name,
        r.father_name || '—',
        `${r.designation_alias || 'SW'} (${r.designation_name || 'Skilled'})`,
        r.contractor_name || 'Direct / Unassigned',
        r.circle_name || 'General Circle',
        r.uan ? String(r.uan) : '—',
        r.bank_account ? String(r.bank_account) : '—',
        r.ifsc || '—',
        r.esi_number ? String(r.esi_number) : '—',
        r.date_of_joining || '—',
        r.dob || '—',
        r.age_above_58 === 'Y' ? 'YES' : 'NO',
        r.experience_years || '—',
        r.qualification || '—',
        r.is_active ? 'ACTIVE' : 'INACTIVE',
        grossRate,
        { formula: `ROUND((R${rowIdx}/30)*30, 0)`, result: grossRate }
      ]);

      row.getCell(8).numFmt = '@';
      row.getCell(9).numFmt = '@';
      row.getCell(11).numFmt = '@';
      row.getCell(18).numFmt = '#,##0.00';
      row.getCell(19).numFmt = '#,##0.00';

      row.alignment = { vertical: 'middle' };
      if (idx % 2 === 1) {
        row.eachCell(cell => {
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8FAFC' } };
        });
      }
    });

    ws.columns = [
      { width: 8 },  // Sr No
      { width: 14 }, // Emp Code
      { width: 26 }, // Name
      { width: 22 }, // Father's Name
      { width: 20 }, // Designation
      { width: 30 }, // Contractor
      { width: 20 }, // Circle
      { width: 18 }, // UAN
      { width: 22 }, // Bank A/c
      { width: 15 }, // IFSC
      { width: 18 }, // ESI
      { width: 15 }, // Joining
      { width: 14 }, // DOB
      { width: 12 }, // Age > 58
      { width: 14 }, // Experience
      { width: 16 }, // Qualification
      { width: 12 }, // Status
      { width: 20 }, // Gross Salary Rate
      { width: 24 }  // Proportioned Salary
    ];

    const filename = `GGSSTP_Employees_Master_Export_${new Date().toISOString().slice(0, 10)}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    await workbook.xlsx.write(res);
    res.end();
  } catch (err: any) {
    console.error('Export employees error:', err);
    res.status(500).json({ error: err.message || 'Failed to export employees' });
  }
});

export default router;
