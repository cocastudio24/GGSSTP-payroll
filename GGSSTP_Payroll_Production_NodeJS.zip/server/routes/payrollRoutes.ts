import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { calculatePayroll } from '../engine/payrollCalculator';
import { isSuperAdmin } from '../middleware/rbac';
import { fetchPayslipData } from '../payslip/payslipUtils';
import { syncPeriodWithActiveEmployees, syncEmployeesWithOpenPayrollPeriods } from '../services/payrollSyncService';

const router = Router();

// ==================== PAYROLL RULE SETS & FORMULA CONFIGURATION ====================

// GET /api/payroll/rules (Plant-wide rule sets with user fallback)
router.get('/rules', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    let result = await db.query(
      `SELECT * FROM payroll_rule_sets WHERE owner_user_id = $1 ORDER BY id ASC;`,
      [userId]
    );
    if (result.rows.length === 0) {
      result = await db.query(`SELECT * FROM payroll_rule_sets ORDER BY is_active DESC, id ASC;`);
    }
    res.json({ rules: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/rules
router.post('/rules', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Only Super Administrators can configure statutory formula rules' });
    }
    const userId = req.user!.id;
    const {
      name, epfWageCap, epfEmployerRate, epfMaxCap, epfAdminRate, epfAdminMaxCap,
      epfEmployeeRate, esiThreshold, esiEmployerRate, esiEmployeeRate,
      employerLwf, employeeLwf, thermalAllowanceBase, isActive
    } = req.body;

    if (!name || !name.trim()) return res.status(400).json({ error: 'Rule set name is required' });

    if (isActive) {
      await db.query(`UPDATE payroll_rule_sets SET is_active = FALSE WHERE owner_user_id = $1;`, [userId]);
    }

    const insRes = await db.query(`
      INSERT INTO payroll_rule_sets (
        owner_user_id, name, is_active, epf_wage_cap, epf_employer_rate, epf_max_cap, epf_admin_rate,
        epf_admin_max_cap, epf_employee_rate, esi_threshold, esi_employer_rate,
        esi_employee_rate, employer_lwf, employee_lwf, thermal_allowance_base
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
      RETURNING *;
    `, [
      userId, name.trim(), Boolean(isActive), Number(epfWageCap) || 25000,
      Number(epfEmployerRate) || 0.12, Number(epfMaxCap) || 3000,
      Number(epfAdminRate) || 0.01, Number(epfAdminMaxCap) || 250,
      Number(epfEmployeeRate) || 0.12, Number(esiThreshold) || 21000,
      Number(esiEmployerRate) || 0.0325, Number(esiEmployeeRate) || 0.0075,
      Number(employerLwf) || 20, Number(employeeLwf) || 5,
      Number(thermalAllowanceBase) || 1500
    ]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'CREATE_PAYROLL_RULE_SET', 'RULE_SET', $2, $3, $4);
    `, [req.user?.username || 'admin', String(insRes.rows[0].id), `Created rule set "${name.trim()}"`, userId]);

    res.status(201).json({ rule: insRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/payroll/rules/:id
router.put('/rules/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Only Super Administrators can configure statutory formula rules' });
    }
    const { id } = req.params;
    const userId = req.user!.id;
    const {
      name, epfWageCap, epfEmployerRate, epfMaxCap, epfAdminRate, epfAdminMaxCap,
      epfEmployeeRate, esiThreshold, esiEmployerRate, esiEmployeeRate,
      employerLwf, employeeLwf, thermalAllowanceBase, isActive
    } = req.body;

    if (isActive) {
      await db.query(
        `UPDATE payroll_rule_sets SET is_active = FALSE WHERE id != $1 AND owner_user_id = $2;`,
        [Number(id), userId]
      );
    }

    const updRes = await db.query(`
      UPDATE payroll_rule_sets SET
        name = COALESCE($1, name),
        is_active = COALESCE($2, is_active),
        epf_wage_cap = COALESCE($3, epf_wage_cap),
        epf_employer_rate = COALESCE($4, epf_employer_rate),
        epf_max_cap = COALESCE($5, epf_max_cap),
        epf_admin_rate = COALESCE($6, epf_admin_rate),
        epf_admin_max_cap = COALESCE($7, epf_admin_max_cap),
        epf_employee_rate = COALESCE($8, epf_employee_rate),
        esi_threshold = COALESCE($9, esi_threshold),
        esi_employer_rate = COALESCE($10, esi_employer_rate),
        esi_employee_rate = COALESCE($11, esi_employee_rate),
        employer_lwf = COALESCE($12, employer_lwf),
        employee_lwf = COALESCE($13, employee_lwf),
        thermal_allowance_base = COALESCE($14, thermal_allowance_base)
      WHERE id = $15 AND owner_user_id = $16
      RETURNING *;
    `, [
      name || null, isActive !== undefined ? Boolean(isActive) : null,
      epfWageCap !== undefined ? Number(epfWageCap) : null,
      epfEmployerRate !== undefined ? Number(epfEmployerRate) : null,
      epfMaxCap !== undefined ? Number(epfMaxCap) : null,
      epfAdminRate !== undefined ? Number(epfAdminRate) : null,
      epfAdminMaxCap !== undefined ? Number(epfAdminMaxCap) : null,
      epfEmployeeRate !== undefined ? Number(epfEmployeeRate) : null,
      esiThreshold !== undefined ? Number(esiThreshold) : null,
      esiEmployerRate !== undefined ? Number(esiEmployerRate) : null,
      esiEmployeeRate !== undefined ? Number(esiEmployeeRate) : null,
      employerLwf !== undefined ? Number(employerLwf) : null,
      employeeLwf !== undefined ? Number(employeeLwf) : null,
      thermalAllowanceBase !== undefined ? Number(thermalAllowanceBase) : null,
      Number(id), userId
    ]);

    if (updRes.rows.length === 0) return res.status(404).json({ error: 'Rule set not found' });

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'UPDATE_PAYROLL_RULE_SET', 'RULE_SET', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Updated payroll rule set ${updRes.rows[0].name}`, userId]);

    res.json({ rule: updRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== PAYROLL PERIODS ====================

// GET /api/payroll/periods (Periods list with user-scoped employee count and totals)
router.get('/periods', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const creatorId = req.query.creatorId ? Number(req.query.creatorId) : null;
    const targetUserId = !isSuper ? userId : (creatorId || null);

    let peFilter = '';
    const params: any[] = [];
    if (targetUserId) {
      peFilter = ` AND (pe.owner_user_id = $1 OR pe.created_by_user_id = $1)`;
      params.push(targetUserId);
    }

    let query = `
      SELECT 
        p.*,
        u.username as creator_username,
        u.full_name as creator_name,
        (SELECT COUNT(*) FROM payroll_entries pe JOIN employees e ON pe.employee_id = e.id WHERE pe.payroll_period_id = p.id AND (e.is_archived = FALSE OR e.is_archived IS NULL) AND e.is_active = TRUE ${peFilter}) as employee_count,
        (SELECT COALESCE(SUM(pe.net_payable), 0) FROM payroll_entries pe JOIN employees e ON pe.employee_id = e.id WHERE pe.payroll_period_id = p.id AND (e.is_archived = FALSE OR e.is_archived IS NULL) AND e.is_active = TRUE ${peFilter}) as total_net_payable,
        (SELECT COALESCE(SUM(pe.total_earnings_before_bonus + pe.bonus + pe.total_employer_contributions), 0) 
         FROM payroll_entries pe JOIN employees e ON pe.employee_id = e.id WHERE pe.payroll_period_id = p.id AND (e.is_archived = FALSE OR e.is_archived IS NULL) AND e.is_active = TRUE ${peFilter}) as total_employer_cost
      FROM payroll_periods p
      LEFT JOIN users u ON p.owner_user_id = u.id
      ORDER BY p.year DESC, p.month DESC, p.id DESC;
    `;

    const result = await db.query(query, params);
    res.json({ periods: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/periods (Creates period and computes entries for authorized active employees)
router.post('/periods', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { year, month, totalDays, notes } = req.body;
    if (!year || !month) return res.status(400).json({ error: 'Year and Month are required' });

    const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const mName = monthNames[Number(month)] || 'Month';

    const check = await db.query(
      `SELECT id FROM payroll_periods WHERE year = $1 AND month = $2;`,
      [Number(year), Number(month)]
    );
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Payroll period for ${mName} ${year} already exists in the system.` });
    }

    const insRes = await db.query(`
      INSERT INTO payroll_periods (owner_user_id, created_by_user_id, year, month, month_name, total_days, status, notes)
      VALUES ($1, $1, $2, $3, $4, $5, 'Draft', $6)
      RETURNING *;
    `, [userId, Number(year), Number(month), mName, Number(totalDays) || 30, notes || '']);

    const periodId = insRes.rows[0].id;

    // Fetch active rule set
    let ruleRes = await db.query(
      'SELECT * FROM payroll_rule_sets WHERE is_active = TRUE ORDER BY id ASC LIMIT 1;'
    );
    const activeRule = ruleRes.rows[0];

    let empQuery = `
      SELECT 
        e.id, e.owner_user_id, e.created_by_user_id, d.alias as designation_alias, 
        dsr.gross_salary_rate, dsr.special_allowance, dsr.perf_allowance_default,
        e.default_gross_rate, e.default_special_allowance, e.default_thermal_allowance,
        e.default_perf_allowance, e.default_bonus_percentage,
        e.custom_employee_epf, e.custom_employer_epf, e.custom_employer_epf1,
        e.custom_employee_esi, e.custom_employer_esi, e.custom_employee_lwf, e.custom_employer_lwf,
        e.epf_applicable, e.esi_applicable, e.lwf_applicable
      FROM employees e
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE e.is_active = TRUE AND e.archived_at IS NULL
    `;
    const empParams: any[] = [];
    if (!isSuper) {
      empQuery += ` AND (e.owner_user_id = $1 OR e.created_by_user_id = $1);`;
      empParams.push(userId);
    } else {
      empQuery += `;`;
    }
    const activeEmps = await db.query(empQuery, empParams);

    for (const emp of activeEmps.rows) {
      const grossRate = emp.default_gross_rate ? Number(emp.default_gross_rate) : emp.gross_salary_rate;
      const specialAllowance = emp.default_special_allowance ? Number(emp.default_special_allowance) : emp.special_allowance;
      const thermalAllowance = emp.default_thermal_allowance !== null && emp.default_thermal_allowance !== undefined ? Number(emp.default_thermal_allowance) : (activeRule ? Number(activeRule.thermal_allowance_base) : 1500);
      const perfMonthly = emp.default_perf_allowance !== null && emp.default_perf_allowance !== undefined ? Number(emp.default_perf_allowance) : (Number(emp.perf_allowance_default) || 225);
      const bonusPct = emp.default_bonus_percentage !== null && emp.default_bonus_percentage !== undefined && emp.default_bonus_percentage !== ''
        ? Number(emp.default_bonus_percentage)
        : (emp.default_bonus_percentage === null || emp.default_bonus_percentage === '' ? 0 : 8.33);

      const calc = calculatePayroll({
        designationAlias: emp.designation_alias || 'SW',
        grossSalaryRate: grossRate,
        specialAllowanceRate: specialAllowance,
        customThermalAllowance: thermalAllowance,
        totalDays: Number(totalDays) || 30,
        presentDays: Number(totalDays) || 30,
        perfAllowanceMonthly: perfMonthly,
        bonusPercentage: bonusPct,
        customEmployeeEpf: emp.custom_employee_epf !== null && emp.custom_employee_epf !== undefined && emp.custom_employee_epf !== ''
          ? Number(emp.custom_employee_epf)
          : (emp.epf_applicable === false ? 0 : undefined),
        customEmployerEpf: emp.custom_employer_epf !== null && emp.custom_employer_epf !== undefined && emp.custom_employer_epf !== ''
          ? Number(emp.custom_employer_epf)
          : (emp.epf_applicable === false ? 0 : undefined),
        customEmployerEpf1: emp.custom_employer_epf1 !== null && emp.custom_employer_epf1 !== undefined && emp.custom_employer_epf1 !== ''
          ? Number(emp.custom_employer_epf1)
          : (emp.epf_applicable === false ? 0 : undefined),
        customEmployeeEsi: emp.custom_employee_esi !== null && emp.custom_employee_esi !== undefined && emp.custom_employee_esi !== ''
          ? Number(emp.custom_employee_esi)
          : (emp.esi_applicable === false ? 0 : undefined),
        customEmployerEsi: emp.custom_employer_esi !== null && emp.custom_employer_esi !== undefined && emp.custom_employer_esi !== ''
          ? Number(emp.custom_employer_esi)
          : (emp.esi_applicable === false ? 0 : undefined),
        customEmployeeLwf: emp.custom_employee_lwf !== null && emp.custom_employee_lwf !== undefined && emp.custom_employee_lwf !== ''
          ? Number(emp.custom_employee_lwf)
          : (emp.lwf_applicable === false ? 0 : undefined),
        customEmployerLwf: emp.custom_employer_lwf !== null && emp.custom_employer_lwf !== undefined && emp.custom_employer_lwf !== ''
          ? Number(emp.custom_employer_lwf)
          : (emp.lwf_applicable === false ? 0 : undefined),
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      const effectiveEntryOwner = emp.owner_user_id || emp.created_by_user_id || userId || 1;
      await db.query(`
        INSERT INTO payroll_entries (
          owner_user_id, payroll_period_id, employee_id, present_days, gross_salary_rate, proportioned_salary,
          special_allowance, total_basic, thermal_allowance, perf_allowance_monthly, perf_allowance_days,
          total_earnings_before_bonus, bonus, employer_epf_12, employer_epf_1, employer_esi_325,
          employer_lwf, gross_total, employee_epf_12, employee_esi_075, employee_lwf,
          total_employee_deductions, total_employer_contributions, combined_deductions, net_payable,
          bonus_percentage, perf_last_drawn, perf_as_per_circle, perf_difference,
          calculation_mode
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
          $11, $12, $13, $14, $15, $16, $17, $18, $19, $20,
          $21, $22, $23, $24, $25, $26, $27, $28, $29, 'Reference-Compatible'
        );
      `, [
        effectiveEntryOwner, periodId, emp.id, Number(totalDays) || 30, calc.grossSalaryRate, calc.proportionedSalary,
        calc.specialAllowance, calc.totalBasic, calc.thermalAllowance, calc.perfAllowanceMonthly,
        calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12,
        calc.employerEpf1, calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions, calc.totalEmployerContributions,
        calc.combinedDeductions, calc.netPayable, calc.bonusPercentage, calc.perfLastDrawn,
        calc.perfAsPerCircle, calc.perfDifference
      ]);
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'CREATE_PAYROLL_PERIOD', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [req.user?.username || 'admin', String(periodId), `Created payroll period ${mName} ${year}`, userId]);

    res.status(201).json({ period: insRes.rows[0], entriesCount: activeEmps.rows.length });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/payroll/periods/:id/days (Update total days in period and recalculate)
router.put('/periods/:id/days', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { totalDays } = req.body;
    if (!totalDays || Number(totalDays) <= 0) {
      return res.status(400).json({ error: 'Total days must be greater than zero' });
    }

    const upd = await db.query(
      'UPDATE payroll_periods SET total_days = $1 WHERE id = $2 RETURNING *;',
      [Number(totalDays), Number(id)]
    );
    if (upd.rows.length === 0) return res.status(404).json({ error: 'Period not found' });

    res.json({ period: upd.rows[0], message: `Period total days updated to ${totalDays}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/periods/:id/sync-employees (Synchronize specific period with active employee register)
router.post('/periods/:id/sync-employees', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const syncRes = await syncPeriodWithActiveEmployees(Number(id), isSuper ? undefined : userId);
    if (!syncRes) {
      return res.status(404).json({ error: 'Payroll period not found' });
    }
    res.json({
      message: `Synchronized ${syncRes.periodName}: ${syncRes.addedCount} added, ${syncRes.updatedCount} updated, ${syncRes.removedCount} archived/removed.`,
      result: syncRes
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/sync-all-open (Synchronize all open periods with employee register)
router.post('/sync-all-open', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const result = await syncEmployeesWithOpenPayrollPeriods(userId);
    res.json({
      message: `Synchronized ${result.periodsSynced} open payroll period(s). Added: ${result.totalAdded}, Updated: ${result.totalUpdated}, Removed: ${result.totalRemoved}`,
      result
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== PAYROLL ENTRIES & COMPREHENSIVE ADJUSTMENTS ====================

// GET /api/payroll/entries (Plant-wide entries visible to Admin; strictly scoped for regular users)
router.get('/entries', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const creatorId = req.query.creatorId ? Number(req.query.creatorId) : null;
    const { periodId, designationId, contractorId, circleId, cell, search, page = 1, limit = 100 } = req.query;
    if (!periodId) return res.status(400).json({ error: 'periodId query param is required' });

    // Verify period exists
    const pCheck = await db.query(`SELECT id FROM payroll_periods WHERE id = $1;`, [Number(periodId)]);
    if (pCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Payroll period not found' });
    }

    let query = `
      SELECT 
        pe.*,
        e.emp_code, e.sr_no, e.name as emp_name, e.father_name, e.uan, e.dob,
        e.date_of_joining, e.qualification, e.experience_years, e.bank_account,
        e.ifsc, e.esi_number, e.cell,
        d.alias as designation_alias, d.name as designation_name,
        c.name as contractor_name,
        cir.name as circle_name,
        dep.name as department_name,
        p.total_days as period_total_days, p.status as period_status,
        u.username as creator_username,
        u.full_name as creator_name
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN contractors c ON e.contractor_id = c.id
      LEFT JOIN circles cir ON e.circle_id = cir.id
      LEFT JOIN departments dep ON e.department_id = dep.id
      LEFT JOIN users u ON pe.owner_user_id = u.id
      WHERE pe.payroll_period_id = $1 AND (e.is_archived = FALSE OR e.is_archived IS NULL) AND e.is_active = TRUE
    `;
    const params: any[] = [Number(periodId)];
    let idx = 2;

    if (!isSuper) {
      query += ` AND (pe.owner_user_id = $${idx} OR pe.created_by_user_id = $${idx} OR e.owner_user_id = $${idx} OR e.created_by_user_id = $${idx})`;
      params.push(userId);
      idx++;
    } else if (creatorId) {
      query += ` AND (pe.owner_user_id = $${idx} OR pe.created_by_user_id = $${idx} OR e.owner_user_id = $${idx} OR e.created_by_user_id = $${idx})`;
      params.push(creatorId);
      idx++;
    }

    if (cell) {
      query += ` AND e.cell ILIKE $${idx}`;
      params.push(`%${String(cell).trim()}%`);
      idx++;
    }

    if (search) {
      query += ` AND (e.name ILIKE $${idx} OR e.emp_code ILIKE $${idx} OR e.uan ILIKE $${idx} OR e.bank_account ILIKE $${idx})`;
      params.push(`%${String(search).trim()}%`);
      idx++;
    }

    if (designationId) {
      query += ` AND e.designation_id = $${idx++}`;
      params.push(Number(designationId));
    }

    if (contractorId) {
      query += ` AND e.contractor_id = $${idx++}`;
      params.push(Number(contractorId));
    }

    if (circleId) {
      query += ` AND e.circle_id = $${idx++}`;
      params.push(Number(circleId));
    }

    query += ` ORDER BY e.emp_code ASC`;

    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.max(1, Number(limit) || 100);
    const offset = (pageNum - 1) * limitNum;

    const countRes = await db.query(`SELECT COUNT(*) as total FROM (${query}) sub;`, params);
    const total = Number(countRes.rows[0].total) || 0;

    query += ` LIMIT $${idx++} OFFSET $${idx++}`;
    params.push(limitNum, offset);

    const result = await db.query(query, params);

    res.json({
      entries: result.rows,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum)
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/payroll/entries/:id/payslip (Fetch full payslip JSON for preview and print)
router.get('/entries/:id/payslip', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const entryId = Number(req.params.id);
    const data = await fetchPayslipData(entryId);
    if (!data) return res.status(404).json({ error: 'Payroll entry not found' });

    if (!isSuperAdmin(req.user) && data.ownerUserId !== req.user!.id && data.empOwnerUserId !== req.user!.id) {
      return res.status(403).json({ error: 'You are not authorized to view this employee payslip.' });
    }

    res.json({ payslip: data });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/payroll/entries/:id (Super Admin can update any; regular users update own)
router.put('/entries/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const {
      designation_id,
      present_days,
      gross_salary_rate,
      special_allowance,
      thermal_allowance,
      perf_allowance_monthly,
      bonus,
      bonus_percentage,
      perf_last_drawn,
      perf_as_per_circle,
      employee_epf_12,
      employee_esi_075,
      employee_lwf,
      employer_epf_12,
      employer_epf_1,
      employer_esi_325,
      employer_lwf
    } = req.body;

    // Fetch existing entry
    let entrySql = `
      SELECT pe.*, p.total_days, p.status as period_status, d.alias as designation_alias,
             e.name as emp_name, e.designation_id as emp_designation_id,
             e.owner_user_id as emp_owner_user_id, e.created_by_user_id as emp_created_by_user_id
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      WHERE pe.id = $1
    `;
    const entryParams: any[] = [Number(id)];

    const entryRes = await db.query(entrySql, entryParams);
    if (entryRes.rows.length === 0) return res.status(404).json({ error: 'Payroll entry not found' });
    const existing = entryRes.rows[0];

    if (!isSuper &&
        existing.owner_user_id !== userId &&
        existing.created_by_user_id !== userId &&
        existing.emp_owner_user_id !== userId &&
        existing.emp_created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to edit this payroll entry.' });
    }

    if (existing.period_status === 'Finalized' && !isSuper) {
      return res.status(403).json({ error: 'Period is finalized. Only Super Administrator can make authorized revisions.' });
    }

    // Check designation update if designation_id changed
    let desigAlias = existing.designation_alias || 'SW';
    let defaultGross = Number(existing.gross_salary_rate);
    let defaultSpecial = Number(existing.special_allowance);

    if (designation_id && Number(designation_id) !== Number(existing.emp_designation_id)) {
      const dCheck = await db.query(
        `SELECT d.id, d.alias, dsr.gross_salary_rate, dsr.special_allowance 
         FROM designations d 
         LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
         WHERE d.id = $1;`,
        [Number(designation_id)]
      );
      if (dCheck.rows.length > 0) {
        desigAlias = dCheck.rows[0].alias || desigAlias;
        if (dCheck.rows[0].gross_salary_rate) defaultGross = Number(dCheck.rows[0].gross_salary_rate);
        if (dCheck.rows[0].special_allowance) defaultSpecial = Number(dCheck.rows[0].special_allowance);
        await db.query(`UPDATE employees SET designation_id = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2;`, [Number(designation_id), existing.employee_id]);
      }
    }

    // Fetch active rule set for this user
    let ruleRes = await db.query(
      'SELECT * FROM payroll_rule_sets WHERE is_active = TRUE AND owner_user_id = $1 LIMIT 1;',
      [existing.owner_user_id || userId]
    );
    if (ruleRes.rows.length === 0) {
      ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    }
    const activeRule = ruleRes.rows[0];

    const totalDays = Number(existing.total_days) || 30;
    const newPresentDays = present_days !== undefined ? Number(present_days) : Number(existing.present_days);
    const newGrossRate = gross_salary_rate !== undefined ? Number(gross_salary_rate) : defaultGross;
    const newSpecialAllowance = special_allowance !== undefined ? Number(special_allowance) : defaultSpecial;
    const newPerfMonthly = perf_allowance_monthly !== undefined ? Number(perf_allowance_monthly) : Number(existing.perf_allowance_monthly);
    const newBonusPercentage = bonus_percentage !== undefined ? Number(bonus_percentage) : (existing.bonus_percentage !== null ? Number(existing.bonus_percentage) : 8.33);
    const newPerfLastDrawn = perf_last_drawn !== undefined ? Number(perf_last_drawn) : Number(existing.perf_last_drawn || 0);
    const newPerfAsPerCircle = perf_as_per_circle !== undefined ? Number(perf_as_per_circle) : Number(existing.perf_as_per_circle || 0);

    const calc = calculatePayroll({
      designationAlias: desigAlias,
      grossSalaryRate: newGrossRate,
      specialAllowanceRate: newSpecialAllowance,
      totalDays,
      presentDays: newPresentDays,
      perfAllowanceMonthly: newPerfMonthly,
      bonus: bonus !== undefined ? Number(bonus) : undefined,
      bonusPercentage: newBonusPercentage,
      perfLastDrawn: newPerfLastDrawn,
      perfAsPerCircle: newPerfAsPerCircle,
      customThermalAllowance: thermal_allowance !== undefined ? Number(thermal_allowance) : undefined,
      customEmployeeEpf: employee_epf_12 !== undefined ? Number(employee_epf_12) : undefined,
      customEmployeeEsi: employee_esi_075 !== undefined ? Number(employee_esi_075) : undefined,
      customEmployeeLwf: employee_lwf !== undefined ? Number(employee_lwf) : undefined,
      customEmployerEpf: employer_epf_12 !== undefined ? Number(employer_epf_12) : undefined,
      customEmployerEpf1: employer_epf_1 !== undefined ? Number(employer_epf_1) : undefined,
      customEmployerEsi: employer_esi_325 !== undefined ? Number(employer_esi_325) : undefined,
      customEmployerLwf: employer_lwf !== undefined ? Number(employer_lwf) : undefined,
      ruleSet: activeRule ? {
        epfWageCap: Number(activeRule.epf_wage_cap),
        epfEmployerRate: Number(activeRule.epf_employer_rate),
        epfMaxCap: Number(activeRule.epf_max_cap),
        epfAdminRate: Number(activeRule.epf_admin_rate),
        epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
        epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
        esiThreshold: Number(activeRule.esi_threshold),
        esiEmployerRate: Number(activeRule.esi_employer_rate),
        esiEmployeeRate: Number(activeRule.esi_employee_rate),
        employerLwf: Number(activeRule.employer_lwf),
        employeeLwf: Number(activeRule.employee_lwf),
        thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
      } : undefined
    });

    const isCustomized = (
      thermal_allowance !== undefined || employee_epf_12 !== undefined ||
      employee_esi_075 !== undefined || employee_lwf !== undefined ||
      employer_epf_12 !== undefined || employer_esi_325 !== undefined
    );

    let updateEntrySql = `
      UPDATE payroll_entries SET
        present_days = $1,
        gross_salary_rate = $2,
        proportioned_salary = $3,
        special_allowance = $4,
        total_basic = $5,
        thermal_allowance = $6,
        perf_allowance_monthly = $7,
        perf_allowance_days = $8,
        total_earnings_before_bonus = $9,
        bonus = $10,
        employer_epf_12 = $11,
        employer_epf_1 = $12,
        employer_esi_325 = $13,
        employer_lwf = $14,
        gross_total = $15,
        employee_epf_12 = $16,
        employee_esi_075 = $17,
        employee_lwf = $18,
        total_employee_deductions = $19,
        total_employer_contributions = $20,
        combined_deductions = $21,
        net_payable = $22,
        bonus_percentage = $23,
        perf_last_drawn = $24,
        perf_as_per_circle = $25,
        perf_difference = $26,
        is_overridden = $27,
        updated_by_user_id = $28,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $29
    `;
    const updateParams: any[] = [
      newPresentDays, newGrossRate, calc.proportionedSalary, newSpecialAllowance,
      calc.totalBasic, calc.thermalAllowance, newPerfMonthly, calc.perfAllowanceDaysWise,
      calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12, calc.employerEpf1,
      calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
      calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
      calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
      calc.bonusPercentage, calc.perfLastDrawn, calc.perfAsPerCircle, calc.perfDifference,
      isCustomized || existing.is_overridden, userId, Number(id)
    ];

    updateEntrySql += ` RETURNING *;`;

    const updRes = await db.query(updateEntrySql, updateParams);

    // Rates & Wages Memory: Persist modified rates as the employee's default wage baseline
    if (req.body.rememberRates !== false) {
      try {
        await db.query(`
          UPDATE employees SET
            default_gross_rate = COALESCE($1, default_gross_rate),
            default_special_allowance = COALESCE($2, default_special_allowance),
            default_thermal_allowance = COALESCE($3, default_thermal_allowance),
            default_perf_allowance = COALESCE($4, default_perf_allowance),
            default_bonus_percentage = COALESCE($5, default_bonus_percentage),
            updated_at = CURRENT_TIMESTAMP
          WHERE id = $6;
        `, [
          gross_salary_rate !== undefined ? Number(gross_salary_rate) : null,
          special_allowance !== undefined ? Number(special_allowance) : null,
          thermal_allowance !== undefined ? Number(thermal_allowance) : null,
          perf_allowance_monthly !== undefined ? Number(perf_allowance_monthly) : null,
          bonus_percentage !== undefined ? Number(bonus_percentage) : null,
          existing.employee_id
        ]);
      } catch (rateErr) {
        console.error('Failed to update employee default wage rates:', rateErr);
      }
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'UPDATE_PAYROLL_ENTRY', 'PAYROLL_ENTRY', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Updated components for ${existing.emp_name}. Net payable: ₹${calc.netPayable}`, userId]);

    res.json({ entry: updRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/payroll/entries/:id/net-payable (Direct Edit / Override Net Payable Salary)
router.put('/entries/:id/net-payable', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { netPayable, isOverridden = true, reason } = req.body;

    if (netPayable === undefined || isNaN(Number(netPayable))) {
      return res.status(400).json({ error: 'Valid netPayable numeric value is required' });
    }

    let checkSql = `
      SELECT pe.*, e.name as emp_name, e.owner_user_id as emp_owner_user_id, e.created_by_user_id as emp_created_by_user_id
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      WHERE pe.id = $1
    `;
    const checkParams: any[] = [Number(id)];
    const checkRes = await db.query(checkSql, checkParams);
    if (checkRes.rows.length === 0) {
      return res.status(404).json({ error: 'Payroll entry not found' });
    }
    const entry = checkRes.rows[0];

    if (!isSuper &&
        entry.owner_user_id !== userId &&
        entry.created_by_user_id !== userId &&
        entry.emp_owner_user_id !== userId &&
        entry.emp_created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to edit this payroll entry.' });
    }

    const updSql = `
      UPDATE payroll_entries SET
        net_payable = $1,
        is_overridden = $2,
        updated_by_user_id = $3,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $4
      RETURNING *;
    `;
    const updRes = await db.query(updSql, [Number(netPayable), Boolean(isOverridden), userId, Number(id)]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'OVERRIDE_NET_PAYABLE', 'PAYROLL_ENTRY', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Edited Net Payable for ${entry.emp_name} to ₹${netPayable} (Reason: ${reason || 'Direct user adjustment'})`, userId]);

    res.json({ entry: updRes.rows[0], message: `Net payable updated to ₹${netPayable}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/payroll/entries/:id/salary (Clear / Reset Salary for Single Employee)
router.delete('/entries/:id/salary', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);

    let checkSql = `
      SELECT pe.*, e.name as emp_name, e.owner_user_id as emp_owner_user_id, e.created_by_user_id as emp_created_by_user_id
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      WHERE pe.id = $1
    `;
    const checkParams: any[] = [Number(id)];
    const checkRes = await db.query(checkSql, checkParams);
    if (checkRes.rows.length === 0) {
      return res.status(404).json({ error: 'Payroll entry not found' });
    }
    const entry = checkRes.rows[0];

    if (!isSuper &&
        entry.owner_user_id !== userId &&
        entry.created_by_user_id !== userId &&
        entry.emp_owner_user_id !== userId &&
        entry.emp_created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to clear this payroll entry.' });
    }

    const resetSql = `
      UPDATE payroll_entries SET
        present_days = 0,
        proportioned_salary = 0,
        total_basic = 0,
        thermal_allowance = 0,
        perf_allowance_days = 0,
        total_earnings_before_bonus = 0,
        bonus = 0,
        employer_epf_12 = 0,
        employer_epf_1 = 0,
        employer_esi_325 = 0,
        gross_total = 0,
        employee_epf_12 = 0,
        employee_esi_075 = 0,
        total_employee_deductions = employee_lwf,
        total_employer_contributions = employer_lwf,
        combined_deductions = employee_lwf + employer_lwf,
        net_payable = 0,
        is_overridden = FALSE,
        updated_by_user_id = $2,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $1
      RETURNING *;
    `;
    const updRes = await db.query(resetSql, [Number(id), userId]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'RESET_EMPLOYEE_SALARY', 'PAYROLL_ENTRY', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Cleared salary calculation for ${entry.emp_name}`, userId]);

    res.json({ entry: updRes.rows[0], message: `Salary reset to zero for ${entry.emp_name}` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/periods/:id/bulk-delete-salaries (Bulk Clear / Reset Salaries for Selected Employees)
router.post('/periods/:id/bulk-delete-salaries', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    let { employeeIds, entryIds } = req.body;

    if ((!Array.isArray(employeeIds) || employeeIds.length === 0) && Array.isArray(entryIds) && entryIds.length > 0) {
      const mapped = await db.query(`SELECT employee_id FROM payroll_entries WHERE id = ANY($1);`, [entryIds]);
      employeeIds = mapped.rows.map(r => r.employee_id);
    }

    if (!Array.isArray(employeeIds) || employeeIds.length === 0) {
      return res.status(400).json({ error: 'employeeIds or entryIds array is required' });
    }

    let resetSql = `
      UPDATE payroll_entries SET
        present_days = 0,
        proportioned_salary = 0,
        total_basic = 0,
        thermal_allowance = 0,
        perf_allowance_days = 0,
        total_earnings_before_bonus = 0,
        bonus = 0,
        employer_epf_12 = 0,
        employer_epf_1 = 0,
        employer_esi_325 = 0,
        gross_total = 0,
        employee_epf_12 = 0,
        employee_esi_075 = 0,
        total_employee_deductions = employee_lwf,
        total_employer_contributions = employer_lwf,
        combined_deductions = employee_lwf + employer_lwf,
        net_payable = 0,
        is_overridden = FALSE,
        updated_at = CURRENT_TIMESTAMP
      WHERE payroll_period_id = $1 AND employee_id = ANY($2)
    `;
    const params: any[] = [Number(id), employeeIds];
    if (!isSuper) {
      resetSql += ` AND (owner_user_id = $3 OR created_by_user_id = $3 OR employee_id IN (SELECT id FROM employees WHERE owner_user_id = $3 OR created_by_user_id = $3))`;
      params.push(userId);
    }
    resetSql += ` RETURNING id;`;

    const result = await db.query(resetSql, params);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BULK_RESET_SALARIES', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Cleared salaries for ${result.rows.length} employee(s)`, userId]);

    res.json({
      message: `Cleared salary calculations for ${result.rows.length} employee(s)`,
      clearedCount: result.rows.length
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/periods/:id/generate-salaries (Bulk Generate Net Payable with Rounding Mode)
router.post('/periods/:id/generate-salaries', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { employeeIds, mode = 'formula', roundingMode = 'round_50_up', adoptExcel = false } = req.body;

    let periodSql = `SELECT * FROM payroll_periods WHERE id = $1`;
    const pParams: any[] = [Number(id)];
    const pRes = await db.query(periodSql, pParams);
    if (pRes.rows.length === 0) return res.status(404).json({ error: 'Payroll period not found' });
    const period = pRes.rows[0];

    // Fetch entries
    let entrySql = `
      SELECT pe.*, e.name as emp_name, d.alias as designation_alias,
             e.default_gross_rate, e.default_special_allowance, e.default_thermal_allowance,
             e.default_perf_allowance, e.default_bonus_percentage,
             e.epf_applicable, e.esi_applicable, e.lwf_applicable
      FROM payroll_entries pe
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      WHERE pe.payroll_period_id = $1
    `;
    const entryParams: any[] = [Number(id)];
    let eIdx = 2;
    if (!isSuper) {
      entrySql += ` AND (pe.owner_user_id = $${eIdx} OR pe.created_by_user_id = $${eIdx} OR e.owner_user_id = $${eIdx} OR e.created_by_user_id = $${eIdx})`;
      entryParams.push(userId);
      eIdx++;
    }
    if (Array.isArray(employeeIds) && employeeIds.length > 0) {
      entrySql += ` AND pe.employee_id = ANY($${eIdx++})`;
      entryParams.push(employeeIds);
    }
    const entries = await db.query(entrySql, entryParams);

    // Fetch active rule set
    let ruleRes = await db.query(
      'SELECT * FROM payroll_rule_sets WHERE is_active = TRUE AND owner_user_id = $1 LIMIT 1;',
      [userId]
    );
    if (ruleRes.rows.length === 0) {
      ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    }
    const activeRule = ruleRes.rows[0];

    let updatedCount = 0;
    for (const r of entries.rows) {
      let finalNetPayable: number;
      let isOverridden = r.is_overridden;

      if (adoptExcel && r.imported_net_payable !== null && r.imported_net_payable !== undefined) {
        finalNetPayable = Number(r.imported_net_payable);
        isOverridden = true;
      } else {
        const totalDays = Number(period.total_days) || 30;
        const presentDays = Number(r.present_days) || totalDays;
        const grossRate = Number(r.gross_salary_rate || r.default_gross_rate || 16530);
        const specialAllowance = Number(r.special_allowance || r.default_special_allowance || 3802);
        const thermalAllowance = Number(r.thermal_allowance || r.default_thermal_allowance || 1500);
        const perfMonthly = Number(r.perf_allowance_monthly || r.default_perf_allowance || 0);
        const bonusPct = r.bonus_percentage !== null ? Number(r.bonus_percentage) : (r.default_bonus_percentage !== null ? Number(r.default_bonus_percentage) : 8.33);

        const calc = calculatePayroll({
          designationAlias: r.designation_alias || 'SW',
          grossSalaryRate: grossRate,
          specialAllowanceRate: specialAllowance,
          customThermalAllowance: thermalAllowance,
          totalDays,
          presentDays,
          perfAllowanceMonthly: perfMonthly,
          bonusPercentage: bonusPct,
          roundingMode: roundingMode as any,
          ruleSet: activeRule ? {
            epfWageCap: Number(activeRule.epf_wage_cap),
            epfEmployerRate: Number(activeRule.epf_employer_rate),
            epfMaxCap: Number(activeRule.epf_max_cap),
            epfAdminRate: Number(activeRule.epf_admin_rate),
            epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
            epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
            esiThreshold: Number(activeRule.esi_threshold),
            esiEmployerRate: Number(activeRule.esi_employer_rate),
            esiEmployeeRate: Number(activeRule.esi_employee_rate),
            employerLwf: Number(activeRule.employer_lwf),
            employeeLwf: Number(activeRule.employee_lwf),
            thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
          } : undefined
        });

        finalNetPayable = calc.netPayable;

        await db.query(`
          UPDATE payroll_entries SET
            proportioned_salary = $1,
            total_basic = $2,
            thermal_allowance = $3,
            perf_allowance_days = $4,
            total_earnings_before_bonus = $5,
            bonus = $6,
            employer_epf_12 = $7,
            employer_epf_1 = $8,
            employer_esi_325 = $9,
            gross_total = $10,
            employee_epf_12 = $11,
            employee_esi_075 = $12,
            total_employee_deductions = $13,
            total_employer_contributions = $14,
            combined_deductions = $15,
            net_payable = $16,
            rounding_mode = $17,
            updated_at = CURRENT_TIMESTAMP
          WHERE id = $18;
        `, [
          calc.proportionedSalary, calc.totalBasic, calc.thermalAllowance,
          calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.bonus,
          calc.employerEpf12, calc.employerEpf1, calc.employerEsi325,
          calc.grossTotal, calc.employeeEpf12, calc.employeeEsi075,
          calc.totalEmployeeDeductions, calc.totalEmployerContributions,
          calc.combinedDeductions, finalNetPayable, roundingMode, r.id
        ]);
        updatedCount++;
        continue;
      }

      await db.query(`
        UPDATE payroll_entries SET
          net_payable = $1,
          is_overridden = $2,
          rounding_mode = $3,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $4;
      `, [finalNetPayable, isOverridden, roundingMode, r.id]);
      updatedCount++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'GENERATE_NET_PAYABLE', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Generated Net Payable for ${updatedCount} employees with roundingMode=${roundingMode}`, userId]);

    res.json({
      message: `Successfully generated Net Payable for ${updatedCount} employees (${roundingMode})`,
      updatedCount
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/attendance/batch (Batch update employee days)
router.post('/attendance/batch', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { periodId, days, employeeIds } = req.body;
    if (!periodId || days === undefined || Number(days) < 0) {
      return res.status(400).json({ error: 'periodId and valid days are required' });
    }

    let query = `
      SELECT pe.*, p.total_days, d.alias as designation_alias,
             dsr.gross_salary_rate as curr_gross, dsr.special_allowance as curr_special
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE pe.payroll_period_id = $1
    `;
    const params: any[] = [Number(periodId)];
    let pIdx = 2;

    if (!isSuper) {
      query += ` AND (pe.owner_user_id = $${pIdx} OR pe.created_by_user_id = $${pIdx} OR e.owner_user_id = $${pIdx} OR e.created_by_user_id = $${pIdx})`;
      params.push(userId);
      pIdx++;
    }

    if (Array.isArray(employeeIds) && employeeIds.length > 0) {
      query += ` AND pe.employee_id = ANY($${pIdx++})`;
      params.push(employeeIds);
    }

    const rows = await db.query(query, params);

    let ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE AND owner_user_id = $1 LIMIT 1;', [userId]);
    if (ruleRes.rows.length === 0) {
      ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    }
    const activeRule = ruleRes.rows[0];

    let count = 0;
    for (const r of rows.rows) {
      const calc = calculatePayroll({
        designationAlias: r.designation_alias || 'SW',
        grossSalaryRate: Number(r.curr_gross || r.gross_salary_rate),
        specialAllowanceRate: Number(r.curr_special || r.special_allowance),
        totalDays: Number(r.total_days),
        presentDays: Number(days),
        perfAllowanceMonthly: Number(r.perf_allowance_monthly),
        bonus: r.is_overridden ? Number(r.bonus) : undefined,
        bonusPercentage: r.bonus_percentage !== null && r.bonus_percentage !== undefined ? Number(r.bonus_percentage) : 8.33,
        perfLastDrawn: Number(r.perf_last_drawn || 0),
        perfAsPerCircle: Number(r.perf_as_per_circle || 0),
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          present_days = $1,
          proportioned_salary = $2,
          total_basic = $3,
          thermal_allowance = $4,
          perf_allowance_days = $5,
          total_earnings_before_bonus = $6,
          bonus = $7,
          employer_epf_12 = $8,
          employer_epf_1 = $9,
          employer_esi_325 = $10,
          gross_total = $11,
          employee_epf_12 = $12,
          employee_esi_075 = $13,
          total_employee_deductions = $14,
          total_employer_contributions = $15,
          combined_deductions = $16,
          net_payable = $17,
          bonus_percentage = $18,
          perf_last_drawn = $19,
          perf_as_per_circle = $20,
          perf_difference = $21,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $22;
      `, [
        Number(days), calc.proportionedSalary, calc.totalBasic, calc.thermalAllowance,
        calc.perfAllowanceDaysWise, calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12,
        calc.employerEpf1, calc.employerEsi325, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.totalEmployeeDeductions, calc.totalEmployerContributions,
        calc.combinedDeductions, calc.netPayable, calc.bonusPercentage, calc.perfLastDrawn,
        calc.perfAsPerCircle, calc.perfDifference, r.id
      ]);
      count++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BATCH_ATTENDANCE_UPDATE', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [req.user?.username || 'admin', String(periodId), `Batch updated attendance to ${days} days for ${count} employees`, userId]);

    res.json({ message: `Attendance updated for ${count} employees`, count });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/batch-update
router.post('/batch-update', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const {
      periodId,
      entryIds,
      designationId,
      contractorId,
      updates = {}
    } = req.body;

    if (!periodId) return res.status(400).json({ error: 'periodId is required' });

    const periodRes = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [Number(periodId)]);
    if (periodRes.rows.length === 0) return res.status(404).json({ error: 'Period not found' });
    const period = periodRes.rows[0];

    if (period.status === 'Finalized' && req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Period is finalized. Only Super Administrator can make authorized revisions.' });
    }

    let ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE ORDER BY id ASC LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    let query = `
      SELECT pe.*, p.total_days, d.alias as designation_alias,
             dsr.gross_salary_rate as std_gross, dsr.special_allowance as std_special, dsr.perf_allowance_default as std_perf
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE pe.payroll_period_id = $1
    `;
    const params: any[] = [Number(periodId)];
    let pIdx = 2;

    if (!isSuper) {
      query += ` AND (pe.owner_user_id = $${pIdx} OR pe.created_by_user_id = $${pIdx} OR e.owner_user_id = $${pIdx} OR e.created_by_user_id = $${pIdx})`;
      params.push(userId);
      pIdx++;
    }

    if (Array.isArray(entryIds) && entryIds.length > 0) {
      query += ` AND pe.id = ANY($${pIdx++})`;
      params.push(entryIds);
    } else {
      if (designationId) {
        query += ` AND e.designation_id = $${pIdx++}`;
        params.push(Number(designationId));
      }
      if (contractorId) {
        query += ` AND e.contractor_id = $${pIdx++}`;
        params.push(Number(contractorId));
      }
    }

    const rowsRes = await db.query(query, params);
    if (rowsRes.rows.length === 0) {
      return res.json({ message: 'No entries matched the criteria', updatedCount: 0 });
    }

    let updatedCount = 0;
    for (const r of rowsRes.rows) {
      const totalDays = Number(r.total_days) || 30;

      let newGrossRate = Number(r.gross_salary_rate);
      let newSpecialAllowance = Number(r.special_allowance);
      let newPerfMonthly = Number(r.perf_allowance_monthly);
      let newPresentDays = Number(r.present_days);
      let newBonusPercentage = r.bonus_percentage !== null && r.bonus_percentage !== undefined ? Number(r.bonus_percentage) : 8.33;
      let newPerfLastDrawn = Number(r.perf_last_drawn || 0);
      let newPerfCircle = Number(r.perf_as_per_circle || 0);
      let explicitBonus: number | undefined = r.is_overridden ? Number(r.bonus) : undefined;
      let customThermal: number | undefined = undefined;

      if (updates.resetToDesignationDefaults) {
        newGrossRate = r.std_gross !== null ? Number(r.std_gross) : Number(r.gross_salary_rate);
        newSpecialAllowance = r.std_special !== null ? Number(r.std_special) : Number(r.special_allowance);
        newPerfMonthly = r.std_perf !== null ? Number(r.std_perf) : 225;
        customThermal = undefined;
        newBonusPercentage = 8.33;
        explicitBonus = undefined;
      } else {
        if (updates.gross_salary_rate !== undefined && updates.gross_salary_rate !== null && updates.gross_salary_rate !== '') {
          newGrossRate = Number(updates.gross_salary_rate);
        }
        if (updates.special_allowance !== undefined && updates.special_allowance !== null && updates.special_allowance !== '') {
          newSpecialAllowance = Number(updates.special_allowance);
        }
        if (updates.perf_allowance_monthly !== undefined && updates.perf_allowance_monthly !== null && updates.perf_allowance_monthly !== '') {
          newPerfMonthly = Number(updates.perf_allowance_monthly);
        }
        if (updates.bonus_percentage !== undefined && updates.bonus_percentage !== null && updates.bonus_percentage !== '') {
          newBonusPercentage = Number(updates.bonus_percentage);
          explicitBonus = undefined; // Dynamically recalculate bonus based on new percentage
        }
        if (updates.bonus !== undefined && updates.bonus !== null && updates.bonus !== '') {
          explicitBonus = Number(updates.bonus);
        }
        if (updates.perf_last_drawn !== undefined && updates.perf_last_drawn !== null && updates.perf_last_drawn !== '') {
          newPerfLastDrawn = Number(updates.perf_last_drawn);
        }
        if (updates.perf_as_per_circle !== undefined && updates.perf_as_per_circle !== null && updates.perf_as_per_circle !== '') {
          newPerfCircle = Number(updates.perf_as_per_circle);
        }
        if (updates.present_days !== undefined && updates.present_days !== null && updates.present_days !== '') {
          newPresentDays = Number(updates.present_days);
        }
        if (updates.thermal_mode === 'fixed') {
          customThermal = updates.thermal_allowance !== undefined && updates.thermal_allowance !== '' ? Number(updates.thermal_allowance) : 1500;
        } else if (updates.thermal_mode === 'custom') {
          customThermal = Number(updates.thermal_allowance);
        } else if (updates.thermal_mode === 'auto') {
          customThermal = undefined;
        } else if (updates.thermal_allowance !== undefined && updates.thermal_allowance !== '') {
          customThermal = Number(updates.thermal_allowance);
        } else {
          customThermal = r.thermal_allowance !== null ? Number(r.thermal_allowance) : undefined;
        }
      }

      const calc = calculatePayroll({
        designationAlias: r.designation_alias || 'SW',
        grossSalaryRate: newGrossRate,
        specialAllowanceRate: newSpecialAllowance,
        totalDays,
        presentDays: newPresentDays,
        perfAllowanceMonthly: newPerfMonthly,
        bonus: explicitBonus,
        bonusPercentage: newBonusPercentage,
        perfLastDrawn: newPerfLastDrawn,
        perfAsPerCircle: newPerfCircle,
        customThermalAllowance: customThermal,
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          present_days = $1,
          gross_salary_rate = $2,
          proportioned_salary = $3,
          special_allowance = $4,
          total_basic = $5,
          thermal_allowance = $6,
          perf_allowance_monthly = $7,
          perf_allowance_days = $8,
          total_earnings_before_bonus = $9,
          bonus = $10,
          employer_epf_12 = $11,
          employer_epf_1 = $12,
          employer_esi_325 = $13,
          employer_lwf = $14,
          gross_total = $15,
          employee_epf_12 = $16,
          employee_esi_075 = $17,
          employee_lwf = $18,
          total_employee_deductions = $19,
          total_employer_contributions = $20,
          combined_deductions = $21,
          net_payable = $22,
          bonus_percentage = $23,
          perf_last_drawn = $24,
          perf_as_per_circle = $25,
          perf_difference = $26,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $27;
      `, [
        newPresentDays, newGrossRate, calc.proportionedSalary, newSpecialAllowance,
        calc.totalBasic, calc.thermalAllowance, newPerfMonthly, calc.perfAllowanceDaysWise,
        calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12, calc.employerEpf1,
        calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
        calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
        calc.bonusPercentage, calc.perfLastDrawn, calc.perfAsPerCircle, calc.perfDifference,
        r.id
      ]);
      updatedCount++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'BULK_UPDATE_ALLOWANCES_RATES', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [req.user?.username || 'admin', String(periodId), `Bulk updated allowances and rates for ${updatedCount} employees`, userId]);

    res.json({ message: `Successfully updated ${updatedCount} employees in 1-click`, updatedCount });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/batch-save-grid
router.post('/batch-save-grid', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    const { periodId, rows } = req.body;
    if (!periodId || !Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'periodId and rows array are required' });
    }

    const periodRes = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [Number(periodId)]);
    if (periodRes.rows.length === 0) return res.status(404).json({ error: 'Period not found' });
    const period = periodRes.rows[0];

    if (period.status === 'Finalized' && req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Period is finalized. Only Super Administrator can make authorized revisions.' });
    }

    let ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE ORDER BY id ASC LIMIT 1;');
    const activeRule = ruleRes.rows[0];

    let savedCount = 0;
    for (const r of rows) {
      if (!r.id) continue;
      let entryQuery = `
        SELECT pe.*, p.total_days, d.alias as designation_alias
        FROM payroll_entries pe
        JOIN payroll_periods p ON pe.payroll_period_id = p.id
        JOIN employees e ON pe.employee_id = e.id
        LEFT JOIN designations d ON e.designation_id = d.id
        WHERE pe.id = $1 AND pe.payroll_period_id = $2
      `;
      const entryParams: any[] = [Number(r.id), Number(periodId)];
      if (!isSuper) {
        entryQuery += ` AND (pe.owner_user_id = $3 OR pe.created_by_user_id = $3 OR e.owner_user_id = $3 OR e.created_by_user_id = $3)`;
        entryParams.push(userId);
      }
      const entryRes = await db.query(entryQuery, entryParams);

      if (entryRes.rows.length === 0) continue;
      const existing = entryRes.rows[0];
      const totalDays = Number(existing.total_days) || 30;

      const newPresentDays = r.present_days !== undefined ? Number(r.present_days) : Number(existing.present_days);
      const newGrossRate = r.gross_salary_rate !== undefined ? Number(r.gross_salary_rate) : Number(existing.gross_salary_rate);
      const newSpecial = r.special_allowance !== undefined ? Number(r.special_allowance) : Number(existing.special_allowance);
      const newThermal = r.thermal_allowance !== undefined ? Number(r.thermal_allowance) : Number(existing.thermal_allowance);
      const newPerfMonthly = r.perf_allowance_monthly !== undefined ? Number(r.perf_allowance_monthly) : Number(existing.perf_allowance_monthly);
      const newBonusPercentage = r.bonus_percentage !== undefined && r.bonus_percentage !== null && r.bonus_percentage !== ''
        ? Number(r.bonus_percentage)
        : (existing.bonus_percentage !== null ? Number(existing.bonus_percentage) : 8.33);
      const newBonus = r.bonus !== undefined && r.bonus !== null && r.bonus !== ''
        ? Number(r.bonus)
        : (r.bonus_percentage !== undefined ? undefined : (existing.is_overridden ? Number(existing.bonus) : undefined));
      const newPerfLastDrawn = r.perf_last_drawn !== undefined ? Number(r.perf_last_drawn) : Number(existing.perf_last_drawn || 0);
      const newPerfCircle = r.perf_as_per_circle !== undefined ? Number(r.perf_as_per_circle) : Number(existing.perf_as_per_circle || 0);

      const calc = calculatePayroll({
        designationAlias: existing.designation_alias || 'SW',
        grossSalaryRate: newGrossRate,
        specialAllowanceRate: newSpecial,
        totalDays,
        presentDays: newPresentDays,
        perfAllowanceMonthly: newPerfMonthly,
        bonus: newBonus,
        bonusPercentage: newBonusPercentage,
        perfLastDrawn: newPerfLastDrawn,
        perfAsPerCircle: newPerfCircle,
        customThermalAllowance: newThermal,
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          present_days = $1,
          gross_salary_rate = $2,
          proportioned_salary = $3,
          special_allowance = $4,
          total_basic = $5,
          thermal_allowance = $6,
          perf_allowance_monthly = $7,
          perf_allowance_days = $8,
          total_earnings_before_bonus = $9,
          bonus = $10,
          employer_epf_12 = $11,
          employer_epf_1 = $12,
          employer_esi_325 = $13,
          employer_lwf = $14,
          gross_total = $15,
          employee_epf_12 = $16,
          employee_esi_075 = $17,
          employee_lwf = $18,
          total_employee_deductions = $19,
          total_employer_contributions = $20,
          combined_deductions = $21,
          net_payable = $22,
          bonus_percentage = $23,
          perf_last_drawn = $24,
          perf_as_per_circle = $25,
          perf_difference = $26,
          updated_by_user_id = $27,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $28;
      `, [
        newPresentDays, newGrossRate, calc.proportionedSalary, newSpecial,
        calc.totalBasic, calc.thermalAllowance, newPerfMonthly, calc.perfAllowanceDaysWise,
        calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12, calc.employerEpf1,
        calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
        calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
        calc.bonusPercentage, calc.perfLastDrawn, calc.perfAsPerCircle, calc.perfDifference,
        userId, r.id
      ]);
      savedCount++;
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'GRID_SAVE_ALLOWANCES_RATES', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [req.user?.username || 'admin', String(periodId), `Grid saved allowances and rates for ${savedCount} entries in 1 click`, userId]);

    res.json({ message: `Saved changes for ${savedCount} entries in 1-click`, savedCount });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/entries/:id/override (Manual field override)
router.post('/entries/:id/override', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const { fieldName, overrideValue, reason } = req.body;
    if (!fieldName || overrideValue === undefined || !reason) {
      return res.status(400).json({ error: 'fieldName, overrideValue, and reason are required' });
    }

    const isSuper = isSuperAdmin(req.user);
    const curRes = await db.query(
      `SELECT pe.*, e.owner_user_id as emp_owner_user_id, e.created_by_user_id as emp_created_by_user_id 
       FROM payroll_entries pe 
       JOIN employees e ON pe.employee_id = e.id 
       WHERE pe.id = $1;`,
      [Number(id)]
    );
    if (curRes.rows.length === 0) return res.status(404).json({ error: 'Payroll entry not found' });
    const cur = curRes.rows[0];

    if (!isSuper &&
        cur.owner_user_id !== userId &&
        cur.created_by_user_id !== userId &&
        cur.emp_owner_user_id !== userId &&
        cur.emp_created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to override this payroll entry.' });
    }

    const originalValue = cur[fieldName];
    const validFields = [
      'gross_salary_rate', 'special_allowance', 'thermal_allowance', 'bonus',
      'employee_epf_12', 'employee_esi_075', 'employee_lwf', 'net_payable'
    ];
    if (!validFields.includes(fieldName)) {
      return res.status(400).json({ error: `Field "${fieldName}" cannot be manually overridden.` });
    }

    await db.query(`
      UPDATE payroll_entries SET ${fieldName} = $1, is_overridden = TRUE, updated_at = CURRENT_TIMESTAMP
      WHERE id = $2;
    `, [Number(overrideValue), Number(id)]);

    await db.query(`
      INSERT INTO payroll_overrides (owner_user_id, payroll_entry_id, field_name, original_value, override_value, reason, user_name)
      VALUES ($1, $2, $3, $4, $5, $6, $7);
    `, [cur.owner_user_id || userId, Number(id), fieldName, Number(originalValue) || 0, Number(overrideValue), reason, req.user?.username || 'admin']);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'OVERRIDE_PAYROLL_FIELD', 'PAYROLL_ENTRY', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Overrode ${fieldName} to ₹${overrideValue}. Reason: ${reason}`, userId]);

    const updated = await db.query(`SELECT * FROM payroll_entries WHERE id = $1;`, [Number(id)]);
    res.json({ entry: updated.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/periods/:id/status (Workflow state machine strictly user-scoped)
router.post('/periods/:id/status', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const { status, justification } = req.body;
    const allowed = ['Draft', 'Calculated', 'Under Review', 'Approved', 'Finalized', 'Reopened'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Allowed: ${allowed.join(', ')}` });
    }

    const isSuper = isSuperAdmin(req.user);
    const pCheck = await db.query('SELECT * FROM payroll_periods WHERE id = $1;', [Number(id)]);
    if (pCheck.rows.length === 0) return res.status(404).json({ error: 'Payroll period not found' });
    const period = pCheck.rows[0];

    if (!isSuper && period.owner_user_id !== userId && period.created_by_user_id !== userId) {
      return res.status(403).json({ error: 'Access denied: You are not authorized to modify the status of this payroll period.' });
    }

    let query = `UPDATE payroll_periods SET status = $1`;
    const params: any[] = [status === 'Reopened' ? 'Draft' : status];

    if (status === 'Finalized') {
      query += `, finalized_at = CURRENT_TIMESTAMP`;
    }

    query += ` WHERE id = $2 RETURNING *;`;
    params.push(Number(id));

    const result = await db.query(query, params);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'UPDATE_PERIOD_STATUS', 'PAYROLL_PERIOD', $2, $3, $4);
    `, [req.user?.username || 'admin', String(id), `Status changed to ${status}. ${justification ? `Notes: ${justification}` : ''}`, userId]);

    res.json({ period: result.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payroll/recalculate-all
router.post('/recalculate-all', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { periodId } = req.body;
    const userId = req.user!.id;
    const isSuper = isSuperAdmin(req.user);
    if (!periodId) return res.status(400).json({ error: 'periodId is required' });

    const pCheck = await db.query('SELECT id FROM payroll_periods WHERE id = $1;', [Number(periodId)]);
    if (pCheck.rows.length === 0) return res.status(404).json({ error: 'Period not found' });

    // Fetch active rule set
    let ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE AND owner_user_id = $1 LIMIT 1;', [userId]);
    if (ruleRes.rows.length === 0) {
      ruleRes = await db.query('SELECT * FROM payroll_rule_sets WHERE is_active = TRUE LIMIT 1;');
    }
    const activeRule = ruleRes.rows[0];

    let entriesQuery = `
      SELECT pe.*, p.total_days, d.alias as designation_alias,
             dsr.gross_salary_rate as curr_gross, dsr.special_allowance as curr_special
      FROM payroll_entries pe
      JOIN payroll_periods p ON pe.payroll_period_id = p.id
      JOIN employees e ON pe.employee_id = e.id
      LEFT JOIN designations d ON e.designation_id = d.id
      LEFT JOIN designation_salary_rates dsr ON d.id = dsr.designation_id AND dsr.is_active = TRUE
      WHERE pe.payroll_period_id = $1
    `;
    const entriesParams: any[] = [Number(periodId)];
    if (!isSuper) {
      entriesQuery += ` AND (pe.owner_user_id = $2 OR pe.created_by_user_id = $2 OR e.owner_user_id = $2 OR e.created_by_user_id = $2);`;
      entriesParams.push(userId);
    }
    const entriesRes = await db.query(entriesQuery, entriesParams);

    let count = 0;
    for (const row of entriesRes.rows) {
      const calc = calculatePayroll({
        designationAlias: row.designation_alias || 'SW',
        grossSalaryRate: row.curr_gross !== null ? Number(row.curr_gross) : Number(row.gross_salary_rate),
        specialAllowanceRate: row.curr_special !== null ? Number(row.curr_special) : Number(row.special_allowance),
        totalDays: Number(row.total_days),
        presentDays: Number(row.present_days),
        perfAllowanceMonthly: Number(row.perf_allowance_monthly),
        bonus: row.is_overridden ? Number(row.bonus) : undefined,
        bonusPercentage: row.bonus_percentage !== null && row.bonus_percentage !== undefined ? Number(row.bonus_percentage) : 8.33,
        perfLastDrawn: Number(row.perf_last_drawn || 0),
        perfAsPerCircle: Number(row.perf_as_per_circle || 0),
        ruleSet: activeRule ? {
          epfWageCap: Number(activeRule.epf_wage_cap),
          epfEmployerRate: Number(activeRule.epf_employer_rate),
          epfMaxCap: Number(activeRule.epf_max_cap),
          epfAdminRate: Number(activeRule.epf_admin_rate),
          epfAdminMaxCap: Number(activeRule.epf_admin_max_cap),
          epfEmployeeRate: Number(activeRule.epf_employee_rate || activeRule.epf_employer_rate),
          esiThreshold: Number(activeRule.esi_threshold),
          esiEmployerRate: Number(activeRule.esi_employer_rate),
          esiEmployeeRate: Number(activeRule.esi_employee_rate),
          employerLwf: Number(activeRule.employer_lwf),
          employeeLwf: Number(activeRule.employee_lwf),
          thermalAllowanceBase: Number(activeRule.thermal_allowance_base)
        } : undefined
      });

      await db.query(`
        UPDATE payroll_entries SET
          proportioned_salary = $1,
          total_basic = $2,
          thermal_allowance = $3,
          perf_allowance_days = $4,
          total_earnings_before_bonus = $5,
          bonus = $6,
          employer_epf_12 = $7,
          employer_epf_1 = $8,
          employer_esi_325 = $9,
          employer_lwf = $10,
          gross_total = $11,
          employee_epf_12 = $12,
          employee_esi_075 = $13,
          employee_lwf = $14,
          total_employee_deductions = $15,
          total_employer_contributions = $16,
          combined_deductions = $17,
          net_payable = $18,
          bonus_percentage = $19,
          perf_last_drawn = $20,
          perf_as_per_circle = $21,
          perf_difference = $22,
          updated_at = CURRENT_TIMESTAMP
        WHERE id = $23;
      `, [
        calc.proportionedSalary, calc.totalBasic, calc.thermalAllowance, calc.perfAllowanceDaysWise,
        calc.totalEarningsBeforeBonus, calc.bonus, calc.employerEpf12, calc.employerEpf1,
        calc.employerEsi325, calc.employerLwf, calc.grossTotal, calc.employeeEpf12,
        calc.employeeEsi075, calc.employeeLwf, calc.totalEmployeeDeductions,
        calc.totalEmployerContributions, calc.combinedDeductions, calc.netPayable,
        calc.bonusPercentage, calc.perfLastDrawn, calc.perfAsPerCircle, calc.perfDifference,
        row.id
      ]);
      count++;
    }

    res.json({ message: `Successfully recalculated ${count} entries with active rules` });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
