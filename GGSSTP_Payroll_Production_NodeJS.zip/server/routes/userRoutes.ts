import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { db } from '../database/db';
import { generateToken, authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { isSuperAdmin } from '../middleware/rbac';
import { ensureUserWorkspace } from '../database/workspaceManager';

const router = Router();
export const PROTECTED_USERNAMES = ['admin', 'cell1', 'cell2', 'cell3'];

// GET /api/users (Restricted strictly to Super Administrator)
router.get('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Access denied: Only Super Administrators can view user accounts' });
    }

    const result = await db.query(`
      SELECT id, uuid, username, full_name, role, is_active, created_at, updated_at
      FROM users
      ORDER BY id ASC;
    `);
    res.json({ users: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/users
router.post('/', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Only Super Administrators can create users' });
    }

    const { username, password, fullName, role } = req.body;
    if (!username || !password || !fullName) {
      return res.status(400).json({ error: 'Username, password, and full name are required' });
    }

    if (username.trim().length < 3) {
      return res.status(400).json({ error: 'Username must be at least 3 characters long' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long' });
    }

    const check = await db.query('SELECT id FROM users WHERE LOWER(username) = LOWER($1);', [username.trim()]);
    if (check.rows.length > 0) {
      return res.status(409).json({ error: `Username "${username.trim()}" is already taken.` });
    }

    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(password, salt);
    const userUuid = crypto.randomUUID();

    const result = await db.query(`
      INSERT INTO users (uuid, username, password_hash, full_name, role, is_active)
      VALUES ($1, $2, $3, $4, $5, TRUE)
      RETURNING id, uuid, username, full_name, role, is_active, created_at;
    `, [userUuid, username.trim(), hash, fullName.trim(), role || 'Payroll Operator']);

    const newUser = result.rows[0];
    await ensureUserWorkspace(newUser.id);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
      VALUES ($1, 'CREATE_USER', 'USER', $2, $3, $4);
    `, [req.user.username, String(newUser.id), `Created user ${username} (${role})`, newUser.id]);

    res.status(201).json({ user: newUser });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/users/:id
router.put('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Only Super Administrators can update users' });
    }

    const { id } = req.params;
    const targetId = Number(id);
    const { username, fullName, role, isActive, password } = req.body;

    const existingRes = await db.query('SELECT id, uuid, username, full_name, role, is_active FROM users WHERE id = $1;', [targetId]);
    if (existingRes.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    const existing = existingRes.rows[0];

    // Protected Account Identity Rule: Cannot rename usernames of protected system accounts
    if (PROTECTED_USERNAMES.includes(existing.username.toLowerCase()) && username && username.trim().toLowerCase() !== existing.username.toLowerCase()) {
      return res.status(400).json({ error: `Cannot rename protected permanent system account "${existing.username}".` });
    }

    // Administrator protection: Prevent deactivating or demoting the last active Super Administrator
    if (isSuperAdmin(existing) && ((role && !isSuperAdmin({ role })) || isActive === false)) {
      const superCount = await db.query("SELECT COUNT(*) as count FROM users WHERE role ILIKE '%SUPER%' AND is_active = TRUE;");
      if (parseInt(superCount.rows[0].count, 10) <= 1) {
        return res.status(400).json({ error: 'Cannot demote or deactivate the only remaining active Super Administrator.' });
      }
    }

    if (username && username.trim().toLowerCase() !== existing.username.toLowerCase()) {
      const check = await db.query('SELECT id FROM users WHERE LOWER(username) = LOWER($1) AND id != $2;', [username.trim(), targetId]);
      if (check.rows.length > 0) {
        return res.status(409).json({ error: `Username "${username.trim()}" is already taken by another account.` });
      }
    }

    const updates: string[] = ['updated_at = CURRENT_TIMESTAMP'];
    const params: any[] = [];
    let idx = 1;

    if (fullName !== undefined && fullName !== null) {
      updates.push(`full_name = $${idx++}`);
      params.push(fullName.trim());
    }

    if (username !== undefined && username !== null && username.trim()) {
      updates.push(`username = $${idx++}`);
      params.push(username.trim());
    }

    if (role !== undefined && role !== null) {
      updates.push(`role = $${idx++}`);
      params.push(role);
    }

    if (isActive !== undefined && isActive !== null) {
      updates.push(`is_active = $${idx++}`);
      params.push(Boolean(isActive));
    }

    if (password && password.trim()) {
      if (password.trim().length < 6) {
        return res.status(400).json({ error: 'New password must be at least 6 characters long' });
      }
      const salt = bcrypt.genSaltSync(10);
      const hash = bcrypt.hashSync(password.trim(), salt);
      updates.push(`password_hash = $${idx++}`);
      params.push(hash);
    }

    params.push(targetId);
    const query = `UPDATE users SET ${updates.join(', ')} WHERE id = $${idx} RETURNING id, uuid, username, full_name, role, is_active, created_at, updated_at;`;

    const result = await db.query(query, params);
    const updatedUser = result.rows[0];

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'UPDATE_USER', 'USER', $2, $3);
    `, [req.user.username, String(targetId), `Updated user ${updatedUser.username} details/role/credentials`]);

    // If the authenticated admin updated their own username/role, provide fresh token
    let newToken: string | undefined;
    if (req.user.id === targetId) {
      newToken = generateToken({
        id: updatedUser.id,
        uuid: updatedUser.uuid,
        username: updatedUser.username,
        fullName: updatedUser.full_name,
        role: updatedUser.role
      });
    }

    res.json({ user: updatedUser, token: newToken });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/users/:id
router.delete('/:id', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (!isSuperAdmin(req.user)) {
      return res.status(403).json({ error: 'Only Super Administrators can delete users' });
    }

    const { id } = req.params;
    const targetId = Number(id);

    // Safeguard: Cannot delete yourself
    if (req.user.id === targetId) {
      return res.status(400).json({ error: 'You cannot delete your own active administrator account while logged in.' });
    }

    const userToDel = await db.query('SELECT role, username FROM users WHERE id = $1;', [targetId]);
    if (userToDel.rows.length === 0) return res.status(404).json({ error: 'User not found' });
    const targetUsername = userToDel.rows[0].username.toLowerCase();

    // Protected Account Identity Rule: Permanent accounts cannot be deleted
    if (PROTECTED_USERNAMES.includes(targetUsername)) {
      return res.status(400).json({ error: `Cannot delete protected permanent system account "${userToDel.rows[0].username}".` });
    }

    // Safeguard: Cannot delete if it is the only Super Administrator
    if (isSuperAdmin(userToDel.rows[0])) {
      const superCount = await db.query("SELECT COUNT(*) as count FROM users WHERE role ILIKE '%SUPER%' AND is_active = TRUE;");
      if (parseInt(superCount.rows[0].count, 10) <= 1) {
        return res.status(400).json({ error: 'Cannot delete the only remaining active Super Administrator.' });
      }
    }

    const delRes = await db.query('DELETE FROM users WHERE id = $1 RETURNING id, username, full_name, role;', [targetId]);

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'DELETE_USER', 'USER', $2, $3);
    `, [req.user.username, String(targetId), `Deleted user ${delRes.rows[0].username} (${delRes.rows[0].role})`]);

    res.json({ message: 'User deleted successfully', user: delRes.rows[0] });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
