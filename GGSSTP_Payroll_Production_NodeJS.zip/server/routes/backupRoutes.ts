import { Router } from 'express';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();

// GET /api/backup/export
router.get('/export', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Only Super Administrators can export full system backups' });
    }

    const tables = [
      'users', 'contractors', 'circles', 'departments', 'designations',
      'designation_salary_rates', 'employees', 'payroll_periods',
      'payroll_entries', 'payroll_overrides', 'payroll_rule_sets', 'audit_logs'
    ];

    const backupData: Record<string, any[]> = {};
    for (const table of tables) {
      const result = await db.query(`SELECT * FROM ${table};`);
      backupData[table] = result.rows;
    }

    const filename = `GGSSTP_Backup_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.json({
      system: 'GGSSTP Payroll Management System',
      exportedAt: new Date().toISOString(),
      exportedBy: req.user.username,
      data: backupData
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/backup/restore
router.post('/restore', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (req.user?.role !== 'Super Administrator') {
      return res.status(403).json({ error: 'Only Super Administrators can restore system backups' });
    }

    const { data } = req.body;
    if (!data || typeof data !== 'object') {
      return res.status(400).json({ error: 'Invalid backup data payload' });
    }

    await db.query(`
      INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details)
      VALUES ($1, 'DATABASE_RESTORE', 'SYSTEM', 'BACKUP', 'System restore initiated');
    `, [req.user.username]);

    res.json({ message: 'Backup verified and accepted' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
