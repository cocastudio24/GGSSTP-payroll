import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { db } from '../database/db';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';

const router = Router();

// Ensure chat uploads directory exists
const uploadDir = path.join(__dirname, '../../data/chat_uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer storage for shared files
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `${uniqueSuffix}-${safeName}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB maximum file size
});

// GET /api/chat/messages - Retrieve latest team chat messages
router.get('/messages', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const result = await db.query(`
      SELECT 
        id, user_id, user_name, user_role, message, 
        file_url, file_name, file_size, file_type, 
        created_at
      FROM chat_messages
      ORDER BY created_at ASC
      LIMIT 200;
    `);
    res.json({ messages: result.rows });
  } catch (err: any) {
    console.error('Error fetching chat messages:', err);
    res.status(500).json({ error: err.message || 'Failed to fetch messages' });
  }
});

// POST /api/chat/messages - Send message and/or upload shared file
router.post('/messages', authMiddleware, upload.single('file'), async (req: AuthRequest, res: Response) => {
  try {
    const messageText = (req.body.message || '').trim();
    const file = req.file;

    if (!messageText && !file) {
      return res.status(400).json({ error: 'Please enter a message or select a file to share' });
    }

    const userName = req.user?.fullName || req.user?.username || 'GGSSTP Personnel';
    const userRole = req.user?.role || 'Authorized User';
    const userId = req.user?.id || null;

    let fileUrl: string | null = null;
    let fileName: string | null = null;
    let fileSize: number | null = null;
    let fileType: string | null = null;

    if (file) {
      fileName = file.originalname;
      fileSize = file.size;
      fileType = file.mimetype;
      fileUrl = `/api/chat/files/${path.basename(file.path)}`;
    }

    const insRes = await db.query(`
      INSERT INTO chat_messages (
        user_id, user_name, user_role, message,
        file_url, file_name, file_size, file_type
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *;
    `, [
      userId,
      userName,
      userRole,
      messageText || null,
      fileUrl,
      fileName,
      fileSize,
      fileType
    ]);

    res.status(201).json({ message: insRes.rows[0] });
  } catch (err: any) {
    console.error('Error sending chat message:', err);
    res.status(500).json({ error: err.message || 'Failed to send message' });
  }
});

// GET /api/chat/files/:filename - Download or view shared file (Authenticated)
router.get('/files/:filename', authMiddleware, (req: Request, res: Response) => {
  try {
    const rawParam = req.params.filename;
    const rawFilename = Array.isArray(rawParam) ? rawParam[0] : (rawParam || '');
    // Prevent directory traversal
    const safeBaseName = path.basename(rawFilename);
    const filePath = path.join(uploadDir, safeBaseName);


    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'Shared file not found or has been removed' });
    }

    // Determine original filename if prefixed with timestamp
    const parts = safeBaseName.split('-');
    const downloadName = parts.length > 2 ? parts.slice(2).join('-') : safeBaseName;

    res.download(filePath, downloadName);
  } catch (err: any) {
    console.error('Error serving chat file:', err);
    res.status(500).json({ error: 'Error downloading file' });
  }
});

// GET /api/chat/users - List plant personnel for chat
router.get('/users', authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const result = await db.query(`
      SELECT id, username, full_name, role, is_active
      FROM users
      ORDER BY role ASC, full_name ASC;
    `);
    res.json({ users: result.rows });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
