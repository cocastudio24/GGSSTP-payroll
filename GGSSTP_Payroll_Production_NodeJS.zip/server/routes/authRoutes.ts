import { Router } from 'express';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { db } from '../database/db';
import { generateToken, authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { ensureUserWorkspace } from '../database/workspaceManager';

const router = Router();

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }

    const userRes = await db.query(
      `SELECT id, uuid, username, password_hash, full_name, role, is_active FROM users WHERE LOWER(username) = LOWER($1);`,
      [username.trim()]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    const user = userRes.rows[0];
    if (!user.is_active) {
      return res.status(403).json({ error: 'User account is deactivated. Contact administrator.' });
    }

    const match = bcrypt.compareSync(password, user.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    // Ensure user has a valid UUID
    let userUuid = user.uuid;
    if (!userUuid) {
      userUuid = crypto.randomUUID();
      await db.query(`UPDATE users SET uuid = $1 WHERE id = $2;`, [userUuid, user.id]);
    }

    // Ensure workspace defaults are initialized for this user
    await ensureUserWorkspace(user.id);

    const authUser = {
      id: user.id,
      uuid: userUuid,
      username: user.username,
      fullName: user.full_name,
      role: user.role
    };

    const token = generateToken(authUser);

    await db.query(
      `INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
       VALUES ($1, 'USER_LOGIN', 'USER', $2, 'User logged in successfully', $3);`,
      [user.username, String(user.id), user.id]
    );

    res.json({ token, user: authUser });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ error: err.message || 'Internal server error during login' });
  }
});

// POST /api/auth/register (New User Registration with isolated private workspace)
router.post('/register', async (req, res) => {
  try {
    const { username, password, fullName, role } = req.body;
    if (!username || !password || !fullName) {
      return res.status(400).json({ error: 'Username, password, and full name are required' });
    }

    if (username.trim().length < 3) {
      return res.status(400).json({ error: 'Username must be at least 3 characters long' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long' });
    }

    const dupCheck = await db.query(
      `SELECT id FROM users WHERE LOWER(username) = LOWER($1);`,
      [username.trim()]
    );
    if (dupCheck.rows.length > 0) {
      return res.status(409).json({ error: `Username "${username.trim()}" is already registered` });
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);
    const userUuid = crypto.randomUUID();
    const userRole = role || 'Payroll Operator';

    const insRes = await db.query(`
      INSERT INTO users (uuid, username, password_hash, full_name, role, is_active)
      VALUES ($1, $2, $3, $4, $5, TRUE)
      RETURNING id, uuid, username, full_name, role, is_active, created_at;
    `, [userUuid, username.trim(), passwordHash, fullName.trim(), userRole]);

    const newUser = insRes.rows[0];

    // Initialize private isolated workspace defaults for this new user
    await ensureUserWorkspace(newUser.id);

    const authUser = {
      id: newUser.id,
      uuid: newUser.uuid,
      username: newUser.username,
      fullName: newUser.full_name,
      role: newUser.role
    };

    const token = generateToken(authUser);

    await db.query(
      `INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
       VALUES ($1, 'USER_REGISTER', 'USER', $2, 'New user registered with private workspace', $3);`,
      [newUser.username, String(newUser.id), newUser.id]
    );

    res.status(201).json({
      message: 'Account registered successfully with private workspace',
      token,
      user: authUser
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    res.status(500).json({ error: err.message || 'Failed to register account' });
  }
});

// GET /api/auth/me (Database is authoritative source of truth)
router.get('/me', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const userRes = await db.query(
      `SELECT id, uuid, username, full_name, role, is_active FROM users WHERE id = $1;`,
      [req.user!.id]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({ error: 'User account not found' });
    }

    const user = userRes.rows[0];
    if (!user.is_active) {
      return res.status(403).json({ error: 'User account is deactivated. Contact administrator.' });
    }

    res.json({
      user: {
        id: user.id,
        uuid: user.uuid,
        username: user.username,
        fullName: user.full_name,
        role: user.role
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/reset-password
router.post('/reset-password', authMiddleware, async (req: AuthRequest, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current password and new password are required' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters long' });
    }

    const userRes = await db.query(`SELECT password_hash FROM users WHERE id = $1;`, [req.user!.id]);
    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const match = bcrypt.compareSync(currentPassword, userRes.rows[0].password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Incorrect current password' });
    }

    const salt = bcrypt.genSaltSync(10);
    const newHash = bcrypt.hashSync(newPassword, salt);
    await db.query(`UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2;`, [newHash, req.user!.id]);

    await db.query(
      `INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
       VALUES ($1, 'PASSWORD_RESET', 'USER', $2, 'User updated account password', $3);`,
      [req.user!.username, String(req.user!.id), req.user!.id]
    );

    res.json({ message: 'Password updated successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/auth/logout
router.post('/logout', authMiddleware, async (req: AuthRequest, res) => {
  try {
    if (req.user) {
      await db.query(
        `INSERT INTO audit_logs (user_name, action, entity_type, entity_id, details, owner_user_id)
         VALUES ($1, 'USER_LOGOUT', 'USER', $2, 'User logged out', $3);`,
        [req.user.username, String(req.user.id), req.user.id]
      );
    }
    res.json({ message: 'Logged out successfully' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
