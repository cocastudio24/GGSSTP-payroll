-- GGSSTP Relational PostgreSQL Schema with Strict Multi-User Data Isolation

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  uuid VARCHAR(64) UNIQUE,
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(200) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'Payroll Operator',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS contractors (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(50),
  contact_person VARCHAR(100),
  phone VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS circles (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS departments (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  circle_id INTEGER REFERENCES circles(id) ON DELETE SET NULL,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(50),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS designations (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  alias VARCHAR(50) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS designation_salary_rates (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  designation_id INTEGER REFERENCES designations(id) ON DELETE CASCADE,
  gross_salary_rate NUMERIC(12, 2) NOT NULL,
  special_allowance NUMERIC(12, 2) NOT NULL,
  thermal_allowance NUMERIC(12, 2) NOT NULL DEFAULT 1500.00,
  perf_allowance_default NUMERIC(12, 2) NOT NULL DEFAULT 225.00,
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to DATE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS employees (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emp_code VARCHAR(100) NOT NULL,
  sr_no VARCHAR(100),
  name VARCHAR(255) NOT NULL,
  father_name VARCHAR(255),
  uan VARCHAR(100),
  designation_id INTEGER REFERENCES designations(id) ON DELETE SET NULL,
  dob TEXT,
  age_above_58 TEXT DEFAULT 'N',
  date_of_joining TEXT,
  more_than_3_yrs TEXT DEFAULT 'NO',
  more_than_5_yrs TEXT DEFAULT 'NO',
  qualification TEXT,
  experience_years TEXT,
  qualified_status TEXT,
  contractor_id INTEGER REFERENCES contractors(id) ON DELETE SET NULL,
  circle_id INTEGER REFERENCES circles(id) ON DELETE SET NULL,
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  hazard_duty TEXT,
  above_60 TEXT,
  check_status TEXT,
  cell TEXT,
  bank_name TEXT,
  bank_account TEXT,
  ifsc TEXT,
  account_holder_name TEXT,
  esi_number TEXT,
  aadhar_number TEXT,
  pan_number TEXT,
  mobile_number TEXT,
  date_of_exit TEXT,
  custom_data JSONB DEFAULT '{}'::jsonb,
  epf_applicable BOOLEAN NOT NULL DEFAULT TRUE,
  esi_applicable BOOLEAN NOT NULL DEFAULT TRUE,
  lwf_applicable BOOLEAN NOT NULL DEFAULT TRUE,
  epf_statutory_doj TEXT,
  default_gross_rate NUMERIC(12, 2),
  default_special_allowance NUMERIC(12, 2),
  default_thermal_allowance NUMERIC(12, 2) DEFAULT 1500,
  default_perf_allowance NUMERIC(12, 2) DEFAULT 0,
  default_bonus_percentage NUMERIC(6, 2) DEFAULT 8.33,
  custom_employee_epf NUMERIC(12, 2),
  custom_employer_epf NUMERIC(12, 2),
  custom_employer_epf1 NUMERIC(12, 2),
  custom_employee_esi NUMERIC(12, 2),
  custom_employer_esi NUMERIC(12, 2),
  custom_employee_lwf NUMERIC(12, 2),
  custom_employer_lwf NUMERIC(12, 2),
  other_allowances NUMERIC(12, 2) DEFAULT 0,
  other_deductions NUMERIC(12, 2) DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  is_archived BOOLEAN NOT NULL DEFAULT FALSE,
  archived_at TIMESTAMP WITH TIME ZONE,
  archived_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  archived_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payroll_periods (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL,
  month_name VARCHAR(20) NOT NULL,
  total_days INTEGER NOT NULL DEFAULT 30,
  status VARCHAR(50) NOT NULL DEFAULT 'Draft',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  finalized_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE IF NOT EXISTS payroll_entries (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payroll_period_id INTEGER REFERENCES payroll_periods(id) ON DELETE CASCADE,
  employee_id INTEGER REFERENCES employees(id) ON DELETE CASCADE,
  present_days NUMERIC(5, 2) NOT NULL DEFAULT 0,
  gross_salary_rate NUMERIC(12, 2) NOT NULL DEFAULT 0,
  proportioned_salary NUMERIC(12, 2) NOT NULL DEFAULT 0,
  special_allowance NUMERIC(12, 2) NOT NULL DEFAULT 0,
  total_basic NUMERIC(12, 2) NOT NULL DEFAULT 0,
  thermal_allowance NUMERIC(12, 2) NOT NULL DEFAULT 0,
  perf_allowance_monthly NUMERIC(12, 2) NOT NULL DEFAULT 0,
  perf_allowance_days NUMERIC(12, 2) NOT NULL DEFAULT 0,
  total_earnings_before_bonus NUMERIC(12, 2) NOT NULL DEFAULT 0,
  bonus NUMERIC(12, 2) NOT NULL DEFAULT 0,
  employer_epf_12 NUMERIC(12, 2) NOT NULL DEFAULT 0,
  employer_epf_1 NUMERIC(12, 2) NOT NULL DEFAULT 0,
  employer_esi_325 NUMERIC(12, 2) NOT NULL DEFAULT 0,
  employer_lwf NUMERIC(12, 2) NOT NULL DEFAULT 20,
  gross_total NUMERIC(12, 2) NOT NULL DEFAULT 0,
  employee_epf_12 NUMERIC(12, 2) NOT NULL DEFAULT 0,
  employee_esi_075 NUMERIC(12, 2) NOT NULL DEFAULT 0,
  employee_lwf NUMERIC(12, 2) NOT NULL DEFAULT 5,
  total_employee_deductions NUMERIC(12, 2) NOT NULL DEFAULT 0,
  total_employer_contributions NUMERIC(12, 2) NOT NULL DEFAULT 0,
  combined_deductions NUMERIC(12, 2) NOT NULL DEFAULT 0,
  net_payable NUMERIC(12, 2) NOT NULL DEFAULT 0,
  imported_net_payable NUMERIC(12, 2),
  rounding_mode VARCHAR(20) DEFAULT 'round_50_up',
  bonus_percentage NUMERIC(6, 2) NOT NULL DEFAULT 8.33,
  perf_last_drawn NUMERIC(12, 2) NOT NULL DEFAULT 0,
  perf_as_per_circle NUMERIC(12, 2) NOT NULL DEFAULT 0,
  perf_difference NUMERIC(12, 2) NOT NULL DEFAULT 0,
  is_overridden BOOLEAN NOT NULL DEFAULT FALSE,
  calculation_mode VARCHAR(50) NOT NULL DEFAULT 'Reference-Compatible',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(payroll_period_id, employee_id)
);

CREATE TABLE IF NOT EXISTS payroll_overrides (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  payroll_entry_id INTEGER REFERENCES payroll_entries(id) ON DELETE CASCADE,
  field_name VARCHAR(100) NOT NULL,
  original_value NUMERIC(12, 2) NOT NULL,
  override_value NUMERIC(12, 2) NOT NULL,
  reason TEXT NOT NULL,
  user_name VARCHAR(100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payroll_rule_sets (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  epf_wage_cap NUMERIC(12, 2) NOT NULL DEFAULT 25000,
  epf_employer_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.1200,
  epf_max_cap NUMERIC(12, 2) NOT NULL DEFAULT 3000,
  epf_admin_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.0100,
  epf_admin_max_cap NUMERIC(12, 2) NOT NULL DEFAULT 250,
  epf_employee_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.1200,
  esi_threshold NUMERIC(12, 2) NOT NULL DEFAULT 21000,
  esi_employer_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.0325,
  esi_employee_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.0075,
  employer_lwf NUMERIC(12, 2) NOT NULL DEFAULT 20.00,
  employee_lwf NUMERIC(12, 2) NOT NULL DEFAULT 5.00,
  thermal_allowance_base NUMERIC(12, 2) NOT NULL DEFAULT 1500.00,
  net_payable_rounding_mode VARCHAR(20) DEFAULT 'round_50_up',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  user_name VARCHAR(100) NOT NULL,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id VARCHAR(100),
  details TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS import_jobs (
  id SERIAL PRIMARY KEY,
  owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  file_name VARCHAR(255) NOT NULL,
  sheet_name VARCHAR(100) NOT NULL,
  layout_detected VARCHAR(100) NOT NULL,
  total_records INTEGER NOT NULL DEFAULT 0,
  created_records INTEGER NOT NULL DEFAULT 0,
  updated_records INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  user_name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id SERIAL PRIMARY KEY,
  user_id INTEGER,
  user_name VARCHAR(100) NOT NULL,
  user_role VARCHAR(100) NOT NULL,
  message TEXT,
  file_url TEXT,
  file_name TEXT,
  file_size INTEGER,
  file_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indices for Strict Multi-User Isolation Performance
CREATE INDEX IF NOT EXISTS idx_employees_owner ON employees(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_payroll_entries_owner ON payroll_entries(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_payroll_periods_owner ON payroll_periods(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_contractors_owner ON contractors(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_circles_owner ON circles(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_departments_owner ON departments(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_designations_owner ON designations(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_designation_salary_rates_owner ON designation_salary_rates(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_payroll_rule_sets_owner ON payroll_rule_sets(owner_user_id);
