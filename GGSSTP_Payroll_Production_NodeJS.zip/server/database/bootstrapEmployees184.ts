import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';

export async function bootstrapEmployees184(
  queryFn: (sql: string, params?: any[]) => Promise<{ rows: any[]; rowCount?: number }>
): Promise<void> {
  // Check count of active non-archived employees
  const empCheck = await queryFn('SELECT COUNT(*) as count FROM employees WHERE is_archived = FALSE;');
  const count = parseInt(empCheck.rows[0]?.count || '0', 10);
  if (count >= 184) {
    // Already populated with at least the official 184 employees
    return;
  }

  console.log(`[Bootstrap 184] Current employee count is ${count}. Populating official 184 employee roster...`);

  const possibleCsvs = [
    path.resolve(__dirname, '../../reference_files/user_prompt_184_employees.csv'),
    path.resolve(__dirname, '../reference_files/user_prompt_184_employees.csv'),
    path.resolve(process.cwd(), 'reference_files/user_prompt_184_employees.csv'),
    path.resolve(process.cwd(), 'dist/reference_files/user_prompt_184_employees.csv')
  ];

  const csvPath = possibleCsvs.find(p => fs.existsSync(p));
  if (!csvPath) {
    console.warn('[Bootstrap 184] Warning: user_prompt_184_employees.csv not found; skipping bootstrap.');
    return;
  }

  const wb = XLSX.readFile(csvPath, { raw: true });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const data: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true });

  // 1. Resolve user IDs
  const usersRes = await queryFn('SELECT id, username FROM users ORDER BY id ASC;');
  const userMap: Record<string, number> = {};
  usersRes.rows.forEach((u: any) => {
    userMap[u.username] = u.id;
  });

  const adminId = userMap['admin'] || 1;
  const cell1Id = userMap['cell1'] || 2;
  const cell2Id = userMap['cell2'] || 3;
  const cell3Id = userMap['cell3'] || 4;

  // 2. Resolve contractor
  let contractorId = 1;
  const contRes = await queryFn("SELECT id FROM contractors WHERE name ILIKE '%sodhi%' ORDER BY id ASC LIMIT 1;");
  if (contRes.rows.length > 0) {
    contractorId = contRes.rows[0].id;
  } else {
    const newCont = await queryFn(
      "INSERT INTO contractors (owner_user_id, name, code) VALUES ($1, 'M/s Sodhi Erectors', 'SODHI') RETURNING id;",
      [adminId]
    );
    contractorId = newCont.rows[0].id;
  }

  // 3. Resolve designations
  const desRes = await queryFn('SELECT id, name, alias FROM designations;');
  const desMap: Record<string, number> = {};
  desRes.rows.forEach((d: any) => {
    desMap[d.name.toLowerCase()] = d.id;
    desMap[d.alias.toLowerCase()] = d.id;
  });

  // 4. Resolve circles
  const circleNames = ['C&I', 'EMC', 'MM-1', 'MM-2', 'OPERATION', 'Chief Chemist/Coal'];
  const circleMap: Record<string, number> = {};
  for (const cName of circleNames) {
    const existing = await queryFn(
      'SELECT id FROM circles WHERE LOWER(TRIM(name)) = LOWER(TRIM($1)) ORDER BY id ASC LIMIT 1;',
      [cName]
    );
    if (existing.rows.length > 0) {
      circleMap[cName] = existing.rows[0].id;
    } else {
      const ins = await queryFn(
        'INSERT INTO circles (owner_user_id, name, code) VALUES ($1, $2, $3) RETURNING id;',
        [adminId, cName, cName.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8)]
      );
      circleMap[cName] = ins.rows[0].id;
    }
  }
  circleMap['MM-I'] = circleMap['MM-1'];

  // 5. Resolve September 2026 period
  let periodId = 1;
  const periodRes = await queryFn(
    "SELECT id FROM payroll_periods WHERE month = 9 AND year = 2026 ORDER BY id ASC LIMIT 1;"
  );
  if (periodRes.rows.length > 0) {
    periodId = periodRes.rows[0].id;
  } else {
    const newPeriod = await queryFn(`
      INSERT INTO payroll_periods (owner_user_id, year, month, month_name, total_days, status, created_by_user_id)
      VALUES ($1, 2026, 9, 'September', 30, 'Draft', $1) RETURNING id;
    `, [adminId]);
    periodId = newPeriod.rows[0].id;
  }

  // 6. Extract 184 employees
  const employeesToSync: any[] = [];
  for (const r of data) {
    if (!r || !r[0] || !String(r[0]).trim().startsWith('EMP-')) continue;

    const code = String(r[0] || '').trim();
    const rawCircle = String(r[1] || '').trim();
    const name = String(r[2] || '').replace(/\r?\n/g, ' ').replace(/\s+/g, ' ').trim();
    const father = String(r[3] || '').trim();

    let desName = 'Skilled';
    let uan = '';
    let esi = '';
    let aadhar = '';
    let account = '';
    let ifsc = '';
    let dob = '';
    let doj = '';
    let totalDays = 30;
    let presentDays = 7;
    let grossSalary = 16530;
    let bp = 0;
    let specialAllowance = 3802;
    let totalBasic = 4744;
    let thermalAllowance = 350;
    let perfMonthly = 0;
    let perfDays = 0;
    let totalEarnings = 0;
    let bonus = 0;
    let employerEpf12 = 0;
    let employerEpf1 = 0;
    let employerEsi325 = 0;
    let employerLwf = 20;
    let grossTotal = 0;
    let employeeEpf12 = 0;
    let employeeEsi075 = 0;
    let employeeLwf = 5;
    let totalEmpDeductions = 0;
    let totalEmployerContributions = 0;
    let combinedDeductions = 0;
    let netPayable = 0;

    let ownerUserId = adminId;
    let targetCircle = rawCircle;
    let cellName = 'CELL3';

    if (rawCircle === 'C&I') {
      ownerUserId = cell3Id;
      cellName = 'CELL3';
      targetCircle = 'C&I';
      desName = String(r[4] || '').trim();
      dob = String(r[5] || '').trim();
      uan = String(r[6] || '').trim();
      esi = String(r[7] || '').trim();
      aadhar = String(r[8] || '').trim();
      account = String(r[9] || '').trim();
      ifsc = String(r[10] || '').trim();
      doj = String(r[11] || '').trim();
      totalDays = Number(r[12]) || 30;
      presentDays = Number(r[13]) || 7;
      grossSalary = Number(r[14]) || 16530;
      specialAllowance = Number(r[16]) || 3802;
      totalBasic = Number(r[17]) || 4744;
      thermalAllowance = Number(r[18]) || 350;
      perfMonthly = Number(r[19]) || 0;
      perfDays = Number(r[20]) || 0;
      totalEarnings = Number(r[21]) || 0;
      bonus = Number(r[22]) || 0;
      employerEpf12 = Number(r[23]) || 0;
      employerEpf1 = Number(r[24]) || 0;
      employerEsi325 = Number(r[25]) || 0;
      employerLwf = Number(r[26]) || 20;
      grossTotal = Number(r[27]) || 0;
      employeeEpf12 = Number(r[28]) || 0;
      employeeEsi075 = Number(r[29]) || 0;
      employeeLwf = Number(r[30]) || 5;
      totalEmpDeductions = Number(r[31]) || 0;
      totalEmployerContributions = Number(r[32]) || 0;
      combinedDeductions = Number(r[33]) || 0;
      netPayable = Number(r[34]) || 0;
    } else if (rawCircle === 'EMC') {
      ownerUserId = cell1Id;
      cellName = 'CELL1';
      targetCircle = 'EMC';
      uan = String(r[4] || r[11] || '').trim();
      desName = String(r[5] || '').trim();
      dob = String(r[6] || '').trim();
      doj = String(r[7] || '').trim();
      account = String(r[8] || '').trim();
      ifsc = String(r[9] || '').trim();
      esi = String(r[10] || '').trim();
      totalDays = Number(r[12]) || 30;
      presentDays = Number(r[13]) || 7;
      grossSalary = Number(r[14]) || 16530;
      bp = Number(r[15]) || 0;
      specialAllowance = Number(r[16]) || 3802;
      totalBasic = Number(r[17]) || 4744;
      thermalAllowance = Number(r[18]) || 350;
      perfMonthly = Number(r[19]) || 0;
      perfDays = Number(r[20]) || 0;
      totalEarnings = Number(r[21]) || 0;
      bonus = Number(r[22]) || 0;
      employerEpf12 = Number(r[23]) || 0;
      employerEpf1 = Number(r[24]) || 0;
      employerEsi325 = Number(r[25]) || 0;
      employerLwf = Number(r[26]) || 20;
      grossTotal = Number(r[27]) || 0;
      employeeEpf12 = Number(r[28]) || 0;
      employeeEsi075 = Number(r[29]) || 0;
      employeeLwf = Number(r[30]) || 5;
      totalEmpDeductions = Number(r[31]) || 0;
      totalEmployerContributions = Number(r[32]) || 0;
      combinedDeductions = Number(r[33]) || 0;
      netPayable = Number(r[34]) || 0;
    } else if (rawCircle === 'MM-I' || rawCircle === 'MM-1') {
      ownerUserId = cell1Id;
      cellName = 'CELL1';
      targetCircle = 'MM-1';
      desName = String(r[4] || '').trim();
      dob = String(r[5] || '').trim();
      doj = String(r[6] || '').trim();
      aadhar = String(r[7] || '').trim();
      account = String(r[8] || '').trim();
      ifsc = String(r[9] || '').trim();
      esi = String(r[10] || '').trim();
      uan = String(r[11] || '').trim();
      totalDays = Number(r[12]) || 30;
      presentDays = Number(r[13]) || 7;
      grossSalary = Number(r[14]) || 16530;
      specialAllowance = Number(r[16]) || 3802;
      totalBasic = Number(r[17]) || 4744;
      thermalAllowance = Number(r[18]) || 350;
      perfMonthly = Number(r[19]) || 0;
      perfDays = Number(r[20]) || 0;
      totalEarnings = Number(r[21]) || 0;
      bonus = Number(r[22]) || 0;
      employerEpf12 = Number(r[23]) || 0;
      employerEpf1 = Number(r[24]) || 0;
      employerEsi325 = Number(r[25]) || 0;
      employerLwf = Number(r[26]) || 20;
      grossTotal = Number(r[27]) || 0;
      employeeEpf12 = Number(r[28]) || 0;
      employeeEsi075 = Number(r[29]) || 0;
      employeeLwf = Number(r[30]) || 5;
      totalEmpDeductions = Number(r[31]) || 0;
      totalEmployerContributions = Number(r[32]) || 0;
      combinedDeductions = Number(r[33]) || 0;
      netPayable = Number(r[34]) || 0;
    } else if (rawCircle === 'MM-2') {
      ownerUserId = cell2Id;
      cellName = 'CELL2';
      targetCircle = 'MM-2';
      desName = String(r[4] || '').trim();
      account = String(r[5] || '').trim();
      ifsc = String(r[6] || '').trim();
      esi = String(r[7] || '').trim();
      uan = String(r[8] || '').trim();
      dob = String(r[11] || '').trim();
      totalDays = Number(r[12]) || 30;
      presentDays = Number(r[13]) || 6;
      grossSalary = Number(r[14]) || 16530;
      bp = Number(r[15]) || 0;
      specialAllowance = Number(r[16]) || 3802;
      totalBasic = Number(r[17]) || 4066;
      thermalAllowance = Number(r[18]) || 300;
      perfMonthly = Number(r[19]) || 0;
      perfDays = Number(r[20]) || 0;
      totalEarnings = Number(r[21]) || 0;
      bonus = Number(r[22]) || 0;
      employerEpf12 = Number(r[23]) || 0;
      employerEpf1 = Number(r[24]) || 0;
      employerEsi325 = Number(r[25]) || 0;
      employerLwf = Number(r[26]) || 20;
      grossTotal = Number(r[27]) || 0;
      employeeEpf12 = Number(r[28]) || 0;
      employeeEsi075 = Number(r[29]) || 0;
      employeeLwf = Number(r[30]) || 5;
      totalEmpDeductions = Number(r[31]) || 0;
      totalEmployerContributions = Number(r[32]) || 0;
      combinedDeductions = Number(r[33]) || 0;
      netPayable = Number(r[34]) || 0;
    } else if (rawCircle === 'OPERATION' || rawCircle === 'Chief Chemist/Coal') {
      ownerUserId = cell3Id;
      cellName = 'CELL3';
      targetCircle = rawCircle;
      desName = String(r[4] || '').trim();
      dob = String(r[5] || '').trim();
      uan = String(r[6] || '').trim();
      esi = String(r[7] || '').trim();
      aadhar = String(r[8] || '').trim();
      account = String(r[9] || '').trim();
      ifsc = String(r[10] || '').trim();
      doj = String(r[11] || '').trim();
      totalDays = Number(r[12]) || 30;
      presentDays = Number(r[13]) || 7;
      grossSalary = Number(r[14]) || 16530;
      specialAllowance = Number(r[16]) || 3802;
      totalBasic = Number(r[17]) || 4744;
      thermalAllowance = Number(r[18]) || 350;
      perfMonthly = Number(r[19]) || 0;
      perfDays = Number(r[20]) || 0;
      totalEarnings = Number(r[21]) || 0;
      bonus = Number(r[22]) || 0;
      employerEpf12 = Number(r[23]) || 0;
      employerEpf1 = Number(r[24]) || 0;
      employerEsi325 = Number(r[25]) || 0;
      employerLwf = Number(r[26]) || 20;
      grossTotal = Number(r[27]) || 0;
      employeeEpf12 = Number(r[28]) || 0;
      employeeEsi075 = Number(r[29]) || 0;
      employeeLwf = Number(r[30]) || 5;
      totalEmpDeductions = Number(r[31]) || 0;
      totalEmployerContributions = Number(r[32]) || 0;
      combinedDeductions = Number(r[33]) || 0;
      netPayable = Number(r[34]) || 0;
    }

    const designationId = desMap[desName.toLowerCase()] || (desName.toLowerCase().includes('un') ? 1 : 3);
    const circleId = circleMap[targetCircle] || circleMap['MM-1'] || 1;

    employeesToSync.push({
      code, name, father, designationId, desName, circleId, targetCircle,
      contractorId, cellName, ownerUserId,
      dob, doj, uan, esi, aadhar, account, ifsc,
      totalDays, presentDays, grossSalary, bp, specialAllowance, totalBasic,
      thermalAllowance, perfMonthly, perfDays, totalEarnings, bonus,
      employerEpf12, employerEpf1, employerEsi325, employerLwf, grossTotal,
      employeeEpf12, employeeEsi075, employeeLwf, totalEmpDeductions,
      totalEmployerContributions, combinedDeductions, netPayable
    });
  }

  // Upsert official 184 employees and their September 2026 payroll entries without removing user-created records
  for (const emp of employeesToSync) {
    const existingEmp = await queryFn('SELECT id FROM employees WHERE emp_code = $1;', [emp.code]);
    let empId: number;

    if (existingEmp.rows.length === 0) {
      const insRes = await queryFn(`
        INSERT INTO employees (
          emp_code, sr_no, name, father_name, uan, designation_id,
          dob, date_of_joining, contractor_id, circle_id,
          bank_account, ifsc, esi_number, aadhar_number,
          cell, owner_user_id, created_by_user_id, is_active, is_archived,
          default_gross_rate, default_special_allowance, default_thermal_allowance, default_perf_allowance
        ) VALUES (
          $1, $2, $3, $4, $5, $6,
          $7, $8, $9, $10,
          $11, $12, $13, $14,
          $15, $16, $17, TRUE, FALSE,
          $18, $19, $20, $21
        ) RETURNING id;
      `, [
        emp.code, emp.code.replace('EMP-', ''), emp.name, emp.father, emp.uan, emp.designationId,
        emp.dob, emp.doj, emp.contractorId, emp.circleId,
        emp.account, emp.ifsc, emp.esi, emp.aadhar,
        emp.cellName, emp.ownerUserId, emp.ownerUserId,
        emp.grossSalary, emp.specialAllowance, emp.thermalAllowance, emp.perfMonthly
      ]);
      empId = insRes.rows[0].id;
    } else {
      empId = existingEmp.rows[0].id;
      await queryFn(`
        UPDATE employees SET
          sr_no = $2, name = $3, father_name = $4, uan = $5, designation_id = $6,
          dob = $7, date_of_joining = $8, contractor_id = $9, circle_id = $10,
          bank_account = $11, ifsc = $12, esi_number = $13, aadhar_number = $14,
          cell = $15, owner_user_id = $16, updated_by_user_id = $16, is_active = TRUE, is_archived = FALSE, archived_at = NULL,
          default_gross_rate = $17, default_special_allowance = $18, default_thermal_allowance = $19, default_perf_allowance = $20
        WHERE id = $1;
      `, [
        empId, emp.code.replace('EMP-', ''), emp.name, emp.father, emp.uan, emp.designationId,
        emp.dob, emp.doj, emp.contractorId, emp.circleId,
        emp.account, emp.ifsc, emp.esi, emp.aadhar,
        emp.cellName, emp.ownerUserId,
        emp.grossSalary, emp.specialAllowance, emp.thermalAllowance, emp.perfMonthly
      ]);
    }

    const existingEntry = await queryFn(
      'SELECT id FROM payroll_entries WHERE payroll_period_id = $1 AND employee_id = $2;',
      [periodId, empId]
    );

    if (existingEntry.rows.length === 0) {
      await queryFn(`
        INSERT INTO payroll_entries (
          owner_user_id, created_by_user_id, payroll_period_id, employee_id,
          present_days, gross_salary_rate, proportioned_salary, special_allowance, total_basic,
          thermal_allowance, perf_allowance_monthly, perf_allowance_days, total_earnings_before_bonus,
          bonus, employer_epf_12, employer_epf_1, employer_esi_325, employer_lwf,
          gross_total, employee_epf_12, employee_esi_075, employee_lwf,
          total_employee_deductions, total_employer_contributions, combined_deductions,
          net_payable, imported_net_payable, is_overridden, calculation_mode
        ) VALUES (
          $1, $2, $3, $4,
          $5, $6, $7, $8, $9,
          $10, $11, $12, $13,
          $14, $15, $16, $17, $18,
          $19, $20, $21, $22,
          $23, $24, $25,
          $26, $27, TRUE, 'Reference-Compatible'
        );
      `, [
        emp.ownerUserId, emp.ownerUserId, periodId, empId,
        emp.presentDays, emp.grossSalary, emp.bp, emp.specialAllowance, emp.totalBasic,
        emp.thermalAllowance, emp.perfMonthly, emp.perfDays, emp.totalEarnings,
        emp.bonus, emp.employerEpf12, emp.employerEpf1, emp.employerEsi325, emp.employerLwf,
        emp.grossTotal, emp.employeeEpf12, emp.employeeEsi075, emp.employeeLwf,
        emp.totalEmpDeductions, emp.totalEmployerContributions, emp.combinedDeductions,
        emp.netPayable, emp.netPayable
      ]);
    } else {
      await queryFn(`
        UPDATE payroll_entries SET
          owner_user_id = $1, updated_by_user_id = $2,
          present_days = $4, gross_salary_rate = $5, proportioned_salary = $6, special_allowance = $7, total_basic = $8,
          thermal_allowance = $9, perf_allowance_monthly = $10, perf_allowance_days = $11, total_earnings_before_bonus = $12,
          bonus = $13, employer_epf_12 = $14, employer_epf_1 = $15, employer_esi_325 = $16, employer_lwf = $17,
          gross_total = $18, employee_epf_12 = $19, employee_esi_075 = $20, employee_lwf = $21,
          total_employee_deductions = $22, total_employer_contributions = $23, combined_deductions = $24,
          net_payable = $25, imported_net_payable = $26, is_overridden = TRUE, calculation_mode = 'Reference-Compatible'
        WHERE id = $3;
      `, [
        emp.ownerUserId, emp.ownerUserId, existingEntry.rows[0].id,
        emp.presentDays, emp.grossSalary, emp.bp, emp.specialAllowance, emp.totalBasic,
        emp.thermalAllowance, emp.perfMonthly, emp.perfDays, emp.totalEarnings,
        emp.bonus, emp.employerEpf12, emp.employerEpf1, emp.employerEsi325, emp.employerLwf,
        emp.grossTotal, emp.employeeEpf12, emp.employeeEsi075, emp.employeeLwf,
        emp.totalEmpDeductions, emp.totalEmployerContributions, emp.combinedDeductions,
        emp.netPayable, emp.netPayable
      ]);
    }
  }

  console.log(`[Bootstrap 184] Successfully seeded and synchronized all 184 employees into database.`);
}
