import dotenv from 'dotenv';
dotenv.config();

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { PGlite } from '@electric-sql/pglite';
import { Pool, PoolConfig } from 'pg';
import { bootstrapEmployees184 } from './bootstrapEmployees184';

export interface DBResult<T = any> {
  rows: T[];
  rowCount?: number;
}

class DatabaseManager {
  private pgliteInstance: PGlite | null = null;
  private pgPool: Pool | null = null;
  private initPromise: Promise<void> | null = null;

  async init(): Promise<void> {
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      const databaseUrl = process.env.DATABASE_URL;
      const dbHost = process.env.DB_HOST;
      const dbUser = process.env.DB_USER;

      if (databaseUrl || (dbHost && dbUser)) {
        console.log('Connecting to external persistent PostgreSQL production database...');
        const poolConfig: PoolConfig = {};

        if (databaseUrl) {
          poolConfig.connectionString = databaseUrl;
        } else {
          poolConfig.host = dbHost;
          poolConfig.port = parseInt(process.env.DB_PORT || '5432', 10);
          poolConfig.user = dbUser;
          poolConfig.password = process.env.DB_PASSWORD || '';
          poolConfig.database = process.env.DB_NAME || process.env.DB_DATABASE || 'ggsstp_payroll';
        }

        poolConfig.max = parseInt(process.env.DB_POOL_MAX || '10', 10);
        poolConfig.idleTimeoutMillis = 30000;
        poolConfig.connectionTimeoutMillis = 15000;

        const isLocal = (poolConfig.host === 'localhost' || poolConfig.host === '127.0.0.1') ||
                        (databaseUrl && (databaseUrl.includes('localhost') || databaseUrl.includes('127.0.0.1')));

        if (process.env.DB_SSL === 'true' || (!isLocal && process.env.DB_SSL !== 'false')) {
          poolConfig.ssl = { rejectUnauthorized: false };
        }

        this.pgPool = new Pool(poolConfig);
        const testClient = await this.pgPool.connect();
        await testClient.query('SELECT 1;');
        testClient.release();
        console.log('Successfully connected to production PostgreSQL database.');

        await this.applySchema();
        await this.seedInitialData();
      } else {
        const dataDir = process.env.PG_DATA_DIR || process.env.DATA_DIR || path.resolve(process.cwd(), 'data/ggsstp_pg');
        fs.mkdirSync(dataDir, { recursive: true });

        // Clean up stale postmaster.pid left after abrupt crash or process restart
        const pidFile = path.join(dataDir, 'postmaster.pid');
        if (fs.existsSync(pidFile)) {
          try { fs.unlinkSync(pidFile); } catch {}
        }

        console.log(`Using persistent PGlite PostgreSQL storage at: ${dataDir}`);

        // Open PGlite with safe retry logic
        let opened = false;
        let lastErr: any = null;
        for (let attempt = 1; attempt <= 10; attempt++) {
          try {
            if (fs.existsSync(pidFile)) {
              try { fs.unlinkSync(pidFile); } catch {}
            }
            this.pgliteInstance = new PGlite(dataDir);
            await this.pgliteInstance.query('SELECT 1;');
            opened = true;
            break;
          } catch (err: any) {
            lastErr = err;
            console.warn(`[PGlite Notice] Attempt ${attempt}/10 to access storage (${err.message}). Retrying...`);
            if (fs.existsSync(pidFile)) {
              try { fs.unlinkSync(pidFile); } catch {}
            }
            await new Promise(r => setTimeout(r, attempt * 150));
          }
        }

        if (!opened || !this.pgliteInstance) {
          console.error(`[CRITICAL DATABASE ERROR] Could not open persistent database at ${dataDir}:`, lastErr);
          throw new Error(`Failed to access persistent PostgreSQL database at ${dataDir}: ${lastErr?.message}. Please check directory permissions or set DATABASE_URL.`);
        }

        // Non-destructive automated snapshot backup for administrative safety (NEVER overwrites dataDir)
        try {
          const files = fs.readdirSync(dataDir);
          if (files.length > 3) {
            const backupBase = path.resolve(process.cwd(), 'data/backups/latest_snapshot');
            fs.mkdirSync(backupBase, { recursive: true });
            fs.cpSync(dataDir, backupBase, { recursive: true, force: true });
            const backupPid = path.join(backupBase, 'postmaster.pid');
            if (fs.existsSync(backupPid)) {
              try { fs.unlinkSync(backupPid); } catch {}
            }
          }
        } catch {}

        await this.applySchema();
        await this.seedInitialData();
      }

      console.log('Database initialized successfully.');
    })();

    return this.initPromise;
  }

  async query<T = any>(sql: string, params: any[] = []): Promise<DBResult<T>> {
    if (!this.initPromise) await this.init();
    else await this.initPromise;

    if (this.pgPool) {
      const result = await this.pgPool.query(sql, params);
      return { rows: result.rows as T[], rowCount: result.rowCount || 0 };
    } else if (this.pgliteInstance) {
      const result = await this.pgliteInstance.query<T>(sql, params);
      return { rows: result.rows, rowCount: result.rows.length };
    }
    throw new Error('Database not initialized');
  }

  async exec(sql: string): Promise<void> {
    if (!this.initPromise) await this.init();
    else await this.initPromise;

    if (this.pgPool) {
      await this.pgPool.query(sql);
    } else if (this.pgliteInstance) {
      await this.pgliteInstance.exec(sql);
    }
  }

  private async rawExec(sql: string): Promise<void> {
    if (this.pgPool) {
      await this.pgPool.query(sql);
    } else if (this.pgliteInstance) {
      await this.pgliteInstance.exec(sql);
    }
  }

  private async rawQuery<T = any>(sql: string, params: any[] = []): Promise<DBResult<T>> {
    if (this.pgPool) {
      const result = await this.pgPool.query(sql, params);
      return { rows: result.rows as T[], rowCount: result.rowCount || 0 };
    } else if (this.pgliteInstance) {
      const result = await this.pgliteInstance.query<T>(sql, params);
      return { rows: result.rows, rowCount: result.rows.length };
    }
    throw new Error('Database not initialized');
  }

  private async applySchema() {
    const possibleSchemas = [
      path.join(__dirname, 'schema.sql'),
      path.join(__dirname, '../database/schema.sql'),
      path.join(__dirname, '../../server/database/schema.sql'),
      path.join(process.cwd(), 'server/database/schema.sql'),
      path.join(process.cwd(), 'dist/database/schema.sql')
    ];
    const schemaPath = possibleSchemas.find(p => fs.existsSync(p));
    if (!schemaPath) throw new Error('Database schema.sql file could not be found.');
    const schemaSql = fs.readFileSync(schemaPath, 'utf8');
    await this.rawExec(schemaSql);

    // Apply incremental migrations if needed
    try {
      await this.rawExec(`
        ALTER TABLE payroll_rule_sets 
        ADD COLUMN IF NOT EXISTS epf_employee_rate NUMERIC(6, 4) NOT NULL DEFAULT 0.1200;

        CREATE TABLE IF NOT EXISTS chat_messages (
          id SERIAL PRIMARY KEY,
          user_id INTEGER,
          user_name VARCHAR(100) NOT NULL,
          user_role VARCHAR(100) NOT NULL,
          message TEXT,
          file_url TEXT,
          file_name TEXT,
          file_size INTEGER,
          file_type TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );
      `);
    } catch {
      // Ignored if already exists
    }

    // Multi-User Data Isolation Migration
    try {
      await this.rawExec(`
        ALTER TABLE users ADD COLUMN IF NOT EXISTS uuid VARCHAR(64);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS updated_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE payroll_periods ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE payroll_periods ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE payroll_periods ADD COLUMN IF NOT EXISTS updated_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS updated_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS bonus_percentage NUMERIC(6, 2) DEFAULT 8.33;
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS perf_last_drawn NUMERIC(12, 2) DEFAULT 0;
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS perf_as_per_circle NUMERIC(12, 2) DEFAULT 0;
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS perf_difference NUMERIC(12, 2) DEFAULT 0;
        ALTER TABLE contractors ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE contractors ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE circles ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE circles ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE departments ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE departments ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE designations ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE designations ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE designation_salary_rates ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE payroll_rule_sets ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE payroll_rule_sets ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE payroll_overrides ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE import_jobs ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS owner_user_id INTEGER REFERENCES users(id) ON DELETE CASCADE;
        ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS created_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;

        UPDATE employees SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE employees SET created_by_user_id = owner_user_id WHERE created_by_user_id IS NULL;
        UPDATE payroll_periods SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE payroll_periods SET created_by_user_id = owner_user_id WHERE created_by_user_id IS NULL;
        UPDATE payroll_entries SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE payroll_entries SET created_by_user_id = owner_user_id WHERE created_by_user_id IS NULL;
        UPDATE contractors SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE circles SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE departments SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE designations SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE designation_salary_rates SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE payroll_rule_sets SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE payroll_overrides SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE import_jobs SET owner_user_id = 1 WHERE owner_user_id IS NULL;
        UPDATE audit_logs SET owner_user_id = 1 WHERE owner_user_id IS NULL;

        CREATE INDEX IF NOT EXISTS idx_employees_owner ON employees(owner_user_id);
        CREATE INDEX IF NOT EXISTS idx_payroll_entries_owner ON payroll_entries(owner_user_id);
        CREATE INDEX IF NOT EXISTS idx_payroll_periods_owner ON payroll_periods(owner_user_id);

        -- Employee Module Enhancement Columns
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS cell TEXT;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS bank_name TEXT;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS account_holder_name TEXT;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS epf_applicable BOOLEAN DEFAULT TRUE;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS esi_applicable BOOLEAN DEFAULT TRUE;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS lwf_applicable BOOLEAN DEFAULT TRUE;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS epf_statutory_doj TEXT;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS default_gross_rate NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS default_special_allowance NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS default_thermal_allowance NUMERIC(12, 2) DEFAULT 1500;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS default_perf_allowance NUMERIC(12, 2) DEFAULT 0;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS default_bonus_percentage NUMERIC(6, 2) DEFAULT 8.33;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_employee_epf NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_employer_epf NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_employer_epf1 NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_employee_esi NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_employer_esi NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_employee_lwf NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS custom_employer_lwf NUMERIC(12, 2);
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS other_allowances NUMERIC(12, 2) DEFAULT 0;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS other_deductions NUMERIC(12, 2) DEFAULT 0;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS archived_at TIMESTAMP WITH TIME ZONE;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS is_archived BOOLEAN DEFAULT FALSE;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS archived_by_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
        ALTER TABLE employees ADD COLUMN IF NOT EXISTS archived_reason TEXT;
        UPDATE employees SET is_archived = (archived_at IS NOT NULL) WHERE is_archived IS NULL;

        -- Payroll Engine & Exact Net Payable Columns
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS imported_net_payable NUMERIC(12, 2);
        ALTER TABLE payroll_entries ADD COLUMN IF NOT EXISTS rounding_mode VARCHAR(20) DEFAULT 'round_50_up';
        ALTER TABLE payroll_rule_sets ADD COLUMN IF NOT EXISTS net_payable_rounding_mode VARCHAR(20) DEFAULT 'round_50_up';

        -- Synchronize payroll_entries ownership to match employee ownership
        UPDATE payroll_entries pe
        SET owner_user_id = e.owner_user_id
        FROM employees e
        WHERE pe.employee_id = e.id AND e.owner_user_id IS NOT NULL AND (pe.owner_user_id IS NULL OR pe.owner_user_id != e.owner_user_id);
      `);
    } catch {
      // Ignored if already executed
    }

    // Auto-consolidate Sodhi Erectors duplicate contractors if any exist
    try {
      const sodhiRows = await this.rawQuery(`SELECT id, name FROM contractors WHERE name ILIKE '%sodhi%erectors%' ORDER BY id ASC;`);
      if (sodhiRows.rows.length > 1) {
        let primary = sodhiRows.rows.find((r: any) => r.name.trim().toLowerCase() === 'm/s sodhi erectors') || sodhiRows.rows[0];
        const primaryId = primary.id;
        const duplicateIds = sodhiRows.rows.filter((r: any) => r.id !== primaryId).map((r: any) => r.id);

        if (duplicateIds.length > 0) {
          await this.rawQuery(`UPDATE employees SET contractor_id = $1 WHERE contractor_id = ANY($2::int[]);`, [primaryId, duplicateIds]);
          await this.rawQuery(`DELETE FROM contractors WHERE id = ANY($1::int[]);`, [duplicateIds]);
          await this.rawQuery(`UPDATE contractors SET name = 'M/s Sodhi Erectors' WHERE id = $1;`, [primaryId]);
        }
      }
    } catch {
      // Ignored if table not ready
    }
  }

  private async seedInitialData() {
    // Check if designations exist
    const desCheck = await this.rawQuery('SELECT COUNT(*) as count FROM designations;');
    if (parseInt(desCheck.rows[0].count, 10) === 0) {
      console.log('Seeding initial designations & salary rates...');
      const designations = [
        { name: 'Unskilled', alias: 'USW', gross: 14408, special: 3314 },
        { name: 'Semi Skilled', alias: 'SEMI SW', gross: 15395, special: 3541 },
        { name: 'Skilled', alias: 'SW', gross: 16530, special: 3802 },
        { name: 'Highly Skilled', alias: 'HSW', gross: 17835, special: 4102 }
      ];

      for (const d of designations) {
        const desRes = await this.rawQuery(
          `INSERT INTO designations (name, alias) VALUES ($1, $2) RETURNING id;`,
          [d.name, d.alias]
        );
        const desId = desRes.rows[0].id;
        await this.rawQuery(
          `INSERT INTO designation_salary_rates 
           (designation_id, gross_salary_rate, special_allowance, thermal_allowance, perf_allowance_default)
           VALUES ($1, $2, $3, 1500, 225);`,
          [desId, d.gross, d.special]
        );
      }
    }

    // 2. Migration & Seeding for the 4 Protected Permanent Accounts:
    // admin (INDERJIT SINGH, SUPER_ADMIN), cell1 (BALJIT KAUR, PAYROLL_ADMIN),
    // cell2 (GOPIKA KASHYAP, PAYROLL_ADMIN), cell3 (HARPREET SINGH, PAYROLL_ADMIN)
    const salt = bcrypt.genSaltSync(10);
    const permanentAccounts = [
      { username: 'admin', fullName: 'INDERJIT SINGH', role: 'SUPER_ADMIN', pass: 'admin@ggsstp2026' },
      { username: 'cell1', fullName: 'BALJIT KAUR', role: 'PAYROLL_ADMIN', pass: 'cell1@ggsstp2026' },
      { username: 'cell2', fullName: 'GOPIKA KASHYAP', role: 'PAYROLL_ADMIN', pass: 'cell2@ggsstp2026' },
      { username: 'cell3', fullName: 'HARPREET SINGH', role: 'PAYROLL_ADMIN', pass: 'cell3@ggsstp2026' }
    ];

    try {
      // Migrate legacy accounts if present
      await this.rawQuery(`UPDATE users SET full_name = 'INDERJIT SINGH', role = 'SUPER_ADMIN' WHERE username = 'admin';`);
      
      const checkCell1 = await this.rawQuery(`SELECT id FROM users WHERE username = 'cell1';`);
      if (checkCell1.rows.length === 0) {
        const checkOld1 = await this.rawQuery(`SELECT id FROM users WHERE username = 'payroll_admin';`);
        if (checkOld1.rows.length > 0) {
          const passHash = bcrypt.hashSync('cell1@ggsstp2026', salt);
          await this.rawQuery(`UPDATE users SET username = 'cell1', full_name = 'BALJIT KAUR', role = 'PAYROLL_ADMIN', password_hash = $1 WHERE username = 'payroll_admin';`, [passHash]);
        }
      }

      const checkCell2 = await this.rawQuery(`SELECT id FROM users WHERE username = 'cell2';`);
      if (checkCell2.rows.length === 0) {
        const checkOld2 = await this.rawQuery(`SELECT id FROM users WHERE username = 'operator';`);
        if (checkOld2.rows.length > 0) {
          const passHash = bcrypt.hashSync('cell2@ggsstp2026', salt);
          await this.rawQuery(`UPDATE users SET username = 'cell2', full_name = 'GOPIKA KASHYAP', role = 'PAYROLL_ADMIN', password_hash = $1 WHERE username = 'operator';`, [passHash]);
        }
      }

      const checkCell3 = await this.rawQuery(`SELECT id FROM users WHERE username = 'cell3';`);
      if (checkCell3.rows.length === 0) {
        const checkOld3 = await this.rawQuery(`SELECT id FROM users WHERE username = 'auditor';`);
        if (checkOld3.rows.length > 0) {
          const passHash = bcrypt.hashSync('cell3@ggsstp2026', salt);
          await this.rawQuery(`UPDATE users SET username = 'cell3', full_name = 'HARPREET SINGH', role = 'PAYROLL_ADMIN', password_hash = $1 WHERE username = 'auditor';`, [passHash]);
        }
      }

      // Ensure all 4 permanent accounts are present
      for (const acc of permanentAccounts) {
        const existing = await this.rawQuery(`SELECT id, uuid FROM users WHERE username = $1;`, [acc.username]);
        if (existing.rows.length === 0) {
          const hash = bcrypt.hashSync(acc.pass, salt);
          const newUuid = crypto.randomUUID();
          await this.rawQuery(
            `INSERT INTO users (uuid, username, password_hash, full_name, role, is_active) VALUES ($1, $2, $3, $4, $5, TRUE);`,
            [newUuid, acc.username, hash, acc.fullName, acc.role]
          );
        } else {
          // Keep identity attributes in sync without resetting user password if already changed
          await this.rawQuery(
            `UPDATE users SET full_name = $1, role = $2 WHERE username = $3;`,
            [acc.fullName, acc.role, acc.username]
          );
        }
      }

      // Ensure all users have valid UUID
      const usersWithoutUuid = await this.rawQuery('SELECT id FROM users WHERE uuid IS NULL;');
      for (const u of usersWithoutUuid.rows) {
        const newUuid = crypto.randomUUID();
        await this.rawQuery('UPDATE users SET uuid = $1 WHERE id = $2;', [newUuid, u.id]);
      }
    } catch (err) {
      console.error('Error establishing protected permanent accounts:', err);
    }

    // 3. Check if default rule set exists
    const ruleCheck = await this.rawQuery('SELECT COUNT(*) as count FROM payroll_rule_sets;');
    if (parseInt(ruleCheck.rows[0].count, 10) === 0) {
      await this.rawQuery(`
        INSERT INTO payroll_rule_sets 
        (name, is_active, epf_wage_cap, epf_employer_rate, epf_max_cap, epf_admin_rate, epf_admin_max_cap,
         esi_threshold, esi_employer_rate, esi_employee_rate, employer_lwf, employee_lwf, thermal_allowance_base)
        VALUES
        ('GGSSTP Reference Rule Set (Sep 2026)', TRUE, 25000, 0.1200, 3000, 0.0100, 250,
         21000, 0.0325, 0.0075, 20.00, 5.00, 1500.00);
      `);
    }

    // 4. Automatic Bootstrap of Official 184 Excel Employees
    try {
      await bootstrapEmployees184(this.rawQuery.bind(this));
    } catch (err) {
      console.error('[Bootstrap 184 Error]:', err);
    }
  }

  async close(): Promise<void> {
    if (this.pgPool) {
      await this.pgPool.end();
      this.pgPool = null;
    }
    if (this.pgliteInstance) {
      await this.pgliteInstance.close();
      this.pgliteInstance = null;
    }
    this.initPromise = null;
  }
}

export const db = new DatabaseManager();
