import { db } from './db';

/**
 * Ensures that an authenticated user has their isolated workspace initialized
 * with default rule set, designations, salary rates, circles, and contractors.
 * Only inserts if none currently exist for this user.
 */
export async function ensureUserWorkspace(userId: number): Promise<void> {
  if (!userId) return;

  try {
    // 1. Ensure active rule set for this user
    const ruleCheck = await db.query(
      `SELECT COUNT(*) as count FROM payroll_rule_sets WHERE owner_user_id = $1;`,
      [userId]
    );
    if (parseInt(ruleCheck.rows[0].count, 10) === 0) {
      await db.query(`
        INSERT INTO payroll_rule_sets 
        (name, is_active, epf_wage_cap, epf_employer_rate, epf_max_cap, epf_admin_rate, epf_admin_max_cap,
         epf_employee_rate, esi_threshold, esi_employer_rate, esi_employee_rate, employer_lwf, employee_lwf,
         thermal_allowance_base, owner_user_id)
        VALUES
        ('GGSSTP Reference Rule Set (Sep 2026)', TRUE, 25000, 0.1200, 3000, 0.0100, 250,
         0.1200, 21000, 0.0325, 0.0075, 20.00, 5.00, 1500.00, $1);
      `, [userId]);
    }

    // 2. Ensure designations and rates for this user
    const desCheck = await db.query(
      `SELECT COUNT(*) as count FROM designations WHERE owner_user_id = $1;`,
      [userId]
    );
    if (parseInt(desCheck.rows[0].count, 10) === 0) {
      const defaultDesignations = [
        { name: 'Unskilled', alias: 'USW', gross: 14408, special: 3314 },
        { name: 'Semi Skilled', alias: 'SEMI SW', gross: 15395, special: 3541 },
        { name: 'Skilled', alias: 'SW', gross: 16530, special: 3802 },
        { name: 'Highly Skilled', alias: 'HSW', gross: 17835, special: 4102 }
      ];

      for (const d of defaultDesignations) {
        const insDes = await db.query(
          `INSERT INTO designations (name, alias, owner_user_id) VALUES ($1, $2, $3) RETURNING id;`,
          [d.name, d.alias, userId]
        );
        const desId = insDes.rows[0].id;
        await db.query(
          `INSERT INTO designation_salary_rates 
           (designation_id, gross_salary_rate, special_allowance, thermal_allowance, perf_allowance_default, owner_user_id)
           VALUES ($1, $2, $3, 1500, 225, $4);`,
          [desId, d.gross, d.special, userId]
        );
      }
    }

    // 3. Ensure circles for this user
    const cirCheck = await db.query(
      `SELECT COUNT(*) as count FROM circles WHERE owner_user_id = $1;`,
      [userId]
    );
    if (parseInt(cirCheck.rows[0].count, 10) === 0) {
      await db.query(`INSERT INTO circles (name, code, owner_user_id) VALUES ('EMC Circle', 'EMC', $1);`, [userId]);
      await db.query(`INSERT INTO circles (name, code, owner_user_id) VALUES ('MM-1 Circle', 'MM-1', $1);`, [userId]);
    }

    // 4. Ensure default contractor for this user
    const conCheck = await db.query(
      `SELECT COUNT(*) as count FROM contractors WHERE owner_user_id = $1;`,
      [userId]
    );
    if (parseInt(conCheck.rows[0].count, 10) === 0) {
      await db.query(`INSERT INTO contractors (name, code, owner_user_id) VALUES ('M/s Sodhi Erectors', 'CON-01', $1);`, [userId]);
    }
  } catch (err) {
    console.error(`Error ensuring workspace for user ${userId}:`, err);
  }
}
