/**
 * GGSSTP Thermal Plant Payroll Portal - Root Production Entry Point
 * 
 * Provides seamless compatibility for Node.js hosting environments,
 * cPanel Node.js selector, PM2, Docker, Cloud Run, and process managers
 * that launch via `node index.js`, `node .`, or `npm start`.
 */

try {
  require('dotenv').config();
} catch {}

require('./dist/server.js');
