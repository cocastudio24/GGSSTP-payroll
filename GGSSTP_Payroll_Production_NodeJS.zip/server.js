/**
 * GGSSTP Thermal Plant Payroll Portal - Server Entry Point
 * 
 * Provides direct compatibility for hosting platforms that expect
 * a `server.js` startup file at the root (e.g. cPanel, Plesk, Render).
 */

try {
  require('dotenv').config();
} catch {}

require('./dist/server.js');
